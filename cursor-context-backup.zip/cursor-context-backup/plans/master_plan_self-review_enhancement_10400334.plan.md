---
name: Master Plan Self-Review Enhancement
overview: Comprehensive self-review, critique, and enhancement of the Venture Master Plan v1 -- fixing cost errors, deepening User Intelligence and Agent Restructure sections, adding missing operational concerns, creating the AI Model Registry doc, and cleaning up naming inconsistencies.
todos:
  - id: fix-costs
    content: "Fix Wyoming cost errors: annual report $52->$60, filing $103->$100. Update Section 0 and F7."
    status: completed
  - id: fix-api-naming
    content: Replace apis/filefree-api/ -> apis/filefree/, apis/launchfree-api/ -> apis/launchfree/, apis/studio-api/ -> apis/studio/ throughout plan.
    status: completed
  - id: deepen-user-intel
    content: "Expand Section 4 with: strategic WHY, event taxonomy, recommendation engine logic, data compounding vision, journey mapping, revenue connection."
    status: completed
  - id: deepen-agent-restructure
    content: "Expand Section 6 with: three-tier persona model from superseded plan, per-persona change specs, split specs, n8n dependency graph."
    status: completed
  - id: deepen-social
    content: "Expand Section 5 with: hook bank, 30-day content calendar, platform rules, model routing for content, faceless vs founder strategy."
    status: completed
  - id: create-model-registry
    content: Create docs/AI_MODEL_REGISTRY.md -- living doc for model costs, usage tracking, swap history. Update agent-ops.mdc to reference it.
    status: completed
  - id: add-interactive-model-guidance
    content: "Add Section 0E addendum: Opus for strategy/architecture sessions, Sonnet for routine coding. Not overkill."
    status: completed
  - id: add-operational-sections
    content: Add alerting strategy, phase timeline reality check, decide trinkets domain (tools.filefree.ai).
    status: completed
  - id: update-social-mdc
    content: Add scope note to social.mdc flagging it as FileFree-specific pending Phase 6 split.
    status: completed
isProject: false
---

# Master Plan Self-Review Enhancement

## 1. Fix Cost Errors (Section 0, F7)

The Wyoming LLC costs are wrong in two places:

- **Line 63 area**: "Annual report: $52/yr" should be **$60/yr** (Wyoming SOS confirmed)
- **Line 63 area**: "$103" filing fee should be **$100** (Wyoming SOS 2026 fee schedule)
- Recalculate total year 1 to **~$195-210** (was ~$200, close enough but line items wrong)

These appear in Section 0 (Venture Overview) and F7 (RA Legal).

## 2. Fix API Folder Naming Throughout

Replace all instances of:

- `apis/filefree-api/` -> `apis/filefree/`
- `apis/launchfree-api/` -> `apis/launchfree/`
- `apis/studio-api/` -> `apis/studio/`

Affects: Section 2 (Architecture), Phase 1 tasks (P1.6, P1.8), Phase 6 persona globs, compose.dev.yaml references, render.yaml references.

## 3. Deepen Section 4: User Intelligence Platform

Current state: data model + 5 segments + consent + campaigns + email sequences (~55 lines). 

Add:

- **3A. The Strategic WHY**: This is the Credit Karma playbook. Filing taxes / forming LLCs generates financial profile data that makes every subsequent recommendation more valuable. User intelligence is why the venture is worth 8-12x revenue (data asset) vs 3-5x (pure SaaS). The platform IS the data.
- **3B. Event Taxonomy** (specific, exhaustive):

```
Acquisition Events: signup, signup_source, referral_click
FileFree Events: w2_uploaded, w2_ocr_completed, filing_started, filing_completed, 
                 refund_amount_calculated, pdf_downloaded, efile_submitted, 
                 efile_accepted, partner_cta_viewed, partner_cta_clicked, 
                 tax_opt_plan_purchased
LaunchFree Events: state_selected, name_search_started, name_available,
                   formation_started, formation_completed, ra_purchased,
                   compliance_calendar_viewed, banking_cta_clicked, 
                   payroll_cta_clicked
Trinkets Events: tool_used, tool_result_viewed, cross_sell_cta_clicked
Cross-Product: cross_product_opt_in, cross_product_opt_out, 
               email_opened, email_clicked, email_unsubscribed
```

- **3C. Recommendation Engine Logic**: Rules-based engine with segment + milestone + timing triggers:

```
IF segment = "filed_taxes_no_llc" 
   AND income > 50000 
   AND has_1099_income = true
   AND days_since_filing > 14
   AND cross_product_opted_in = true
THEN recommend: "LaunchFree LLC formation"
     channel: email
     template: "biz_income_llc_nudge"
     delay: 72h after filing completion
```

- **3D. Data Compounding Vision**: Year 1 = rules-based segments (5 initial, grow to 15-20). Year 2 = enough data for basic ML (predict who will convert before they act). Year 3 = predictive (proactive recommendations: "Based on your tax profile, you could save $X by forming an LLC before year-end").
- **3E. Journey Mapping**: Common user paths with conversion funnels:

```
Path A: FileFree -> LaunchFree (biz income detection)
Path B: LaunchFree -> FileFree (tax season cross-sell)
Path C: Trinkets -> FileFree (financial calculator -> tax filing CTA)
Path D: FileFree -> HYSA partner (refund routing)
```

- **3F. Revenue Connection**: How each intelligence event connects to the 77% of revenue from referrals. Map: user profile data point -> eligible partner product -> estimated conversion rate -> estimated revenue per conversion.

## 4. Deepen Section 6: Agent Restructure

Current state: agent table + three-layer diagram (~60 lines).

Integrate the detailed content from `revenue_social_agents_review` (lines 269-363):

- **6A. The Problem Statement**: All 12 personas are FileFree-specific. social.mdc references @filefree handles, brand.mdc references filefree.tax, growth.mdc references TurboTax competition. Need to be product-aware.
- **6B. Three-Tier Persona Model** (with full table from the superseded plan):
  - Tier 1: 9 venture-level personas (engineering, ux, strategy, legal, cfo, qa, partnerships, workflows, agent-ops) -- specific changes needed per persona
  - Tier 2: 10 product-level personas with glob patterns (tax-domain, cpa, filefree-social, filefree-growth, filefree-brand, formation-domain, launchfree-social, launchfree-growth, launchfree-brand, studio)
  - Tier 3: 18 n8n workflows with dependency graph
- **6C. Persona Change Specs**: For each of the 9 venture-level personas, document the specific line changes needed (e.g., engineering.mdc adds monorepo conventions, legal.mdc adds UPL compliance for formation, partnerships.mdc adds banking/payroll/RA partners).
- **6D. Persona Split Specs**: How social.mdc becomes filefree-social.mdc + launchfree-social.mdc (different handles, different content themes, different hooks, different compliance requirements). Same for brand and growth.
- **6E. n8n Workflow Dependency Graph**: Which workflows feed into others (e.g., Knowledge Base Sync feeds L1 Support Bot, Analytics Reporter feeds Weekly Strategy Check-in).

## 5. Deepen Section 5: Social Pipeline

Current state: n8n pipeline diagram + cost + content themes + validation strategy (~30 lines).

Add from `revenue_social_agents_review` and `brand_identity_and_social_strategy`:

- **5A. Hook Bank**: Tax/finance hooks (pain, curiosity, transformation) for FileFree + LaunchFree formation hooks. From the superseded plan, lines 226-249.
- **5B. 30-Day Pre-Launch Content Calendar**: Week-by-week breakdown from `brand_identity_and_social_strategy` lines 94-127.
- **5C. Platform-Specific Production Rules**: First 1.5s = everything, bold text overlay (60% silent views), change visuals every 2-3s, one CTA per video.
- **5D. Model Routing for Content**: Reference Section 0E -- GPT-4o for scripts (brand voice), DALL-E 3 for images, ElevenLabs for voiceover. Not Gemini or Claude.
- **5E. Faceless vs Founder Strategy**: Daily automated faceless (n8n pipeline) + weekly founder face (10 min). Total ~30 min/week.

## 6. Create `docs/AI_MODEL_REGISTRY.md`

Standalone living document owned by agent-ops persona. Contains:

- Current model assignments table (mirror of Section 0E but with actuals)
- Monthly cost tracking table (Month | Model | API Calls | Tokens Used | Actual Cost | Budget | Delta)
- Swap history log (Date | Old Model | New Model | Workflows Affected | Reason | Cost Impact)
- Model evaluation queue (new models to assess)
- Links: OpenAI usage dashboard, Anthropic console, Google Cloud billing

Update `agent-ops.mdc` to reference this doc instead of only Section 0E.

## 7. Add Section 0E Addendum: Interactive Session Model Guidance

Add a note to Section 0E clarifying:

- The routing strategy covers **automated workflows** (n8n, batch operations)
- For **interactive Cursor sessions**: Opus for strategy/architecture/deep reasoning, Sonnet for routine coding/component building
- This is not overkill -- strategy sessions are high-stakes decisions where the quality delta justifies the cost

## 8. Add Missing Operational Sections

- **Section 7B: Alerting Strategy**: Infra Health Monitor alerts via email (primary) + Discord webhook (secondary). Critical: Render/Vercel down. Warning: response time > 2s. Info: deploy completed.
- **Section 7C: Phase Timeline Reality Check**: Acknowledge the 14-week plan is ambitious for one founder. Add buffer weeks. Note that Phases 4-6 can run partially in parallel.
- **Section 10 additions**: Decide Trinkets domain (recommend `tools.filefree.ai` subdomain -- no purchase needed, easy DNS, clear brand connection).

## 9. Update `social.mdc` Scope Note

Add a note to current `social.mdc` that it will be split in Phase 6 into `filefree-social.mdc` + `launchfree-social.mdc`. Flag it as "FileFree-specific, pending venture-wide split."