---
name: Distill Brand + Round 4
overview: Renames "FileFree Pro" to "Distill" (distill.tax) as a separate B2B brand under Paperwork Labs, adds a bootstrapped B2B GTM playbook, and executes all pending Deep Self-Review Round 4 findings — architectural splits, security specs, timeline fixes, and plan file cleanup.
todos:
  - id: rename-b2b-brand
    content: Rename all 'FileFree Pro' / 'filefree-pro' / 'pro.filefree' references to 'Distill' / 'distill' / 'distill.tax' across VENTURE_MASTER_PLAN.md (21), KNOWLEDGE.md (8), FINANCIALS.md (2), FOUNDER_SIDE_PROJECTS.md (4). Update brand architecture in Section 0, monorepo in Section 2, Section 1C title/content, Phase 9 title, PATH F, Channel 4, competitor table.
    status: completed
  - id: fix-h1-package-split
    content: Split packages/data/ into packages/data/, packages/tax-engine/, packages/document-processing/ in Section 2 monorepo structure. Update Phase task references.
    status: completed
  - id: fix-h2-multi-tenant
    content: Add multi-tenant data isolation spec (RLS, firm-scoped middleware) to Section 1C (Distill section). Add P9.9 security audit task.
    status: completed
  - id: fix-h3-dpa
    content: Add DPA requirement to Section 1C (Distill section). Add P9.10 DPA template task.
    status: completed
  - id: add-distill-product-features
    content: "Add to Section 1C: audit trail logging spec (7yr retention, immutable log, CSV export), brand separation note (Distill vs FileFree), two product lines clarification (Distill for CPAs + Distill API)."
    status: completed
  - id: fix-m1-phase9-timing
    content: Adjust Phase 9 timeline from 'Dec 2026 - Jan 2027' to 'Jan - Mar 2027' in Phase 9 section and Phase Timeline table.
    status: completed
  - id: fix-m3-vercel-cost
    content: Add Vercel Pro ($20/mo) to FINANCIALS.md at-scale variable costs. Update app names (distill replaces filefree-pro).
    status: completed
  - id: fix-m5-user-split
    content: Split Section 5L acquisition model into 'Direct Users' vs 'API Filing Volume' (Distill API) with valuation multiple note.
    status: completed
  - id: fix-m6-partnerships-b2b
    content: Add Section 3.5 to PARTNERSHIPS.md for Distill CPA sales motion with ownership clarification (Founder 1 owns CPA outreach).
    status: completed
  - id: add-b2b-gtm-playbook
    content: Add Section 5M 'Distill B2B Go-to-Market (Bootstrapped Playbook)' to VENTURE_MASTER_PLAN.md — pre-launch engineering-as-marketing, tax season launch, post-season growth, revenue milestones.
    status: completed
  - id: fix-low-findings
    content: Fix L1 (B2B SLA note for Distill), L2 (competitive moat point 6 — Distill referral flywheel), L3 (P1.9c scaffold apps/distill/), L4 (annual billing discount note).
    status: completed
  - id: add-taxwire-competitor
    content: Add TaxWire to competitor table in Section 4O (sales tax compliance, different market, Year 3+ partnership opportunity).
    status: completed
  - id: add-knowledge-decisions
    content: "Add D70 (Package Split Architecture) and D71 (Distill: Separate B2B Brand decision with rationale) to KNOWLEDGE.md."
    status: completed
  - id: update-self-review-table
    content: Add Review Round 4 + Round 5 (Distill rename) findings table to Section 9 of VENTURE_MASTER_PLAN.md.
    status: completed
  - id: update-side-projects
    content: Update FOUNDER_SIDE_PROJECTS.md Section 9 to reference 'Distill' instead of 'FileFree Pro'.
    status: completed
  - id: close-archived-plans
    content: Mark 9 superseded plan files as archived in their frontmatter.
    status: completed
isProject: false
---

# Distill Brand Launch + Deep Self-Review Round 4 Execution

Combines two workstreams: (A) renaming "FileFree Pro" to **Distill** (distill.tax) as a separate B2B brand and adding a bootstrapped B2B GTM strategy, and (B) executing all 12 pending findings from the Deep Self-Review Round 4.

---

## Part 1: B2B Brand Rename — "FileFree Pro" to "Distill"

### Why

Research-backed decision ([prior conversation analysis](2793f9cb-462d-4302-bf01-9e2dab047db9)):

- "Free" literally in the brand name creates cognitive dissonance for B2B buyers paying $199/mo
- Tax industry standard is separate brands (Intuit: TurboTax vs ProConnect/Lacerte)
- SBI Growth research: "free" in B2B contexts signals low quality, experimental
- "Distill" = extract pure essence from raw material — perfect metaphor for OCR-to-structured-data
- Fits naturally under Paperwork Labs (distilling paperwork)

### Brand Architecture After Rename

```mermaid
graph TD
    PL["Paperwork Labs (Venture Parent)"]
    
    subgraph consumer ["Consumer Brands"]
        FF["FileFree\nfilefree.ai\nFree tax filing"]
        LF["LaunchFree\nlaunchfree.ai\nFree LLC formation"]
        TR["Trinkets\ntools.filefree.ai\nUtility tools"]
    end
    
    subgraph b2b ["B2B Brand"]
        DCPA["Distill for CPAs\ndistill.tax\nSaaS $49-199/mo"]
        DAPI["Distill API\napi.distill.tax\nTax-as-a-Service"]
    end
    
    PL --> consumer
    PL --> b2b
```



### Files to Update (35 references total)

- [docs/VENTURE_MASTER_PLAN.md](docs/VENTURE_MASTER_PLAN.md) — 21 occurrences of "FileFree Pro" / "filefree-pro" / "pro.filefree"
- [docs/KNOWLEDGE.md](docs/KNOWLEDGE.md) — 8 occurrences
- [docs/FINANCIALS.md](docs/FINANCIALS.md) — 2 occurrences
- [docs/FOUNDER_SIDE_PROJECTS.md](docs/FOUNDER_SIDE_PROJECTS.md) — 4 occurrences

### Key Rename Mappings

- `FileFree Pro` -> `Distill`
- `pro.filefree.ai` -> `distill.tax`
- `apps/filefree-pro/` -> `apps/distill/`
- `@venture/filefree-pro` -> `@venture/distill`
- `[data-theme="filefree"]` on Pro -> `[data-theme="distill"]`
- Phase 9 title: "FileFree Pro -- B2B CPA Product" -> "Distill -- B2B Tax Automation Platform"
- Section 1C title: "FileFree Pro -- B2B Tax Automation for CPAs" -> "Distill -- B2B Tax Automation Platform (distill.tax)"
- PATH F: "FileFree Pro CPA -> Consumer FileFree" -> "Distill CPA -> Consumer FileFree"
- Channel 4: "B2B CPA Outreach (FileFree Pro)" -> "B2B CPA Outreach (Distill)"

### Additional Section 1C Updates (with rename)

- Clarify: "Distill is a separate brand from FileFree. Consumer FileFree = free, ad-free, trust-first. Distill = professional-grade paid SaaS. They share `packages/tax-engine/` and `packages/document-processing/` but have separate domains, landing pages, and marketing."
- Clarify: "Distill has two product lines: **Distill for CPAs** (SaaS dashboard at distill.tax) and **Distill API** (headless tax-as-a-service for platforms at api.distill.tax). Both share the same packages. CPA SaaS launches Phase 9. API launches Year 2."
- Add: **Audit trail logging** — "Every extraction, edit, export, and submission timestamped with user ID and firm ID. Immutable audit log retained for 7 years (IRS record retention requirement). Exportable as CSV for CPA firm compliance needs."

---

## Part 2: Bootstrapped B2B GTM Playbook (New Section)

Add to [docs/VENTURE_MASTER_PLAN.md](docs/VENTURE_MASTER_PLAN.md) as **Section 5M: Distill B2B Go-to-Market (Bootstrapped Playbook)**.

### Content Summary

**Pre-Launch (Now - Dec 2026, $0 spend):**

- Engineering-as-marketing: Build 3 free CPA-targeted Trinkets (W-2 OCR Tester, Filing Deadline Tracker, Tax Bracket Calculator Pro) that rank for SEO and demonstrate tech quality
- LinkedIn content engine: Founder posts 2-3x/week on CPA pain points, AI in tax prep
- Waitlist at distill.tax: Collect firm size + current tax software for export format prioritization

**Tax Season Launch (Jan-Apr 2027, $0-200/mo):**

- Free tier: 10 returns/month, no credit card. Trojan horse for tax season trial.
- Founder-led sales: 50-100 CPA outreach via LinkedIn DMs, r/taxpros, state CPA directories
- Product Hunt launch: "AI Tax Extraction for CPAs" — time for early January
- Viral loop: Exported returns include "Extracted by Distill" metadata watermark

**Post-Season Growth (May 2027+, revenue-funded):**

- Content SEO: 2-4 articles/month targeting "best AI tax prep for CPAs", "[competitor] vs Distill"
- CPA community: Sponsor local CPA society meetups ($100-300/event), guest articles in Accounting Today
- Referral program: "Refer a CPA firm, both get one month free"
- API self-serve: Developer docs, GitHub SDKs, dev.to/HackerNews posts

**Revenue milestones (no funding required):**

- 10 firms by Feb 2027 = $500-2K MRR (founder-led sales)
- 50 firms by Apr 2027 = $2.5K-10K MRR (Product Hunt + content)
- 200 firms by Jan 2028 = $10K-40K MRR (Season 2 returning firms + SEO)

---

## Part 3: Deep Self-Review Round 4 Fixes (Existing)

All findings from the existing [deep_self-review_round_4](deep_self-review_round_4_1e841559.plan.md) plan, updated with Distill branding:

### HIGH Severity

**H1**: Split `packages/data/` into `packages/data/`, `packages/tax-engine/`, `packages/document-processing/` in Section 2 monorepo structure. Update all Phase task references. Add D70 to KNOWLEDGE.md.

**H2**: Add multi-tenant data isolation spec to Section 1C (now "Distill" section): RLS on PostgreSQL, `firm_id` injection from auth token, P9.9 security audit task.

**H3**: Add DPA requirement to Section 1C: CPA firms sign DPA covering data processing scope, 24hr image retention, no cross-product data usage. Add P9.10 DPA template task.

### MEDIUM Severity

**M1**: Adjust Phase 9 timeline from "Dec 2026 - Jan 2027" to "Jan - Mar 2027".

**M2**: ~~Clarify Pro vs API distinction~~ -> Now handled by Distill brand architecture (CPA SaaS vs API are two product lines under one B2B brand).

**M3**: Add Vercel Pro ($20/mo) to FINANCIALS.md variable costs (5 apps: filefree, distill, launchfree, studio, trinkets).

**M5**: Split Section 5L acquisition model into "Direct Users" vs "API Filing Volume" with valuation multiple note.

**M6**: Add Section 3.5 to PARTNERSHIPS.md for Distill CPA sales motion (now Founder 1 owns CPA outreach since product-led, Founder 2 focuses consumer partnerships).

### LOW Severity

**L1**: Add B2B SLA note (99.5% during tax season) to Section 2B.2.

**L2**: Add competitive moat point 6: "B2B distribution moat: CPA firms using Distill become referral channels for consumer FileFree."

**L3**: Add P1.9c to scaffold `apps/distill/` placeholder in Phase 1 monorepo.

**L4**: Add annual billing discount impact note to FINANCIALS.md.

---

## Part 4: Additional Updates

- Add **TaxWire** to competitor table: "Global sales tax compliance (Avalara competitor). Different market — indirect tax, not income tax. No overlap today. Year 3+ partnership/expansion opportunity for LaunchFree LLC sales tax compliance."
- Add **D71 — Distill: Separate B2B Brand for CPA SaaS + Tax API** to KNOWLEDGE.md with full rationale (cognitive dissonance, industry precedent, brand architecture).
- Update **Section 9** self-review table with Round 4 + Round 5 (Distill rename) findings.
- Update **FOUNDER_SIDE_PROJECTS.md** Section 9 to reference "Distill" instead of "FileFree Pro".
- Archive 9 superseded plan files (add `status: archived` to frontmatter).

---

## Execution Order

1. Rename all "FileFree Pro" -> "Distill" across all docs (bulk find-replace, then verify context)
2. Execute H1 (package split) — structural change that other fixes reference
3. Execute H2 + H3 (multi-tenant + DPA) — security-critical for Distill
4. Execute M1-M6 (medium findings)
5. Add Section 5M (B2B GTM playbook)
6. Execute L1-L4 (low findings)
7. Add audit trail feature to Section 1C
8. Add TaxWire to competitor table
9. Add D70 + D71 to KNOWLEDGE.md
10. Update Section 9 self-review table
11. Archive 9 superseded plan files

