---
name: Admin UI Cleanup
overview: "Tidy Admin Dashboard/Coverage/Tracked pages: remove redundant panels, align quick actions, ensure data completeness."
todos:
  - id: dashboard-clean
    content: Clean Admin Dashboard spacing/remove Last Task Runs
    status: completed
  - id: coverage-polish
    content: Polish Coverage UI layout/actions
    status: completed
  - id: tracked-verify
    content: Verify/fix Tracked page data completeness
    status: completed
---

# Admin Dashboard/Coverage/Tracked Cleanup

## Goals
- Dashboard: remove redundant "Last Task Runs" block, ensure spacing/alignment stays clean; keep Quick Actions consistent.
- Coverage pages: polish layout for summary/quick actions/buckets; ensure actions list is clear and non-duplicative.
- Tracked page: verify it displays required data (tracked symbols, freshness, metadata) and fetches all necessary fields.

## Steps
1) Dashboard cleanup
- Remove the "Last Task Runs" section and adjust spacing after coverage card and quick actions.
- Verify Quick Actions rendering uses consistent buttons and spacing.

2) Coverage UI polish
- Review Coverage components (Summary card, actions list, buckets/kpis/trends) for alignment/spacing; tidy labels/ordering if needed without changing behavior.

3) Tracked page data check
- Ensure tracked page query/data includes needed fields (symbols, sectors/industry/ATR/stage etc. per existing schema) and renders without missing data; fix any gaps or undefined displays.

## Files to touch (likely)
- `frontend/src/pages/AdminDashboard.tsx`
- `frontend/src/utils/coverage.ts`
- Coverage components: `frontend/src/components/coverage/*`
- Tracked page: `frontend/src/pages/AdminTracked.tsx` (and related utils/components)

## Notes
- Keep coverage quick actions intact (bootstrap, schedule monitor, recompute, record history, backfill daily/5m if present); just keep them tidy and aligned.
- No backend changes expected unless a missing tracked-field fetch is found.