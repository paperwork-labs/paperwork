---
name: Revenue Social Agents Review
overview: Data-backed correction of the Year 1 revenue model (FileFree + LaunchFree), deep dive on audit shield economics, a faceless/AI-driven social media strategy that removes the founder as bottleneck, and a holistic restructure of all 30 agents/personas to work venture-wide.
todos:
  - id: revenue-model
    content: Update STRATEGY_REPORT.md and venture master plan with corrected revenue projections. Add audit shield economics section. Update ARPU assumptions for first-season vs at-scale.
    status: pending
  - id: audit-shield-pipeline
    content: Add TaxAudit/Protection Plus partnership to PARTNERSHIPS.md and Founder 2 pipeline. Add to TASKS.md as dependency for Task 3.6.
    status: pending
  - id: social-pipeline
    content: Redesign social.mdc into faceless autonomous pipeline. Create filefree-social.mdc and launchfree-social.mdc. Add ElevenLabs + CapCut to tool stack.
    status: pending
  - id: persona-restructure
    content: Update 7 existing venture-wide personas (engineering, strategy, cfo, legal, partnerships, qa, workflows). Split 3 personas into product-specific versions (social, brand, growth). Create 5 new personas (formation-domain, launchfree-social, launchfree-growth, launchfree-brand, studio).
    status: pending
  - id: n8n-content-pipeline
    content: "Design n8n faceless content pipeline workflow: trending topics -> GPT script -> ElevenLabs voiceover -> video assembly -> Postiz queue. Design for both FileFree and LaunchFree."
    status: pending
  - id: n8n-workflow-migrate
    content: "Update existing 6 n8n workflows: change output from Notion to Google Drive, split social/growth bots into per-product variants, expand strategy check-in to venture scope."
    status: pending
isProject: false
---

# Revenue, Social Media, and Agent Architecture: Venture Review

**Date**: March 11, 2026

---

## Part 1: Revenue Model Correction

### The Timeline Problem

The original plan conflates "Year 1" across two products with different launch dates:

- **LaunchFree**: Summer 2026 launch -> revenue in H2 2026
- **FileFree**: January 2027 launch -> revenue starts Jan 2027 (first tax season = Jan-Apr)

"Year 1" for FileFree is really **4 months of tax season** (Jan-Apr 2027), not a full 12 months. The $242K estimate assumed Scenario B ARPU ($8.05) applied evenly to 30K users -- but several revenue streams won't be ready on day one.

### What Blocks Day-1 Revenue


| Revenue Stream         | Dependency                                            | Likely Ready by Jan 2027?                                    |
| ---------------------- | ----------------------------------------------------- | ------------------------------------------------------------ |
| Refund routing to HYSA | Affiliate partnership (Marcus/Wealthfront via Impact) | Probably yes -- applied in 2026, 1-2 week approval           |
| Financial referrals    | Same affiliate networks                               | Probably yes                                                 |
| Audit Shield           | Partnership with TaxAudit/Protection Plus             | Maybe -- requires signed agreement, 3-6 months lead time     |
| Tax Optimization Plan  | Internal build (Stripe + premium dashboard)           | Yes -- we own this                                           |
| Refund advance         | Lending partner + Column Tax e-file live              | Unlikely -- lending partnerships take 6+ months to negotiate |


### Corrected Revenue: FileFree First Tax Season (Jan-Apr 2027)

**Three scenarios, with realistic first-season attach rates (lower than at-scale assumptions):**


| Stream                | First-Season Attach Rate | Revenue Per | 10K Filers | 20K Filers | 30K Filers |
| --------------------- | ------------------------ | ----------- | ---------- | ---------- | ---------- |
| Refund routing HYSA   | 4% (vs 8% at scale)      | $50         | $20K       | $40K       | $60K       |
| Financial referrals   | 1.5% (vs 3% at scale)    | $75         | $11K       | $22.5K     | $34K       |
| Audit Shield          | 5% (IF partner ready)    | $20         | $10K       | $20K       | $30K       |
| Tax Optimization Plan | 2% (vs 3% at scale)      | $29         | $5.8K      | $11.6K     | $17.4K     |
| Refund advance        | 0% (not ready)           | --          | $0         | $0         | $0         |
| **TOTAL**             |                          |             | **$47K**   | **$94K**   | **$141K**  |


**Without Audit Shield** (if TaxAudit partnership not closed in time):


| Scenario   | Revenue |
| ---------- | ------- |
| 10K filers | $37K    |
| 20K filers | $74K    |
| 30K filers | $111K   |


### Corrected Revenue: LaunchFree (H2 2026, ~6 months)


| Stream                                      | Volume            | Revenue Per | Total        |
| ------------------------------------------- | ----------------- | ----------- | ------------ |
| RA credits (3% of formations buy $49/yr RA) | 60-150 customers  | $49         | $3K-7.4K     |
| Banking referrals (5% of formations)        | 100-250 customers | $50         | $5K-12.5K    |
| Payroll referrals (1% of formations)        | 20-50 customers   | $100        | $2K-5K       |
| **TOTAL**                                   |                   |             | **$10K-25K** |


### Corrected Combined Revenue Summary


| Scenario     | LaunchFree (H2 2026) | FileFree (Jan-Apr 2027) | Combined "Year 1" |
| ------------ | -------------------- | ----------------------- | ----------------- |
| Conservative | $10K                 | $47K (10K filers)       | **$57K**          |
| Moderate     | $18K                 | $94K (20K filers)       | **$112K**         |
| Aggressive   | $25K                 | $141K (30K filers)      | **$166K**         |


**Previous estimate was $262K-292K. Corrected range: $57K-166K.** The delta comes from:

1. First-season attach rates are ~50% of at-scale rates (unoptimized UX, no A/B testing data)
2. Refund advance revenue = $0 (lending partner won't be ready)
3. Audit Shield may not be ready (need TaxAudit partnership)
4. 30K filers in the first season is the aggressive case, not the base case

### The Path to Real Revenue

Year 2 (2028) is where it gets interesting:

- 80% retention + new user growth = 40K-75K FileFree filers
- At-scale attach rates after a season of A/B testing
- Audit Shield + refund advance both live
- Cross-sell: LaunchFree users -> FileFree Schedule C
- LaunchFree hits 10K+ formations/year
- **Year 2 revenue: $300K-600K** (realistic at-scale ARPU kicks in)

---

## Part 2: Audit Shield Deep Dive

### What It Is

Audit Shield (also called "Audit Defense" or "Audit Protection") is a prepaid service that provides **professional IRS representation** if the customer gets audited. The customer gets:

- A dedicated Enrolled Agent or CPA handles ALL IRS communication
- Coverage for correspondence audits, office audits, and field audits
- Up to $1M in professional defense services (covers the EA/CPA cost, NOT taxes owed)
- Coverage lasts 3 years for federal, 4 years for state
- Tax identity theft support
- IRS notice resolution

**What it does NOT cover**: Additional taxes, penalties, or interest the IRS determines are owed. It covers the cost of someone fighting for you, not the bill itself.

### Industry Pricing


| Provider   | Product                             | Consumer Price |
| ---------- | ----------------------------------- | -------------- |
| FreeTaxUSA | Audit Defense (via TaxAudit)        | $19.99         |
| TaxAct     | Audit Defense (via Protection Plus) | $49.99         |
| TurboTax   | Audit Defense (via TaxAudit)        | $45-60         |
| H&R Block  | Peace of Mind                       | ~$50-70        |


### What It Costs Us

**White-label via Protection Plus / TaxAudit**: $10/return (firm-level program). This is the same provider FreeTaxUSA, TaxAct, and TurboTax use.

The economics are insurance-like:

- IRS audit rate for simple W-2 filers: ~0.2-0.5%
- Average defense cost when a claim IS filed: $250-1,125 (5-15 hrs of EA time)
- Expected cost per enrolled member: ~$1.50 (at 0.3% claim rate)
- TaxAudit keeps ~$8.50/member in margin on their $10 wholesale price

**FileFree's margin**: Sell at $19-24 (matching FreeTaxUSA as the low-cost leader), pay $10 wholesale = **$9-14 profit per sale, 47-58% gross margin**.

### Attachment Rate Expectations

- First season (unoptimized): 5-8% of filers
- At scale (after A/B testing, checkout page order bump): 10-15%
- Sweet spot placement: checkbox at checkout ("Add Audit Protection for $19.99"), not a separate screen

### Implementation Path

1. Contact TaxAudit / Protection Plus for white-label agreement ([prosales@taxact.com](mailto:prosales@taxact.com) or taxaudit.com/partners)
2. Integrate as a checkout add-on (checkbox on the summary/download page)
3. Upon purchase: create a TaxAudit enrollment via API, store enrollment ID
4. No ongoing operational cost -- TaxAudit handles ALL claims

**Timeline**: Partnership agreement takes 2-4 months. If started Q2 2026, should be ready by launch in January 2027.

**Action**: Add to Founder 2's partnership pipeline alongside HYSA affiliates.

---

## Part 3: AI-Driven Social Media Strategy (Founder Not a Bottleneck)

### The Research: What Actually Works

**Pieter Levels does NOT use AI avatars.** His strategy is personal brand + radical transparency + build-in-public on X (600K followers). His success comes from authenticity, not automation.

**AI avatars (HeyGen, Synthesia, D-ID)**: Available at $6-89/mo. BUT:

- Gen Z detects and distrusts AI talking heads
- Platform algorithms are increasingly deprioritizing AI-generated faces
- "Uncanny valley" kills trust -- the exact opposite of what a tax app needs

**What DOES work for faceless finance content**:

- Finance is the highest-earning faceless TikTok niche ($0.08-8 CPM)
- AI voiceover (ElevenLabs, $22/mo) + stock footage + bold text overlays
- Screen recordings of the product (the "reaction" format)
- Educational "did you know" content with stats on screen

### Recommended Strategy: Hybrid Faceless + Occasional Founder

**Daily (automated, no founder time):**

- Faceless educational content: AI script + ElevenLabs voice clone + stock footage/screen recordings + text overlays
- Produced by n8n pipeline, queued in Postiz
- Founder reviews queue once daily (~5 min)
- 1-2 posts/day across TikTok, IG Reels, YouTube Shorts, X

**Weekly (10 min founder time):**

- 1 quick founder-face video: "This week's tax tip" or "Building FileFree update"
- Recorded on phone, minimal editing
- This 1 video becomes trust anchor -- proves a real human is behind it

**Result: ~30 posts/week, <30 min/week founder time**

### The Autonomous Content Pipeline (n8n)

```
[8:00am] n8n cron fires
    |
    v
[Trend Research] n8n fetches trending finance/tax topics (GNews API + Reddit API)
    |
    v
[Script Generation] GPT-4o generates 3 scripts with hooks (using social.mdc prompt)
    |
    v
[Voice Generation] ElevenLabs API creates voiceover (cloned founder voice or brand voice)
    |
    v
[Visual Assembly] Template-based video: text overlays + stock B-roll (Pexels free) + voice
    - Option A: CapCut API (if available) or Remotion (React-based video)
    - Option B: Pre-made Canva templates with dynamic text
    |
    v
[Platform Optimization] Resize for TikTok/IG/YT/X, add captions, hashtags
    |
    v
[Queue in Postiz] n8n pushes to Postiz via REST API as "draft"
    |
    v
[5-min Human Review] Founder opens Postiz, approves/rejects/edits, schedules
    |
    v
[Publish + Track] Postiz publishes -> PostHog tracks UTMs -> n8n pulls analytics weekly
```

### Monthly Cost


| Tool                             | Monthly Cost  |
| -------------------------------- | ------------- |
| ElevenLabs (voice, Creator plan) | $22           |
| CapCut Pro (editing, optional)   | $10           |
| Stock footage (Pexels, free)     | $0            |
| GPT-4o API (scripts, ~200/mo)    | $15-30        |
| Postiz (already self-hosted)     | $0            |
| n8n (already self-hosted)        | $0            |
| **TOTAL**                        | **$47-62/mo** |


### Hook Bank (Tax/Finance Hooks That Stop the Scroll)

**Pain hooks** (highest engagement in finance):

1. "The IRS already knows about this. Do you?"
2. "If you made under $75K last year, stop scrolling."
3. "That $89 you paid TurboTax? You didn't have to."

**Curiosity hooks**:
4. "I filed my taxes in 4 minutes. Here's how."
5. "CPAs don't want you to know this about free filing."
6. "Your tax refund isn't a gift. It's money they held hostage."

**Transformation hooks**:
7. "I went from owing $2,000 to getting $1,400 back. One form."
8. "Filing taxes used to take 3 hours. Now it takes 3 minutes."

**Production rules**:

- First 1.5 seconds = everything (algorithms judge intro retention)
- Bold text overlay (5-8 words) -- 60%+ of views are silent
- Change visuals every 2-3 seconds to maintain completion rate
- One CTA per video, never more

### For LaunchFree (Business Formation Content)

Same pipeline, different hooks:

- "You can start an LLC for $0 in 10 states."
- "ZenBusiness charges $199. Here's what you actually need."
- "3 tax deductions you unlock the day you form an LLC."
- "Nobody tells you about the $800 California LLC fee."
- "Stop running your side hustle as a sole prop."

### Why NOT Full AI Avatars

- Gen Z detects synthetic faces -> trust drops
- Tax/finance content needs credibility -> uncanny valley kills it
- Platform detection improving -> potential shadowban risk
- Voice clone + text overlays outperforms avatar video in finance niches
- HeyGen/Synthesia add $29-89/mo for worse results

**Revisit AI avatars when quality improves (2027+)**. For now, faceless + voice is the sweet spot.

---

## Part 4: Venture-Wide Agent/Persona Restructure

### Current Problem

All 12 Cursor personas and 6 n8n workflows are **FileFree-specific**:

- `social.mdc` references @filefree handles, "Gen Z tax filing app"
- `brand.mdc` references filefree.tax domain, FileFree-specific colors
- `growth.mdc` references tax-specific SEO, TurboTax competition
- `partnerships.mdc` references HYSA referrals, tax partnerships only
- n8n workflows all output to "FileFree HQ" Notion databases

Now that we're a venture with LaunchFree, sankalpsharma.com, and shared infrastructure, **the agent architecture needs to be product-aware, not product-locked**.

### Restructured Agent Architecture

**Principle**: Agents are organized into three tiers:

1. **Venture-level** (shared across all products)
2. **Product-level** (specific to FileFree or LaunchFree)
3. **Operational** (n8n autonomous workflows)

### Tier 1: Venture-Level Personas (Root `.cursor/rules/`)

These apply to ALL products. They use `alwaysApply` or broad globs.


| Persona         | File               | Changes Needed                                                                         |
| --------------- | ------------------ | -------------------------------------------------------------------------------------- |
| Staff Engineer  | `engineering.mdc`  | Add monorepo conventions, pnpm workspace patterns, shared packages                     |
| UX/UI Lead      | `ux.mdc`           | Add shared design system reference (packages/ui)                                       |
| Chief of Staff  | `strategy.mdc`     | Expand from FileFree to full venture context                                           |
| General Counsel | `legal.mdc`        | Add LLC formation compliance (LaunchFree), RA legal requirements                       |
| CFO             | `cfo.mdc`          | Expand unit economics to both products, shared infra cost allocation                   |
| QA Lead         | `qa.mdc`           | Add formation data validation, cross-product security rules                            |
| Partnership Dev | `partnerships.mdc` | Add LaunchFree partnerships (banking, payroll, RA providers, formation state partners) |
| Git Workflow    | `git-workflow.mdc` | No changes needed (already generic)                                                    |
| Workflows       | `workflows.mdc`    | Add LaunchFree-specific workflow templates                                             |


### Tier 2: Product-Level Personas

**Restructured to use glob-based activation:**


| Persona                     | File                                              | Globs                                                                          | Purpose                                                   |
| --------------------------- | ------------------------------------------------- | ------------------------------------------------------------------------------ | --------------------------------------------------------- |
| Tax Domain Expert           | `tax-domain.mdc`                                  | `apps/filefree/`**, `apis/filefree-api/`**, `packages/data/**/tax-*`           | IRS rules, brackets, MeF                                  |
| CPA / Tax Advisor           | `cpa.mdc`                                         | `apps/filefree/**`                                                             | Tax advisory content quality                              |
| FileFree Social             | `filefree-social.mdc` (rename from `social.mdc`)  | `apps/filefree/**/social/**`                                                   | FileFree content strategy, handles, hooks                 |
| FileFree Growth             | `filefree-growth.mdc` (extract from `growth.mdc`) | `apps/filefree/**`                                                             | Tax-specific SEO, TurboTax positioning                    |
| FileFree Brand              | `filefree-brand.mdc` (extract from `brand.mdc`)   | `apps/filefree/**`                                                             | FileFree visual identity, voice                           |
| **Formation Domain Expert** | `formation-domain.mdc` (NEW)                      | `apps/launchfree/`**, `apis/launchfree-api/`**, `packages/data/**/formation-*` | State LLC rules, RA requirements, annual report deadlines |
| **LaunchFree Social**       | `launchfree-social.mdc` (NEW)                     | `apps/launchfree/**/social/`**                                                 | LaunchFree content strategy, handles, hooks               |
| **LaunchFree Growth**       | `launchfree-growth.mdc` (NEW)                     | `apps/launchfree/`**                                                           | Formation-specific SEO, LegalZoom positioning             |
| **LaunchFree Brand**        | `launchfree-brand.mdc` (NEW)                      | `apps/launchfree/`**                                                           | LaunchFree visual identity, voice                         |
| **Studio**                  | `studio.mdc` (NEW)                                | `apps/studio/`**                                                               | sankalpsharma.com portfolio/venture site                  |


### Tier 3: n8n Autonomous Workflows (Restructured)

**Existing (update output destinations from Notion to Google Drive):**


| #   | Workflow                     | Update Needed                                               |
| --- | ---------------------------- | ----------------------------------------------------------- |
| 1   | Social Content Generator     | Split into FileFree + LaunchFree variants; output to GDrive |
| 2   | Growth Content Writer        | Split into FileFree + LaunchFree variants; output to GDrive |
| 3   | Weekly Strategy Check-in     | Expand to cover both products; output to GDrive             |
| 4   | QA Security Scan             | Scan both APIs; output to GitHub Issues (keep as-is)        |
| 5   | Partnership Outreach Drafter | Add LaunchFree partners; output to GDrive                   |
| 6   | CPA Tax Review               | Keep FileFree-only; output to GDrive                        |


**New (from Workstream 3 + social pipeline):**


| #   | Workflow                               | Type              | Purpose                                               |
| --- | -------------------------------------- | ----------------- | ----------------------------------------------------- |
| 7   | Faceless Content Pipeline (FileFree)   | Cron (daily, 8am) | Script -> voiceover -> video assembly -> Postiz queue |
| 8   | Faceless Content Pipeline (LaunchFree) | Cron (daily, 8am) | Same pipeline, business formation topics              |
| 9   | L1 Support Bot                         | Webhook           | Answer from knowledge base                            |
| 10  | L2 Support Bot                         | Webhook           | Execute actions (check status, resend email)          |
| 11  | State Data Validator                   | Cron (monthly)    | Check 50 state websites for rule/fee changes          |
| 12  | IRS Update Monitor                     | Cron (October)    | Parse Revenue Procedure updates                       |
| 13  | Competitive Intel                      | Cron (weekly)     | Monitor LegalZoom/ZenBusiness/TurboTax                |
| 14  | Analytics Reporter                     | Cron (weekly)     | PostHog metrics -> GDrive weekly report               |
| 15  | Infra Health Monitor                   | Cron (hourly)     | Check Render/Vercel/Hetzner                           |
| 16  | Affiliate Revenue Tracker              | Cron (daily)      | Check affiliate dashboards                            |
| 17  | Formation Compliance Alerts            | Cron (monthly)    | Annual report deadline alerts for LaunchFree users    |
| 18  | Knowledge Base Sync                    | Cron (nightly)    | Sync GDrive docs to support bot context               |


**Total: 18 n8n workflows + 12 Cursor personas = 30 agents (unchanged count, but restructured)**

### What Changes in Existing Persona Files

**Files that need venture-wide expansion** (content changes, not structural):

1. `[engineering.mdc](.cursor/rules/engineering.mdc)`: Add monorepo structure, pnpm workspace conventions, shared packages, multi-app deploy patterns
2. `[strategy.mdc](.cursor/rules/strategy.mdc)`: Replace "FileFree" context with venture context, reference both products, updated revenue model
3. `[cfo.mdc](.cursor/rules/cfo.mdc)`: Add LaunchFree unit economics, combined burn rate, shared infra allocation
4. `[legal.mdc](.cursor/rules/legal.mdc)`: Add LLC formation compliance, RA legal framework, state-specific formation requirements
5. `[partnerships.mdc](.cursor/rules/partnerships.mdc)`: Add LaunchFree partnership targets (banking, payroll, RA providers), TaxAudit/Protection Plus as audit shield partner
6. `[qa.mdc](.cursor/rules/qa.mdc)`: Add formation data validation rules, cross-product test patterns
7. `[workflows.mdc](.cursor/rules/workflows.mdc)`: Add LaunchFree workflow templates, venture-level operating cadence

**Files that split into product-specific versions:**

1. `[social.mdc](.cursor/rules/social.mdc)` -> `filefree-social.mdc` + `launchfree-social.mdc` (NEW)
2. `[brand.mdc](.cursor/rules/brand.mdc)` -> venture-level `brand.mdc` (shared palette/typography) + `filefree-brand.mdc` + `launchfree-brand.mdc` (NEW)
3. `[growth.mdc](.cursor/rules/growth.mdc)` -> venture-level `growth.mdc` (shared SEO/analytics) + `filefree-growth.mdc` + `launchfree-growth.mdc` (NEW)

**Files that stay product-specific (no changes to scope, just update to new domain):**

1. `[tax-domain.mdc](.cursor/rules/tax-domain.mdc)`: Add appropriate globs, update domain to filefree.ai
2. `[cpa.mdc](.cursor/rules/cpa.mdc)`: Add appropriate globs

**New files to create:**

1. `formation-domain.mdc`: LaunchFree business domain expert (state LLC rules, RA requirements, annual reports)
2. `launchfree-social.mdc`: LaunchFree social media playbook
3. `launchfree-growth.mdc`: LaunchFree growth/SEO strategy
4. `launchfree-brand.mdc`: LaunchFree brand guide
5. `studio.mdc`: sankalpsharma.com context

### Social Media Persona Changes (Detail)

**Current `social.mdc` says:**

- "Founder-led, casual, phone-recorded. Overproduced = death on TikTok."
- "Video content still requires you to record"
- "45-60 min/day during tax season"

**Updated approach:**

- Faceless AI-voice educational content is the DEFAULT (daily, automated via n8n pipeline)
- Founder face appears 1-2x/week for trust anchoring (10 min/week total)
- n8n pipeline handles script -> voiceover -> assembly -> Postiz queue
- Founder's only daily task: 5-min Postiz queue review (approve/reject/edit)
- Total founder time: ~30 min/week (down from 45-60 min/DAY)

This is documented in the new `filefree-social.mdc` and `launchfree-social.mdc` with the full autonomous pipeline spec.

---

## Summary of Key Corrections


| Item                      | Previous                 | Corrected                                          |
| ------------------------- | ------------------------ | -------------------------------------------------- |
| FileFree Year 1 revenue   | $242K                    | $47K-141K (first tax season, 4 months)             |
| LaunchFree Year 1 revenue | $20K-50K                 | $10K-25K (6 months, ramp-up)                       |
| Combined Year 1           | $262K-292K               | $57K-166K                                          |
| Audit Shield cost to us   | Not specified            | $10/return via TaxAudit white-label                |
| Audit Shield revenue/sale | $19-29                   | $9-14 profit at $20 price point                    |
| Founder social media time | 45-60 min/day            | ~30 min/week (faceless pipeline)                   |
| Social content cost       | Not budgeted             | $47-62/mo                                          |
| Agent count               | 30 (all FileFree-scoped) | 30 (restructured: 9 venture + 10 product + 18 n8n) |
| Persona files to update   | 0                        | 7 existing + 5 new = 12 total changes              |


