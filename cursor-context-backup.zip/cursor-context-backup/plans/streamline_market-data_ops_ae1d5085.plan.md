---
name: Streamline market-data ops
overview: Make Admin Dashboard/Runbook much simpler by centering around tracked-universe daily coverage, exposing only 2–3 guided actions by default, and moving advanced knobs (index-only, batch sizes, 5m) into a collapsible section with clear naming and progress observability.
todos:
  - id: ui-guided-actions
    content: Replace Admin Dashboard quick actions with 3 guided buttons (Restore Daily Coverage, Backfill Stale Only, Refresh Coverage) + collapsed Advanced section.
    status: completed
  - id: runbook-simplify
    content: Simplify Admin Runbook to 2 runbooks focused on daily coverage and troubleshooting, with optional step details.
    status: completed
    dependencies:
      - ui-guided-actions
  - id: backend-orchestrator
    content: Add a Celery orchestrator task for tracked-universe daily coverage reset (no 5m), return structured counters for jobs.
    status: completed
  - id: docs-operator-runbook
    content: Update docs with an operator-focused section explaining which button to use and when, including batch size guidance.
    status: completed
    dependencies:
      - ui-guided-actions
      - backend-orchestrator
  - id: tests-streamlined-ops
    content: Add/adjust frontend and backend tests for the streamlined ops flows.
    status: completed
    dependencies:
      - ui-guided-actions
      - runbook-simplify
      - backend-orchestrator
---

# Streamline Market Data Runbooks + Actions

## What you hit (the “20 ticker throttle”)
- The UI action **“Backfill Index Universe (Daily)”** currently maps to `POST /api/v1/market-data/backfill/index-universe` with a default `batch_size=20`.
- That’s why it looked like a 20-ticker throttle.

## New mental model (simplified)
- **Coverage is about `tracked:all`** (the universe the platform actually monitors).
- Index-constituent bootstrap is a **secondary/advanced** tool.
- **5m is informational** when disabled (already implemented).

## Changes (frontend)

### Admin Dashboard (default: guided)
- Replace the current “Quick Actions” list with **3 primary buttons**:
  - **Restore Daily Coverage (Tracked Universe)**
    - Triggers: refresh constituents → update tracked → backfill daily (tracked universe) → recompute indicators → record history → refresh coverage.
  - **Backfill Daily (Stale Only)**
    - Triggers: `POST /api/v1/market-data/admin/coverage/backfill-stale-daily` → refresh coverage.
  - **Refresh Coverage Now**
    - Triggers: `POST /api/v1/market-data/admin/coverage/refresh`.
- Keep the **5m toggle**, but visually mark it as “Informational/Optional” and clarify that coverage ignores 5m when disabled.
- Show a compact **Status strip**:
  - `meta.source` (cache/db)
  - `meta.updated_at`
  - Last `monitor_coverage_health` run time from `/api/v1/market-data/admin/tasks/status`.

### Advanced (collapsed)
- A collapsible “Advanced” section that contains:
  - **Index-only backfill** (`/market-data/backfill/index-universe?batch_size=...`) with a batch size selector.
  - **Backfill last-200 (full tracked universe)** (`/market-data/backfill/last-200`).
  - **Recompute indicators** and **Record history** as separate buttons.

### Admin Runbook (simplify)
- Keep Runbook page, but reduce it to 2 runbooks:
  - **Restore Daily Coverage (Tracked)** (the main one)
  - **Troubleshoot** (Stale-only + Refresh coverage)
- Move the long “chain” view into a details drawer (“Show steps”).

## Changes (backend)
- Add a backend orchestrator task `bootstrap_daily_coverage_tracked` (new Celery task) that runs the full daily chain against tracked universe (no 5m).
  - Returns structured counters so Admin Jobs can show real progress.
- Keep existing tasks as building blocks.

## Docs
- Update `docs/MARKET_DATA.md` with a short “Operator Runbook” section:
  - What to click for daily coverage.
  - When to use stale-only.
  - When index-only matters.

## Testing
- Frontend tests (Vitest):
  - Admin Dashboard renders the 3 guided actions.
  - Clicking each calls the correct endpoints.
- Backend tests (pytest):
  - New orchestrator task can be enqueued and returns expected shape.

## Files likely to change
- Frontend: [`/Users/sankalpsharma/development/quantmatrix/frontend/src/pages/AdminDashboard.tsx`](/Users/sankalpsharma/development/quantmatrix/frontend/src/pages/AdminDashboard.tsx), [`/Users/sankalpsharma/development/quantmatrix/frontend/src/pages/AdminRunbook.tsx`](/Users/sankalpsharma/development/quantmatrix/frontend/src/pages/AdminRunbook.tsx)
- Backend: [`/Users/sankalpsharma/development/quantmatrix/backend/tasks/market_data_tasks.py`](/Users/sankalpsharma/development/quantmatrix/backend/tasks/market_data_tasks.py), [`/Users/sankalpsharma/development/quantmatrix/backend/api/routes/market_data.py`](/Users/sankalpsharma/development/quantmatrix/backend/api/routes/market_data.py)
- Docs: [`/Users/sankalpsharma/development/quantmatrix/docs/MARKET_DATA.md`](/Users/sankalpsharma/development/quantmatrix/docs/MARKET_DATA.md)