---
name: Fix Jobs Pagination + All Fetch
overview: Ensure jobs endpoint and UI honor "All" selection, show correct totals, and adjust batch backfill defaults clarity.
todos:
  - id: backend-jobs-all
    content: Honor all=true, no limit/offset
    status: completed
  - id: frontend-jobs-all
    content: Send all=true, show correct totals in UI
    status: completed
  - id: jobs-summary-fix
    content: Summary uses total, disable paging on All
    status: completed
---

# Fix Jobs Pagination + All Fetch

## Goals

- “Show per page: All” should fetch full job history (no 50 cap) and show correct totals.
- Pagination UI should display accurate totals and page info.
- Keep batch size bump (100) noted; verify no unintended limits.

## Steps

1) Backend jobs endpoint

- Update `/market-data/admin/jobs` to honor `all=true` by skipping limit/offset, returning full list and accurate `total`. Ensure `limit` not forced when `all` is set. File: [`backend/api/routes/market_data.py`](backend/api/routes/market_data.py).
- Reuse/adjust serializer to avoid `_serialize_jobs` leftovers. File: [`backend/api/routes/utils.py`](backend/api/routes/utils.py).

2) Frontend jobs page

- Ensure dropdown “All” sends `all=true` and does not compute offsets; coerce totals correctly. File: [`frontend/src/pages/AdminJobs.tsx`](frontend/src/pages/AdminJobs.tsx).
- Fix summary text to show real total (from API) and the actual count returned; avoid defaulting to 50 when All is chosen.
- Keep pagination buttons hidden/disabled when “All” is active.

3) Verify & polish UI labels

- Check any headers/summary blocks that show totals (e.g., “Total Runs”) so they use the API `total` not the current page length. File: [`frontend/src/pages/AdminJobs.tsx`](frontend/src/pages/AdminJobs.tsx).

4) Quick test

- Manual fetch with `all=true` to confirm backend returns >50 items; reload UI with “All” to confirm full list and correct totals.