---
name: Intelligence Data Moat PR Fixes
overview: "Consolidated execution: (1) expand Section 4 with experimentation, data intelligence, early credit score, and data moat subsections, (2) add PII lifecycle, autonomous engineering, workspace/agent/self-review updates, (3) address all 21 Copilot PR review comments, (4) sync docs and commit."
todos:
  - id: expand-section4
    content: Add 4K (Experimentation Platform), 4L (Data Intelligence & Analytics), 4M (Early Credit Score Moat) to master plan Section 4. Rename cross-sell -> intelligence in architecture. Update Phase 5 tasks.
    status: completed
  - id: pii-and-eng
    content: "Add Section 0I (PII Data Lifecycle), Section 6K (Autonomous Engineering Protocol). Add Partnership Intelligence agent #34 to org chart."
    status: completed
  - id: workspace-agents-review
    content: Simplify workspace scoping, confirm agent alwaysApply, collapse Section 9 self-review to summary table only.
    status: completed
  - id: pr-comments
    content: "Fix all 21 Copilot PR comments: ea.mdc (Discord->Slack, globs, docs URL), agent-ops.mdc (globs), master plan (Legal Risk Matrix, ports, header), KNOWLEDGE.md (D36 superseded), FINANCIALS.md (Workspace cost, annual double-count), TASKS.md (LLC status, domain refs, budget), social.mdc (filefree.ai note)."
    status: completed
  - id: sync-commit
    content: Sync VENTURE_MASTER_PLAN.md from cursor plan file, add KNOWLEDGE.md decisions D58-D61, commit and push to docs/master-plan-enhancements-v2 branch.
    status: completed
isProject: false
---

# Master Plan: Data Intelligence, PII, and PR Comment Fixes

Three streams of work, all applied to [docs/VENTURE_MASTER_PLAN.md](docs/VENTURE_MASTER_PLAN.md) and related files on the `docs/master-plan-enhancements-v2` branch.

---

## Stream 1: Intelligence Engine Expansion (Section 4)

Section 4 "User Intelligence Platform" already has data model, events, segments, recommendation engine, campaigns, and journeys. We ADD three new subsections and revise phasing.

### 1A. Add Section 4K: Experimentation Platform (Our "Darwin")

Insert after 4J. Three-phase approach:

- **Phase 1 (Launch)**: PostHog feature flags + simple A/B (already in stack, free tier 1M events/mo). Test recommendation placement, partner ordering, CTA copy. Track CTR, conversion, revenue/impression.
- **Phase 2 (10K+ users)**: Thompson Sampling multi-armed bandit for partner ranking (~200 lines Python, `scipy.stats.beta`). Auto-allocates traffic to higher-converting partners.
- **Phase 3 (50K+ users)**: ML collaborative filtering on user-partner interaction data. Serve via FastAPI.
- **FTC compliance constraint**: Experiments NEVER test "pre-approved" / "guaranteed" / "you qualify" language. Only "may qualify" / "based on your profile." Baked into framework rules.

### 1B. Add Section 4L: Data Intelligence & Analytics (broadened from "Retention Intelligence")

This is the user's key insight: design data models from the start so ANY post-production analysis is possible. Not just churn -- company KPIs, cohort analysis, funnel metrics, LTV, partner performance, campaign effectiveness.

**Company KPIs (tracked from day one via PostHog + event taxonomy):**

- Activation rate: signups -> first completed action (filed taxes / formed LLC)
- Conversion funnel: signup -> start -> complete -> partner engagement
- Monthly active users, DAU/MAU ratio
- Revenue per user (RPU), Lifetime value (LTV)
- Partner conversion rate per product, per segment
- Churn rate (30-day, 90-day, seasonal)
- Net Promoter Score (quarterly survey)

**Churn prediction signals:**

- Days since last login, repeat vs one-time filer, recommendation engagement, email opt-out, credit score change

**Lifecycle campaigns (n8n + `packages/email`):**

- 7 trigger-based campaigns (from plan: post-filing refund, mid-year check-in, post-formation banking, credit score change, tax season return, annual report deadline, 90-day dormant)

**Churn model (Phase 2+):** ChurnGuard AI (open-source, PostHog + Stripe) for MVP. Features: login frequency, engagement, email opens, conversions. Risk score per user.

**Push notifications (Phase 2+):** Web push via service worker (no app store). Opt-in, max 2/week, high-value triggers only.

**Data as moat:** Every interaction adds data points. Year 2 users have income trajectory + credit score delta + behavioral history. Compounds and cannot be replicated by competitors who only see one-time transactions.

### 1C. Revise Phase Timeline: Credit Score at Phase 1.5

Move credit score from Phase 2 to Phase 1.5 (Launch + 3 months). Update Section 4 phased approach.

**Why**: Tax return data + credit score = the richest financial profile in fintech. CK's moat was 2,500 data points/user. FileFree already knows exact income (W-2 Box 1), filing status, dependents, refund amount, state, employer. Add credit score and we have approval odds for any financial product. Partners will pay premium referral fees for pre-qualified customers.

Add subsection "4M. Why Early Credit Score Is the Moat (Not Just a Feature)" with the data advantage argument and credit score integration research (soft pull via TransUnion reseller Array/SavvyMoney, Plaid LendScore alternative, FCRA compliance ~$500-1K legal review).

### 1D. Update packages/intelligence structure

In Section 2 architecture, rename `packages/cross-sell/` to `packages/intelligence/`. Expanded module list:

- Profile builder (financial profile from FileFree + LaunchFree + credit score)
- Partner matcher (rules -> bandit -> ML progression)
- Experimentation (PostHog feature flags, A/B tracking, bandit allocation)
- Data intelligence (KPI computation, churn signals, cohort analysis, funnel metrics)
- Campaign triggers (milestone-based lifecycle campaigns)

### 1E. Update Phase 5 tasks

In Section 7, Phase 5 references `P5.3 packages/cross-sell engine` -- rename to `packages/intelligence engine` and add experimentation + data intelligence tasks.

### 1F. Add Partnership Intelligence Agent

Add agent #34 to Section 6E (New Agents). n8n weekly cron. Scans affiliate networks, compares commission rates, monitors performance, generates weekly report to Slack `#partnerships`, generates compatibility scores. Update org chart in 6I to add under VP Partnerships.

---

## Stream 2: PII Plan Items (from [pii_partners_intelligence_eng plan](pii_partners_intelligence_eng_b2fac409.plan.md))

### 2A. Add Section 0I: PII Data Lifecycle

After Section 0H. CCPA/CPRA focus (not GDPR). Data inventory, retention policy (W-2 images 24hrs, tax data 7 years, LLC data indefinite, accounts until deletion), deletion rights, consent architecture, ADMT disclosure, risk assessments.

### 2B. Add Section 6K: Autonomous Engineering Protocol

Background agents write code, create PRs. Human reviews and merges. Task table (state tax JSONs, formation JSONs, UI components, test suites, MeF schemas, API scaffolding). All use Claude Sonnet. Pattern: human writes first implementation, agent replicates for remaining.

### 2C. Simplify Workspace Scoping (Section 2)

Update "Cursor Workspace Scoping" to clarify root workspace is the default. Focused workspaces are optional for deep-focus sessions.

### 2D. Agent Availability

Confirm venture-level personas use `alwaysApply: true`. n8n agents already available everywhere via Slack.

### 2E. Collapse Section 9 Self-Review

Keep the F1-F12 summary table. Remove detailed research under each finding (already implemented, per anti-bloat rules).

---

## Stream 3: PR Comment Fixes (21 Copilot comments)

### Files to fix:

**[.cursor/rules/ea.mdc](.cursor/rules/ea.mdc)** (6 comments):

- Fix `globs:` null -> `globs: []`
- Replace ALL Discord references with Slack (lines 26, 104, 134-135): `Discord #ops-alerts` -> `Slack #ops-alerts`, `Discord slash command` -> `Slack slash command /ea`
- Update `sankalpsharma.com/docs/`* -> `paperworklabs.com/docs/`* (line 67)

**[.cursor/rules/agent-ops.mdc](.cursor/rules/agent-ops.mdc)** (1 comment):

- Fix `globs:` null -> `globs: []`

**[docs/VENTURE_MASTER_PLAN.md](docs/VENTURE_MASTER_PLAN.md)** (4 comments):

- Fix Legal Risk Matrix table (line 215): close the quoted string in row 4 remediation, add closing `|`
- Fix Port assignments in Phase 1 tasks (line 2401-2404): P1.9 studio should be 3004 and P1.9b trinkets should be 3003, matching the Port Map at line 937-948 (trinkets=3003, studio=3004)
- Fix source-of-truth header (line 1): update to state this file IS the source of truth (the .cursor/plans/ file is not in the repo)

**[docs/KNOWLEDGE.md](docs/KNOWLEDGE.md)** (2 comments):

- Mark D36 as superseded: "SUPERSEDED by D54 (Paperwork Labs LLC, California). Originally decided Wyoming LLC."

**[docs/FINANCIALS.md](docs/FINANCIALS.md)** (2 comments):

- Fix Google Workspace actuals: $6 was month 1 (1 seat); update note to clarify recurring is $12/mo (2 seats, Olga added later in March)
- Fix annual fixed costs double-counting: remove `+ $800/yr franchise tax` since it's already amortized in the $284/mo figure

**[docs/TASKS.md](docs/TASKS.md)** (4 comments):

- Update "Decide LLC name" status from NOT STARTED to DONE (Paperwork Labs LLC)
- Update P0.7 `ops/social.sankalpsharma.com` -> `ops/social.paperworklabs.com`
- Update Phase 4 Studio/docs references from `sankalpsharma.com` to `paperworklabs.com`
- Standardize TikTok Spark Ads budget to `$100-300/mo` (matching master plan)

**[.cursor/rules/social.mdc](.cursor/rules/social.mdc)** (1 comment):

- Update `filefree.tax` references to note `filefree.ai` migration (scope note already exists at line 8, but the body still says `filefree.tax` in CTAs -- add note about Phase 0 migration)

---

## Execution Order

1. Edit the Cursor plan file (venture_master_plan_v1) with all Section 4 additions, Section 0I, 6K, workspace/agent/self-review changes, and PR comment fixes to master plan
2. Fix ea.mdc, agent-ops.mdc, social.mdc
3. Fix KNOWLEDGE.md, FINANCIALS.md, TASKS.md
4. Sync VENTURE_MASTER_PLAN.md from the Cursor plan file
5. Log new decisions in KNOWLEDGE.md (D58-D61)
6. Commit and push to existing branch

