---
name: Comprehensive Status and Next Steps
overview: Full audit of project state across all 13 personas, doc freshness, agent readiness, and a prioritized action plan to get from current state (Sprint 0/1 partial) to agent-assisted operations.
todos:
  - id: fix-docs
    content: "Fix stale/missing docs: recreate brand.mdc (no image refs), add Tool Registry to cfo.mdc, add D28-D30 to KNOWLEDGE.md, recreate SOCIAL_ROADMAP.md, fix .cursorrules Tailwind refs, update PITCH_PACKAGE.md costs, commit compose.yaml"
    status: pending
  - id: commit-infra
    content: Commit the compose.yaml Elasticsearch + MAIN_URL changes and mcp.json Postiz credentials (exclude API keys from commit)
    status: pending
  - id: sprint2-prep
    content: "Prep Sprint 2: identify exactly which files/components need building for Tasks 1.1-1.4"
    status: pending
isProject: false
---

# FileFree: Where We Stand and What's Next

## Current State Summary

**8 of 51 tasks complete, 2 partial.** Sprint 0 and Sprint 1 are ~80% done. Sprint 2+ is untouched.

### What's Live

- **filefree.tax** -- landing page, waitlist, demo, pricing, 3 SEO guides, privacy/terms, sitemap
- **api.filefree.tax** -- FastAPI with health, waitlist, demo-upload endpoints; Neon DB
- **n8n.filefree.tax** -- 6 persona workflows imported (social, growth, strategy, partnership, CPA, QA)
- **social.filefree.tax** -- Postiz running with Temporal + Elasticsearch, account registered, MCP connected
- PostHog analytics integrated with PII scrubbing
- Social handles claimed on TikTok, IG, X, YouTube
- Git guardrails (pre-push hook, git-workflow.mdc)
- 13 AI persona files active

### What's Broken or Missing in Docs


| Item                    | Issue                                                                                         | Fix                                            |
| ----------------------- | --------------------------------------------------------------------------------------------- | ---------------------------------------------- |
| `brand.mdc`             | File missing entirely (was never committed after creation)                                    | Recreate without deleted image references      |
| `SOCIAL_ROADMAP.md`     | Never committed to `docs/`                                                                    | Recreate from the content plan drafted earlier |
| `cfo.mdc` Tool Registry | Section was supposed to be added but isn't in the file                                        | Add the tool inventory section                 |
| `compose.yaml`          | Local file has ES addition but was never committed                                            | Commit the Elasticsearch + MAIN_URL changes    |
| `KNOWLEDGE.md`          | Missing entries for: Postiz 502 fix (ES addition), brand asset cleanup, Postiz MCP activation | Add D28-D30                                    |
| `PITCH_PACKAGE.md`      | Shows $34.50/mo burn (stale); actual is ~$17/mo with ES                                       | Update cost figures                            |
| `layout.tsx`            | No OG image, no favicon reference, no Apple touch icon                                        | Add back when proper brand assets exist        |
| `.cursorrules`          | References `tailwind.config.ts` which doesn't exist (Tailwind 4 uses CSS)                     | Update Tailwind config section                 |


## Persona-by-Persona Next Steps

### Engineering (alwaysApply)

- **Immediate**: Sprint 2 Task 1.1 -- Camera component + image quality validation
- **Immediate**: Sprint 2 Task 1.2 -- Wire real OCR pipeline (Cloud Vision + GPT, currently mock)
- Fix stale Tailwind 4 references in `.cursorrules`

### UX/UI Lead

- Sprint 2 Task 1.3 -- "Try Before Signup" frontend (demo flow without auth)
- Design the filing flow wireframes for Sprint 3

### Growth

- Sprint 2 Task 1.4 -- Content foundation + social media launch sprint
- First 5 founder-journey posts on socials

### Social Media Manager

- Start posting manually via Postiz (founder journey, "building in public")
- Recreate `SOCIAL_ROADMAP.md` with the 30-day content calendar
- Connect social accounts in Postiz (TikTok, X, IG, YouTube)

### CFO

- Add Tool Registry section to `cfo.mdc` with current 26-tool inventory
- Update `PITCH_PACKAGE.md` cost figures ($17/mo with Hetzner ES)

### Strategy

- Close Sprint 0 human-action items: B.1 (EFIN), B.2 (LLC/bank), B.5/B.9 (Column Tax outreach)
- Add decisions D28-D30 to KNOWLEDGE.md

### Legal

- B.1 -- EFIN Application (IRS Form 8633) -- requires human action
- B.2 -- LLC formation -- requires human action

### Partnerships (Founder 2)

- B.5 -- Column Tax outreach
- B.8 -- Affiliate applications (defer until filing MVP live, ~May)

### QA

- Not triggered until Sprint 2 code ships
- n8n QA Security Scan workflow is ready when needed

### CPA / Tax Domain

- Not triggered until Sprint 3 tax calculation engine
- Tax data files and bracket validation will be Sprint 3 tasks

### Workflows

- All 6 n8n workflows imported; none yet triggered in production
- Need: Notion API key configured in n8n for workflow outputs to land

## How Far from Agents Running Things

```
Current State                     Target State
--------------                    ---------------
Manual posting on Postiz    -->   n8n generates drafts to Notion,
                                  you review, schedule via Postiz

No automated content        -->   Social Content Generator +
                                  Growth Content Writer workflows
                                  fire on schedule, output to
                                  Notion Content Calendar

Manual strategy decisions   -->   Weekly Strategy Check-in runs
                                  Mondays, surfaces priorities
                                  in Notion

No automated QA             -->   QA Security Scan creates
                                  GitHub Issues on triggers
```

**Gap to close**: The n8n workflows are imported but need their **Notion credentials configured** to actually output anywhere. Once you set the Notion API key in n8n and map the database IDs, the content generation workflows can fire. Estimate: 1 session to configure.

**Recommended sequencing**:

1. Post manually for 1-2 weeks (own the voice first)
2. Configure n8n Notion credentials
3. Run content generator workflows, review outputs in Notion
4. If quality is good, set up scheduled triggers (daily/weekly)

## Prioritized Next Steps (Ordered)

1. **Fix docs** -- recreate `brand.mdc`, add Tool Registry to `cfo.mdc`, add KNOWLEDGE.md entries D28-D30, recreate `SOCIAL_ROADMAP.md`, commit compose.yaml changes
2. **Start posting** -- connect social accounts in Postiz, create first 3-5 posts
3. **Sprint 0 human actions** -- EFIN (B.1), LLC (B.2), Column Tax call (B.5/B.9)
4. **Sprint 2 dev work** -- Camera component (1.1), real OCR pipeline (1.2), try-before-signup (1.3)
5. **Configure n8n Notion integration** -- set API key, map database IDs, test one workflow
6. **Sentry activation** -- get DSN, wire into frontend + backend

