---
name: Fix login and stabilize
overview: Login fails because Section 1 re-enabled the `strategies` route but didn't add required SQLAlchemy relationships to the User model. Every backend request returns 500. Two relationship additions fix login; then we stabilize tests.
todos:
  - id: fix-user-model
    content: Add `strategies` and `strategy_executions` relationships to User model in backend/models/user.py
    status: completed
  - id: verify-login
    content: Verify backend auto-reloads, curl login returns 401 (not 500), and browser login works
    status: completed
  - id: run-tests
    content: Run `make test` and triage remaining failures (pre-existing vs Section 1 regressions)
    status: completed
isProject: false
---

# Fix Login and Stabilize Backend

## Root Cause

Section 1 uncommented the `strategies` route in [backend/api/main.py](backend/api/main.py) (line 32). This triggers the import chain:

```
main.py -> strategies.py -> strategy_manager.py -> backend.models.strategy
```

The `Strategy` model defines:

```python
# strategy.py line 172
user = relationship("User", back_populates="strategies", foreign_keys=[user_id])
```

And `StrategyExecution` defines:

```python
# strategy.py line 502-503
user = relationship("User", back_populates="strategy_executions")
```

But [backend/models/user.py](backend/models/user.py) has **neither** `strategies` nor `strategy_executions` relationships (line 108 even says "Commented out relationships that reference models not in core imports").

This causes SQLAlchemy mapper initialization to fail on every request:

```
"Mapper 'Mapper[User(users)]' has no property 'strategies'"
```

The backend returns 500 on every request, including `/auth/login`. The frontend's 30s axios timeout fires because the error response isn't what it expects.

**Proof:** `curl -s POST http://localhost:8000/api/v1/auth/login` returns the mapper error in ~19ms (it's not a timeout -- it's a 500).

## Fix (2 lines in one file)

Add the two missing relationships to the `User` model in [backend/models/user.py](backend/models/user.py), after line 107:

```python
strategies = relationship(
    "Strategy", back_populates="user",
    foreign_keys="[Strategy.user_id]", cascade="all, delete-orphan"
)
strategy_executions = relationship(
    "StrategyExecution", back_populates="user",
    cascade="all, delete-orphan"
)
```

No migration needed -- these are ORM-only relationships, not new columns.

## Validation

1. The backend container has `--reload` and volume mounts, so it will auto-pick up the change
2. Verify `curl POST /api/v1/auth/login` returns 401 (bad creds) instead of 500
3. Verify login works in the browser
4. Run `make test` and compare failures to the 51 failures / 16 errors from last run -- the mapper fix should resolve some of those too (any test importing `from backend.api.main import app` was hitting the same mapper crash)

## Test Failures to Investigate After

The 16 collection errors (test files that couldn't even import `app`) should all resolve once the mapper is fixed. The 51 test failures need triage -- some may be pre-existing (before Section 1), some may be from Section 1 changes. After the login fix, run `make test` and compare.