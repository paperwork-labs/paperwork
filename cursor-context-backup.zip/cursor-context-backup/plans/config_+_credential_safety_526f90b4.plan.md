---
name: Config + Credential Safety
overview: "Build a company-wide credential management system: Zod-validated frontend config, secrets scanning in CI, a credential registry documenting every key across all systems, and n8n workflow import with credential setup."
todos:
  - id: credential-registry
    content: Create docs/CREDENTIALS.md — company-wide credential registry mapping every key to its purpose, location, and owner
    status: completed
  - id: server-config
    content: Create web/src/lib/server-config.ts — Zod-validated server-side config
    status: completed
  - id: client-config
    content: Create web/src/lib/client-config.ts — Zod-validated client-side config
    status: completed
  - id: fix-env-files
    content: Move secrets out of tracked .env.production, create .env.local and .env.example
    status: completed
  - id: migrate-consumers
    content: Replace all raw process.env reads with config module imports
    status: completed
  - id: secrets-scanner
    content: Add gitleaks job to CI workflow + .gitleaksignore
    status: completed
  - id: import-workflows
    content: Import 6 n8n workflows via REST API + document credential setup
    status: completed
  - id: verify
    content: Type check, tests, no secrets in git, ops dashboard live
    status: completed
isProject: false
---

# Config + Credential Safety System

## Current State

- **Backend**: Already has Pydantic `BaseSettings` in [api/app/config.py](api/app/config.py) -- well-typed, validated, env-file loading. No changes needed.
- **Frontend**: 14 raw `process.env` reads scattered across 10 files, no validation, no single source of truth.
- **Secrets in git**: `web/.env.production` is tracked and contains the PostHog API key (`phc_tBJ...`). Adding more keys here would leak them.
- **No secrets scanner**: No gitleaks, trufflehog, or pre-commit hooks. Nothing prevents accidental commits.
- **n8n agents**: Need OpenAI, Notion, GitHub, Postiz credentials configured in n8n's own credential store (separate from app env vars).
- **No credential registry**: No single doc mapping every credential to where it lives and who owns it.

## What We Build

### 1. Credential Registry -- `docs/CREDENTIALS.md`

A single source of truth documenting every credential across all systems:

- **Per credential**: name, purpose, which systems use it, where it's configured (Render dashboard / Vercel / n8n UI / Docker .env), rotation policy, owner
- **Categories**: Core Infrastructure, OAuth, AI/ML, Analytics, Ops Tools, CI, n8n Agent Credentials
- **QA checkpoint**: any new credential MUST be added here before merge (enforced by review convention)

This is what the QA persona checks against. Agents reference it when they need to know where a key lives.

### 2. Frontend Config Modules

Two Zod-validated modules replacing all raw `process.env` reads:

- `**web/src/lib/server-config.ts`** -- server-only vars: `N8N_API_KEY`, `N8N_HOST`, `GITHUB_TOKEN`
- `**web/src/lib/client-config.ts`** -- client vars: `apiUrl`, `posthogKey`, `posthogHost`, `sentryDsn`, `googleClientId`, `appleClientId`, `appleRedirectUri`

Mirrors the backend's Pydantic pattern. Fails fast on startup if required vars are invalid.

### 3. Fix Env File Strategy

- Move PostHog key out of tracked `web/.env.production` into `.env.local` (already gitignored by Next.js)
- Keep tracked env files for non-secret defaults only (URLs, feature flags)
- Create `web/.env.example` documenting all vars with placeholder values
- Update [infra/env.dev.example](infra/env.dev.example) with ops section (N8N_API_KEY, GITHUB_TOKEN)

### 4. Migrate Consumers

Replace `process.env` in these files:

- [web/src/lib/api.ts](web/src/lib/api.ts) -- `clientConfig.apiUrl`
- [web/src/lib/posthog.ts](web/src/lib/posthog.ts) -- `clientConfig.posthogKey`, `clientConfig.posthogHost`
- [web/src/components/auth/google-sign-in.tsx](web/src/components/auth/google-sign-in.tsx) -- `clientConfig.googleClientId`
- [web/src/components/auth/apple-sign-in.tsx](web/src/components/auth/apple-sign-in.tsx) -- `clientConfig.appleClientId`, `clientConfig.appleRedirectUri`
- [web/src/app/api/ops/route.ts](web/src/app/api/ops/route.ts) -- `serverConfig.N8N_API_KEY`, `serverConfig.GITHUB_TOKEN`

Skip Next.js built-ins (`NODE_ENV`, `NEXT_RUNTIME`, `CI`).

### 5. Secrets Scanner in CI

- Add `gitleaks/gitleaks-action@v2` job to [.github/workflows/ci.yaml](.github/workflows/ci.yaml)
- Runs on every PR, scans for API keys, tokens, passwords in code and git history
- Add `.gitleaksignore` for the PostHog key already in git history (can't rewrite history)
- Blocks merge if new secrets are detected

### 6. Import n8n Workflows + Document Credential Setup

- POST the 6 workflow JSONs from [infra/hetzner/workflows/](infra/hetzner/workflows/) to n8n REST API
- Document in `CREDENTIALS.md` exactly which n8n credentials each workflow needs and how to configure them in the n8n UI
- Workflows import as inactive; activation is manual after credentials are configured

### 7. Verify

- `npx tsc --noEmit` clean
- `npx vitest run` all pass
- No secrets in tracked git files
- Ops dashboard renders with live data
- Credential registry complete and accurate

## Architecture: Credential Flow

```mermaid
flowchart TB
  subgraph registry ["docs/CREDENTIALS.md (Source of Truth)"]
    CredList["Every credential documented:\nname, purpose, location, owner"]
  end

  subgraph backend ["Backend (Render)"]
    PydanticSettings["api/app/config.py\nPydantic BaseSettings"]
    RenderDash["Render Dashboard\n(production secrets)"]
    RenderDash --> PydanticSettings
  end

  subgraph frontend ["Frontend (Vercel)"]
    ServerConfig["server-config.ts\nZod validated"]
    ClientConfig["client-config.ts\nZod validated"]
    VercelDash["Vercel Dashboard\n(production secrets)"]
    EnvLocal[".env.local\n(dev secrets, gitignored)"]
    VercelDash --> ServerConfig
    VercelDash --> ClientConfig
    EnvLocal --> ServerConfig
    EnvLocal --> ClientConfig
  end

  subgraph ops ["Hetzner Ops Stack"]
    N8nCreds["n8n Credential Store\n(OpenAI, Notion, GitHub, Postiz)"]
    DockerEnv["Docker .env\n(Postgres, Redis, n8n auth)"]
  end

  subgraph ci ["CI (GitHub Actions)"]
    Gitleaks["gitleaks scanner\n(blocks leaked secrets)"]
  end

  registry -.->|"QA audits against"| backend
  registry -.->|"QA audits against"| frontend
  registry -.->|"QA audits against"| ops
  Gitleaks -.->|"prevents leaks into"| registry
```



## What We Do NOT Change

- Backend `api/app/config.py` -- already solid
- Sentry config files (`sentry.*.config.ts`) -- these use `NEXT_PUBLIC_SENTRY_DSN` which will come from `clientConfig`, but the Sentry init files themselves have special initialization timing; we import `clientConfig` where safe
- Docker Compose env strategy -- already works with `.env` + `env.example`
- Render/Vercel dashboard secrets -- those are the right place for production values

