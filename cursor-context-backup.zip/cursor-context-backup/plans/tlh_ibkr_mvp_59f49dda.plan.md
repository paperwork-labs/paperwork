---
name: TLH IBKR MVP
overview: Build a backend-first tax loss harvesting assistant for 2025 using IBKR Activity Statement CSVs to reconstruct lots (HIFO), allow lot selection to hit a target (e.g., 0 or -$3k), optionally include dividends/interest, and provide substitute suggestions. Dockerized with light/dark mode and dev ports ending in 10 (API 8010, web 3010).
todos:
  - id: scaffold-repo
    content: Scaffold monorepo with `backend/` (FastAPI) + `frontend/` (Next.js), wiring API base URL and ports 8010/3010.
    status: completed
  - id: db-schema
    content: Add Postgres schema + migrations for IBKR trades, corporate actions, transfers, income events, and manual basis overrides.
    status: completed
    dependencies:
      - scaffold-repo
  - id: ibkr-parser
    content: Implement robust IBKR Activity Statement CSV parser for Trades/CorporateActions/Transfers/Dividends/Interest/Fees/WithholdingTax sections; dedupe across multiple statement files.
    status: completed
    dependencies:
      - db-schema
  - id: lot-engine
    content: Implement lot reconstruction + HIFO matching + split adjustments + scenario sell simulation; expose API endpoints for lots and scenario totals.
    status: completed
    dependencies:
      - ibkr-parser
  - id: ui-lot-selection
    content: Build lots UI (group by ticker, expand lots, checkboxes) + target panel + include/exclude toggles + manual other-broker totals inputs.
    status: completed
    dependencies:
      - lot-engine
  - id: ui-manual-basis
    content: Add UI + API for entering ACATS transfer basis and acquisition date, and refresh lot calculations accordingly.
    status: completed
    dependencies:
      - ui-lot-selection
  - id: substitutes
    content: Add substitutes mapping config + UI display for selected tickers.
    status: completed
    dependencies:
      - ui-lot-selection
  - id: theme-toggle
    content: Implement light/dark mode (persisted) across the frontend.
    status: completed
    dependencies:
      - scaffold-repo
  - id: dockerize
    content: Add Dockerfiles + `docker-compose.yml` for db/api/web; ensure ports end in 10 (8010/3010).
    status: completed
    dependencies:
      - scaffold-repo
  - id: tests
    content: Add backend unit tests for parser + lot engine + split handling + scenario math; add minimal frontend tests for selection/totals rendering.
    status: completed
    dependencies:
      - lot-engine
      - ui-lot-selection
---

# Tax Loss Harvesting App (2025) — IBKR CSV MVP

## Goals (MVP)

- Import IBKR Activity Statement CSVs from `ibkr/` and store normalized data in a DB.
- Reconstruct **open lots** and **realized ST/LT** using **HIFO** by default, with a “scenario engine” that lets you **check/uncheck lots** to simulate selling and see resulting ST/LT totals.
- Provide a **target** control (e.g., 0 or -3000) and show the delta to target as you select lots.
- Allow **include/exclude** categories: dividends, interest, withholding tax, fees (in “target math”), while still reporting them separately.
- Show **manual totals** inputs for Schwab/tastytrade/Robinhood (ST/LT + income) to see combined totals, without importing those brokers yet.
- Suggest **substitutes** for tickers (config-driven to start).
- Add **light/dark mode**.
- Dockerize and ensure dev ports end in **…10**: API **8010**, web **3010**.

## Key repo structure (new)

- Backend (FastAPI): [`backend/`](backend/)
- Frontend (Next.js): [`frontend/`](frontend/)
- Docker: [`docker-compose.yml`](docker-compose.yml)
- Shared docs + samples: [`docs/`](docs/)

## Data model + parsing approach

- Parse IBKR CSV sections we observed:
- `Trades` (drives lot reconstruction)
- `Corporate Actions` (splits must adjust lots)
- `Transfers` (ACATS in/out; **manual basis entry required** for “In”)
- `Dividends`, `Interest`, `Withholding Tax`, `Fees`, `Commission Adjustments`
- Store normalized tables (Postgres) for trades, corporate actions, transfers, cash/income events, and a small table for **manual basis overrides**.
- Lot reconstruction:
- Build an internal “ledger” per `symbol` over time.
- Apply splits from `Corporate Actions` to affected lots (quantity and per-share basis adjustments).
- Apply sells by consuming lots via **HIFO** (highest cost basis per share first) to compute realized ST/LT.
- For TLH scenarios, we don’t rely on historical realized P/L (your statement disables it); we compute from trades.

## Scenario engine (the core user workflow)

- The backend exposes an endpoint that returns **open lots** per symbol:
- acquisition date, remaining qty, cost basis, current/reference price, unrealized P/L, holding period (ST/LT if sold on selected date), wash-sale risk flags (IBKR-only)
- User selects lots to “sell” (hypothetical), backend computes:
- realized ST/LT P/L for the selection
- projected end state (remaining lots)
- combined totals including optional categories (dividends/interest/fees/taxes) depending on toggles

## Substitute suggestions (MVP)

- Start with a config file (editable): [`backend/config/substitutes.yaml`](backend/config/substitutes.yaml) mapping `ticker -> [alternatives]`.
- UI shows “Suggested substitutes” for selected tickers and allows manual override.
- Add a clear disclaimer that “substantially identical” is nuanced; the app provides suggestions, not tax advice.

## UI (frontend)

- Next.js app that is **read-only** except for scenario inputs (lot selection, toggles, manual totals, manual basis entries).
- Pages:
- **Import**: upload CSV(s) or select server-side files from `ibkr/` for dev.
- **Lots**: grouped-by-ticker table with expandable lots + checkboxes.
- **Target panel**: target number (0 / -3000 / custom), live delta, ST/LT breakdown, included income toggles.
- **Other brokers**: manual ST/LT + dividends/interest inputs for Schwab/tastytrade/Robinhood; included in combined view.
- **Settings**: theme toggle (light/dark).

## Ports and Docker

- Backend runs on **8010** (instead of 8000).
- Frontend runs on **3010** (instead of 3000).
- `docker-compose.yml` brings up:
- `db` (Postgres)
- `api` (FastAPI)
- `web` (Next.js)

## Testing strategy (MVP)

- Backend: unit tests for
- parsing each IBKR section
- split handling
- HIFO matching
- scenario selection math
- transferred-basis overrides
- Frontend: basic component tests for lot selection + totals, plus API contract tests (lightweight).

## Deliverables for you

- A running local app where you can:
- import the IBKR CSVs you already have in `ibkr/`
- see per-ticker lots + ST/LT implications
- select lots to hit a target (0 or -3000)
- include/exclude dividends/interest/fees/taxes in the target calculation
- enter missing ACATS transfer basis/acquisition dates
- keep manual Schwab/tastytrade/Robinhood totals alongside IBKR
- use light/dark mode
- run via Docker with ports **8010/3010**