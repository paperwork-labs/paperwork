---
name: Company Structure Deep Dive
status: archived
overview: "ARCHIVED — BizFree naming superseded by Distill brand. McKinsey-style analysis of corporate structure, agent infrastructure architecture, and brand hierarchy for a multi-product bootstrapped venture."
todos:
  - id: register-domain
    content: Register bizfree.ai immediately -- domains can be sniped at any time
    status: pending
  - id: secure-handles
    content: Secure @bizfree social handles on TikTok, Instagram, X, YouTube before someone else does
    status: pending
  - id: form-llc
    content: Form the LLC (Task B.2) with a parent-friendly name (not product-specific)
    status: pending
  - id: trademark-search
    content: Run USPTO trademark search on 'BizFree' before investing further
    status: pending
  - id: filefree-sprint4
    content: "Continue FileFree Sprint 4 as priority #1 -- BizFree build starts after Sprint 4 (May/June 2026)"
    status: pending
  - id: migrate-subdomains
    content: Migrate n8n/Postiz from filefree.tax subdomains to sankalpsharma.com subdomains (May 2026)
    status: pending
  - id: bizfree-repo
    content: Create BizFree repo + Cursor workspace with customized .mdc personas (June 2026)
    status: pending
isProject: false
---

# Multi-Product Company Structure: McKinsey Deep Dive

## 1. The Name: BizFree Over LaunchFree -- Agreed

I actually agree with your instinct. BizFree is the stronger choice for this specific product. Here's why:

**Scope**: BizFree covers the full product vision -- formation, RA, compliance, banking, bookkeeping referrals. LaunchFree implies a one-time event ("launch your business") and sounds awkward for ongoing services ("LaunchFree handles your annual compliance" doesn't land).

**Brevity**: 7 characters vs 10. Shorter URL, shorter hashtag, easier to say in a TikTok caption.

**Marketing versatility test**:

- "BizFree formed my LLC for free" -- works
- "BizFree handles my registered agent" -- works
- "BizFree got me a free business bank account" -- works
- "LaunchFree handles my registered agent" -- sounds weird

**Industry validation**: ZenBusiness ($200M+ raised), BizFilings, Biz2Credit all use "Biz" or "Business" in their names. It's not dated -- it's the accepted shorthand in this space.

**Domain**: bizfree.ai is available. Register it today.

---

## 2. Corporate Structure: The Strategic Question

Task B.2 in TASKS.md ("Register LLC/Corp if not already done") is still incomplete. This is actually perfect timing -- you can architect the entity structure before forming anything.

### Three Options Evaluated

**Option A: Single LLC, Products as Brands**

```
Sharma Ventures LLC (or similar)
  |-- FileFree (brand / DBA)
  |-- BizFree (brand / DBA)
  |-- Future products...
```

- One EIN, one tax return, one bank account, one operating agreement
- File DBAs for each product brand ($10-50/state)
- Simplest. Cheapest. Fastest.
- Risk: No liability isolation between products

**Option B: Holding Company + Product LLCs**

```
Sharma Ventures LLC (holding company)
  |-- FileFree LLC (subsidiary)
  |-- BizFree LLC (subsidiary)
```

- Each product is a separate legal entity
- Liability isolation (lawsuit against BizFree can't touch FileFree)
- More expensive: 2-3 state filings, 2-3 bank accounts, 2-3 EINs, separate bookkeeping
- More "institutional" for partnerships and investors
- Typical cost: $500-1000/yr in additional filing fees + bookkeeping overhead

**Option C: Product-first LLC, Restructure Later**

```
Phase 1 (Now): FileFree LLC → owns everything
Phase 2 ($100K+ rev): Restructure into holding + subs
```

- Form one LLC now, add BizFree as a DBA
- Restructure into holding company when revenue justifies it
- Cheapest path to start, deferred complexity

### Strategy + CFO + Legal Assessment

**Strategy says**: Option A or C. You're pre-revenue with a 2-person team. Corporate complexity is an enemy of speed right now. Every hour spent on entity management is an hour not shipping product. Restructure when you have revenue to protect.

**CFO says**: Option C saves $500-1000/yr in filing fees and bookkeeping time. At $0 revenue, liability isolation isn't worth the admin overhead. Business insurance ($500-1000/yr for E&O) provides better protection at this stage than corporate structure.

**Legal says**: The real risk vectors (tax advice liability, RA service liability) are better mitigated by disclaimers, E&O insurance, and proper Terms of Service than by entity separation. Entity separation matters when one product has significant assets to protect from another product's liabilities.

### Recommendation: Option C (Product-first, Restructure Later)

**Now**: Form a single LLC with a neutral name that works as a parent entity.

**Naming options for the LLC** (NOT a product-facing brand, just the legal entity):

- **FreeStack LLC** -- nods to the "[X]Free" product family and the tech stack
- **Sharma Ventures LLC** -- straightforward, personal, founder-identified
- **Freeform Labs LLC** -- creative, product-aligned (check trademark)
- Or simply **FileFree LLC** -- and add BizFree as a DBA when needed

The LLC name doesn't matter much because users never see it. It appears on bank statements, tax returns, and contracts. Product brands (FileFree, BizFree) are what users know.

**Restructure trigger**: When combined revenue exceeds $100K/yr OR you raise outside investment OR either product handles a regulatory-sensitive activity that could generate significant liability.

### Eat Your Own Dog Food

When BizFree launches, document the process of forming BizFree's LLC using BizFree itself. This is an incredibly powerful marketing moment: "We literally used BizFree to form BizFree." Screenshot every step. Make it a launch video.

---

## 3. Agent Architecture: Centralized Hub

This is the most interesting technical question. You currently have a powerful ops stack:

**Current state** (Hetzner CX33, 8GB RAM, EUR 5.49/mo):

- n8n: 6 FileFree persona workflows (social content, growth content, strategy, partnerships, CPA review, QA scan)
- Postiz: FileFree social accounts
- PostgreSQL: ops database
- Redis: caching
- Temporal + Elasticsearch: Postiz job scheduling
- Caddy: reverse proxy + TLS

**Current domains**: n8n.filefree.tax, social.filefree.tax

### The Problem

If n8n and Postiz serve BOTH FileFree and BizFree, they shouldn't live under `filefree.tax`. That's like running Google's ad platform under `youtube.com`. The ops infrastructure is a shared service, not a FileFree feature.

### The Architecture

```mermaid
graph TB
  subgraph personalBrand ["sankalpsharma.com (Venture Studio)"]
    studio["Landing page: portfolio + blog"]
  end

  subgraph opsInfra ["Hetzner CX33 (Shared Ops)"]
    n8n["n8n (ops.sankalpsharma.com)"]
    postiz["Postiz (social.sankalpsharma.com)"]
    pg["PostgreSQL"]
    redis["Redis"]
    temporal["Temporal + ES"]
  end

  subgraph filefreeProduct ["FileFree (filefree.tax)"]
    ffWeb["Vercel: filefree.tax"]
    ffApi["Render: api.filefree.tax"]
    ffNeon["Neon: filefree DB"]
    ffSocial["@filefree.tax socials"]
  end

  subgraph bizfreeProduct ["BizFree (bizfree.ai)"]
    bfWeb["Vercel: bizfree.ai"]
    bfApi["Render: api.bizfree.ai"]
    bfNeon["Neon: bizfree DB"]
    bfSocial["@bizfree socials"]
  end

  n8n -->|"filefree-* workflows"| ffSocial
  n8n -->|"bizfree-* workflows"| bfSocial
  n8n --> postiz
  postiz --> ffSocial
  postiz --> bfSocial
  studio --> ffWeb
  studio --> bfWeb
```



### The Recommendation: Centralized Ops, Separated Products

**Shared (one instance, serves all products):**

- n8n (automation engine) -- at `ops.sankalpsharma.com`
- Postiz (social scheduling) -- at `social.sankalpsharma.com`
- OpenAI API key (one account, one billing)
- Notion workspace (separate databases per product)
- GitHub org (separate repos per product)
- Hetzner VPS (same server, same EUR 5.49/mo)

**Separate (one per product):**

- Vercel project (filefree.tax, bizfree.ai)
- Render service (api.filefree.tax, api.bizfree.ai)
- Neon database (separate project per product -- PII isolation is critical)
- Social media accounts (@filefree vs @bizfree)
- Cursor workspace + .mdc persona files (separate repos)
- Domain + DNS

**Why this split:**

- n8n and Postiz are "backoffice" tools -- they don't handle user PII, so sharing is safe
- Databases MUST be separate -- FileFree has SSNs, BizFree will have EINs. Cross-contamination is a compliance nightmare
- Vercel/Render are separate because each product has its own deployment lifecycle
- Social accounts are obviously separate (different brand voice, different audience, different content)

### n8n Workflow Namespacing

Current FileFree workflows become:

1. `filefree-social-content` (was: Social Content Generator)
2. `filefree-growth-content` (was: Growth Content Writer)
3. `filefree-strategy-checkin` (was: Weekly Strategy Check-in)
4. `filefree-partnership-outreach` (was: Partnership Outreach Drafter)
5. `filefree-cpa-review` (was: CPA Tax Review)
6. `filefree-qa-scan` (was: QA Security Scan)

New BizFree workflows (built June 2026):

1. `bizfree-social-content` -- LLC tips, business compliance content, "did you know" facts
2. `bizfree-growth-content` -- SEO articles about business formation
3. `bizfree-strategy-checkin` -- BizFree-specific metrics and weekly review
4. `bizfree-compliance-alerts` -- state filing deadline reminders (unique to BizFree)
5. `bizfree-partnership-outreach` -- bank, insurance, payroll partner outreach
6. `bizfree-qa-scan` -- security scan for BizFree codebase

Same n8n instance. Workflows use different system prompts (pulled from BizFree's .mdc equivalents). Different Postiz channels for output.

### Postiz Multi-Brand Architecture

Postiz supports multiple "organizations" or channel groups. Setup:

- **FileFree channels**: TikTok @filefree.tax, IG @filefree.tax, X @filefreetax, YouTube @FileFreeTax
- **BizFree channels**: TikTok @bizfree, IG @bizfree.ai, X @bizfreeai, YouTube @BizFreeAI

Same Postiz instance. n8n workflows target the right channels via API.

### .mdc Persona Strategy for BizFree

**Copy the pattern, customize the content.** The persona ROLES are universal (Growth, Strategy, Legal, CFO, QA, Engineering). The persona CONTENT diverges significantly:


| Persona    | FileFree Content                        | BizFree Content                                 |
| ---------- | --------------------------------------- | ----------------------------------------------- |
| Growth     | Tax filing SEO, refund season marketing | LLC formation SEO, "start a business" content   |
| Legal      | Circular 230, EFIN, SSN rules           | RA requirements, state formation rules, UPL     |
| Tax Domain | IRS brackets, W-2 parsing, MeF          | State filing fees, entity types, annual reports |
| CFO        | OCR costs, per-filing economics         | RA costs, per-formation economics               |
| CPA        | Tax advisory quality                    | Business structure advisory quality             |


Create a separate BizFree Cursor workspace with its own `.cursorrules` and `.cursor/rules/` directory. Copy the structure from FileFree, rewrite the content for business formation context. The files are small (~100 lines each) and will diverge quickly.

### Cost Impact (CFO Review)


| Item              | Current (FileFree only) | With BizFree   | Delta                         |
| ----------------- | ----------------------- | -------------- | ----------------------------- |
| Hetzner VPS       | EUR 5.49/mo             | EUR 5.49/mo    | $0 (same server)              |
| Render            | $7/mo                   | $14/mo         | +$7/mo (second Starter)       |
| Vercel            | $0/mo                   | $0/mo          | $0 (second Hobby project)     |
| Neon              | $0/mo                   | $0/mo          | $0 (second free-tier project) |
| Upstash           | $0/mo                   | $0/mo          | $0 (second free-tier project) |
| OpenAI            | variable                | ~1.5x variable | +50% (more n8n workflows)     |
| bizfree.ai domain | $0                      | ~$50-90/yr     | +$4-8/mo                      |
| **Total delta**   |                         |                | **+$11-15/mo**                |


BizFree adds approximately $11-15/mo to the fixed burn. Total portfolio burn goes from $12.49/mo to ~$24-27/mo. Still well under the $50/mo infrastructure target.

**Memory check**: Hetzner CX33 has 8GB RAM. Current usage is likely 4-5GB (PostgreSQL + Redis + n8n + Postiz + Temporal + Elasticsearch). Adding 6 more n8n workflows doesn't significantly increase memory (workflows execute on demand, not resident). Monitor with `docker stats`. Upgrade trigger: sustained >7GB usage -> CX43 (16GB, ~$8/mo).

---

## 4. sankalpsharma.com: The Venture Studio Hub

### Role

sankalpsharma.com becomes the **personal brand / venture studio** that ties everything together. It's not a product -- it's the builder's identity.

### What It Should Be

A lightweight, beautiful landing page that:

1. Introduces you as the builder ("I build free tools that eliminate tedious processes")
2. Links to the product portfolio (FileFree, BizFree, future products)
3. Houses the ops infrastructure subdomains (ops, social)
4. Optionally: blog about building with AI agents (thought leadership)

### DNS Architecture

```
sankalpsharma.com          -> Venture studio landing page (Vercel, free)
ops.sankalpsharma.com      -> n8n dashboard (Hetzner)
social.sankalpsharma.com   -> Postiz dashboard (Hetzner)

filefree.tax               -> FileFree product (Vercel)
api.filefree.tax           -> FileFree API (Render)

bizfree.ai                 -> BizFree product (Vercel)
api.bizfree.ai             -> BizFree API (Render)
```

### Migration Plan for Hetzner Subdomains

Currently n8n and Postiz are at `n8n.filefree.tax` and `social.filefree.tax`. Migrate to:

- `ops.sankalpsharma.com` (n8n)
- `social.sankalpsharma.com` (Postiz)

This is just DNS changes (update Caddy config on Hetzner + add A records on sankalpsharma.com's DNS). Keep the old filefree.tax subdomains as redirects temporarily.

### What It Should NOT Be

- Not a corporate "About Us" page (no one cares about corporate pages)
- Not a resume/CV (you're building products, not job-hunting)
- Not the legal entity's website (the LLC is a backend construct, not a brand)

### Build Priority

**Low**. A 1-page Vercel site with 3 hours of work. Do it after BizFree's landing page, not before. The products are what matter; the studio page is credibility infrastructure.

---

## 5. The Complete Architecture (Summary)

```
Legal Entity: [Name] LLC (single entity)
  |
  |-- sankalpsharma.com (venture studio / personal brand)
  |     |-- ops.sankalpsharma.com (n8n - shared automation)
  |     |-- social.sankalpsharma.com (Postiz - shared social)
  |
  |-- filefree.tax (Product #1: Free Tax Filing)
  |     |-- api.filefree.tax (Render)
  |     |-- Neon DB (isolated)
  |     |-- @filefree socials
  |     |-- Cursor workspace + .mdc personas
  |
  |-- bizfree.ai (Product #2: Free Business Formation)
  |     |-- api.bizfree.ai (Render)
  |     |-- Neon DB (isolated)
  |     |-- @bizfree socials
  |     |-- Cursor workspace + .mdc personas
  |
  |-- Shared Infrastructure:
        |-- Hetzner CX33 (n8n, Postiz, Temporal, ES, PG, Redis)
        |-- OpenAI account (one API key)
        |-- Notion workspace (separate DBs per product)
        |-- GitHub (separate repos, same org)
```

### Monthly Burn (Portfolio)


|           | FileFree | BizFree | Shared   | Total       |
| --------- | -------- | ------- | -------- | ----------- |
| Render    | $7       | $7      | --       | $14         |
| Vercel    | $0       | $0      | --       | $0          |
| Neon      | $0       | $0      | --       | $0          |
| Upstash   | $0       | $0      | --       | $0          |
| Hetzner   | --       | --      | EUR 5.49 | $6          |
| Domains   | ~$1/mo   | ~$5/mo  | ~$1/mo   | ~$7         |
| **Total** | **$8**   | **$12** | **$7**   | **~$27/mo** |


---

## 6. Sequencing (What Happens When)

**Now (March 2026)**:

- Register bizfree.ai domain
- Secure @bizfree social handles (TikTok, IG, X, YouTube)
- Form the LLC (Task B.2) with a parent-friendly name
- Continue FileFree Sprint 4 as priority #1

**May/June 2026 (After FileFree Sprint 4)**:

- Migrate n8n/Postiz subdomains from filefree.tax to sankalpsharma.com
- Create BizFree GitHub repo, copy architectural patterns from FileFree
- Set up BizFree Cursor workspace with customized .mdc personas
- Deploy BizFree Vercel + Render (from Sprint 0 templates)
- Add BizFree social accounts to Postiz
- Build 6 BizFree n8n workflows

**Summer 2026**:

- Ship BizFree MVP
- Build sankalpsharma.com venture studio page
- Add BizFree social accounts to Postiz
- Start BizFree content marketing

**$100K+ revenue (restructure trigger)**:

- Form holding company
- Convert products to subsidiary LLCs
- Separate bank accounts and bookkeeping

