---
name: Venture Master Strategy
overview: "The final, consolidated strategic plan for the [X]Free.ai venture: unified .ai domain strategy with migration plan, complete AI agent org chart for a one-human company, monorepo architecture with studio, and data-backed growth trajectory."
todos:
  - id: buy-domains
    content: Buy launchfree.ai + filefree.ai + launchfree.llc. Skip launchfree.biz.
    status: pending
  - id: migrate-filefree
    content: "Migrate filefree.tax to filefree.ai: Vercel config, DNS records, 301 redirects from .tax and taxfilefree.com"
    status: pending
  - id: google-workspace
    content: Set up Google Workspace on sankalpsharma.com ($6/mo). Add filefree.ai + launchfree.ai as secondary domains. Create aliases.
    status: pending
  - id: gdrive-mcp
    content: Create Google Drive Venture HQ folder structure. Add GDrive MCP to Cursor.
    status: pending
  - id: secure-handles
    content: Secure @launchfree on TikTok, Instagram, X, YouTube
    status: pending
  - id: form-llc
    content: Form LLC with neutral parent name
    status: pending
  - id: ws1-monorepo
    content: "WORKSTREAM 1: Restructure repo into pnpm workspace monorepo with apps/filefree, apps/launchfree, apps/studio, packages/ui+auth+analytics+data"
    status: pending
  - id: ws2-state-data
    content: "WORKSTREAM 2: Build 50-state LLC formation rules + 50-state tax calculations in packages/data. Build state engine. Set up n8n validation agents."
    status: pending
  - id: ws3-agents
    content: "WORKSTREAM 3: Build sankalpsharma.com. Build chat widget + support agents. Build LaunchFree social workflows. Migrate DNS subdomains. Wire all 12 new n8n agents."
    status: pending
isProject: false
---

# The [X]Free.ai Venture: Master Strategy

**Date**: March 11, 2026
**Model**: One human + AI agent workforce + partnerships co-founder
**Comparable**: Pieter Levels ($3.1M ARR, 6 products, zero employees, <$200/mo infra)

---

## 1. Domain Strategy: Unified .ai Brand Family

### The Decision

**Buy all three. Skip .biz.**


| Domain         | Action | Cost      | Role                                                |
| -------------- | ------ | --------- | --------------------------------------------------- |
| launchfree.ai  | BUY    | $159.96   | Primary domain for LaunchFree                       |
| filefree.ai    | BUY    | $159.96   | NEW primary domain for FileFree (migrate from .tax) |
| launchfree.llc | BUY    | $10.35    | Defensive redirect to launchfree.ai                 |
| launchfree.biz | SKIP   | --        | .biz has zero prestige, wastes $6                   |
| **Total**      |        | **~$331** |                                                     |


### Why Unified .ai

**The data:**

- Google treats .ai equally to .com for SEO -- zero ranking disadvantage
- .ai signals "AI-powered" which IS the differentiator vs LegalZoom/ZenBusiness/TurboTax
- .llc has <0.1% web adoption -- people don't recognize it as a TLD. Someone hearing "launchfree.llc" will type "launchfree.com"
- Brand family consistency compounds recognition: `filefree.ai` + `launchfree.ai` + `[future]free.ai`
- The ".ai" becomes part of the brand identity, not just a domain

**The pattern:**

```
filefree.ai      ->  "File free. AI does it."
launchfree.ai    ->  "Launch free. AI does it."
[book]free.ai    ->  Future: "Book free. AI does it."
[hire]free.ai    ->  Future: "Hire free. AI does it."
```

Every product name carries the value prop ("free") AND the differentiator (".ai") in the URL itself.

### Why Migrate filefree.tax NOW

**Now is the cheapest moment to change domains. It only gets more expensive.**

- FileFree is pre-launch: waitlist only, no significant organic traffic, no backlinks at scale
- 301 redirect from filefree.tax -> filefree.ai preserves 90-99% of any existing SEO value
- Google Search Console's "Change of Address" tool handles the transition cleanly
- filefree.tax stays as a permanent redirect (you already own it) -- anyone who bookmarked it still gets there
- taxfilefree.com also redirects to filefree.ai

If you wait until January 2027 with 50K users, marketing materials everywhere, and real SEO traffic -- migration becomes a six-figure risk. Do it now when it's a one-hour DNS change.

### Domain Architecture (Post-Purchase)

```
sankalpsharma.com       ->  Venture studio (Vercel) [OWNED]
  ops.sankalpsharma.com ->  n8n dashboard (Hetzner)
  social.sankalpsharma.com -> Postiz dashboard (Hetzner)

filefree.ai             ->  FileFree product (Vercel) [BUY + MIGRATE]
  api.filefree.ai       ->  FileFree API (Render)
filefree.tax            ->  301 redirect to filefree.ai [OWNED, KEEP]
taxfilefree.com         ->  301 redirect to filefree.ai [OWNED, KEEP]

launchfree.ai           ->  LaunchFree product (Vercel) [BUY]
  api.launchfree.ai     ->  LaunchFree API (Render)
launchfree.llc          ->  301 redirect to launchfree.ai [BUY, REDIRECT]
```

---

## 2. The One-Human Company: Agent Org Chart

### The Model is Already Proven

- **Pieter Levels**: $3.1M ARR, 6+ products, zero employees, <$200/mo infra
- **36.3% of all 2026 startups** are solo-founded (up from 22% in 2023)
- **Business Insider (Feb 2026)**: Solo founder runs company with 15 AI agents
- **Anthropic CEO Dario Amodei**: 70-80% confidence in a billion-dollar single-employee company by 2026

You're not building something unprecedented. You're building something that's just now becoming possible.

### Your Agent Workforce (Current + Planned)

**ALREADY BUILT (12 Cursor personas + 6 n8n workflows = 18 agents):**


| #   | Agent                    | Type                              | Status |
| --- | ------------------------ | --------------------------------- | ------ |
| 1   | Staff Engineer           | Cursor persona (engineering.mdc)  | Active |
| 2   | UX/UI Lead               | Cursor persona (ux.mdc)           | Active |
| 3   | Head of Growth           | Cursor persona (growth.mdc)       | Active |
| 4   | Social Media Manager     | Cursor persona (social.mdc)       | Active |
| 5   | Chief of Staff           | Cursor persona (strategy.mdc)     | Active |
| 6   | General Counsel          | Cursor persona (legal.mdc)        | Active |
| 7   | CFO                      | Cursor persona (cfo.mdc)          | Active |
| 8   | QA Lead                  | Cursor persona (qa.mdc)           | Active |
| 9   | Tax Domain Expert        | Cursor persona (tax-domain.mdc)   | Active |
| 10  | CPA / Tax Advisor        | Cursor persona (cpa.mdc)          | Active |
| 11  | Partnership Dev          | Cursor persona (partnerships.mdc) | Active |
| 12  | Brand Manager            | Cursor persona (brand.mdc)        | Active |
| 13  | Social Content Bot       | n8n autonomous workflow           | Active |
| 14  | Growth Content Bot       | n8n autonomous workflow           | Active |
| 15  | Strategy Check-in Bot    | n8n autonomous workflow           | Active |
| 16  | Partnership Outreach Bot | n8n autonomous workflow           | Active |
| 17  | CPA Review Bot           | n8n autonomous workflow           | Active |
| 18  | QA Security Scanner      | n8n autonomous workflow           | Active |


**TO BUILD (Workstream 3 + new agents = 12 more):**


| #   | Agent                     | Type               | Trigger           | Purpose                                             |
| --- | ------------------------- | ------------------ | ----------------- | --------------------------------------------------- |
| 19  | L1 Support (DocBot)       | n8n webhook        | User message      | Answer from knowledge base (60% resolution)         |
| 20  | L2 Support (OpsBot)       | n8n webhook        | DocBot escalation | Execute actions: check status, resend email (30%)   |
| 21  | State Data Validator      | n8n cron (monthly) | 1st of month      | Check 50 state websites for fee/rule changes        |
| 22  | IRS Update Monitor        | n8n cron (October) | Annual            | Parse new Revenue Procedure for bracket changes     |
| 23  | Competitive Intel         | n8n cron (weekly)  | Mondays           | Monitor LegalZoom/ZenBusiness/TurboTax changes      |
| 24  | Analytics Reporter        | n8n cron (weekly)  | Sundays           | Pull PostHog data, generate weekly metrics report   |
| 25  | Infra Health Monitor      | n8n cron (hourly)  | Continuous        | Check Render/Vercel/Hetzner status, alert on issues |
| 26  | Affiliate Revenue Tracker | n8n cron (daily)   | Daily             | Check affiliate dashboards, report conversions      |
| 27  | LaunchFree Social Bot     | n8n cron (daily)   | 8am               | Draft LaunchFree social content for Postiz          |
| 28  | LaunchFree Growth Bot     | n8n cron (weekly)  | Mondays           | Draft LaunchFree SEO articles                       |
| 29  | LaunchFree Compliance Bot | n8n cron (monthly) | 1st               | State filing deadline alerts for users              |
| 30  | Knowledge Base Sync       | n8n cron (nightly) | 2am               | Sync Google Drive docs to support agent context     |


**Total: 30 agents. One human makes decisions. Wife closes partnerships.**

### The Three Layers

```mermaid
graph TB
  subgraph layer1 ["Layer 1: Strategy (Human)"]
    founder["Founder (You)"]
    cofounder["Co-founder (Partnerships)"]
  end

  subgraph layer2 ["Layer 2: Execution (AI Agents)"]
    subgraph cursorAgents ["Cursor Personas (12)"]
      eng["Engineering"]
      growth["Growth"]
      legal["Legal"]
      cfo["CFO"]
      qa["QA"]
      others["+ 7 more"]
    end
    subgraph n8nAgents ["n8n Autonomous (18)"]
      social["Social Bots x2"]
      support["Support Bots x2"]
      monitors["Monitors x5"]
      content["Content Bots x4"]
      ops["Ops Bots x5"]
    end
  end

  subgraph layer3 ["Layer 3: Infrastructure"]
    hetzner["Hetzner VPS (n8n, Postiz)"]
    vercel["Vercel x3 (sites)"]
    render["Render x2 (APIs)"]
    gworkspace["Google Workspace"]
    openai["OpenAI API"]
  end

  founder -->|"Decisions + Code"| cursorAgents
  cofounder -->|"Relationships"| n8nAgents
  cursorAgents -->|"Ship code"| layer3
  n8nAgents -->|"Autonomous ops"| layer3
```



### Human vs Agent Responsibilities

**Only the human does:**

- Strategic decisions (which product, which market, which partnerships)
- Recording video content (face on camera = trust)
- Signing legal agreements / filings
- Final approval on AI-drafted content (5-min daily review in Postiz)
- Responding to L3 escalated support tickets (<5% of volume)
- IRS/state government interactions (EFIN, RA filings)

**Agents do everything else:**

- Write all code (Cursor)
- Draft all content (n8n + GPT)
- Schedule all social posts (n8n + Postiz)
- Handle 95% of support (n8n + chat widget)
- Monitor all infrastructure (n8n)
- Track all revenue/analytics (n8n)
- Research competitors (n8n)
- Draft partnership emails (n8n)
- Validate tax/formation data (n8n)
- Run QA/security scans (n8n)

---

## 3. Monorepo Architecture (Confirmed)

**Yes, sankalpsharma.com is `apps/studio/` in the monorepo.** It shares `packages/ui` (dark theme, shadcn components) and `packages/analytics` (PostHog tracking). Three apps, shared packages, three independent APIs.

```
venture/
  apps/
    filefree/         (filefree.ai - Next.js)
    launchfree/       (launchfree.ai - Next.js)
    studio/           (sankalpsharma.com - Next.js)
  packages/
    ui/               (22 shadcn components + theme)
    auth/             (shared auth flows)
    analytics/        (PostHog + attribution)
    data/             (50-state formation + tax data + engine)
  apis/
    filefree-api/     (Python/FastAPI)
    launchfree-api/   (Python/FastAPI)
  infra/              (Hetzner, Docker, render.yaml)
  pnpm-workspace.yaml
```

Each `apps/` directory has its own `.cursor/rules/` with product-specific personas. When working in Cursor, open the specific app directory as workspace root for focused AI context.

---

## 4. Growth Trajectory (Data-Backed)

### Revenue Model Per Product

**LaunchFree** (Year 1 -- Summer 2026 launch):

- Free LLC formation (acquisition channel)
- Revenue: RA credits ($49/yr base, free via partner actions), banking referrals ($50-100/funded), payroll referrals (Gusto, $100+/referral), insurance referrals ($30-50/referral)
- Target: 5K formations by Dec 2026, 2% RA conversion = 100 paying RA customers
- Year 1 revenue estimate: $20K-50K (conservative, referral ramp-up)

**FileFree** (Year 1 -- January 2027 launch):

- Free tax filing (acquisition channel)
- Revenue: Refund routing to HYSA ($50-100/funded), financial referrals, audit shield ($19-29/yr), Tax Optimization Plan ($29/yr)
- Target: 30K filers by April 2027 (Scenario B)
- Year 1 revenue estimate: $242K (Scenario B, per existing PRD)

**Combined Year 1**: $262K-292K
**Combined Year 2**: $500K-800K (cross-sell kicks in: LaunchFree users -> FileFree Schedule C)

### The Pieter Levels Benchmark

Pieter does $3.1M ARR across 6 products with zero employees and <$200/mo infra. Your target:


| Metric     | Pieter Levels  | Your Venture (Year 2) |
| ---------- | -------------- | --------------------- |
| Products   | 6              | 2 (+ future)          |
| Revenue    | $3.1M ARR      | $500K-800K ARR        |
| Employees  | 0              | 0 (+1 partnerships)   |
| Infra cost | <$200/mo       | ~$46/mo               |
| AI agents  | Scripts + cron | 30 structured agents  |


You're more systematized (structured agent org chart vs ad-hoc scripts) and your products have higher ARPU (financial services vs SaaS tools). The trajectory to $1M ARR by Year 2-3 is realistic with the referral model.

---

## 5. Immediate Actions (This Week)

1. **Buy domains**: launchfree.ai + filefree.ai + launchfree.llc (skip .biz)
2. **Migrate FileFree**: Point filefree.ai to Vercel, 301 redirect filefree.tax -> filefree.ai, update Render/DNS
3. **Set up Google Workspace** on sankalpsharma.com, add filefree.ai + launchfree.ai as secondary domains
4. **Create Google Drive** "Venture HQ" folder, add GDrive MCP to Cursor
5. **Secure @launchfree** social handles (TikTok, IG, X, YouTube)
6. **Form LLC** (Sharma Ventures LLC or similar)

Then proceed to the three coding workstreams from the previous plan:

- Workstream 1: Monorepo restructure
- Workstream 2: 50-state data + shared infrastructure
- Workstream 3: sankalpsharma.com + agent operations

