---
name: B2B CPA Integration Plan
status: archived
overview: "ARCHIVED — All 10 todos completed. Content integrated into Venture Master Plan Section 1C, Phase 9. 'FileFree Pro' subsequently renamed to 'Distill' (distill.tax) in the Distill Brand + Round 4 plan."
todos:
  - id: add-section-1c-pro
    content: "Add Section 1C: FileFree Pro -- B2B CPA automation product spec, pricing tiers, competitive positioning vs MagneticTax, tech delta"
    status: completed
  - id: add-phase-9
    content: "Add Phase 9 tasks (P9.1-P9.7) for FileFree Pro: CPA onboarding, bulk upload, professional dashboard, tax software export, Stripe B2B billing, landing page, outreach"
    status: completed
  - id: update-competitor-table
    content: Add MagneticTax to Section 4O competitor landscape table with threat assessment
    status: completed
  - id: fix-self-review
    content: Fix 6 MEDIUM self-review findings (F13-F18) in VENTURE_MASTER_PLAN.md and PARTNERSHIPS.md
    status: completed
  - id: business-tax-section
    content: Add business tax filing (1065, 1120-S) to form coverage roadmap and both consumer + Pro product lines
    status: completed
  - id: growth-playbook
    content: Upgrade Section 5K with 4 growth channels (tax season surge, B2B API, community-led, B2B CPA outreach) and 2M-user projections
    status: completed
  - id: financials-update
    content: Update FINANCIALS.md with B2B SaaS revenue line, business filing revenue, and B2B API revenue
    status: completed
  - id: knowledge-decisions
    content: Add D67 (Business Tax Filing), D68 (Growth Playbook), D69 (FileFree Pro B2B) to KNOWLEDGE.md
    status: completed
  - id: journey-path-e
    content: Add PATH E (LaunchFree -> FileFree Business cross-sell) to Section 4F
    status: completed
  - id: founder-side-projects
    content: Add business tax filing GO/NO-GO evaluation to FOUNDER_SIDE_PROJECTS.md
    status: completed
isProject: false
---

# Integrate B2B CPA Automation ("FileFree Pro") into Venture Master Plan

## Why This Is a Near-Free Revenue Layer

The entire B2B CPA product is a **different frontend on the same backend**. The tech overlap with consumer FileFree is ~80%:

```mermaid
flowchart TB
    subgraph sharedCore ["Shared Core (Already Building)"]
        OCR["OCR Pipeline\nCloud Vision + GPT"]
        Extract["Field Extraction\nW-2, 1099, 1040"]
        TaxCalc["Tax Calculation Engine\n50-state"]
        Storage["Document Storage\nGCP Cloud Storage"]
    end

    subgraph consumerApp ["Consumer: FileFree (Free)"]
        UserUpload["User uploads W-2"]
        Review["Review + confirm fields"]
        File["File return (MeF)"]
    end

    subgraph proApp ["B2B: FileFree Pro ($49-199/mo)"]
        BulkUpload["CPA bulk uploads\nclient documents"]
        ProDashboard["Professional dashboard\nmulti-client management"]
        Export["Export to UltraTax\nDrake, ProConnect"]
    end

    UserUpload --> OCR
    BulkUpload --> OCR
    OCR --> Extract
    Extract --> TaxCalc
    TaxCalc --> Review
    TaxCalc --> ProDashboard
    Review --> File
    ProDashboard --> Export
```



**Delta to build (B2B-specific)**: ~2-3 weeks of engineering on top of Phase 7.

## What Gets Added to the Master Plan

### 1. Section 1C: FileFree Pro -- B2B Tax Automation for CPAs

Add to [docs/VENTURE_MASTER_PLAN.md](docs/VENTURE_MASTER_PLAN.md) after Section 1B.3:

- **What**: SaaS product for CPA firms and tax professionals. Upload client W-2s/1099s, auto-extract fields via shared OCR pipeline, export to professional tax software.
- **Pricing**: $49/mo (Solo, 1 preparer, 50 returns/mo), $99/mo (Team, 3 preparers, 200 returns/mo), $199/mo (Firm, unlimited, 500+ returns/mo, API access)
- **Competitive positioning vs MagneticTax**: MagneticTax (YC S25) does the same thing but is pre-revenue and VC-funded. We build the same core pipeline for consumer FileFree anyway -- the B2B product is marginal cost.
- **Revenue model**: Pure SaaS. No marketplace needed. Revenue from month 1.
- **Tech delta**: Multi-tenant team management, bulk document upload, professional tax software export (CSV/XML import formats for UltraTax, Drake, ProConnect, Lacerte), CPA dashboard (new `apps/filefree-pro/` in monorepo or new route group in existing `apps/filefree/`)

### 2. Revenue Projections (Immediate Revenue)


| Scenario          | CPA Firms | Avg Plan | Monthly Rev | Annual Rev |
| ----------------- | --------- | -------- | ----------- | ---------- |
| Conservative (Y1) | 30        | $79/mo   | $2,370      | **$28K**   |
| Moderate (Y1)     | 100       | $99/mo   | $9,900      | **$119K**  |
| Aggressive (Y1)   | 300       | $129/mo  | $38,700     | **$464K**  |


This is **immediate, predictable SaaS revenue** -- not marketplace ARPU that requires scale. It starts the moment a CPA firm signs up. Tax season (Jan-Apr) creates natural urgency. Off-season: CPAs do extensions, amendments, prior-year returns, so there's year-round demand.

### 3. Phase 9: FileFree Pro (December 2026 - January 2027)

New phase tasks to add to Section 7, directly after Phase 8:


| Task                           | Details                                                                                                                        |
| ------------------------------ | ------------------------------------------------------------------------------------------------------------------------------ |
| P9.1 CPA onboarding flow       | Firm registration, team invites, role management (admin/preparer/reviewer)                                                     |
| P9.2 Bulk document upload      | Drag-and-drop multiple W-2s/1099s, queue through shared OCR pipeline, progress tracking                                        |
| P9.3 Professional dashboard    | Client list, per-client document status, extraction results, accuracy indicators                                               |
| P9.4 Tax software export       | Generate import files for UltraTax (CSV), Drake (XML), ProConnect (CSV), Lacerte (CSV). These are publicly documented formats. |
| P9.5 Stripe B2B billing        | Monthly subscription plans, seat-based billing, usage metering (returns/mo)                                                    |
| P9.6 CPA-specific landing page | filefree.ai/pro or pro.filefree.ai. SEO: "AI tax preparation software for CPAs"                                                |
| P9.7 CPA outreach campaign     | Target independent CPAs and small firms (1-10 preparers). LinkedIn + direct email. Tax season urgency.                         |


**Timeline**: Phase 9 starts December 2026 (after Phase 7 OCR pipeline is built). Launches January 2027 alongside consumer FileFree. Same tax season, two products, one pipeline.

### 4. Competitor Landscape Update (Section 4O)

Add MagneticTax to the competitor table:


| Competitor      | Model                                                                                   | Threat Level                               | Our Advantage                                                                                                                                                                                                 |
| --------------- | --------------------------------------------------------------------------------------- | ------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **MagneticTax** | B2B AI tax prep for CPAs. YC S25. Automates 1040 data entry into existing tax software. | LOW-MEDIUM (indirect, same tech direction) | We build the same OCR/extraction pipeline for consumer filing anyway -- B2B is marginal cost. They're VC-funded with burn; we're bootstrapped with consumer filing as acquisition funnel for the Pro product. |


### 5. Update FINANCIALS.md

Add B2B SaaS revenue line to the revenue projections table, showing it as a separate line item from consumer FileFree marketplace revenue. This is the first revenue stream that does NOT depend on user scale.

### 6. Knowledge Decision (D67 or D69)

Add to [docs/KNOWLEDGE.md](docs/KNOWLEDGE.md):

- **Decision**: Add B2B CPA automation ("FileFree Pro") as a SaaS product leveraging shared OCR pipeline
- **Rationale**: ~~80% tech overlap with consumer FileFree. Immediate SaaS revenue vs. marketplace revenue that requires scale. MagneticTax validates the market. Marginal engineering cost (~~2-3 weeks on top of Phase 7).
- **Alternatives**: (a) API-only (Tax-as-a-Service for other platforms -- already in growth playbook, different audience), (b) Skip B2B entirely and focus on consumer marketplace (slower to revenue)

### 7. Integrate with Pending Todos

This plan ALSO executes the 7 pending todos from the previous conversation:

- Fix 6 MEDIUM self-review findings (F13-F18)
- Add business tax filing (1065, 1120-S) -- now part of both consumer and Pro product roadmap
- Growth playbook upgrade (3 channels + B2B CPA as 4th channel)
- PATH E (LaunchFree -> FileFree Business cross-sell)
- FINANCIALS.md update (now includes B2B SaaS line)
- Knowledge decisions (D67-D69)
- FOUNDER_SIDE_PROJECTS.md update

## Key Architectural Decision

**Where does FileFree Pro live in the monorepo?**

Two options:

- **Option A**: New app `apps/filefree-pro/` with its own Next.js app and Vercel deployment at `pro.filefree.ai`
- **Option B**: Route group inside `apps/filefree/` at `/pro/`* with middleware-based auth (CPA vs consumer)

Recommendation: **Option A** (separate app). Different users (CPAs vs consumers), different UX patterns (bulk operations vs single-file flow), different billing (SaaS vs free). Shares `packages/` (OCR, tax-calc, UI) via monorepo. Clean separation, independent deployment.

## Summary: Why This Is a No-Brainer

1. **~80% shared tech** -- you're building the pipeline anyway
2. **Immediate SaaS revenue** -- CPAs pay monthly, no marketplace scale required
3. **~2-3 weeks marginal engineering** on top of Phase 7
4. **Validates your tech** with demanding professional users before consumer launch
5. **MagneticTax proves the market** -- YC funded this exact idea
6. **Same tax season launch** -- January 2027 for both consumer and Pro

