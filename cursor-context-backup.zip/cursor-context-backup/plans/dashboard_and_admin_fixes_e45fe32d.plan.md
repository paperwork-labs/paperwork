---
name: Dashboard and Admin Fixes
overview: Fix missing symbol fundamentals, resolve red health dimensions, surface Render cron schedules in the Schedules page, and redesign the MarketDashboard into an insight-driven market intelligence view with sector rotation, trading setups, and breadth gauges.
todos:
  - id: fill-fundamentals
    content: Add admin endpoint + UI button for fill_missing_snapshot_fundamentals task
    status: pending
  - id: repair-stage-button
    content: Add "Repair Stage History" UI button wired to existing POST /market-data/admin/stage/repair endpoint
    status: pending
  - id: fix-stage-red
    content: Fix monotonicity checker in stage_quality_summary to compare consecutive trading days only (skip weekends/holidays)
    status: pending
  - id: fix-audit-red
    content: Add Render cron job for audit_market_data_quality in render.yaml
    status: pending
  - id: fix-schedules
    content: Show static Celery Beat schedule definitions on Schedules page even when ENABLE_CELERY_BEAT is false
    status: pending
  - id: update-runbook
    content: Update AdminRunbook stage_quality and audit fix text to reference new buttons and missing audit data scenario
    status: pending
  - id: dashboard-backend
    content: Enhance sector_etf_table with 5D/20D/RS; add entering Stage 3/4 lists; ensure all regime breadth data is surfaced
    status: pending
  - id: dashboard-frontend
    content: Redesign MarketDashboard.tsx with Market Pulse hero, Sector Rotation heatmap table, Trading Setups cards, Stage Transitions, and improved matrices
    status: pending
isProject: false
---

# Dashboard Redesign and Admin Fixes

## Issue 1: Missing Name/Sector/Industry for 28 Symbols

**Root Cause**: 28 out of 581 tracked symbols have NULL `name`, `sector`, and `industry` in `market_snapshot`. These are all legitimate stocks (AAPL, ADBE, AMD, etc.) that failed FMP fundamentals fetch due to rate limiting during the initial `recompute_indicators_universe` run.

**Fix**:

- Expose the existing `fill_missing_snapshot_fundamentals` Celery task as a new admin endpoint in [backend/api/routes/market_data.py](backend/api/routes/market_data.py) -- add `POST /market-data/admin/fundamentals/fill-missing` calling `_enqueue_task(fill_missing_snapshot_fundamentals)`
- Add a "Fill Missing Fundamentals" button to [frontend/src/components/admin/AdminOperatorActions.tsx](frontend/src/components/admin/AdminOperatorActions.tsx) in the Compute section
- This task already exists in [backend/tasks/market_data_tasks.py](backend/tasks/market_data_tasks.py) (line 242) and does DB-first lookup then FMP/yfinance fallback -- it just needs an API route and UI trigger
- Add entry to `taskEndpoints` map in `runNamedTask`: `admin_fundamentals_fill_missing` -> `POST /market-data/admin/fundamentals/fill-missing`

**Also add**: "Repair Stage History" button wired to the existing `POST /market-data/admin/stage/repair` endpoint (line 1127 of [market_data.py](backend/api/routes/market_data.py)). This calls `repair_stage_history_window()` which recomputes `current_stage_days`, `previous_stage_label`, `previous_stage_days` across the last N days of `market_snapshot_history`. Add to `taskEndpoints` map: `admin_stage_repair` -> `POST /market-data/admin/stage/repair`

---

## Issue 2: Stage Quality and Audit Red

**Stage Quality -- RED because of 42 monotonicity issues**

The `stage_quality_summary()` in [backend/services/market/market_data_service.py](backend/services/market/market_data_service.py) (line 2135) checks `market_snapshot_history` for monotonicity: within a stage, `current_stage_days` must increment by exactly 1 each day; on stage transition it must reset to 1. The threshold is `stage_monotonicity_max: 0`. The 42 violations are false positives from weekends/holidays -- the checker currently expects `+1` between every consecutive row, but `market_snapshot_history` only has rows for trading days, so Friday->Monday naturally jumps by 3 calendar days.

**Fix**: Modify the monotonicity loop in `stage_quality_summary()` (lines 2217-2236) to compare consecutive *rows* in the series (which are already sorted by `as_of_date` ascending) using the delta between rows rather than expecting exactly `+1`. Specifically:

- When `norm == prev_norm`: expect `cur_days == prev_days + 1` **only if** consecutive rows are exactly 1 calendar day apart. If the gap is >1 day (weekend/holiday), allow `cur_days == prev_days + gap_trading_days` or simply skip the check for that pair.
- Simplest correct approach: since `current_stage_days` is computed as a running count of trading days in the stage, consecutive trading-day rows should always show `+1`. The real fix is to track the `as_of_date` in the loop and only flag a monotonicity issue when the date gap is exactly 1 calendar day (i.e., it's a true consecutive trading day) but the days counter doesn't match.

The loop currently discards the date (`for _, stage_label, current_days in series`). Change it to `for dt, stage_label, current_days in series` and compare `(dt - prev_dt).days`. When the gap is >1 calendar day, accept any `cur_days > prev_days` (same stage) or `cur_days >= 1` (new stage) without requiring exact `+1`.

**Audit -- RED because no audit data exists**

The `_build_audit_dimension()` reads Redis key `market_audit:last` (line 209 of [admin_health_service.py](backend/services/market/admin_health_service.py)). This key is populated by the `audit_market_data_quality` task, which is only defined in the Celery Beat static schedule (02:45 UTC) -- but Celery Beat is **disabled** in production (`ENABLE_CELERY_BEAT=false`). There is no corresponding Render Cron Job for it.

**Fix**: Add a Render Cron Job for `audit_market_data_quality` in [render.yaml](render.yaml) (same pattern as the existing cron jobs), so the audit runs nightly.

### Runbook Improvements ([AdminRunbook.tsx](frontend/src/components/admin/AdminRunbook.tsx))

#### Structural improvements

1. **Replace wall-of-text `fix` strings with structured steps.** Change `RunbookEntry.fix` from `string` to `string[]` (array of numbered steps). Render each step as a numbered list item. This makes the runbook scannable during an incident instead of a paragraph to parse.
2. **Make `stage_quality` context-aware.** The stage dimension has 3 independent failure modes (unknowns, invalid rows, monotonicity) -- each with a different fix. Instead of showing all steps regardless, accept the health dimension data and only show relevant steps. Change the interface to:

```typescript
interface RunbookEntry {
  what: string;
  steps: string[];
  contextualSteps?: (dim: Record<string, unknown>) => string[];
  threshold: (thresholds: Record<string, number>) => string;
}
```

When `contextualSteps` is provided, it receives the dimension data and returns only the relevant steps. For `stage_quality`, this means:

- If `unknown_rate` is high -> "Run Recompute Indicators"
- If `monotonicity_issues > 0` -> "Run Repair Stage History"
- If `invalid_count > 0` -> "Check for corrupt data in Admin > Jobs"
- Always -> "If daily bars are missing, backfill first"

1. **Surface actual metric values inline.** Below the steps, show which sub-thresholds are passing vs failing with their actual values, e.g.:

```
Unknown rate: 0.17% (ok)    Invalid rows: 0 (ok)    Monotonicity: 42 (FAILING)
```

This eliminates guesswork about *why* the dimension is red.

#### Per-entry content updates

`**coverage**` -- **keep steps, minor restructure**:

1. Click "Refresh Coverage" in Safe Actions.
2. If stale, try "Backfill Daily Coverage (Tracked)" or "Backfill Daily (Stale Only)" in Backfill Actions.
3. Check Admin > Jobs for failed coverage tasks.
4. Check Admin > Schedules to verify the hourly coverage monitor is active.

`**stage_quality**` -- **rewrite with context-aware steps**:

- Unknown rate high: "Run 'Recompute Indicators (Market Snapshot)' under Show Advanced > Maintenance. If unknowns persist, daily bars may be missing -- run 'Backfill Daily Coverage (Tracked)' first."
- Monotonicity issues: "Run 'Repair Stage History' under Show Advanced > Maintenance to recompute stage duration fields across history."
- Missing fundamentals: "Run 'Fill Missing Fundamentals' under Show Advanced > Maintenance."
- Fallback: "Check Admin > Jobs for specific task errors."

`**jobs**` -- **correct as-is, just convert to steps**:

1. Go to Admin > Jobs to inspect the failed task and error message.
2. Re-trigger the task from Operator Actions (Safe or Backfill sections).
3. If the error is environmental (API key, network), fix the root cause. The schedule auto-retries on the next cron tick.

`**audit**` -- **add missing-data scenario**:

1. If audit shows "no audit data in cache": the audit task has not run yet. Check Admin > Schedules to ensure `audit_market_data_quality` is scheduled, or trigger it manually.
2. For low daily fill: run "Backfill Daily Coverage (Tracked)" from Backfill Actions.
3. For low snapshot fill: open Show Advanced and run "Backfill Snapshot History (period)".
4. If specific symbols are listed as missing, verify they are still tracked in Market > Tracked.

---

## Issue 3: Schedules Page Shows Nothing

**Root Cause**: The [AdminSchedules.tsx](frontend/src/pages/AdminSchedules.tsx) page fetches from `GET /admin/schedules`, which reads from RedBeat (Redis) and static `beat_schedule`. In production:

- `ENABLE_CELERY_BEAT=false` -> `beat_schedule = {}` (empty)
- `ENABLE_REDBEAT=false` -> no RedBeat entries

The actual scheduling runs via **Render Cron Jobs** (7 separate Docker containers in [render.yaml](render.yaml)), which are completely invisible to the Celery Beat system.

**Fix**: Modify the `GET /admin/schedules` endpoint in [backend/api/routes/admin_scheduler.py](backend/api/routes/admin_scheduler.py) to also surface the static Celery Beat schedule definitions even when `ENABLE_CELERY_BEAT` is False. The static definitions in [celery_app.py](backend/tasks/celery_app.py) serve as the source of truth for what *should* run, regardless of the scheduler backend. Additionally, add a `source` indicator so the UI can distinguish between RedBeat-managed, static, and infrastructure-managed (Render) schedules.

---

## Issue 4: MarketDashboard Redesign

### Current State

The current [MarketDashboard.tsx](frontend/src/pages/MarketDashboard.tsx) displays only a fraction of the data the backend computes. The backend `build_dashboard()` in [market_dashboard_service.py](backend/services/market/market_dashboard_service.py) already returns:


| Data                                              | Currently Displayed? |
| ------------------------------------------------- | -------------------- |
| `regime.stage_counts_normalized`                  | Yes (badges)         |
| `entry_proximity_top`                             | Yes                  |
| `exit_proximity_top`                              | Yes                  |
| `sector_etf_table`                                | Yes (1D only)        |
| `entering_stage_2a`                               | Yes                  |
| `top10_matrix` / `bottom10_matrix`                | Yes                  |
| `leaders` (momentum scored)                       | **No**               |
| `setups.breakout_candidates`                      | **No**               |
| `setups.pullback_candidates`                      | **No**               |
| `setups.rs_leaders`                               | **No**               |
| `sector_momentum` (avg 20D, RS by sector)         | **No**               |
| `action_queue` (notable movers)                   | **No**               |
| `regime.above_sma50_count` / `above_sma200_count` | **No**               |
| `regime.up_1d_count` / `down_1d_count`            | **No**               |
| `coverage`                                        | **No**               |


### Redesigned Layout

```mermaid
flowchart TB
  subgraph hero [Market Pulse - Hero Section]
    breadthGauge["Breadth Gauges: % above 50DMA, 200DMA"]
    advDec["Advance/Decline: up vs down count"]
    stageBar["Stage Distribution: horizontal stacked bar"]
  end

  subgraph rotation [Sector Rotation - Money Flow]
    sectorHeat["Enhanced Sector ETF Table: 1D, 5D, 20D, Stage, RS, Days"]
    sectorMom["Sector Momentum Rankings: avg 20D perf + avg RS by sector"]
  end

  subgraph setups [Trading Setups - Actionable]
    breakout["Breakout Candidates"]
    pullback["Pullback Buys"]
    rsLeaders["RS Leaders"]
    momLeaders["Momentum Leaders"]
  end

  subgraph transitions [Stage Transitions]
    entering2A["Entering Stage 2A (buy signals)"]
    entering34["Entering Stage 3/4 (warning/sell signals)"]
  end

  subgraph matrices [Ranked Metrics]
    top10["Top 10 Matrix"]
    bottom10["Bottom 10 Matrix"]
  end

  hero --> rotation --> setups --> transitions --> matrices
```



### Backend Changes ([market_dashboard_service.py](backend/services/market/market_dashboard_service.py))

1. **Enhance `sector_etf_table**`: Add `perf_5d`, `perf_20d`, `rs_mansfield_pct`, `current_stage_days`, `atrx_sma_50` for each sector ETF (data already available in `_SummaryRow`)
2. **Add stage transition lists**: Not just "entering 2A" but also "entering Stage 3" and "entering Stage 4" (sell/short warnings)
3. **Surface breadth metrics**: Ensure `regime.above_sma50_count`, `above_sma200_count`, `up_1d_count`, `down_1d_count` are explicitly included (they already are, just need frontend)

### Frontend Changes ([MarketDashboard.tsx](frontend/src/pages/MarketDashboard.tsx))

**Section 1 -- Market Pulse (hero)**

- Compact card row showing 4 key metrics: % above 50DMA, % above 200DMA, advance/decline ratio, total tracked count
- Stage distribution as a colored horizontal stacked bar chart (1, 2A, 2B, 2C, 3, 4) with counts and percentages
- Color-coded regime indicator (bullish when >60% above 50DMA, bearish when <40%)

**Section 2 -- Sector Rotation (money flow)**

- Expanded sector ETF table with columns: Sector, Stage, Days, 1D%, 5D%, 20D%, RS
- Heat-map style cell coloring (green for positive, red for negative, intensity by magnitude)
- Sorted by 20D momentum by default, with column sorting
- Sector momentum summary from the `sector_momentum` data (stocks aggregated by GICS sector)

**Section 3 -- Trading Setups**

- Three-card horizontal layout: Breakout Candidates, Pullback Buys, RS Leaders
- Each card shows top 5-8 symbols with: symbol, stage, perf_1d, perf_20d, RS Mansfield
- Momentum Leaders card showing top 12 by composite momentum score

**Section 4 -- Stage Transitions**

- Two-column layout: "Entering Stage 2A" (bullish) and "Entering Stage 3/4" (warnings)
- Each shows symbol, previous stage, days in new stage

**Section 5 -- Ranked Metrics Matrix**

- Keep existing Top/Bottom 10 matrices
- Add stage badge next to each symbol for context

**Section 6 -- Entry/Exit Proximity** (moved lower since it requires manual price setting)

- Keep existing but show empty-state more gracefully

