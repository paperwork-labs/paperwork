---
name: Admin Dashboard Improvements
overview: Comprehensive admin surface improvement -- unified coverage visualization, semantic colors, runbook panel, schedule visibility fix, jobs filtering, route protection fix, and dead code cleanup.
todos:
  - id: coverage-strip
    content: Replace CoverageDailyHistogram + CoverageSparklineView + toggle with unified CoverageHealthStrip in components/coverage/ (shared). Also replace duplicate histogram in MarketCoverage.tsx.
    status: completed
  - id: semantic-colors
    content: Replace colorScheme green/red with status.success/danger/warning semantic tokens in AdminHealthBanner and AdminDomainCards
    status: completed
  - id: runbook-panel
    content: Create AdminRunbook.tsx component with per-dimension explanations and remediation steps, add to AdminDashboard below health banner
    status: completed
  - id: static-schedules
    content: Merge static beat_schedule entries into the admin_scheduler list_schedules response even when RedBeat is active
    status: completed
  - id: jobs-filter
    content: Add exclude_task query param to backend /admin/jobs endpoint, add toggle in AdminJobs UI to hide coverage refresh jobs by default
    status: completed
  - id: route-guard-fix
    content: Fix App.tsx settings route - remove RequireNonMarketAccess wrapping settings, move RequireAdmin to only wrap admin/* child routes
    status: completed
  - id: dead-code-cleanup
    content: Delete placeholder GET /admin/system/status endpoint and old chart component files
    status: completed
  - id: tests-update
    content: Update frontend tests for CoverageHealthStrip, runbook, color changes, and route guard fix
    status: completed
isProject: false
---

# Admin Dashboard Improvements Round 2

## Audit Findings

Full audit of admin surface (4 frontend pages, 6 components, 4 backend route files, 30+ endpoints).

### What's Working Well

- Health service architecture is solid (single endpoint, typed thresholds, strict composite)
- Component decomposition from round 1 is clean (AdminDashboard went from 1145 to ~390 lines)
- Job catalog and schedule metadata system are well-designed

### Issues Found

**Route protection bug** (`[App.tsx:89-103](frontend/src/App.tsx)`):

- `RequireAdmin` wraps the entire `/settings` path, blocking non-admin users from profile/preferences/brokerages/security
- Settings is also wrapped in `RequireNonMarketAccess section="portfolio"` -- semantically wrong, settings is not a "portfolio" feature
- Admin bypasses both guards anyway (RequireNonMarketAccess line 14), so the guards are redundant noise for the admin case
- When non-admin users are added, they will not be able to access their own settings

**Static beat schedules invisible** (`[celery_app.py](backend/tasks/celery_app.py)` vs `[admin_scheduler.py](backend/api/routes/admin_scheduler.py)`):

- 5 static schedules defined in `celery_app.py` (coverage refresh hourly, coverage backfill at 03:00, etc.)
- `list_schedules` only returns RedBeat entries when RedBeat is active, drops static ones
- Explains why Jobs shows hourly runs but Schedules page shows nothing

**Coverage chart in wrong directory:**

- `CoverageDailyHistogram.tsx` and `CoverageSparklineView.tsx` live in `components/admin/` but are shared with the public `MarketCoverage.tsx` page
- Should live in `components/coverage/` alongside `CoverageSummaryCard.tsx`

**Dead code:**

- `GET /admin/system/status` in `[admin.py](backend/api/routes/admin.py)` returns hard-coded placeholder. Only referenced in RBAC test.

**Duplicate task definitions (noted, not fixing):**

- `TASK_ACTIONS` in `market_data.py` (line 91) and `CATALOG` in `job_catalog.py` (line 40) are parallel lists that can drift apart

### Deferred (too big for this round)

- Route restructuring (`/market-data/admin/*` -> `/admin/market-data/*`) -- breaking change
- Admin audit log / action history
- Consolidating TASK_ACTIONS and CATALOG into single source of truth

---

## Plan

### 1. Unified Coverage Health Strip

Replace both chart views and the toggle with one compact `CoverageHealthStrip`:

```
[  heatmap cells: 1 per trading day, HSL red-to-green by fill %  ]
[  snapshot dots: green/orange/red/gray per day                   ]  Latest: 98.2%  [~~sparkline~~]
```

- **Heatmap cells**: ~14px tall, `flex: 1 0 0` width, HSL gradient, native `title` for hover
- **Snapshot dots**: 4px circles, semantic colors (`status.success`/`warning`/`danger`/`fg.subtle`)
- **Inline sparkline**: 80x20 SVG path + latest value text, right-aligned
- **Window picker**: Kept (50d / 100d / 200d)
- **~30px total height** vs current ~60px + legend. No toggle needed.

**File changes:**

- Create `[frontend/src/components/coverage/CoverageHealthStrip.tsx](frontend/src/components/coverage/CoverageHealthStrip.tsx)` (new, in coverage dir since it's shared)
- Delete `CoverageDailyHistogram.tsx` and `CoverageSparklineView.tsx` from `components/admin/`
- Update `[AdminDashboard.tsx](frontend/src/pages/AdminDashboard.tsx)`: use CoverageHealthStrip, remove toggle state and both chart imports
- Update `[MarketCoverage.tsx](frontend/src/pages/MarketCoverage.tsx)`: replace inline ~90-line histogram with shared component
- Update `components/admin/index.ts`: remove old exports

### 2. Semantic status colors

Replace `colorScheme="green"/"red"` with theme tokens (`[system.ts:159-176](frontend/src/theme/system.ts)`):

- `[AdminHealthBanner.tsx](frontend/src/components/admin/AdminHealthBanner.tsx)`: `STATUS_COLOR` map, per-dimension badges
- `[AdminDomainCards.tsx](frontend/src/components/admin/AdminDomainCards.tsx)`: `DimBadge` component

For badges: `colorPalette="green"/"red"/"orange"`. For text/icons: `color="status.success"` etc.

### 3. Runbook panel

New `[AdminRunbook.tsx](frontend/src/components/admin/AdminRunbook.tsx)`:

- Collapsible "Runbook / On-Call Guide" below health banner
- Reads `health.dimensions` -- only shows RED dimensions with:
  - **What** (1 sentence)
  - **Fix** (which button/page, with link to Admin Jobs/Schedules where relevant)
  - **Threshold** (from `health.thresholds`)
- When all green: "All systems healthy -- no action needed"
- No new API calls

### 4. Surface static beat schedules

In `[admin_scheduler.py](backend/api/routes/admin_scheduler.py)` `list_schedules` (line 104-166):

- After building RedBeat list, also iterate `celery_app.conf.beat_schedule`
- Append entries whose task is not already present (match by dotted task path)
- Tag with `source: "static"`, `enabled: True`
- Parse crontab object to extract cron expression. Include `last_run` lookup.

Surfaces 5 static schedules:

- `admin_coverage_refresh` (hourly)
- `admin_coverage_backfill` (03:00 UTC)
- `admin_market_data_audit` (02:45 UTC)
- `admin_retention_enforce` (04:30 UTC)
- `ibkr-daily-flex-sync` (02:15 UTC)

### 5. AdminJobs: coverage refresh filter

**Backend** (`[market_data.py](backend/api/routes/market_data.py)` `/admin/jobs` endpoint):

- Add optional `exclude_task: str = Query(None)` param
- When provided, filter with `.filter(JobRun.task_name != exclude_task)`
- Works correctly with existing pagination

**Frontend** (`[AdminJobs.tsx](frontend/src/pages/AdminJobs.tsx)`):

- Add `hideCoverageRefresh` state (default: `true`)
- When true, pass `exclude_task=monitor_coverage_health` in API call
- Badge at top: "Coverage refresh hidden (toggle)"

### 6. Fix route protection

Current (`[App.tsx:89-103](frontend/src/App.tsx)`) -- settings is overly locked down:

```
RequireNonMarketAccess section="portfolio"
  RequireAdmin
    settings/profile        <-- blocked for non-admin!
    settings/admin/dashboard  <-- correctly admin-only
```

Fixed -- only admin/* routes require admin:

```
settings
  profile, preferences, brokerages, security, notifications  <-- open to all auth users
  RequireAdmin
    admin/dashboard, admin/jobs, admin/schedules, admin/users  <-- admin-only
```

Remove `RequireNonMarketAccess` from settings wrapper. Move `RequireAdmin` to only wrap `admin/*` child routes using `<Route element={<RequireAdmin />}>` as a layout route.

### 7. Dead code cleanup

- Delete `GET /admin/system/status` from `[admin.py](backend/api/routes/admin.py)`
- Update RBAC test in `[test_rbac.py](backend/tests/test_rbac.py)` to use `GET /admin/users` instead
- Delete `CoverageDailyHistogram.tsx` and `CoverageSparklineView.tsx` (replaced by CoverageHealthStrip)

### 8. Tests

- `CoverageHealthStrip` tests: renders heatmap cells, snapshot dots, inline sparkline, empty data returns null
- `AdminRunbook` tests: shows remediation for RED dims, shows "all healthy" when green
- Update `AdminDashboardCoverageRefresh.test.tsx`: remove toggle references, use new strip
- Update `AdminComponents.test.tsx`: replace histogram/sparkline tests, verify semantic colors
- Route guard test: non-admin can reach `/settings/profile`, cannot reach `/settings/admin/dashboard`

