---
name: Market Data Flow Cleanup
overview: Harden ordering semantics and simplify snapshot/stage pipelines so metric correctness is explicit, testable, and resilient. Include a data-correction pass to repair rows affected by prior ordering mismatches.
todos:
  - id: audit-ordering-contracts
    content: Map every newest/oldest ordering assumption in snapshot + stage flows and replace implicit behavior with explicit normalization helpers.
    status: completed
  - id: refactor-snapshot-pipeline
    content: Refactor MarketDataService snapshot path into staged functions with clear ordering contracts and invariant checks.
    status: completed
  - id: add-regression-tests
    content: Add/extend tests for current-price anchoring, performance windows, stage input ordering, and latest-per-symbol endpoint semantics.
    status: completed
  - id: run-data-correction
    content: Recompute tracked-universe snapshots from DB bars using corrected ordering, then run stage metadata repair for consistency.
    status: completed
  - id: post-run-verification
    content: Validate before/after metrics and spot-check key symbols (SPY + sector ETFs) in DB and API responses.
    status: completed
isProject: false
---

# Market Data Service Flow Cleanup

## What your question implies

- Yes: with the previous ordering mismatch, any snapshot built via DB-path could have incorrect "current"-anchored fields (price, performance windows, ATR-distance style metrics, stage inputs).
- Stage run metadata (`current_stage_days`, `previous_stage_*`) is derived from history transitions and may be partially preserved, but stage label inputs can still be wrong if snapshot inputs were wrong.

## Key areas to clean up

- Snapshot assembly and ordering contracts in [/Users/sankalpsharma/development/axiomfolio/backend/services/market/market_data_service.py](/Users/sankalpsharma/development/axiomfolio/backend/services/market/market_data_service.py)
- Dataframe conversion helper in [/Users/sankalpsharma/development/axiomfolio/backend/services/market/dataframe_utils.py](/Users/sankalpsharma/development/axiomfolio/backend/services/market/dataframe_utils.py)
- Indicator ordering assumptions in [/Users/sankalpsharma/development/axiomfolio/backend/services/market/indicator_engine.py](/Users/sankalpsharma/development/axiomfolio/backend/services/market/indicator_engine.py)
- Snapshot API expectations in [/Users/sankalpsharma/development/axiomfolio/backend/api/routes/market_data.py](/Users/sankalpsharma/development/axiomfolio/backend/api/routes/market_data.py)
- Regression tests in [/Users/sankalpsharma/development/axiomfolio/backend/tests/test_market_data_technical_snapshots_endpoint.py](/Users/sankalpsharma/development/axiomfolio/backend/tests/test_market_data_technical_snapshots_endpoint.py) and new market-data-service ordering tests.

## Cleanup design

- Introduce explicit dataframe-order utilities:
  - `ensure_newest_first(df)` and `ensure_oldest_first(df)` (single source of truth)
  - avoid ad-hoc `iloc[::-1]` / mixed `ascending=` calls in hot paths.
- Split snapshot computation into clear stages:
  - normalize input ordering
  - compute core indicators
  - compute performance/stage enrichments
  - persist current snapshot + history
- Add invariant checks (dev/test only):
  - assert expected monotonic index direction before each major computation.
- Keep stage-derivation logic isolated from price snapshot assembly to reduce cross-coupling.

## Data correctness recovery

- Run a deterministic recompute pass from `price_data` for tracked universe:
  - recompute snapshot metrics from DB bars (correct order)
  - persist updated `market_snapshot` and same-day `market_snapshot_history`
- Then run stage repair window to re-align run metadata after corrected stage labels.
- Emit before/after sanity metrics:
  - sampled symbols (`SPY`, sector ETFs, high-volume equities)
  - distribution deltas for `current_price`, `perf_1d`, `perf_20d`, stage counts.

## Validation plan

- Add focused tests for ordering invariants:
  - DB snapshot uses newest bar as `current_price`
  - performance windows compare against newest bar (not oldest)
  - stage compute receives newest-first daily frames.
- Keep/extend endpoint tests to ensure latest-per-symbol row selection.
- Run backend test subset for market data + snapshots endpoints.

## Rollout

- Ship code cleanup first.
- Execute recompute + stage repair in one controlled run.
- Verify Admin dashboard quality cards and spot-check Market Tracked rows post-refresh.

```mermaid
flowchart TD
  priceData[price_data newest bars] --> normalizeOrder[Normalize order explicitly]
  normalizeOrder --> snapshotCalc[Compute snapshot metrics]
  snapshotCalc --> stageCalc[Compute stage label + run fields]
  stageCalc --> persistCurrent[Persist market_snapshot]
  stageCalc --> persistHistory[Persist market_snapshot_history]
  persistCurrent --> apiRead[Snapshots API latest-per-symbol]
  persistHistory --> qualityChecks[Stage/data quality checks]
```



