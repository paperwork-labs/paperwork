---
name: Sprint 1 Foundation
overview: Build the complete frontend design system (Task 0.2) and backend foundation with database models + Alembic migrations (Task 0.3), then bootstrap the Hetzner ops stack. Incorporates auth deep dive (Google One-Tap + Apple + email/password), attribution/analytics foundation, all-persona review findings, and system pressure test results.
todos:
  - id: frontend-deps
    content: "Task 0.2: Install all frontend dependencies (Tailwind, shadcn, Framer Motion, React Query, etc.)"
    status: completed
  - id: frontend-tailwind
    content: "Task 0.2: Set up Tailwind CSS config, PostCSS, globals.css with design tokens"
    status: completed
  - id: frontend-shadcn
    content: "Task 0.2: Initialize shadcn/ui and install all required components"
    status: completed
  - id: frontend-libs
    content: "Task 0.2: Create foundational files (utils.ts, motion.ts, api.ts, types/index.ts, attribution.ts)"
    status: completed
  - id: frontend-layout
    content: "Task 0.2: Update layout.tsx with fonts, providers, and update page.tsx to Tailwind"
    status: completed
  - id: frontend-merge
    content: "Task 0.2: Commit, push, merge frontend design system branch"
    status: completed
  - id: backend-config-db
    content: "Task 0.3: Create config.py (Pydantic Settings with auth + encryption vars) and database.py (async SQLAlchemy)"
    status: completed
  - id: backend-models
    content: "Task 0.3: Create BaseModel mixin + all models with relationships, cascade delete, auth fields, attribution JSONB"
    status: completed
  - id: backend-schemas-utils
    content: "Task 0.3: Create response envelope, Pydantic schemas, repository/service base classes, and utility modules"
    status: completed
  - id: backend-routers-main
    content: "Task 0.3: Create routers (waitlist with attribution, deep health check) + update main.py with middleware, rate limiter, correlation IDs"
    status: completed
  - id: backend-alembic
    content: "Task 0.3: Initialize Alembic with async support and generate initial migration"
    status: completed
  - id: backend-taxdata-tests
    content: "Task 0.3: Create tax-data/2025.json and write tests (health, waitlist, encryption, PII scrubber, response envelope)"
    status: completed
  - id: backend-merge
    content: "Task 0.3: Commit, push, merge backend foundation branch"
    status: completed
  - id: hetzner-bootstrap
    content: "Bootstrap Hetzner VPS: run setup.sh, configure .env, start ops stack services"
    status: completed
isProject: false
---

# Sprint 1: Application Foundation

Both tasks run on feature branches, get merged to `main`, and auto-deploy. Plan incorporates findings from auth deep dive, system pressure test, and all-persona review (12 personas).

---

## All-Persona Review Summary


| Persona                  | Finding                             | Action                                                                                                        |
| ------------------------ | ----------------------------------- | ------------------------------------------------------------------------------------------------------------- |
| Engineering              | 7 architectural gaps                | Base model, response envelope, repo/service layers, deep health, rate limiter, relationships, correlation IDs |
| Growth                   | No attribution tracking             | Add `attribution` JSONB to Waitlist + User, frontend UTM capture utility                                      |
| Legal                    | Cascade delete + email verification | `cascade="all, delete-orphan"` on relationships, `email_verified` on User                                     |
| QA                       | Foundation tests set the standard   | Add tests for response envelope, deep health check                                                            |
| CFO                      | Cost-neutral                        | Google OAuth free, Apple free on web, PostHog free tier (1M events/mo)                                        |
| Social                   | Confirms no TikTok login            | UTM tracking critical for creator partnership ROI                                                             |
| Partnerships             | Attribution is #1 gap               | Without it, Founder 2 can't prove which partnerships drive revenue                                            |
| Tax Domain               | Tax data correct                    | Standard deductions from P.L. 119-21 confirmed                                                                |
| UX                       | Design system approach correct      | Tokens -> components -> utilities -> pages                                                                    |
| Strategy, CPA, Workflows | No gaps                             | Aligned                                                                                                       |


---

## Auth Architecture Decision (D22)

**Auth methods** (ordered by expected usage):

1. **Google One-Tap** (~60%) -- no redirect, JWT returned directly to frontend, backend validates
2. **Apple Sign In** (~25%) -- OAuth redirect, backend exchanges code
3. **Email + Password** (~15%) -- fallback, includes password reset flow

**TikTok Login rejected**: returns only display_name/avatar, NO email. Useless for a tax app that needs email for transactional communications. Plus regulatory uncertainty.

**Architecture**: FastAPI owns all auth (not Auth.js). Backend validates social tokens, creates Redis sessions, sets HTTP-only cookies. This keeps session management server-side (required for revocation, CCPA deletion, security audits).

**Impact on foundation**: User model needs `auth_provider`, `auth_provider_id`, `email_verified` fields and nullable `password_hash`. Config needs Google/Apple OAuth vars (empty = social login disabled in dev). Actual OAuth endpoints are Task 2.1.

---

## Analytics + Attribution Strategy

**Foundation (this sprint):**

- `attribution` JSONB field on Waitlist and User models (stores `utm_source`, `utm_medium`, `utm_campaign`, `utm_content`, `utm_term`, `referral_code`, `landing_page`)
- Frontend `src/lib/attribution.ts` utility: reads UTM params from URL on landing, persists to sessionStorage, provides `getAttribution()` for forms
- Waitlist POST includes attribution data
- User registration includes attribution data

**Task 1.4 (Sprint 2):**

- TikTok Pixel + Meta Pixel installation via `next/script`
- JSON-LD structured data

**Task 2.7 (Sprint 3):**

- PostHog integration (posthog-js, PII filter)
- Full event tracking: `signup`, `filing_started`, `step_completed`, `upload`, `ocr_completed`, `filing_completed`, `share_card`, `advisory_interest`
- Funnel: landing -> demo -> signup -> filing_start -> filing_complete
- Revenue attribution events: `refund_plan_viewed`, `recommendation_clicked`, `recommendation_converted`

**Key funnel to track end-to-end:**

```
TikTok/IG/X/Organic -> Landing (UTM captured)
  -> Demo (anonymous extraction)
    -> Signup (attribution stored on User)
      -> W2 Upload -> Data Confirm -> Calculate
        -> Download PDF / E-File
          -> Refund Plan (monetization)
```

---

## Task 0.2 -- Frontend Design System

**Branch**: `feat/0.2-frontend-design-system`

Currently `web/` is a bare Next.js 14 shell -- no Tailwind, no shadcn, no dependencies beyond React.

### Step 1: Install all dependencies

In `[web/package.json](web/package.json)`, add:

**Runtime deps**: framer-motion, recharts, lucide-react, zustand, @tanstack/react-query, react-hook-form, @hookform/resolvers, zod, axios, ai, @ai-sdk/react, @ai-sdk/openai, @react-pdf/renderer, clsx, tailwind-merge, next-themes, sonner, vaul, react-dropzone, date-fns, nuqs, canvas-confetti

**Dev deps**: tailwindcss, postcss, autoprefixer, @types/canvas-confetti

Note: `@react-oauth/google` deferred to Task 2.2 (frontend auth). Not needed until OAuth endpoints exist.

### Step 2: Initialize Tailwind CSS

- Create `postcss.config.mjs` with tailwindcss + autoprefixer
- Create `tailwind.config.ts` with:
  - `darkMode: "class"`
  - Content paths for `src/` and shadcn components
  - Indigo primary, Slate neutrals (via CSS variables following shadcn HSL convention)
  - Inter + JetBrains Mono font families
  - Framer Motion animation keyframes (fadeIn, slideIn, etc.)

### Step 3: Create `src/app/globals.css`

CSS custom properties following shadcn convention -- HSL values for `:root` (light) and `.dark` (dark). Brand: deep indigo/slate dark theme with violet-purple gradient accents. Includes all shadcn required variables: `--background`, `--foreground`, `--card`, `--primary`, `--secondary`, `--muted`, `--accent`, `--destructive`, `--border`, `--input`, `--ring`, etc.

### Step 4: Initialize shadcn/ui

Run `npx shadcn@latest init` (New York style, Slate base, CSS variables, 0.5rem radius). Then install components:

button, input, label, card, dialog, sheet, tooltip, popover, dropdown-menu, select, checkbox, radio-group, switch, textarea, separator, badge, skeleton, progress, form, command, accordion, sonner (toast)

### Step 5: Create foundational files

- `src/lib/utils.ts` -- `cn()` (clsx + tailwind-merge), `formatCurrency()` (cents to display), `formatSSN()` (mask XXX-XX-1234)
- `src/lib/motion.ts` -- Framer Motion presets: fadeIn, slideInRight, slideInLeft, slideInUp, scaleIn, countUp spring config, `useReducedMotion()` hook, `MotionDiv` wrapper that respects prefers-reduced-motion
- `src/lib/api.ts` -- axios instance (baseURL from `NEXT_PUBLIC_API_URL`, withCredentials for cookie auth, error interceptor that extracts message from response envelope)
- `src/lib/attribution.ts` -- reads UTM params (`utm_source`, `utm_medium`, `utm_campaign`, `utm_content`, `utm_term`) + `ref` (referral code) from URL on first landing, persists to sessionStorage, exports `getAttribution()` for forms and `AttributionProvider` component
- `src/types/index.ts` -- TypeScript interfaces matching PRD data models (User with auth_provider + attribution, Filing, Document, TaxProfile, TaxCalculation, Submission, Waitlist with attribution). Includes enums for FilingStatus, DocumentType, ExtractionStatus, AuthProvider, etc.

### Step 6: Update layout + providers

- `src/app/layout.tsx` -- Inter via `next/font/google` (weights 400/500/600/700), import globals.css, wrap with Providers
- `src/components/providers.tsx` -- QueryClientProvider + ThemeProvider (next-themes, defaultTheme="dark") + AttributionProvider (captures UTMs on mount)
- Update `src/app/page.tsx` to use Tailwind classes instead of inline styles (still placeholder content, real landing page is Task 0.4)

---

## Task 0.3 -- Backend Foundation + Database

**Branch**: `feat/0.3-backend-database`

Currently `api/` has only `main.py` (CORS + /health) and one test. Need full application structure with production-grade patterns.

### Step 1: Config + Database

- `app/config.py` -- Pydantic Settings reading all env vars with sensible dev defaults:
  - DATABASE_URL, REDIS_URL, SECRET_KEY
  - ENCRYPTION_KEY (for AES-256 PII encryption)
  - OPENAI_API_KEY, GOOGLE_APPLICATION_CREDENTIALS, GCS_BUCKET_NAME
  - GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET (empty = Google login disabled)
  - APPLE_CLIENT_ID, APPLE_TEAM_ID, APPLE_KEY_ID, APPLE_PRIVATE_KEY_PATH (empty = Apple login disabled)
  - FRONTEND_URL, ENVIRONMENT, DEBUG
- `app/database.py` -- async SQLAlchemy engine, async session factory, `get_db` async dependency generator
- Update `infra/env.dev.example` with all new vars (ENCRYPTION_KEY, Google/Apple OAuth)

### Step 2: Base Model + SQLAlchemy Models

**Base model mixin** (`app/models/base.py`):

- `id`: UUID primary key (server-generated via `uuid4`)
- `created_at`: timestamp with timezone, server default
- `updated_at`: timestamp with timezone, onupdate

**Models** (`app/models/`) with full SQLAlchemy relationships:

- `user.py` -- User
  - Fields: email (unique indexed), password_hash (nullable -- social login users), full_name_encrypted, referral_code (unique), referred_by FK -> User, role enum (user/admin), advisor_tier enum (free/premium), **auth_provider** enum (local/google/apple), **auth_provider_id** (nullable), **email_verified** bool (default False), **attribution** JSONB (utm_source, utm_medium, utm_campaign, etc.)
  - Relationships: `filings` (one-to-many, cascade all delete-orphan), `referrals` (self-referential)
- `filing.py` -- Filing
  - Fields: user_id FK, tax_year int, filing_status enum (single/married_joint/married_separate/head_of_household), status enum (draft/documents_uploaded/data_confirmed/calculated/review/submitted/accepted/rejected)
  - Relationships: `user` (many-to-one), `documents` (one-to-many, cascade all delete-orphan), `tax_profile` (one-to-one, cascade), `tax_calculation` (one-to-one, cascade), `submission` (one-to-one, cascade)
- `document.py` -- Document
  - Fields: filing_id FK, document_type enum (w2/drivers_license/1099_misc/1099_nec), storage_key (encrypted), extraction_status enum (pending/processing/completed/failed), extraction_data JSONB (encrypted), confidence_scores JSONB
  - Relationships: `filing` (many-to-one)
- `tax_profile.py` -- TaxProfile
  - Fields: filing_id FK (unique), ssn_encrypted, full_name_encrypted, address_encrypted (JSONB), date_of_birth_encrypted, total_wages int (cents), total_federal_withheld int, total_state_withheld int, state str
  - Relationships: `filing` (one-to-one)
- `tax_calculation.py` -- TaxCalculation
  - Fields: filing_id FK (unique), adjusted_gross_income int, standard_deduction int, taxable_income int, federal_tax int, state_tax int, total_withheld int, refund_amount int, owed_amount int (ALL CENTS), ai_insights JSONB, calculated_at timestamp
  - Relationships: `filing` (one-to-one)
- `submission.py` -- Submission
  - Fields: filing_id FK (unique), transmitter_partner str, submission_id_external str, irs_status enum (submitted/accepted/rejected), rejection_codes JSONB
  - Relationships: `filing` (one-to-one)
- `waitlist.py` -- Waitlist
  - Fields: email (unique), source str, **attribution** JSONB (utm_source, utm_medium, utm_campaign, utm_content, utm_term, referral_code, landing_page)

`**app/models/__init__.py`**: import all models, export `Base` for Alembic target_metadata.

### Step 3: Response Envelope + Pydantic Schemas

**Response envelope** (`app/schemas/base.py`):

```python
class BaseResponse(BaseModel, Generic[T]):
    success: bool
    data: T | None = None
    error: str | None = None
```

Plus helper functions: `success_response(data)`, `error_response(message, status_code)`.

**Schemas** (`app/schemas/`):

- `waitlist.py` -- WaitlistCreate (email, source, attribution dict optional), WaitlistResponse
- `health.py` -- HealthResponse (status, db_connected bool, version str)
- `user.py` -- UserResponse (id, email, full_name, referral_code, auth_provider, email_verified, advisor_tier -- never expose password_hash or encrypted fields)
- Stub schemas for filing, document, tax (flesh out in Task 2.3/2.4)

### Step 4: Repository + Service Base Classes + Utilities

**Repository base** (`app/repositories/base.py`):

- Generic `BaseRepository[ModelType]` with: `get_by_id`, `get_all`, `create`, `update`, `delete`
- Uses async session from `get_db`

**Service base** (`app/services/base.py`):

- Pattern established -- services receive repository via constructor, contain business logic

**Concrete repositories** (functional):

- `app/repositories/waitlist.py` -- WaitlistRepository (get_by_email, create)

**Concrete services** (functional):

- `app/services/waitlist.py` -- WaitlistService (join_waitlist with duplicate check)

**Utility modules** (`app/utils/`):

- `encryption.py` -- AES-256 encrypt/decrypt using `cryptography.fernet`, key from `ENCRYPTION_KEY` config
- `security.py` -- hash_password, verify_password (passlib bcrypt), generate_session_token (secrets.token_urlsafe)
- `exceptions.py` -- NotFoundError, UnauthorizedError, ForbiddenError, ValidationError, RateLimitError. Each maps to HTTP status. Global exception handlers registered on app.
- `pii_scrubber.py` -- logging filter that strips SSN patterns (3-2-4 digits with optional dashes/spaces) from log output
- `correlation.py` -- middleware that generates a UUID correlation ID per request, adds to logging context, returns in `X-Correlation-ID` response header

### Step 5: Routers + Waitlist

- `app/routers/health.py` -- GET /health (deep: checks DB connectivity via `SELECT 1`, returns `{ status, db_connected, version }`)
- `app/routers/waitlist.py` -- POST /api/v1/waitlist (email + source + attribution, wrapped in response envelope, validates email format, checks duplicate)
- Stub files for: `auth.py`, `filings.py`, `documents.py`, `tax.py` (empty routers, registered but with no routes yet)

### Step 6: Update main.py

- Import Settings from config
- Mount middleware stack: CORS, PII scrubber (logging filter), correlation ID middleware
- Initialize `slowapi.Limiter` on the app (key_func=get_remote_address). Specific rate limits applied per-route in Task 2.1+
- Register exception handlers (custom exceptions + slowapi RateLimitExceeded)
- Register all routers (health at root, others at `/api/v1` prefix)
- Lifespan context manager for DB engine startup/shutdown

### Step 7: Alembic Setup

- Run `alembic init --template async` inside `api/` directory
- Configure `alembic.ini`: sqlalchemy.url reads from env (but env.py overrides)
- Configure `env.py`: import all models, use async engine from `app.database`, set `target_metadata = Base.metadata`
- Generate initial migration: `alembic revision --autogenerate -m "initial schema"`
- Update Makefile `migrate` target: `$(COMPOSE) run --rm api alembic upgrade head`

### Step 8: Tax Data

- `api/tax-data/2025.json` -- federal brackets for all 4 filing statuses (single, married_joint, married_separate, head_of_household), standard deductions ($15,750/$31,500/$15,750/$23,625), source citations (Rev. Proc. 2024-40 as amended by P.L. 119-21 "One Big Beautiful Bill")

### Step 9: Tests

- `test_health.py` -- deep health check returns db_connected=true/false
- `test_waitlist.py` -- POST with valid email (201), duplicate email (409), invalid email (422), with/without attribution data
- `test_encryption.py` -- round-trip encrypt/decrypt, different key fails
- `test_pii_scrubber.py` -- SSN patterns stripped from log output (XXX-XX-XXXX, XXXXXXXXX, XXX XX XXXX)
- `test_response_envelope.py` -- success_response wraps correctly, error_response wraps correctly
- `conftest.py` -- async test client, test database (in-memory SQLite or test Postgres), override get_db

### Step 10: Update env + docs

- Update `infra/env.dev.example` with all new config vars
- Add D22 to `docs/KNOWLEDGE.md`: auth architecture decision (Google One-Tap + Apple + email/password, FastAPI owns auth, no TikTok login)

---

## Hetzner Bootstrap

Run `infra/hetzner/setup.sh 204.168.147.100` to install Docker, Caddy, firewall on the ops VPS. Then configure `.env` and start services (Postiz + n8n + PostgreSQL + Redis).

This requires SSH access. Will attempt and report if auth issues arise.

After bootstrap:

- Configure Caddy reverse proxy for n8n.filefree.tax and social.filefree.tax
- Verify services are healthy
- Connect Postiz to social media accounts (manual step for user)

---

## Future Analytics Roadmap (not this sprint)

For reference -- these are planned but not built now:

- **Task 1.4**: TikTok Pixel, Meta Pixel, JSON-LD, sitemap, SEO meta tags
- **Task 2.7**: PostHog integration, full event tracking, funnel visualization, Sentry error monitoring, CI pipeline
- **Task 3.6**: Revenue attribution events (refund_plan_viewed, recommendation_clicked, recommendation_converted)

The foundation built in this sprint (attribution JSONB on models, UTM capture utility, response envelope, correlation IDs) makes all of these plug-and-play when their sprint arrives.

---

## Merge + Deploy Strategy

1. Create `feat/0.2-frontend-design-system` branch, implement, merge to `main` (auto-deploys to Vercel)
2. Create `feat/0.3-backend-database` branch, implement, merge to `main` (auto-deploys to Render, runs migration against Neon)
3. Hetzner bootstrap runs in parallel (no branch needed, infrastructure only)

