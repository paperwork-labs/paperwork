---
name: Snapshot metrics + Discord
overview: Monitor a recompute run end-to-end (Celery/JobRun/DB) and extend MarketSnapshot with the Level 1–4 indicator stack, plus an Admin button to send a snapshot digest to your existing Discord bot integration.
todos:
  - id: monitor-recompute-run
    content: Run recompute end-to-end in our own verification flow (Celery/JobRun/Redis taskstatus), diagnose failures, and improve task observability (counters + bounded error list).
    status: completed
  - id: extend-snapshot-level1-4
    content: Extend DB-first snapshot computation to produce Level 1–4 metrics (SMA/EMA/ATR/range %, ATR multiples, Mansfield RS vs SPY, Weinstein stage today + 5d ago) and persist into MarketSnapshot (columns + raw_analysis as appropriate).
    status: completed
    dependencies:
      - monitor-recompute-run
  - id: discord-digest-button
    content: Implement admin endpoint to format + send snapshot digest via existing Discord bot integration; add Admin Dashboard button to trigger it.
    status: completed
    dependencies:
      - extend-snapshot-level1-4
  - id: tests
    content: Add unit/integration tests for indicator math, stage rules, and Discord sender (mocked).
    status: completed
    dependencies:
      - extend-snapshot-level1-4
      - discord-digest-button
---

# MarketSnapshot enrichment + Discord digest

## What we’ll do next

### 1) We’ll run “Recompute Indicators” ourselves (end-to-end) and harden the run

- **Observe live execution** via Celery worker logs + `JobRun` rows (`backend/models/market_data.py`) and existing Redis task status (`taskstatus:*`).
- **Fix correctness bugs** we find during the run (common culprits: missing/insufficient OHLCV window, wrong resampling, division-by-zero, symbol normalization, benchmark missing).
- **Improve observability** so future failures are self-evident in the UI/DB:
- Ensure `recompute_indicators_universe` writes per-batch counters (processed/ok/error) into `JobRun.counters`.
- Persist a bounded list of recent error symbols + traceback summary into `JobRun.error` (not just logs).

Relevant code:

- `backend/tasks/market_data_tasks.py` (Celery task execution + `task_run` wrapper)
- `backend/services/market/market_data_service.py` (`compute_snapshot_from_db`, `persist_snapshot`, DB-first indicator computation)

### 2) Implement your Level 1–4 indicator stack in `MarketSnapshot`

#### A) 1x fundamentals (not OHLCV)

Good news: the app is already close.

- `MarketSnapshot` already has `sector`, `industry`, `sub_industry` columns.
- There are tasks already designed for this DB-first enrichment:
- `fill_missing_snapshot_fundamentals`
- `enrich_index_fundamentals`

We’ll make sure the “sub-sector” requirement maps cleanly to `sub_industry` (or we’ll add a dedicated column if you want both).

#### B) Level 1 (direct OHLCV indicators)

We’ll compute and persist:

- **SMA**: 5D, 14D, 21D, 50D, 100D, 150D, 200D
- **EMA**: 8D, 21D
- **ATR**: 14D, 30D
- **Range %**:
- % of 20D range, % of 50D range, % of 52wk range (position-in-range: \((close - low)/(high-low)\)*100)

Notes on schema:

- We will **consolidate naming** for queryable indicator columns:\n+  - `sma_5`, `sma_14`, `sma_21`, `sma_50`, `sma_100`, `sma_150`, `sma_200`\n+  - `ema_8`, `ema_21`\n+  - `atr_14`, `atr_30`, plus `atrp_14`, `atrp_30` (ATR/Price as %)\n+- Migration strategy (agreed): **add consolidated columns → backfill from OHLCV → switch code/queries to new columns → drop old columns** (no functionality loss).\n+- Non-critical/rarely-filtered metrics can still live in `raw_analysis`, but we’ll keep anything used by scanners/alerts as first-class columns.

#### C) Level 2 (derived ATR-relative metrics)

Persist:

- **ATR/Price (%)** (use ATR14 by default; also store ATR30%)
- **(Price − SMA)/ATR** for SMA21/SMA50/SMA100/SMA150 (store as numeric “ATR multiples”; UI can render as `2.0x`)

#### D) Level 3 (Relative Strength vs S&P) — recommendation

I’ll implement a **Mansfield Relative Strength** variant (common, stable, stage-friendly):

- Let \(RS_t = close_t / spy_close_t\)
- Let \(RSMA_t = SMA(RS, 52\text{ weeks})\) on weekly bars
- Mansfield RS %: \((RS_t / RSMA_t - 1) * 100\)

Why this choice:

- Widely used with Weinstein stage work; interpretable as “outperforming/underperforming trend”.
- Smooth and robust; avoids needing external ranking data.

#### E) Level 4 (Weinstein Stage today + 5 trading days ago) — recommendation

Use classic Weinstein logic on **weekly bars** (built from daily OHLCV; Friday close convention):

- Compute **30-week SMA** and a slope proxy (e.g., % change of SMA over last 5 weeks).
- Stage rules (clean, testable):
- Stage 2: price above 30W SMA AND SMA slope > 0
- Stage 4: price below 30W SMA AND SMA slope < 0
- Stage 1/3: remaining cases (optionally split by price above/below with flat slope)

Persist:

- `stage_label` (today)
- `stage_label_5d_ago` (new)
- `stage_slope_pct`, `stage_dist_pct` (already exist; we’ll ensure they’re correctly computed and meaningful)

## 3) Add “Send to Discord” (via your existing bot-token integration)

- **Backend**: add an admin endpoint that: