---
name: Dashboard symbol interaction
overview: Replace all SymbolLink navigations with hover sparkline previews and click-to-open slide-out TradingView chart panel, clean up chart labels/fonts, and update docs + architecture diagrams.
todos:
  - id: symbol-interaction
    content: "Rewrite SymbolLink: hover shows sparkline popover (lazy-fetch price data with cache), click opens slide-out TradingView panel"
    status: completed
  - id: slide-panel
    content: Build right-edge slide-out panel using DialogRoot pattern with TradingViewChart, close on X or click-away
    status: completed
  - id: chart-labels
    content: Fix breadth date 00:00:00, histogram negative Y-axis, consistent font sizes, RRG quadrant annotations
    status: completed
  - id: tests
    content: Update MarketDashboard tests for new SymbolLink behavior (no RouterLink, popover + panel)
    status: completed
  - id: docs
    content: Update ARCHITECTURE.md (scheduling section outdated), frontend-ui.md (new chart patterns, SymbolLink interaction), and logos README if needed
    status: completed
isProject: false
---

# Dashboard Symbol Interaction + Chart Label Cleanup + Docs

## Problem

- Every symbol click navigates to `/market-tracked?symbols=...` which is disruptive
- No quick way to see price action for a symbol without leaving the dashboard
- Chart labels have issues: breadth dates show "00:00:00" timestamps, histogram Y-axis can go negative, font sizes inconsistent
- [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) still references RedBeat and static Beat schedules (outdated since unified schedule management)
- [docs/frontend-ui.md](docs/frontend-ui.md) doesn't document chart components, the new Recharts usage, or SymbolLink interaction patterns

## Solution

### 1. Replace SymbolLink with hover sparkline + click slide-out panel

**Current `SymbolLink**` in [MarketDashboard.tsx](frontend/src/pages/MarketDashboard.tsx) (line ~217):

```tsx
const SymbolLink = ({ symbol }) => (
  <RouterLink to={`/market-tracked?symbols=${symbol}`}>
    <Text ...>{symbol}</Text>
  </RouterLink>
);
```

**New behavior:**

- **Hover**: Show a small popover with a mini Sparkline (last 20 close prices) using the existing [Sparkline.tsx](frontend/src/components/charts/Sparkline.tsx) component, plus current price and 1D change
- **Click**: Open a slide-out panel from the right edge with a full TradingView chart using the existing [TradingViewChart.tsx](frontend/src/components/charts/TradingViewChart.tsx) component
- **No navigation** -- stays on the dashboard

**Data source for sparkline**: Lazy-fetch from `marketDataApi.getHistory(symbol, '1mo', '1d')` on hover, with an in-memory `Map<string, number[]>` cache so repeated hovers don't re-fetch. Show a small spinner while loading.

```mermaid
flowchart LR
  SymbolText["Symbol Text"] -->|hover| Popover["Popover: Sparkline + Price + 1D%"]
  SymbolText -->|click| SlidePanel["Right Slide-Out Panel"]
  SlidePanel --> TVChart["TradingView Chart"]
  SlidePanel --> CloseBtn["X button / click-away / Esc"]
  Popover -->|"lazy fetch + cache"| API["getHistory API"]
```



**Slide-out panel implementation**: Use Chakra v3 `DialogRoot` + `DialogPositioner` + `DialogContent` pattern (already used in [DashboardLayout.tsx](frontend/src/components/layout/DashboardLayout.tsx) line 404). Position `fixed` from the right edge, width ~50vw on desktop / 90vw on mobile, full height, with close on X button, click-away, or Escape key.

### 2. Chart label/font cleanup

**Breadth chart date labels** showing "12-31 00:00:00":

- Root cause: `pt.date.slice(5)` doesn't strip the time portion from ISO strings like `2026-01-15T00:00:00`
- Fix: Parse with `new Date()` and format as `MM/DD`

**Histogram Y-axis**:

- Add `domain={[0, 'auto']}` to prevent negative axis values on the count chart

**RRG axis labels**:

- Currently using raw `cc.axis` which resolves to a CSS variable -- may render as the literal string in some SVG contexts. Use direct resolved values.

**General font/label tidy-up across all three Recharts charts:**

- Consistent tick font size: 10px
- Consistent axis label font size: 11px
- Breadth legend: move to top-left, reduce font size
- Histogram: format X-axis labels cleaner (e.g., "0-10%" with % suffix)
- RRG: quadrant labels (Leading, Improving, etc.) as reference area annotations instead of relying solely on the legend

### 3. Documentation updates

**[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)** -- "Scheduling Architecture" section (lines 36-46) is outdated:

- References RedBeat and static Beat schedules, which have been replaced
- Update to reflect the unified DB-backed schedule management: `CronSchedule` model seeded from `job_catalog.py`, CRUD via Admin UI, Render API sync on deploy
- Update the "Data Flow" section to mention the Market Dashboard pipeline (snapshot -> indicators -> dashboard service)

**[docs/frontend-ui.md](docs/frontend-ui.md)** -- missing chart and interaction patterns:

- Add a "Charts" section documenting: Recharts (histograms, area charts, scatter), TradingViewChart (embed), Sparkline (mini bars), SymbolChartWithMarkers (lightweight-charts)
- Add a "Symbol Interaction" section documenting the hover-sparkline + click-slide-out pattern
- Document the `chart.*` semantic tokens added to `system.ts`
- Add a "Dashboard Components" section listing the reusable sub-components (`SetupCard`, `TransitionList`, `RankMatrix`, `StageBar`, `StatCard`, `RangeHistogram`, `BreadthChart`, `RRGChart`)

### 4. Files to change

- [frontend/src/pages/MarketDashboard.tsx](frontend/src/pages/MarketDashboard.tsx) -- Rewrite `SymbolLink`, add slide-out panel state + component, add sparkline popover with lazy fetch + cache, fix chart labels
- [frontend/src/pages/**tests**/MarketDashboard.test.tsx](frontend/src/pages/__tests__/MarketDashboard.test.tsx) -- Update tests since SymbolLink no longer uses RouterLink
- [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) -- Update scheduling and data flow sections
- [docs/frontend-ui.md](docs/frontend-ui.md) -- Add charts, symbol interaction, dashboard component patterns
- No changes needed to [Sparkline.tsx](frontend/src/components/charts/Sparkline.tsx) or [TradingViewChart.tsx](frontend/src/components/charts/TradingViewChart.tsx) -- both already have the right interfaces

