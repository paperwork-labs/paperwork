---
name: Scale Architecture + Growth
status: archived
overview: "ARCHIVED — Content integrated into Venture Master Plan. B2B plan, growth playbook, and self-review findings all implemented."
todos:
  - id: fix-self-review
    content: Fix 6 MEDIUM self-review findings (F13-F18) in VENTURE_MASTER_PLAN.md and PARTNERSHIPS.md
    status: pending
  - id: business-tax-section
    content: "Add Section 1C: FileFree Business Tax Filing as LaunchFree synergy multiplier (1065, 1120-S phasing, engine interface design, revenue model)"
    status: pending
  - id: growth-playbook
    content: Upgrade Section 5K with 3 growth channels (tax season surge, B2B API, community-led) and updated 2M-user acquisition projections
    status: pending
  - id: journey-path-e
    content: Add PATH E (LaunchFree -> FileFree Business mandatory cross-sell) to Section 4F and update form coverage roadmap with Phase 9-10
    status: pending
  - id: financials-update
    content: Update FINANCIALS.md with business filing revenue projections and B2B API revenue line
    status: pending
  - id: knowledge-decisions
    content: Add D67 (Business Tax Filing) and D68 (Growth Playbook Lessons) to KNOWLEDGE.md
    status: pending
  - id: founder-side-projects
    content: Add business tax filing GO/NO-GO evaluation to FOUNDER_SIDE_PROJECTS.md
    status: pending
isProject: false
---

# Scale-Ready Architecture, Business Tax Expansion, and 2M-User Growth Playbook

## Research Findings

### How Taxu Got to 2M Users

Taxu's primary growth channel was NOT social media -- it was **B2B API distribution**. They built an embeddable tax SDK (`@taxu/taxu-js` on npm) that other platforms integrate. SaaS companies, marketplaces, and AI startups use Taxu's API to handle tax for THEIR users. Each B2B partner brings thousands of users. They handle 500M+ API requests/day. This is a platform play, not a consumer app play.

### How TaxDown Got to 4M Users (Spain)

TaxDown's growth was **seasonal surge + TikTok Spark Ads + celebrity marketing**. During Spain's tax season, they went from obscure to #6 most downloaded app in the country. 300% YoY growth. They raised ~EUR 8M and invested heavily in paid seasonal campaigns. Key insight: tax season is a 10-week window where marketing ROI is 10x any other period.

### How Credit Karma Got to 70M Users

CK's original breakout was a **$500 DIY TV ad** that went viral. They filed 1M tax returns in their FIRST season by cross-selling to existing credit score users. The tax product was a DATA PLAY -- free filing generated financial profiles that powered $500M/yr in referral revenue.

### The Business Tax Filing Opportunity

- **31M sole proprietors** file Schedule C (we already plan this in Phase 7)
- **4.5M partnership returns** (Form 1065) -- 72.7% are LLCs (3.3M)
- **5M+ S-Corp returns** (Form 1120-S)
- **NO free option exists** for 1065/1120-S/1120. TaxAct charges $100-170. Accountants charge $500-2,000.
- **Killer synergy**: User forms LLC via LaunchFree -> LLC MUST file business tax return -> currently they pay $170+ elsewhere -> if FileFree offers free business filing, LaunchFree->FileFree cross-sell becomes MANDATORY, not optional

## What Needs to Change in the Master Plan

### Part 1: Fix Self-Review Findings (6 items)

Fix the 6 MEDIUM findings from Section 9 Review Round 3:

- **F13**: Add marketplace tables (`partner_products`, `fit_scores`, `partner_bids`, `partner_eligibility`) to Phase 5 task list as P5.12
- **F14**: Add partner auth system task as P5.13 (API key + partner ID, separate from user auth)
- **F15**: Add Tier 2 consent to user profile/settings page (not just Refund Plan screen)
- **F16**: Add "Key Account Strategy" paragraph to Section 4O Stage 3 -- identify 2-3 Tier B partners who get first-mover API access
- **F17**: Specify Stage 2 data reciprocity mechanism in PARTNERSHIPS.md (monthly CSV email at Stage 2, webhook callback at Stage 3)
- **F18**: Add worked ARPU math example in Section 4O showing the S1->S2 jump ($50 CPA at 6% conversion -> $3 ARPU at S1; $75 CPA at 12% conversion -> $9 ARPU at S2)

### Part 2: Business Tax Filing Expansion (FileFree Business)

Add a new section to the master plan: **"1C. FileFree Business Tax Filing (The LaunchFree Synergy Multiplier)"**

**The strategic insight**: Free personal tax filing is a competitive market (FreeTaxUSA, Cash App Taxes, IRS Free File). Free BUSINESS tax filing does not exist. By offering free 1065/1120-S filing, we:

1. Create a mandatory cross-sell from LaunchFree (every LLC needs a business return)
2. Enter a market with zero free competitors and $100-170 paid incumbents
3. Deepen the financial profile (business income + personal income = complete picture)
4. Justify higher marketplace ARPU (business owners are premium financial product leads)

**Forms to add (phased)**:

- Phase 7 (Jan 2027): Schedule C (sole prop) -- already planned
- Phase 9 (Year 2): Form 1065 (partnerships/LLCs) + Schedule K-1 generation
- Phase 10 (Year 2-3): Form 1120-S (S-Corps) + K-1 generation

**Architecture impact**: Design the tax engine for multi-entity from day 1. The `packages/data/engine` should have a `calculateEntityTax(entityType, ...)` interface that handles 1040, 1065, and 1120-S. Phase 7 implements 1040 only; the interface accommodates the rest.

**Revenue impact**: Every LaunchFree LLC formation becomes a guaranteed FileFree Business user. Update revenue model with business filing conversion projections.

### Part 3: Growth Playbook Upgrade (Path to 2M Users)

Add/upgrade 3 growth channels inspired by Taxu, TaxDown, and Credit Karma:

**Channel 1: Tax Season Surge Strategy (TaxDown playbook)**
Upgrade Section 5K from "$100-300/mo Spark Ads" to a proper seasonal campaign strategy:

- Allocate 60-80% of annual marketing budget to the 10-week tax season window (Jan-Apr)
- TikTok Spark Ads: $500-1,000/mo during tax season (boost proven organic winners)
- "Refund amount sharing" as viral mechanic (shareable card: "I just filed for free and I'm getting $3,743 back")
- Target: become a top-100 Finance app during tax season
- Projection: 10K-50K users per tax season from paid+organic combined

**Channel 2: B2B API / Tax-as-a-Service (Taxu playbook)**
Add new Section 1D or expand Section 4O Stage 4:

- After FileFree's tax engine is proven (post-Season 1), package it as an embeddable API
- Target: payroll platforms, accounting SaaS, gig economy apps, fintech startups
- Revenue: per-return API fee ($2-5/return) + marketplace referral revenue
- This is a Stage 3-4 play (25K+ users, proven engine). NOT a day-1 priority.
- But design the tax engine API interface from day 1 (RESTful, stateless, versioned)

**Channel 3: Community-Led Growth (Reddit/Discord playbook)**
Upgrade Section 5K with a dedicated community strategy:

- r/personalfinance (18M members), r/tax (500K), r/smallbusiness (2M), r/Entrepreneur (3M)
- Strategy: be genuinely helpful for 3 months before any product mention
- "Tax season AMA" posts during January-April
- Discord community for FileFree users (peer support, reduces support burden)

**Updated User Acquisition Projections (2M-user path)**:

```
Year 1: 5K-25K (organic social + SEO + Reddit + Product Hunt + first tax season)
Year 2: 25K-100K (tax season surge + LaunchFree cross-sell + referral program)
Year 3: 100K-500K (B2B API distribution begins + second tax season + paid scale-up)
Year 4: 500K-1M (marketplace network effects + B2B partnerships + third tax season)
Year 5: 1M-2M+ (full platform + business tax filing + API distribution at scale)
```

### Part 4: LaunchFree -> FileFree Synergy Lock-In

Update Section 4F (Journey Mapping) with the business tax filing path:

```
PATH E: LaunchFree -> FileFree Business (MANDATORY cross-sell)
  Form LLC via LaunchFree (100%) -> LLC must file business return (100%)
  -> see "File your LLC taxes for free" CTA (100%) -> start business filing (60%)
  -> complete (80%) -> personal filing cross-sell (50%)
  Net conversion: ~24% of LLC formers file business taxes via FileFree
  Revenue per converted user: marketplace referrals (business loans, insurance, payroll)
```

This is the missing link. Currently the plan says "LaunchFree -> FileFree" is a seasonal tax cross-sell with 7% conversion. With business tax filing, it becomes a MANDATORY annual event for every LLC.

## Files to Modify

- [docs/VENTURE_MASTER_PLAN.md](docs/VENTURE_MASTER_PLAN.md): Fix 6 self-review findings, add Section 1C (business tax filing), upgrade Section 5K (acquisition strategy), add PATH E to Section 4F, add Phase 9-10 to execution phases, update form coverage roadmap
- [docs/PARTNERSHIPS.md](docs/PARTNERSHIPS.md): Add data reciprocity technical mechanism (F17)
- [docs/FINANCIALS.md](docs/FINANCIALS.md): Update revenue projections with business filing + B2B API revenue
- [docs/KNOWLEDGE.md](docs/KNOWLEDGE.md): Add D67 (Business Tax Filing Expansion) and D68 (Growth Playbook: Taxu/TaxDown Lessons)
- [docs/FOUNDER_SIDE_PROJECTS.md](docs/FOUNDER_SIDE_PROJECTS.md): Add business tax filing evaluation

