---
name: MarketTracked Preset Alignment
overview: Overhaul the MarketTracked filter presets to align with dashboard setup logic, add missing bearish/defensive views, fix the broken Stage 2 filter, and cross-link dashboard cards to MarketTracked deep links.
todos:
  - id: audit-filter-engine
    content: Check SortableTable filter engine for supported operators (lt, lte, between, in) and add any missing ones needed by new presets
    status: pending
  - id: fix-giants-preset
    content: Fix 'Giants Waking Up' preset to match Stage 2A/2B/2C instead of exact '2'
    status: pending
  - id: replace-bullish-preset
    content: Replace redundant 'Bullish Trend Day' with a more useful preset
    status: pending
  - id: add-new-presets
    content: Add Breakout Watch, Pullback Buy Zone, RS Leaders, Stage 1 Base Building, Distribution Warning, Stage 4 Decline presets
    status: pending
  - id: update-deeplink-slugs
    content: Update the deep-link slug map with all new preset slugs
    status: pending
  - id: cross-link-dashboard
    content: Add clickable links from Dashboard setup cards to MarketTracked with appropriate preset/symbol deep links
    status: pending
  - id: tests
    content: Update existing MarketTracked deep-link tests and add coverage for new presets
    status: pending
isProject: false
---

# MarketTracked Preset Alignment

## Problem

The 4 existing presets in [frontend/src/pages/MarketTracked.tsx](frontend/src/pages/MarketTracked.tsx) (lines 367-527) are misaligned with what the dashboard computes in [backend/services/market/market_dashboard_service.py](backend/services/market/market_dashboard_service.py):

- **"Giants Waking Up"** filters `stage_label == '2'` (exact match), but stages are now sub-labeled `2A/2B/2C`. This preset is effectively broken.
- **"Bullish Trend Day"** is a strict subset of "Momentum Trend (Clean)" — redundant.
- Dashboard computes **breakout candidates**, **pullback candidates**, **RS leaders**, **stage transitions**, and **action queue** — none of these have a corresponding preset or deep-link path.
- Dashboard cards show lists of symbols but never link to MarketTracked for deeper inspection.
- No bearish/defensive presets exist (Stage 3/4, declining RS, etc.).

## Changes

### 1. Fix and Improve Existing Presets

In [frontend/src/pages/MarketTracked.tsx](frontend/src/pages/MarketTracked.tsx):

- **"Giants Waking Up"**: Change `stage_label equals '2'` to use `in` operator or `contains` matching for `2A`, `2B`, `2C` (whichever the `SortableTable` filter engine supports). If the filter engine only supports `equals`, switch to multiple OR rules for each sub-stage.
- **Replace "Bullish Trend Day"** with something more useful (see new presets below).

### 2. Add New Presets Aligned with Dashboard

Add these presets to mirror dashboard setup logic:

- **"Breakout Watch"** (matches dashboard breakout_candidates logic):
Stage in (2A, 2B, 2C), perf_5d > 0, RS Mansfield > 0, price > SMA 50
- **"Pullback Buy Zone"** (matches dashboard pullback_candidates logic):
Stage in (2A, 2B, 2C), -4% <= perf_5d <= 2%, RS Mansfield > 0, price > SMA 50
- **"RS Leaders"** (matches dashboard rs_leaders):
RS Mansfield > 3, price > SMA 200
- **"Stage 1 Base Building"** (Weinstein accumulation phase):
Stage = 1, range_pos_52w < 30 (near lows, consolidating)
- **"Distribution Warning (Stage 3)"** (bearish setup):
Stage = 3, RS Mansfield < 0
- **"Stage 4 Decline"** (short/avoid candidates):
Stage = 4, price < SMA 50, price < SMA 200

### 3. Update Deep-Link Slug Map

Update the slug map (line 568-573) to include all new presets:

```typescript
const map: Record<string, string> = {
  momentum: 'Momentum Trend (Clean)',
  giants: 'Giants Waking Up (Large Cap Trend)',
  squeeze: 'Short-Term Squeeze (Range + ATR)',
  breakout: 'Breakout Watch',
  pullback: 'Pullback Buy Zone',
  rs_leaders: 'RS Leaders',
  base: 'Stage 1 Base Building',
  distribution: 'Distribution Warning (Stage 3)',
  decline: 'Stage 4 Decline',
};
```

### 4. Cross-Link Dashboard to MarketTracked

In [frontend/src/pages/MarketDashboard.tsx](frontend/src/pages/MarketDashboard.tsx):

- Make the **"Trading Setups"** section headers ("Breakout Candidates", "Pullback Candidates", "RS Leaders") clickable links that navigate to `/market-tracked?preset=breakout`, `?preset=pullback`, `?preset=rs_leaders` respectively.
- Make **"Stage Transitions"** section titles ("Entering Stage 2A", "Entering Stage 3", "Entering Stage 4") link to `/market-tracked?preset=...` or use `?symbols=X,Y,Z` deep links for the specific symbols shown.
- Make individual **symbol names** in dashboard cards clickable, linking to the symbol detail or at minimum to `/market-tracked?symbols=SYMBOL`.

### 5. Check SortableTable Filter Engine Compatibility

Before implementing, verify what operators `SortableTable` supports:

- Existing presets use `gt`, `equals` with `valueSource: 'column'` or `'literal'`
- New presets will need `lt` (less than) and possibly `gte`/`lte` or `between` operators
- If `SortableTable` lacks `lt` or `lte`, we add them to the filter engine

File to check: look for `SortableTable` definition to confirm supported operators.

## Files Changed

- [frontend/src/pages/MarketTracked.tsx](frontend/src/pages/MarketTracked.tsx) -- preset definitions + deep-link slug map
- [frontend/src/pages/MarketDashboard.tsx](frontend/src/pages/MarketDashboard.tsx) -- cross-links from cards to MarketTracked
- [frontend/src/components/SortableTable.tsx](frontend/src/components/SortableTable.tsx) -- add `lt`/`lte` operators if missing
- Frontend tests for presets and deep links

