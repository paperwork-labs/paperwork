---
name: Section 1 Completion
overview: "Complete the remaining Section 1 / PR 1 items from the Master Blueprint: type safety (remove 28 'as any' casts), pagination for Transactions, skeleton loading adoption, SortableTable filter debounce, accessibility polish, and docs overhaul with architecture diagrams."
todos:
  - id: a-type-safety
    content: "Remove ~17 'as any' casts: extend AxiosRequestConfig, add day_pnl_pct to EnrichedPosition, add response types to api.ts, fix page-level casts"
    status: completed
  - id: b-pagination
    content: Add Pagination component to PortfolioTransactions with page/pageSize state, wire to API params, reset on filter change
    status: completed
  - id: c-skeletons
    content: Wire TableSkeleton into PortfolioHoldings, PortfolioOptions, PortfolioTransactions loading states
    status: completed
  - id: d-filter-debounce
    content: Add DebouncedFilterInput wrapper in SortableTable.tsx for text/number filter inputs (300ms)
    status: completed
  - id: e-accessibility
    content: PnlText aria-label, StageBar container aria-label+role=img, mobile overflowX=auto on tables
    status: completed
  - id: f-tests
    content: "Add tests: Transactions pagination, skeleton loading states, PnlText/StageBar accessibility attributes"
    status: completed
  - id: g-docs
    content: Rewrite ARCHITECTURE.md, ROADMAP.md; update PORTFOLIO.md, frontend-ui.md, MODELS.md with mermaid diagrams
    status: completed
  - id: h-validate-push
    content: Run tsc + lint + frontend tests + backend tests; commit and push PR
    status: completed
isProject: false
---

# Section 1 Completion: Foundation Polish

All backend work (1A, 1B) is done. Categories mutations with toasts (1D.4), useDebounce (1D.1-2), AccountContext migration (1D.3) are done. This plan covers the remaining frontend + docs items.

---

## Checkpoint A: Type Safety (remove `as any`)

**Goal:** Eliminate 28 `as any` casts across 18 files. Some are in test/theme files (leave those). Focus on the ~20 meaningful ones.

### A1. Extend AxiosRequestConfig for `_noRetry`

In [frontend/src/services/api.ts](frontend/src/services/api.ts), add a module augmentation at the top of the file (after imports):

```typescript
declare module 'axios' {
  interface InternalAxiosRequestConfig {
    _noRetry?: boolean;
  }
}
```

This eliminates the 2 casts on lines 527 and 532 where `{ _noRetry: true } as any` is used.

### A2. Type `RequestQueue` public getters

In the same file, add a public method to the `RequestQueue` class or type the metrics function. Replace lines 449-455:

```typescript
export const getApiPerformanceMetrics = () => {
  const rq = requestQueue as { activeRequests: number; queue: unknown[]; maxConcurrent: number };
  return {
    activeRequests: rq.activeRequests,
    queueLength: rq.queue.length,
    maxConcurrent: rq.maxConcurrent,
  };
};
```

This eliminates 3 casts. Better: add public getters to `RequestQueue` class if it's defined in this file.

### A3. Add `day_pnl_pct` to `EnrichedPosition`

In [frontend/src/types/portfolio.ts](frontend/src/types/portfolio.ts), add `day_pnl_pct?: number` to the `EnrichedPosition` interface. This fixes 2 casts in `PortfolioHoldings.tsx` (lines 99, 164).

### A4. Add response types to api.ts

Add these interfaces near the existing types in [frontend/src/services/api.ts](frontend/src/services/api.ts):

```typescript
interface StocksResponse { data?: { stocks?: StockRow[]; holdings?: StockRow[] } }
interface StatementsResponse { data?: { transactions?: TxRow[] } }
interface LiveResponse { data?: { accounts?: Record<string, any> }; accounts?: Record<string, any> }
interface ActivityResponse { data?: { activity?: ActivityRow[] }; activity?: ActivityRow[] }
interface UsersListResponse { users?: UserRow[] }
interface InvitesListResponse { invites?: InviteRow[] }
```

Then update the return types of the corresponding API functions (e.g., `getStocks`, `getStatements`, `getLive`). Import `StockRow`, `ActivityRow` from `types/portfolio.ts`.

### A5. Fix page-level casts

- **PortfolioOverview.tsx line 50**: Type the dashboard query return. Replace `overview.summary.data as any` with a typed `DashboardData` or use optional chaining with the response interface.
- **PortfolioOverview.tsx line 299**: Type `rawAccounts` with `BrokerAccount[]` from context.
- **PortfolioTransactions.tsx line 81**: Use `ActivityResponse` type instead of `as any`.
- **PortfolioWorkspace.tsx lines 98, 103**: Use `StocksResponse` and `StatementsResponse`.
- **PortfolioHoldings.tsx line 273**: Type the heatmap data with `FinvizHeatMapData[]` (check FinvizHeatMap component props).
- **SettingsUsers.tsx lines 64-65**: Use `UsersListResponse` and `InvitesListResponse`.
- **DashboardLayout.tsx line 256**: Use `LiveResponse` type.
- **usePortfolio.ts line 333**: Replace the `anyData: any = data as any` with a union type that includes both `all_positions` and `positions` fields.

### A6. Leave alone

- `test/setup.ts` (2 casts) -- test infrastructure, fine as-is
- `colorMode.tsx` (4 casts) -- Chakra theme internals, fragile to type
- `stories/*.tsx` (2 casts) -- Ladle stories, non-critical
- `Login.tsx` (1 cast) -- minor form event cast
- `MarketTracked.tsx` (1 cast) -- assess if simple to fix
- `SettingsPreferences.test.tsx` (1 cast), `SettingsProfile.test.tsx` (2 casts) -- test mocks
- `coverage.test.ts` (1 cast) -- test
- `SymbolChartUI.tsx` (1 cast) -- TradingView widget

**Net reduction**: ~15-17 casts removed (from 28 to ~11-13, all in test/theme/story files).

---

## Checkpoint B: Pagination for Transactions

In [frontend/src/pages/portfolio/PortfolioTransactions.tsx](frontend/src/pages/portfolio/PortfolioTransactions.tsx):

1. Add state: `const [page, setPage] = useState(1);` and `const [pageSize, setPageSize] = useState(50);`
2. Replace hardcoded `limit: 500, offset: 0` in `activityParams` with `limit: pageSize, offset: (page - 1) * pageSize`
3. Reset `page` to 1 when any filter changes (add `page` reset in the deps or a `useEffect`)
4. Import `Pagination` from `../../components/ui/Pagination`
5. After the `SortableTable`, add the `Pagination` component:

```tsx
<Pagination
  page={page}
  pageSize={pageSize}
  total={activityQuery.data?.total ?? activity.length}
  onPageChange={setPage}
  onPageSizeChange={(ps) => { setPageSize(ps); setPage(1); }}
/>
```

1. The backend `/portfolio/activity` endpoint needs to return a `total` count. Check if it already does; if not, add `total` to the response in [backend/api/routes/portfolio.py](backend/api/routes/portfolio.py) or the activity aggregator.

---

## Checkpoint C: Skeleton Loading Adoption

### C1. PortfolioHoldings.tsx

Import `TableSkeleton` from `../../components/shared/Skeleton`. In the `AccountFilterWrapper` children, add a loading check before the table:

```tsx
{positionsQuery.isLoading ? (
  <TableSkeleton rows={8} cols={6} />
) : ( /* existing SortableTable */ )}
```

### C2. PortfolioOptions.tsx

Import `StatCardSkeleton` and `TableSkeleton`. Show `StatCardSkeleton` for the summary row and `TableSkeleton` for the options groups when loading.

### C3. PortfolioTransactions.tsx

Import `TableSkeleton`. Replace the `emptyMessage={activityQuery.isLoading ? 'Loading...' : ...}` pattern with:

```tsx
{activityQuery.isLoading ? (
  <TableSkeleton rows={10} cols={7} />
) : (
  <SortableTable ... emptyMessage="No activity in this range." />
)}
```

---

## Checkpoint D: SortableTable Filter Debounce

In [frontend/src/components/SortableTable.tsx](frontend/src/components/SortableTable.tsx):

1. Import `useDebounce` from `../hooks/useDebounce`
2. The text filter `Input` on line ~617 fires `updateRule` on every keystroke. Instead, add local state per filter rule for text values and debounce them:
  - Add a new small component `DebouncedFilterInput` that wraps `Input` with local state + `useDebounce`, calling `updateRule` only after the debounce settles (300ms)
  - Replace the inline `<Input ... onChange={(e) => updateRule(...)} />` with `<DebouncedFilterInput ... />`
3. This only applies to text/number `<Input>` elements, not the `<NativeSelectField>` dropdowns (those should remain immediate).

---

## Checkpoint E: Accessibility Polish

### E1. PnlText -- add `aria-label`

In [frontend/src/components/shared/PnlText.tsx](frontend/src/components/shared/PnlText.tsx), add `aria-label` to the outer `<Text>`:

```tsx
<Text
  fontSize={fontSize}
  color={color}
  as="span"
  display="inline-flex"
  alignItems="center"
  gap={1}
  aria-label={`${isPositive ? 'Gain' : isZero ? 'No change' : 'Loss'}: ${display}`}
>
```

The arrow chars already have `aria-hidden="true"` (good). The arrows also serve as colorblind indicator (triangle up/down) -- already implemented.

### E2. StageBar -- add container `aria-label`

In [frontend/src/components/shared/StageBar.tsx](frontend/src/components/shared/StageBar.tsx), add `role="img"` and `aria-label` to the outer bar container:

```tsx
<Box
  display="flex"
  h="24px"
  borderRadius="md"
  overflow="hidden"
  role="img"
  aria-label={`Stage distribution: ${STAGES.map(s => `${s}: ${counts[s] ?? 0}`).join(', ')}`}
>
```

### E3. Mobile overflow on tables

In the portfolio page files that use `SortableTable`, wrap the table area in `<Box overflowX="auto">` if not already done. Check `SortableTable.tsx` itself -- if it doesn't have `overflowX="auto"` on its root, add it there so all consumers benefit.

### E4. Responsive grid

In `PortfolioOverview.tsx`, ensure the KPI StatCard row uses responsive columns: `gridTemplateColumns={{ base: 'repeat(2, 1fr)', md: 'repeat(4, 1fr)' }}` (or flex with `minW` + `flexWrap`). Verify this is already the case; if using `display="flex" gap={3} flexWrap="wrap"` with `flex="1" minW="120px"` on each card, that's fine.

---

## Checkpoint F: Docs Overhaul

### F1. Create `docs/assets/` directory

Generate architecture diagrams as images. Since we can't render mermaid to PNG from CLI easily, write the mermaid source into the markdown files directly using fenced code blocks. Readers can render them in GitHub (which supports mermaid natively) or VS Code.

### F2. Rewrite `docs/ARCHITECTURE.md`

Replace with a comprehensive architecture doc that includes:

- **Three Pillars diagram** (mermaid flowchart: Portfolio read-only, Intelligence brain, Strategy execution)
- **System Overview**: FastAPI + Celery + PostgreSQL + Redis + React
- **RBAC model** (keep existing content, it's good)
- **Auth & Security** (keep)
- **Sync Lifecycle**: Broker account add -> auto Celery sync -> positions/trades/options populated -> daily snapshot
- **Market Data Pipeline**: Universe tracking -> yfinance fetch -> indicator calculation -> MarketSnapshot
- **Market-Portfolio Bridge**: LEFT JOIN MarketSnapshot on Position.symbol for stage/RS enrichment
- **Strategy Engine** (planned): Strategy -> RuleEvaluator -> Signal -> OrderEngine
- **Category Engine** (planned): CategoryRule model -> auto-categorize -> drift detection -> rebalance proposals
- **Scheduling**: Celery Beat cron schedule table (already in DB)
- **Frontend Architecture**: React + Chakra v3 + React Query + Recharts + TradingView

### F3. Rewrite `docs/ROADMAP.md`

Update to match the 3-section Master Blueprint structure:

- **Section 1 -- Foundation** (mark items as done/remaining)
- **Section 2 -- Smart Categories + Strategy Engine** (pending)
- **Section 3 -- Live Execution + Polish** (pending)
- Remove legacy milestones

### F4. Update `docs/PORTFOLIO.md`

Add:

- Updated route table (all 6 portfolio pages with routes)
- Sync lifecycle flow (brokerage -> positions -> snapshots)
- Market data integration (how portfolio gets stage/RS)
- Smart categories (planned -- CategoryRule model, presets)
- Component architecture (shared components, hooks, types)

### F5. Update `docs/frontend-ui.md`

Add:

- Updated component map (shared/ directory: StatCard, StageBar, StageBadge, PnlText, Skeleton)
- Skeleton loading pattern with code example
- Pagination pattern with code example
- AccountFilterWrapper pattern
- ChartContext + SymbolLink pattern (used across Market and Portfolio)
- Ladle story inventory

### F6. Update `docs/MODELS.md`

Add:

- CategoryRule model (planned for Section 2)
- Order model (planned for Section 3)
- Updated enum values (StrategyStatus, SignalType additions planned)
- Market data model relationships (MarketSnapshot, DailyBar, etc.)

---

## Checkpoint G: Tests

Write tests alongside each checkpoint:

### G1. Type safety

- No new tests needed -- existing tests validate behavior. TypeScript compiler (`tsc --noEmit`) is the test.

### G2. Pagination

- Add test in `frontend/src/pages/__tests__/PortfolioTransactions.test.tsx`: mock API to return `{ total: 75 }`, verify Pagination component renders with correct range label.

### G3. Skeletons

- Add snapshot test: render Holdings/Options/Transactions in loading state, verify `TableSkeleton` appears.

### G4. Accessibility

- Add test for PnlText: verify `aria-label` contains "Gain" for positive, "Loss" for negative.
- Add test for StageBar: verify container has `aria-label` with stage distribution.

### G5. Run full suite

- `cd frontend && npx tsc --noEmit && npm run lint && npm test`
- `cd backend && make test` (backend unchanged, should still pass)

---

## Execution Order

1. **A (Type Safety)** -- foundational, touches many files but mechanical changes
2. **B (Pagination)** -- small, isolated to Transactions page
3. **C (Skeletons)** -- small, 3 page files
4. **D (Filter Debounce)** -- isolated to SortableTable
5. **E (Accessibility)** -- small touches across shared components
6. **G (Tests)** -- write alongside B-E, run full suite at end
7. **F (Docs)** -- last, after all code is stable

## Commit Strategy

One commit per checkpoint (A through G), or group small ones (B+C+D+E as one commit). Push as a single PR branch.