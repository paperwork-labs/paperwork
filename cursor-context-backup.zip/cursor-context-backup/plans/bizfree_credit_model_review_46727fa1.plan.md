---
name: BizFree Credit Model Review
overview: "McKinsey-style review of the BizFree credit-based RA model: RA is $49/yr (80% cheaper than LegalZoom), but users earn credits toward free RA by completing their post-formation business setup checklist. Transparent, aligned incentives, and the math is backed by actual referral commission data. Reviewed by all personas."
todos:
  - id: bizfree-finalize
    content: "Co-founder decision: confirm the credit-based RA model for BizFree"
    status: pending
  - id: bizfree-ra-partner
    content: Research and contact RA wholesale partners (Northwest, Harbor Compliance, InCorp) for reseller/white-label pricing
    status: pending
  - id: bizfree-affiliates
    content: "Apply to affiliate programs: Novo (banking), Gusto (payroll), QuickBooks (bookkeeping), Next Insurance, Hiscox"
    status: pending
  - id: bizfree-domain
    content: Naming session for BizFree (placeholder name) + secure domain
    status: pending
  - id: filefree-priority
    content: "Continue FileFree Sprint 4 as priority #1 -- BizFree build starts after Sprint 4 completes (May/June 2026)"
    status: pending
isProject: false
---

# BizFree: The Credit Model (McKinsey Review v3)

**Classification**: Internal -- Founders + Advisors
**Prepared by**: AI Strategy Team (multi-persona review)
**Date**: March 2026

---

## 1. The Model: Transparent Credits, Not Hidden Referrals

### Pricing (What the User Sees)


| Service                | Price      | Notes                                       |
| ---------------------- | ---------- | ------------------------------------------- |
| LLC Formation          | **FREE**   | User pays only state filing fee             |
| EIN Application        | **FREE**   | IRS is free, we guide the process           |
| Operating Agreement    | **FREE**   | AI-generated, customized PDF                |
| Compliance Calendar    | **FREE**   | Automated reminders, annual report tracking |
| Registered Agent       | **$49/yr** | 80% cheaper than LegalZoom ($249)           |
| **...OR earn it free** | **$0**     | Complete your business setup, earn credits  |


### The Credit System (What Makes It Work)

When a user forms their LLC, they see a **Business Setup Checklist**. Each completed step earns credits toward free RA:

```
YOUR BUSINESS SETUP CHECKLIST
==============================

[x] Form your LLC                          ✓ Done
[ ] Get your EIN                           ✓ Free — we walk you through it
[ ] Open a business bank account           → 1 YEAR FREE RA
[ ] Get a business insurance quote         → 6 MONTHS FREE RA
[ ] Set up bookkeeping                     → 6 MONTHS FREE RA
[ ] Refer a friend who forms their LLC     → 1 YEAR FREE RA

Complete all steps: up to 3 YEARS of free registered agent service.
```

**The transparency pitch:**

> "We partner with trusted business tools like [Mercury/Novo], [Next Insurance], and [QuickBooks]. When you sign up through us, they pay us a referral fee. We pass that value back to you as free registered agent service. You save money. They get a customer. We earn a referral fee. Everyone wins."

This is not hidden. This is not tacky. This is **honest commerce**.

---

## 2. The Math: Does Every Credit Pay For Itself?

### Per-Credit Economics


| Action                     | Credit Given                    | RA Cost to Us | Referral We Earn           | Net to Us        |
| -------------------------- | ------------------------------- | ------------- | -------------------------- | ---------------- |
| Open business bank account | 1 year free RA ($49 value)      | $30-50        | $40-150                    | **+$0 to +$120** |
| Get insurance quote        | 6 months free RA ($24.50 value) | $15-25        | $25                        | **$0 to +$10**   |
| Set up bookkeeping         | 6 months free RA ($24.50 value) | $15-25        | $50                        | **+$25 to +$35** |
| Refer a friend             | 1 year free RA ($49 value)      | $30-50        | $70+ (full new user value) | **+$20 to +$40** |


**Key insight: Every credit is self-funding.** We never give away more RA value than we earn in referral revenue. The credits ARE the referral revenue, repackaged as user value.

### Scenario Analysis: Four User Types

**User A -- "Does Everything" (best case)**

- Opens bank account, gets insurance quote, sets up bookkeeping
- Credits earned: 2 years free RA
- Referral revenue: $40-150 (bank) + $25 (insurance) + $50 (bookkeeping) = **$115-225**
- RA cost over 2 years: $60-100
- **Net profit: $15-165**

**User B -- "Just Banking" (common case)**

- Opens bank account only (everyone needs one)
- Credits earned: 1 year free RA
- Referral revenue: $40-150
- RA cost for 1 year: $30-50
- Year 2: pays $49/yr for RA
- **Net profit Year 1: $0-120. Year 2+: $0-19/yr on RA.**

**User C -- "Does Nothing" (passive user)**

- Forms LLC, doesn't complete checklist
- Credits earned: none
- Pays $49/yr for RA
- RA cost: $30-50/yr
- **Net profit: -$1 to +$19/yr on RA**
- But: still profitable overall because formation is free (cost us $0.02) and some will convert later

**User D -- "Forms and Disappears" (churns)**

- Forms LLC, never signs up for RA
- Revenue: $0
- Cost: $0.02 (formation)
- **Net: -$0.02** (irrelevant)

### Blended Economics (assuming realistic distribution)


| User Type            | % of Users | ARPU          | RA Cost/Yr | Annual Profit       |
| -------------------- | ---------- | ------------- | ---------- | ------------------- |
| A -- Does Everything | 15%        | $170          | $50        | $120                |
| B -- Just Banking    | 40%        | $75 + $49 yr2 | $40        | $35 yr1, $0-19 yr2+ |
| C -- Pays $49/yr RA  | 25%        | $49/yr        | $40        | $9/yr               |
| D -- Churns / no RA  | 20%        | $0            | $0         | $0                  |
| **Blended**          | 100%       | **~$77**      | **~$32**   | **~$45 Year 1**     |


**Blended Year 1 profit: ~$45/user.** Not the $200+ fantasy from earlier, but honest and sustainable.

At 10,000 users: **$450K profit** in Year 1, growing with volume.
At 50,000 users: **$2.25M profit** in Year 1.

---

## 3. Why NOT Build Payroll (Gusto Competitor)

The user correctly identified this is a trap. Here's why:


| Factor              | Build Payroll                                                  | Refer to Gusto               |
| ------------------- | -------------------------------------------------------------- | ---------------------------- |
| Engineering effort  | 3-6 months, complex                                            | 0 hours, affiliate link      |
| Compliance risk     | HIGH (IRS penalties for payroll errors are personal liability) | ZERO (Gusto's problem)       |
| ACH/banking partner | Need one (months to set up)                                    | Not needed                   |
| State payroll tax   | 50 different state registration + filing requirements          | Not our problem              |
| Revenue             | $15-20/mo per customer (IF they adopt)                         | $300-1,000 one-time referral |
| Market fit          | Most new LLCs have 0 employees                                 | Only 8-10% need payroll      |
| Focus dilution      | Massive distraction from FileFree Jan 2027 launch              | Zero distraction             |


**The Gusto referral commission ($300-1,000) for the 8-10% who need payroll is better economics than building a competing product for that same 8-10%.**

You'd need 15-50 months of $20/mo payroll revenue to match ONE Gusto referral commission. And you'd carry all the compliance liability.

Building payroll makes sense at 100K+ users when you have a dedicated engineering team. For 2026 with two co-founders and a Jan 2027 FileFree launch, it's scope death.

**Use Gusto referrals as a bonus credit, not a core dependency:**

- "Set up payroll through our partner → 2 years free RA"
- We earn $300-1,000 from Gusto
- We spend $60-100 on RA
- Net: $200-900 profit
- But this only hits 8-10% of users, so it's gravy, not the foundation

---

## 4. Competitive Positioning

### The Anti-LegalZoom Pitch


|                       | LegalZoom                                 | BizFree                                             |
| --------------------- | ----------------------------------------- | --------------------------------------------------- |
| Formation             | $0 (but then upsells hit)                 | $0 (genuinely)                                      |
| RA pricing            | $249-299/yr (auto-renews, hard to cancel) | $49/yr (or FREE with credits)                       |
| EIN                   | $159 (bundled in Pro)                     | FREE                                                |
| Operating Agreement   | $249 (bundled in Pro)                     | FREE                                                |
| Checkout experience   | "Notorious for aggressive upselling"      | Transparent checklist with earned credits           |
| How they make money   | Charge YOU subscription fees              | Partners pay US when you sign up for tools you need |
| **Year 1 total cost** | **$657-1,000**                            | **$0-49**                                           |


**Marketing headline**: "LegalZoom's 'free' LLC costs you $657 in Year 1. Ours costs you $0."

### vs ZenBusiness


|            | ZenBusiness                                | BizFree                            |
| ---------- | ------------------------------------------ | ---------------------------------- |
| RA Year 1  | Free (included in $0 Starter)              | $49 (or free with credits)         |
| RA Year 2+ | $199/yr (surprise renewal)                 | $49/yr (or free with credits)      |
| The catch  | Free Year 1 is a trap for $199/yr renewals | Credits are transparent and earned |


ZenBusiness gives Year 1 free, then hopes you forget to cancel before the $199 renewal hits. That's a dark pattern. BizFree's credit system is the opposite -- it rewards you for doing things you need to do anyway.

---

## 5. Persona Reviews

### Strategy (Chief of Staff)

The credit model solves the three problems with the previous approach:

1. **RA cost sustainability**: Credits are self-funding. Each credit earns at least as much referral revenue as the RA cost it covers.
2. **"Actually free" positioning**: Users CAN get free RA. They just need to complete their business setup -- things they'd do anyway.
3. **Transparency vs dark patterns**: While LegalZoom uses aggressive upselling and ZenBusiness uses surprise renewals, BizFree uses honest incentives. This is a brand differentiator, not just a pricing difference.

The $49/yr base price is also defensible -- it's real revenue from users who don't engage with credits, and it's 80% cheaper than LegalZoom. No one will complain about $49/yr.

**Verdict: APPROVED.** This is a more honest model than what I initially proposed. Better to promise $49/yr and over-deliver with credits than to promise "free everything" and struggle with the economics.

### CFO (Cost Optimizer)

Previous model had a hole: free RA at $30-50/yr wholesale with only $70 in one-time referral revenue = potential lifetime loss. The credit model fixes this:

- Users who earn credits: referral revenue covers RA cost (self-funding)
- Users who don't: $49/yr RA revenue covers $30-50 cost (marginally profitable)
- No user type is a net loss over their lifetime

**Unit economics are now clean:**

- Blended ARPU: ~$77/user Year 1
- Blended cost: ~$32/user Year 1 (RA + infrastructure)
- Blended profit: ~$45/user Year 1
- Gross margin: ~58% (lower than FileFree's 99%, but still strong for a service that includes physical infrastructure)

**Risk factor**: If the RA wholesale partner raises prices above $50/yr, margins compress. Mitigation: negotiate volume discounts as user base grows, or switch partners (Harbor Compliance at $89 retail implies ~$25-35 wholesale).

**Verdict: APPROVED.** Every credit pays for itself. The $49/yr base protects against users who don't engage. No scenario produces a lifetime loss.

### Growth (Head of Growth)

The credit system IS the growth engine. Consider:

1. **The checklist is the onboarding funnel.** New LLC owner sees 6 steps. Each step is a monetization touchpoint disguised as a helpful checklist item. Users WANT to complete it because each step earns credits.
2. **Referral credit creates viral loop.** "Refer a friend who forms their LLC → 1 year free RA." At $49 value, this is a meaningful incentive. If 10% of users refer one friend, that's 10% organic growth per cohort.
3. **The "I got my LLC and RA for free" story is TikTok gold.** "I started my LLC in 3 minutes and got 2 years of registered agent for free. Here's how." This is inherently shareable content.
4. **SEO content writes itself:** "How to get a free registered agent for your LLC (2026)" -- this keyword has zero competition because nobody offers it.

**Verdict: APPROVED.** The credit system converts a cost center (RA) into a growth mechanic.

### Legal (General Counsel)

- **FTC disclosure**: Required on the checklist page. "We may earn a referral fee when you sign up for partner services through our links. This doesn't affect the price you pay." Standard, same as NerdWallet, Credit Karma, every affiliate site.
- **Practicing law**: Formation document preparation from user-provided information is NOT practicing law. LegalZoom precedent (multiple state bar cases, 2003-2015). Need clear disclaimer: "We prepare documents based on your answers. This is not legal advice."
- **RA service**: If we partner with a licensed RA provider, they carry the compliance burden. We're a technology/distribution layer. Our terms of service should make the RA provider relationship clear.
- **Credit system**: No gambling/sweepstakes concerns because credits are deterministic (do X, get Y). No randomness. This is a standard loyalty/rewards program structure.

**Verdict: APPROVED with standard FTC disclosures and "not legal advice" disclaimers.**

### CPA (Tax Advisor)

The cross-sell to FileFree is the most under-appreciated part of this model:

- Every BizFree user who forms an LLC needs to file taxes for that LLC
- Single-member LLC = Schedule C on their 1040 (FileFree can handle this)
- Multi-member LLC = partnership return (Form 1065, future FileFree feature)
- Every FileFree user with side-hustle income should consider an LLC

The credit checklist should include: "Set up your business for tax time → link to FileFree" -- no credit needed, this is a direct cross-sell to our own product.

**The data compound**: If a user files taxes through FileFree AND has their LLC through BizFree, we know their personal income, business income, deductions, filing status, and business structure. This makes AI advisory incredibly powerful: "Your LLC earned $45K this year. At your income level, electing S-Corp status could save you $3,200 in self-employment tax."

**Verdict: APPROVED.** The BizFree-FileFree data flywheel is the long-term moat.

### Engineering (Staff Engineer)

The credit system is trivially implementable:

```
CreditAction:
  - action_type: "bank_account" | "insurance" | "bookkeeping" | "referral" | "payroll"
  - credit_months: 12 | 6 | 6 | 12 | 24
  - partner_name: "Novo" | "Next Insurance" | "QuickBooks" | "Gusto"
  - referral_commission: Decimal  # what we earn
  - status: "pending" | "confirmed" | "expired"

UserRASubscription:
  - base_price_cents: 4900  # $49/yr
  - credits_applied_months: Integer
  - paid_through_date: Date
  - next_billing_date: Date | null  # null if credits cover it
```

A webhook from each partner confirms the user completed the action. Credit is applied. RA billing date extends. Same partner webhook pattern as FileFree's refund routing conversion tracking.

Code reuse from FileFree: auth, database, PDF generation, landing page components, analytics, CI/CD. Estimated 70%+ shared infrastructure.

**Verdict: APPROVED.** 6-8 week build for MVP (formation + checklist + credit system + RA partner integration).

---

## 6. What This ISN'T (Avoiding Scope Creep)


| Temptation                          | Why NOT                                                                                                              |
| ----------------------------------- | -------------------------------------------------------------------------------------------------------------------- |
| Build our own payroll               | Compliance nightmare, 8-10% of users need it, Gusto referral earns $300-1K per conversion with zero engineering      |
| Build our own RA infra (Day 1)      | Partner first ($30-50/yr wholesale), own later when 10K+ users justify it. Same as FileFree + Column Tax → own MeF   |
| Free RA for everyone no matter what | The credit model makes free RA EARNED. Users who don't engage pay $49/yr (still 80% cheaper). This protects margins. |
| Compete on every LegalZoom feature  | LegalZoom does wills, trademarks, contracts. We do ONE thing: LLC formation + setup. Do it better than anyone.       |


---

## 7. Final Model Summary

```
BIZFREE = Free LLC Formation + $49/yr RA (earn it free with credits)

Revenue sources:
  1. RA subscriptions ($49/yr from non-credit users)     ~25% of users
  2. Banking referrals ($40-150/signup)                   ~55% of users
  3. Insurance referrals ($25/quote)                      ~30% of users
  4. Bookkeeping referrals ($50/signup)                   ~25% of users
  5. Gusto payroll referrals ($300-1K, rare but huge)     ~8% of users
  6. Credit card referrals ($100-200/approval)            ~10% of users
  7. FileFree cross-sell (tax filing)                     ~30% of users

Costs:
  - RA wholesale: $30-50/yr per RA subscriber
  - Infrastructure: ~$15/mo (same stack as FileFree)
  - AI/form generation: ~$0.02/user

Blended ARPU: ~$77 Year 1
Blended cost: ~$32 Year 1
Profit per user: ~$45 Year 1
Gross margin: ~58%

At scale:
  10K users = ~$450K profit
  50K users = ~$2.25M profit
  100K users = ~$4.5M profit
```

**Timeline**: Summer 2026 launch. 6-8 week build. Same stack. 70% code reuse from FileFree. Does not compete with FileFree Jan 2027 launch timeline.

---

## 8. The One-Sentence Pitch

**To users**: "Start your LLC in 3 minutes. Free. Complete your business setup checklist, and your registered agent is free too."

**To partners**: "We deliver high-intent newly formed LLC owners at the exact moment they need a business bank account, insurance, and bookkeeping. No ad spend required."

**To investors** (if ever needed): "LegalZoom is a $756M/yr business with 42% churn because they charge $249/yr for a $5 service. We give it away for free and monetize the post-formation decision moment. Same playbook as Credit Karma ($7.1B acquisition) applied to business formation."