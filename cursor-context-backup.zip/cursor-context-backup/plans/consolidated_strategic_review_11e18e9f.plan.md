---
name: Consolidated Strategic Review
overview: Data-driven self-review of our previous recommendations against the other agent's proposals, resolving every conflict with evidence, correcting errors on both sides, and producing a single definitive strategic plan for the multi-product venture.
todos:
  - id: naming-final
    content: "FOUNDER DECISION: LaunchFree (marketing-optimized, 74/80 Growth score) vs BizFree (scope-optimized, 57/80). Pick one and register domain TODAY."
    status: pending
  - id: secure-handles
    content: Secure @launchfree (or @bizfree) on TikTok, Instagram, X, YouTube -- before someone else does
    status: pending
  - id: form-llc
    content: Form LLC with neutral parent name (e.g., Sharma Ventures LLC). Complete Task B.2.
    status: pending
  - id: google-workspace
    content: Set up Google Workspace on sankalpsharma.com ($6/mo). Create Venture HQ folder. Add GDrive MCP to Cursor.
    status: pending
  - id: notion-migrate
    content: Migrate Notion docs to Google Drive. Update n8n workflow output nodes. Update .mdc persona references.
    status: pending
  - id: repo-restructure
    content: Restructure fileFree repo into pnpm workspace monorepo. Extract shared packages (ui, auth, analytics).
    status: pending
  - id: launchfree-scaffold
    content: Scaffold LaunchFree app in monorepo (Next.js frontend + FastAPI backend)
    status: pending
  - id: migrate-subdomains
    content: Move n8n/Postiz from filefree.tax subdomains to ops/social.sankalpsharma.com
    status: pending
  - id: filefree-background
    content: Continue EFIN application + Column Tax partnership (background tasks) while building LaunchFree
    status: pending
isProject: false
---

# Consolidated Strategic Review: Honest Self-Audit + Synthesis

This document resolves every point of conflict between our prior analysis and the other agent's "Adulting OS" plan. Where we were wrong, we say so. Where the other agent was wrong, we say so. Every recommendation is backed by data.

---

## Conflict 1: BizFree vs LaunchFree (Naming)

**Our position**: BizFree (broader scope, shorter, user's instinct)
**Other agent's position**: LaunchFree (aspirational, energetic)

### Self-Review

Our Growth persona scoring from the earlier analysis actually rated LaunchFree HIGHER (74/80) than BizFree (57/80). We then overrode our own data because the user expressed a preference for BizFree. That's bad consulting -- you don't tell the client what they want to hear, you tell them what the data says.

### The Data Says


| Factor                           | LaunchFree                         | BizFree                       |
| -------------------------------- | ---------------------------------- | ----------------------------- |
| Growth persona score             | 74/80                              | 57/80                         |
| Emotional hook                   | 9/10                               | 6/10                          |
| Gen Z / young founder appeal     | 9/10                               | 6/10                          |
| Tagline flexibility              | 10/10                              | 6/10                          |
| Cross-sell clarity with FileFree | "You launched? Now file."          | "You biz'd? Now file."        |
| Scope limitation risk            | Moderate ("launch" feels one-time) | Low ("biz" covers everything) |
| Domain availability              | .ai, .co, .llc, .app               | .ai, .co, .app                |
| Character count                  | 10                                 | 7                             |


### The Honest Take

LaunchFree is the stronger **marketing** name. BizFree is the safer **product** name. The user must decide which dimension matters more.

**If marketing-first** (TikTok virality, emotional hooks, "Launch your business. Free."): **LaunchFree**

**If product-first** (scope flexibility, ongoing services like RA/compliance/banking): **BizFree**

One more data point: the cross-sell story is cleaner with LaunchFree:

- "You **launched** with LaunchFree? Now **file** with FileFree." (two clear verbs)
- "You formed with BizFree? Now file with FileFree." (BizFree sounds like it should include filing)

**Revised recommendation**: LaunchFree edges out for marketing + cross-sell clarity. But this is a 55/45 call, not a 90/10 call. Either works. Pick the one you'll be more excited to market at 11pm on a Tuesday.

---

## Conflict 2: Sequencing -- Which Product First?

**Our position**: FileFree Sprint 4 first, then BizFree/LaunchFree in June
**Other agent's position**: LaunchFree first ("LaunchFree Summer, FileFree Winter")

### Self-Review: We Were Wrong

Our reasoning was: "Complete Sprint 4 tasks (3.4, 3.5, 3.6, 5.1) because they build dual-purpose infrastructure." But this ignored a critical timing reality:

**FileFree's next meaningful moment is January 2027 -- that's 10 months away.**

- Tax deadline April 15, 2026 is 35 days out
- Sprint 4 (50 state tax calcs + PDF gen) is 3-4 weeks of work
- Even if shipped by April 5, that's 10 days before deadline with zero marketing, zero users, no e-file
- FileFree cannot meaningfully serve the 2026 tax season
- The IRS MeF transmitter certification (the North Star) is a background process regardless

Meanwhile, business formation demand is year-round. Census Bureau data shows 532K business applications in January 2026 alone, with consistent demand across all months (the data is seasonally adjusted, meaning the raw numbers have seasonal variation but it never drops to zero like tax filing does).

**The math**: 10 months of building a product with year-round demand > 10 months of building a product whose next season is January 2027.

### What About "Dual-Purpose Infrastructure"?

Our argument that Sprint 4 tasks build reusable infrastructure is valid but misframed. If you're doing shared packages (monorepo or not), you build this infrastructure once FOR the business formation product and FileFree reuses it later:

- State engine pattern: Build it for "50 state LLC formation rules" -> FileFree adapts for "50 state tax rules"
- PDF generation: Build it for "Articles of Organization PDF" -> FileFree adapts for "1040 PDF"
- Email infra: Build it for "formation confirmation emails" -> FileFree adapts for "filing confirmation"
- Stripe billing: Build it for "$49/yr RA subscription" -> FileFree adapts for "$29/yr Tax Plan"

The infrastructure gets built either way. The question is which product provides the context.

### Revised Recommendation

**The other agent is right. LaunchFree/BizFree first. FileFree continues in background.**

Sequencing:

1. **Now (March 2026)**: Register domain, secure handles, form LLC
2. **March-April 2026**: Build LaunchFree/BizFree MVP (reuse 90% of FileFree code)
3. **Summer 2026**: Launch, growth marketing, iterate
4. **Background**: EFIN application, Column Tax partnership (Founder 2), MeF certification prep
5. **October 2026**: Resume FileFree Sprint 4, Column Tax sandbox integration
6. **January 2027**: FileFree tax season launch with own MeF transmitter

---

## Conflict 3: Monorepo (Turborepo) vs Separate Repos

**Our position**: Separate repos, copy patterns
**Other agent's position**: Turborepo monorepo

### Data

- pnpm workspaces + Turborepo is the dominant monorepo stack in 2026
- Turborepo config: single `turbo.json` file, low learning curve
- Build speed: 85% faster via intelligent caching
- For <5 dev teams: pnpm workspaces alone is sufficient, add Turborepo when CI optimization matters

### What's Actually Shared (Measured)

I audited the current FileFree codebase:

**Frontend (shared between products)**: ~70%

- 22 shadcn UI components
- Tailwind theme + dark mode
- Auth system (Zustand store, React Query hooks, pages)
- PostHog analytics + PII scrubbing
- Framer Motion presets
- Axios API client + response envelope
- React Hook Form + Zod patterns
- Attribution/UTM tracking

**Backend (shared patterns, not code)**: ~30%

- Auth middleware pattern (different implementations)
- Repository base class pattern
- Response envelope format
- Rate limiting setup
- AES-256 encryption utils
- Database models: COMPLETELY DIFFERENT
- Business logic: COMPLETELY DIFFERENT

### The Verdict

Frontend sharing is substantial enough to justify a monorepo. Backend sharing is pattern-level only (copy, don't import).

**But Turborepo is overkill for 2 apps.** pnpm workspaces alone gives you shared packages without build orchestration complexity. Add Turborepo later if CI gets slow.

### Revised Recommendation: pnpm Workspaces (no Turborepo)

```
venture/
  apps/
    filefree/          (Next.js frontend)
    launchfree/        (Next.js frontend)
  packages/
    ui/                (shared shadcn + Tailwind theme)
    auth/              (shared auth flows + hooks)
    analytics/         (shared PostHog + UTM)
  apis/
    filefree-api/      (Python/FastAPI - independent)
    launchfree-api/    (Python/FastAPI - independent)
  infra/               (shared Docker, Hetzner configs)
  pnpm-workspace.yaml
```

Python backends live in the same repo for convenience but are NOT managed by pnpm -- they're independent directories with their own `requirements.txt`, `pyproject.toml`, and `Dockerfile`. This is how the current FileFree repo already works (`api/` + `web/` in one repo).

**Note on AI coding context**: Cursor can be pointed at specific directories. When working on LaunchFree, set Cursor workspace to `apps/launchfree/` + `packages/`. When working on FileFree API, set workspace to `apis/filefree-api/`. The monorepo doesn't overwhelm AI context if you scope the workspace.

---

## Conflict 4: Google Drive vs Notion

**Our position**: Assumed Notion (already set up)
**Other agent's position**: Google Drive
**User**: "crisp google docs over notion for sure - always"

### Self-Review: We Should Have Asked

We assumed Notion because it was already set up (D7, D26 in KNOWLEDGE.md). We never questioned whether the user actually liked it. The other agent asked. The user clearly prefers Google Drive.

### Migration Scope

Current Notion usage:

- Strategy & Vision page
- Product Roadmap
- Decision Log
- Content Calendar
- Legal & Compliance
- Financials
- Tool Registry
- n8n workflows output to Notion databases

Migration steps:

1. Create "Venture HQ" folder in Google Drive
2. Move each Notion page to a Google Doc
3. Update n8n workflows: replace Notion nodes with Google Drive/Docs API nodes
4. Add Google Drive MCP to `.cursor/mcp.json` (official `@modelcontextprotocol/server-gdrive`, maintained by Anthropic)
5. Update all .mdc persona files to reference Google Drive instead of Notion
6. Keep Notion account active (free tier) as archive

### Revised Recommendation: Google Drive. Period.

Google Drive MCP is production-ready (v2025.1.14, maintained by Anthropic). It exports Docs to Markdown, Sheets to CSV -- perfect for AI agent consumption. User preference is clear. This is not a close call.

---

## Conflict 5: Email Strategy

**Our position**: Didn't address email
**Other agent's position**: Zoho Mail (free) + aliases

### Data Check: Zoho Free Plan Limitation

The other agent assumed Zoho Mail free tier for Chatwoot IMAP integration. **Problem: Zoho Mail free plan has NO IMAP/POP access (web-only).** Email forwarding TO Chatwoot via IMAP requires Zoho Mail Lite ($1/user/mo) or Google Workspace ($6/user/mo).

### The Right Answer

**Don't self-host email. Ever.** (Both agents agree on this.)

Options:

- **Zoho Mail Lite ($1/user/mo)**: Custom domain, IMAP/POP, 5GB storage. Cheapest option with full functionality.
- **Google Workspace ($6/user/mo)**: Custom domain, full Google ecosystem, Drive integration. More expensive but integrates with Google Drive strategy.
- **Zoho Mail Free ($0)**: Web-only access. Fine for reading email, but can't forward to Chatwoot or other tools via IMAP.

**Recommendation**: Google Workspace ($6/mo) if you're going all-in on Google Drive for docs. One ecosystem, one login, one MCP. The $6/mo is negligible. If cost-optimizing, Zoho Lite at $1/mo works.

Setup:

- `hello@sankalpsharma.com` (primary inbox)
- `support@launchfree.ai` -> alias or forwarding rule
- `support@filefree.tax` -> alias or forwarding rule

---

## Conflict 6: Support Infrastructure (Chatwoot)

**Our position**: Didn't address
**Other agent's position**: Chatwoot on Hetzner now

### Data Check: Memory Math

Chatwoot minimum RAM: **4GB** (official docs). Installation spikes: 5.5GB+.

Current Hetzner CX33 usage estimate:

- PostgreSQL: ~500MB
- Redis: ~100MB
- n8n: ~300MB
- Postiz: ~500MB
- Temporal: ~500MB
- Elasticsearch: ~256MB
- Caddy: ~50MB
- **Total: ~2.2GB**

Adding Chatwoot: +4GB = **6.2GB on an 8GB box**. That's 78% utilization before any traffic. Installation could OOM.

### The Other Agent Overpromised Here

Chatwoot technically fits but leaves no headroom. And more importantly: **you have zero users.** Building a 3-level AI support defense system before you have a single customer is textbook over-engineering.

### Revised Recommendation

**NOT now. Add Chatwoot when you have 100+ users.**

When ready:

1. Upgrade Hetzner to CX43 (16GB RAM, ~EUR 8/mo, +$3/mo)
2. Add Chatwoot to compose.yaml
3. The 3-level defense system design from the other agent is solid -- save it as a blueprint

For launch: A shared Gmail/Google Workspace inbox (`support@launchfree.ai`) is sufficient. Upgrade to Chatwoot when ticket volume exceeds what you can handle in Gmail.

---

## Conflict 7: Voice Support (Vapi)

**Other agent's position**: Vapi.ai for Phase 2 voice support

### Assessment

This is a good idea for Phase 3+ but wildly premature. At $0.10/minute and zero users, this is a solution looking for a problem.

**When to revisit**: When you have 1,000+ users and support tickets exceed 10/day. Not before.

---

## Conflict 8: "Adulting OS" Umbrella Brand

**Other agent's position**: "Adulting OS" as the portfolio concept

### Assessment

Good internal codename. Bad user-facing brand.

- "Adulting" is very Gen Z but also slightly cringe to many people
- Users don't care about your portfolio strategy -- they care about forming their LLC or filing their taxes
- The monorepo/internal project can be called `adulting-os/` but users never see it

**Recommendation**: Internal codename only. User-facing brands are LaunchFree/BizFree, FileFree, and sankalpsharma.com.

---

## What We Got Right (Keeping)

1. **Centralized ops on sankalpsharma.com** -- both agents agree
2. **Single LLC for now, restructure at $100K+** -- both agents agree
3. **bizfree.ai / launchfree.ai domain** -- both agents agree on .ai TLD
4. **Shared Hetzner VPS for ops** -- both agents agree
5. **n8n workflow namespacing** -- our original recommendation stands
6. **Credit-based RA model** -- from our earlier deep dive, still valid
7. **The Intuit/filefree.com intelligence** -- critical strategic awareness

---

## What We Got Wrong (Correcting)

1. **Sequencing**: We said "FileFree Sprint 4 first." Wrong. Business formation product first is better given tax season timing.
2. **Notion assumption**: We assumed Notion was fine because it was set up. Should have asked the user. Google Drive wins.
3. **BizFree certainty**: We let user preference override our own Growth scoring data. LaunchFree scored 74/80 vs BizFree's 57/80 in our own analysis.
4. **Separate repos**: For 70% frontend code sharing, a pnpm workspace monorepo is clearly better than copy-paste.

---

## What the Other Agent Got Wrong (Correcting)

1. **Chatwoot on current Hetzner**: 4GB minimum RAM on an 8GB box with 2.2GB already used. Tight, premature, and not needed for zero users.
2. **Zoho Mail free + Chatwoot IMAP**: Free plan has no IMAP/POP. The integration as described doesn't work without paying $1/mo minimum.
3. **Turborepo**: Overkill for 2 apps. pnpm workspaces gives the same shared-package benefit without build orchestration complexity.
4. **Vapi voice support**: Cool but Phase 3+ at earliest. Premature optimization.
5. **"Adulting OS" as branding**: Keep it internal only.

---

## The Definitive Plan

### Entity + Brand Architecture

```
Sharma Ventures LLC (or similar neutral name)
  |
  sankalpsharma.com         (venture studio / personal brand)
    ops.sankalpsharma.com   (n8n)
    social.sankalpsharma.com (Postiz)
  |
  launchfree.ai             (Product #1: Business Formation -- builds first)
  filefree.tax              (Product #2: Tax Filing -- resumes October 2026)
```

### Technical Architecture

```
venture/ (pnpm workspace monorepo)
  apps/filefree/            (Next.js -- existing code)
  apps/launchfree/          (Next.js -- new)
  packages/ui/              (shared shadcn + Tailwind theme)
  packages/auth/            (shared auth hooks + pages)
  packages/analytics/       (shared PostHog + UTM + PII scrub)
  apis/filefree-api/        (Python/FastAPI -- existing code)
  apis/launchfree-api/      (Python/FastAPI -- new)
  infra/                    (Hetzner, Docker configs)
```

### Documentation

- **Google Drive** "Venture HQ" folder (primary, via GDrive MCP)
- Notion archived (read-only reference)
- .mdc persona files stay in each Cursor workspace (code-level context)
- KNOWLEDGE.md stays in repo (agent memory, version-controlled)

### Email

- Google Workspace ($6/mo) on sankalpsharma.com
- Aliases: [support@launchfree.ai](mailto:support@launchfree.ai), [support@filefree.tax](mailto:support@filefree.tax)

### Support

- **Phase 1 (launch)**: Shared Google Workspace inbox
- **Phase 2 (100+ users)**: Chatwoot on upgraded Hetzner CX43 + n8n AI agent
- **Phase 3 (1000+ users)**: Vapi voice support if warranted

### Monthly Burn (Portfolio)


| Item                 | Cost        | Notes                     |
| -------------------- | ----------- | ------------------------- |
| Hetzner CX33         | EUR 5.49    | n8n, Postiz, Temporal, ES |
| Render (FileFree)    | $7          | Starter plan              |
| Render (LaunchFree)  | $7          | Starter plan              |
| Vercel x2            | $0          | Hobby tier (free)         |
| Neon x2              | $0          | Free tier                 |
| Upstash x2           | $0          | Free tier                 |
| Google Workspace     | $6          | Email + Drive             |
| launchfree.ai domain | ~$5         | .ai annual                |
| **Total**            | **~$31/mo** | up from $12.49            |


### Sequencing

1. **Now**: Register launchfree.ai (or bizfree.ai), secure social handles, form LLC
2. **March-April**: Restructure repo into pnpm workspace, extract shared packages, scaffold LaunchFree
3. **May-July**: Build LaunchFree MVP, launch, growth marketing
4. **Background**: EFIN application, Column Tax partnership, MeF prep
5. **October**: Resume FileFree development, Column Tax integration
6. **January 2027**: FileFree tax season launch

