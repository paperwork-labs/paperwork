---
name: Update to GPT-5 Models
overview: Update both the HTML proposal and Loom script/glossary to replace all GPT-4o references with current GPT-5 family models, correct pricing ratios, and refresh the glossary with the full current OpenAI product catalog (March 2026).
todos:
  - id: update-html-models
    content: "Replace all GPT-4o/GPT-4o mini references with GPT-5/GPT-5 mini in discord-openai-proposal.html (6 locations: capabilities, data flow, cost discipline, risk table, closing)"
    status: completed
  - id: update-loom-script
    content: Replace all GPT-4o/GPT-4o mini references with GPT-5/GPT-5 mini in the Loom script sections (lines 53, 59, 83, 103)
    status: completed
  - id: rewrite-glossary
    content: "Rewrite the OpenAI Product Glossary with current model lineup: GPT-5/GPT-5.4, GPT-5 mini, updated Realtime API (gpt-realtime-1.5), omni-moderation, Fine-tuning (GPT-4.1), Agents SDK, corrected pricing ratios"
    status: completed
  - id: update-interview-prep
    content: "Update interview prep answers: consumption math with GPT-5 mini pricing, fine-tuning model clarification, add fine-tuning gotcha Q&A, update competitive landscape answer"
    status: completed
isProject: false
---

# Update OpenAI Model References to GPT-5 Family

## Research Summary

From the live OpenAI docs (platform.openai.com/docs/models), as of March 9, 2026:

**Current Frontier Models:**

- **GPT-5.4** (released March 5, 2026): $2.50/$15 per MTok, 1M context, highest reasoning
- **GPT-5** (released Aug 7, 2025): $1.25/MTok input, previous reasoning model
- **GPT-5 mini** (released Aug 7, 2025): $0.25/$2 per MTok, 400K context, near-frontier
- **GPT-5 nano**: $0.05/MTok input, fastest/cheapest

**Fine-tuning availability:**

- GPT-4.1 and GPT-4.1 mini: Supported
- GPT-5, GPT-5.4, GPT-5 mini: NOT supported
- GPT-4o, GPT-4o mini: Still available (not deprecated)

**Other current products:**

- Whisper (`whisper-1`): Still current, plus `gpt-4o-transcribe` variants
- Realtime API: Now has `gpt-realtime-1.5` (best voice model)
- Embeddings: `text-embedding-3-small` / `text-embedding-3-large` (unchanged)
- Moderation: Upgraded to `omni-moderation` (handles text AND images)
- Agents SDK: New framework for building AI agents
- Structured Outputs: Supported on GPT-5.4 and GPT-5 mini

## Changes to [discord-openai-proposal.html](olgaSharma/discord-openai-proposal.html)

Six targeted replacements:

1. **Line 274** (Conversation Catch-Up capability): "GPT-4o mini" -> "GPT-5 mini", "GPT-4o takes on" -> "GPT-5 takes on"
2. **Line 281** (Voice Intelligence capability): "GPT-4o turns transcripts" -> "GPT-5 turns transcripts"
3. **Line 318** (Data flow diagram): Update model names in all flow lines
4. **Line 331** (Cost discipline bullet): "GPT-4o mini" -> "GPT-5 mini", "GPT-4o is reserved" -> "GPT-5 is reserved"
5. **Line 353** (Risk table, Cost at scale row): "GPT-4o mini" -> "GPT-5 mini", "GPT-4o for complex" -> "GPT-5 for complex"
6. **Line 373** (Closing, product list): "(GPT-4o, GPT-4o mini," -> "(GPT-5, GPT-5 mini,"

**Keep unchanged:**

- "seven products" count stays at 7 (same product categories, updated model names)
- Fine-tuning API line in data flow (doesn't mention a specific model, so remains accurate)
- Whisper, Realtime API, Embeddings, Moderation references (still current product names)

## Changes to [loom-talking-points.md](olgaSharma/loom-talking-points.md)

### Script Sections (6 replacements)

1. **Line 53** (Section 3, Conversation Catch-Up): "GPT-4o mini" -> "GPT-5 mini", "GPT-4o steps in" -> "GPT-5 steps in"
2. **Line 59** (Section 3, Voice Intelligence): "GPT-4o then turns" -> "GPT-5 then turns"
3. **Line 83** (Section 4, Technical Reasoning): "GPT-4o for complex analysis, GPT-4o mini for high-volume filtering" -> "GPT-5 for complex analysis, GPT-5 mini for high-volume filtering"
4. **Line 103** (Section 5, Risks): "GPT-4o mini handles" -> "GPT-5 mini handles", "You reserve GPT-4o" -> "You reserve GPT-5"
5. **Line 113** (Section 6, Close): No model-specific references (says "seven-product"), keep as-is
6. **Line 115** (Section 6): No model-specific references, keep as-is

### Glossary - Full Rewrite Required

Replace the current glossary entries (lines 128-168) with updated versions:

- **GPT-5** (replaces GPT-4o entry): $1.25/$10 per MTok, reasoning model, 400K context. Note GPT-5.4 is the latest flagship ($2.50/$15, 1M context, released March 5, 2026)
- **GPT-5 mini** (replaces GPT-4o mini entry): $0.25/$2 per MTok, 400K context. 5x cheaper than GPT-5 (not "30x" as the old glossary claimed for GPT-4o mini)
- **Whisper**: Keep largely the same, mention `gpt-4o-transcribe` and diarization variants are still available
- **Realtime API**: Update to mention `gpt-realtime-1.5` as the latest voice model
- **Embeddings API**: No changes needed
- **Moderation API**: Update to mention `omni-moderation-latest` handles text AND images (old text-only moderation deprecated)
- **Fine-tuning API**: Critical update - currently available for GPT-4.1 and GPT-4.1 mini, NOT yet supported on GPT-5 models. Still a valid product in the proposal since it's model-agnostic in the data flow
- **Structured Outputs**: Update to note availability on GPT-5 and GPT-5 mini
- **Tokens**: Update pricing examples from "30x less" to "5x less" for mini vs full model
- **New entry: Agents SDK**: Framework for building AI agents, relevant for Discord's community management automation

### Interview Prep - Full Rewrite (lines 172-218)

Keep the existing Q&As but update every model reference, pricing figure, and competitive claim. Also add 3 new Q&As that could come up now that the model landscape has changed. All answers should be fully written out as speakable sentences (not bullets), so Olga can rehearse them as-is.

**Existing Q&As to update:**

1. **"Why Discord?"** - Mostly unchanged (no model references). Keep the "seven products" framing. Confirm the seven are: GPT-5, GPT-5 mini, Whisper, Realtime API, Embeddings, Moderation, Fine-tuning.
2. **"First 90 days?"** - Mostly unchanged. Update the Clyde reference: "they deprecated Clyde in early 2024" stays factual. Add awareness that Discord has since invested in AutoMod AI and server-level AI features, showing internal appetite.
3. **"What's consumption revenue?"** - Update the model references: "GPT-5 mini pricing" instead of "GPT-4o mini pricing." The core narrative stays the same but pricing context changes.
4. **"Isn't Discord already building AI?"** - Keep Clyde/AutoMod history. Strengthen the "build vs. buy" argument: OpenAI now has Agents SDK, Realtime API, omni-moderation, and Fine-tuning in one platform. Building all of that in-house would be a massive distraction from Discord's core product.
5. **"What if they want Anthropic or Google?"** - Update competitive landscape:
  - Anthropic: Still no voice/speech product (no Whisper or Realtime API equivalent). Strong on text reasoning but can't match the breadth.
  - Google/Gemini: Has speech capabilities but not the Realtime API's low-latency WebRTC/SIP integration. Google's moderation tooling is fragmented vs. OpenAI's single omni-moderation endpoint.
  - Key defense: No competitor covers text reasoning, voice transcription, live audio, embeddings, moderation, fine-tuning, and structured outputs from one platform. OpenAI is the only single-vendor solution for all seven capabilities.
6. **"Walk me through the consumption math"** - Full rewrite with GPT-5 mini pricing:
  - 19M active servers, 5% adopt = 950K servers
  - 500 msgs/day average, 10% trigger model calls = 47M API calls/day
  - GPT-5 mini at $0.25/MTok input: at ~200 tokens per message, that's ~9.4B input tokens/day = ~$2,350/day just on input classification
  - Add voice transcription (Whisper at higher per-call revenue), summarization (GPT-5 at $1.25/MTok for complex tasks), embeddings, moderation
  - Conservative total: multi-million dollar annual contract
  - Growth lever: as more servers adopt and voice features launch, volume compounds

**New Q&As to add:**

1. **"GPT-5.4 just launched last week. How does that change the proposal?"** - Full scripted answer:
  "Great question. GPT-5.4 launched March 5th and it's the most capable model OpenAI has ever released, with a million-token context window, native computer use, and the highest reasoning scores. For Discord's use case, GPT-5.4 would be relevant for the most complex analytical tasks, like generating multi-day thread summaries across hundreds of messages or powering the Community Health Insights feature where admins ask open-ended questions about their server. But for the high-volume work like message classification and daily digests, GPT-5 mini at $0.25 per million tokens is the right fit. That cost discipline is what makes the deal viable at Discord's scale. The beauty of OpenAI's model family is that Discord can route different tasks to different models and upgrade specific workflows to GPT-5.4 as the value justifies the cost."
2. **"Which model would Discord fine-tune?"** - Critical gotcha answer:
  "Right now, fine-tuning is available on GPT-4.1 and GPT-4.1 mini, which are excellent non-reasoning models that support supervised fine-tuning, DPO, and even vision fine-tuning. GPT-5 models don't support fine-tuning yet. For Discord's use case, fine-tuning GPT-4.1 mini to understand community-specific norms, slang, and relevance signals is actually a smart starting point, because 4.1 mini is fast, cost-efficient, and purpose-built for tool calling and instruction following. As fine-tuning support expands to GPT-5 models, Discord could upgrade those custom models to get reasoning capabilities on top of their community-specific training. That's a natural expansion path within the account."
3. **"What about the Agents SDK? Should Discord use it?"** - Shows platform awareness:
  "The Agents SDK is newer and very relevant here. Discord could use it to build community management agents that chain multiple tools together: an agent that monitors a channel, calls the Moderation API to check content, uses Embeddings to find related past conversations, and then generates a summary or Q&A response using GPT-5 mini, all in a single orchestrated workflow. The SDK handles the agent loop, tool routing, and error recovery. For the proposal, I focused on the individual API products because that's where the consumption revenue lives, but the Agents SDK is how Discord would actually wire it all together in production. It makes the integration stickier because they're not just calling individual endpoints; they're building agent workflows on top of OpenAI's infrastructure."

**Discord Quick Facts updates:**

- Keep all current facts
- Add: "Discord deprecated Clyde (AI chatbot) in early 2024 but has since invested in AutoMod AI and server-level AI experiments, signaling continued AI appetite"
- Confirm CEO is still Jason Citron (yes, as of 2026)

**"Things NOT to Say" additions:**

- Don't say "GPT-4o" or "GPT-4" in conversation. Those are previous generation. If you accidentally say it, correct yourself: "sorry, GPT-5 mini"
- Don't claim fine-tuning works on GPT-5 models. It doesn't yet. Say "GPT-4.1" for fine-tuning
- Don't call GPT-5.4 "GPT 5 point 4" -- say "GPT five-four" (how OpenAI employees say it)
- Don't confuse the Realtime API with Whisper. Whisper processes recorded audio after the fact. The Realtime API handles live, streaming audio. They're complementary products, not the same thing

