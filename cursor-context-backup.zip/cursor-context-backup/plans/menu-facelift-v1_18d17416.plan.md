---
name: menu-facelift-v1
overview: Restructure the main navigation into Market/Portfolio/Strategy sections, add a stored admin toggle for Market-only release, enforce non-admin route blocking, and remove legacy pages/routes per your choice.
todos:
  - id: app-settings-backend
    content: Add app settings model + migration + admin API endpoints
    status: completed
  - id: route-guards
    content: Enforce market-only on backend + frontend routes
    status: completed
  - id: menu-restructure
    content: Refactor sidebar into Market/Portfolio/Strategy groups with role gating
    status: completed
  - id: legacy-cleanup
    content: Remove legacy pages/routes/tests not in V1 scope
    status: completed
  - id: admin-toggle-ui
    content: Add admin toggle UI for market-only mode
    status: completed
isProject: false
---

# Menu Facelift V1 Plan

## Decisions captured

- Admin toggle: backend feature flag stored + admin UI toggle.
- Market-only mode: non‑admins blocked from non‑Market routes; admins can still access them (hidden by default).
- Legacy cleanup: remove code/routes/tests for legacy pages.

## Approach

- Add a small persistent app setting (DB) for `market_only_mode` and expose admin read/write API endpoints.
- Use that flag on the backend to enforce access for non‑admins on non‑Market routes.
- Update the main sidebar to show only Market for non‑admins (or when market‑only is on), and show Portfolio/Strategy for admins.
- Remove legacy pages/routes/components (and tests) that are no longer part of V1.

## Files to update

- Navigation + layout: `[frontend/src/components/layout/DashboardLayout.tsx](frontend/src/components/layout/DashboardLayout.tsx)`
- Routes: `[frontend/src/App.tsx](frontend/src/App.tsx)`
- Settings admin UI (toggle): `[frontend/src/pages/SettingsShell.tsx](frontend/src/pages/SettingsShell.tsx)` or new admin settings page under Settings
- Auth context / API client: `[frontend/src/context/AuthContext.tsx](frontend/src/context/AuthContext.tsx)` and `[frontend/src/services/api.ts](frontend/src/services/api.ts)` as needed
- Backend flag storage + migration: new model/migration (e.g., `[backend/models/app_settings.py](backend/models/app_settings.py)` and Alembic)
- Backend API endpoints: `[backend/api/routes/admin.py](backend/api/routes/admin.py)` or new route file
- Backend access control: `[backend/api/dependencies.py](backend/api/dependencies.py)` + route guards where needed
- Remove legacy pages/routes/tests (candidates below).

## Legacy pages cleanup (based on current routes)

- Remove unused routes in `[frontend/src/App.tsx](frontend/src/App.tsx)` such as `stocks`, `options-portfolio`, `tax-lots`, `dividends`, `margin`, `analytics`, `notifications` if not in V1.
- Remove page components for those routes in `frontend/src/pages/*` and related tests.
- Remove related menu items from `[frontend/src/components/layout/DashboardLayout.tsx](frontend/src/components/layout/DashboardLayout.tsx)`.

## Menu structure changes

- Replace flat `navigationItems` with grouped sections:
  - Market: Market Dashboard (current `/`), Tracked (`/settings/market/coverage` or `/settings/market/tracked` if that’s the page you want surfaced).
  - Portfolio: Portfolio Dashboard (`/portfolio`), Workspace (`/workspace`), Categories (`/portfolio-categories`), Transactions (`/transactions`).
  - Strategy (WIP): Strategy Manager (`/strategies-manager`), Strategies (`/strategies`).
- Show Market only for non‑admins; show full menu for admins.

## Backend feature flag

- Add `AppSettings` table with `market_only_mode` boolean.
- Add admin endpoints:
  - GET `/admin/app-settings`
  - PATCH `/admin/app-settings` (admin only)
- Default: `market_only_mode=true` for prod; allow admin to toggle.
- Use the flag in backend dependencies to restrict non‑admin access to non‑Market routes.

## Frontend toggle

- Add an admin‑only toggle UI in Settings > Admin (or a new Admin Settings section) to flip `market_only_mode`.
- Persist to backend via the new admin endpoint.

## Route enforcement

- Add a client‑side guard in `[frontend/src/App.tsx](frontend/src/App.tsx)` to redirect non‑admins when `market_only_mode=true` and route is outside Market.
- Keep server‑side enforcement in backend dependencies for safety.

## Clean-up checklist

- Delete unused page components + tests.
- Remove unused routes and nav items.
- Ensure notifications page is removed from sidebar; keep settings notifications under Settings.

## Tests

- Update/add unit tests for the new app settings endpoint.
- Update any affected frontend tests for navigation/route availability.

## Open questions to resolve before implementation

- Confirm the exact URL you want for “Market Dashboard” and “Tracked” in the main menu (current tracked page is under Settings Market section).

