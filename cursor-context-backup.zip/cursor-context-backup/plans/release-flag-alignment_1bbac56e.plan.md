---
name: release-flag-alignment
overview: "Align backend/frontend gating to the release model: admins always see everything, non-admins get Market now, Portfolio/Strategy remain blocked by default until enabled."
todos:
  - id: unify-market-gating
    content: Refactor backend market visibility checks to follow release-flag policy for authenticated non-admin users.
    status: completed
  - id: define-policy-matrix
    content: Define and codify a single access policy matrix (role x section) used by backend/frontend and tests.
    status: completed
  - id: centralize-gating-helper
    content: Introduce one backend helper for release-gating decisions so route guards do not duplicate branching logic.
    status: completed
  - id: set-precedence-rule
    content: Document and enforce precedence that DB-backed app settings drive rollout behavior over env toggles.
    status: completed
  - id: preserve-nonmarket-guards
    content: Keep Portfolio/Strategy API guards as feature-gated (not admin-only) and confirm router wiring.
    status: completed
  - id: update-config-surface
    content: Reduce env-flag ambiguity by removing/deprecating market visibility env branching in API metadata/guards.
    status: completed
  - id: expand-tests
    content: Add/adjust backend and frontend tests for admin full access + non-admin market-only default behavior.
    status: completed
  - id: verify-end-to-end
    content: Run targeted suites and role-based smoke validation before finalizing.
    status: completed
isProject: false
---

# Release Flag Alignment Plan

## Goal

Implement a single, predictable release policy:

- Admin: full access to all sections.
- Non-admin: Market section available now (authenticated users).
- Non-admin Portfolio/Strategy: blocked by default until flags are enabled.

## Current Gap

The backend market guard still depends on `MARKET_DATA_SECTION_PUBLIC` in [backend/config.py](/Users/sankalpsharma/development/axiomfolio/backend/config.py) and [backend/api/dependencies.py](/Users/sankalpsharma/development/axiomfolio/backend/api/dependencies.py), which can conflict with app-level release flags.

## Access Policy Matrix (Source of Truth)

- Admin + Market: allow
- Admin + Portfolio: allow
- Admin + Strategy: allow
- Non-admin + Market: allow (authenticated)
- Non-admin + Portfolio: allow only when `market_only_mode=false` and `portfolio_enabled=true`
- Non-admin + Strategy: allow only when `market_only_mode=false` and `strategy_enabled=true`

## Implementation Steps

- Codify the matrix above in a centralized backend policy helper in [backend/api/dependencies.py](/Users/sankalpsharma/development/axiomfolio/backend/api/dependencies.py) (or adjacent policy module), then consume it from route guards:
  - Keep admin bypass.
  - For market data viewer, allow all authenticated users (as requested rollout state).
  - Keep non-market guard for Portfolio/Strategy using existing section flags.
- Ensure no duplicated path-branch logic remains across multiple dependencies; route guards should call the same policy function.
- Keep Portfolio routes guarded with `require_non_market_access` in [backend/api/main.py](/Users/sankalpsharma/development/axiomfolio/backend/api/main.py) (not admin-only), because these are feature-gated user surfaces, not admin surfaces.
- Enforce an explicit precedence rule:
  - DB app settings are authoritative for section rollout.
  - Env toggles are fallback/bootstrap only (or removed from runtime gating).
  - Reflect this in [backend/config.py](/Users/sankalpsharma/development/axiomfolio/backend/config.py) and [backend/api/routes/market_data.py](/Users/sankalpsharma/development/axiomfolio/backend/api/routes/market_data.py).
- Validate frontend gating remains consistent in [frontend/src/components/auth/RequireNonMarketAccess.tsx](/Users/sankalpsharma/development/axiomfolio/frontend/src/components/auth/RequireNonMarketAccess.tsx) and nav visibility in [frontend/src/components/layout/DashboardLayout.tsx](/Users/sankalpsharma/development/axiomfolio/frontend/src/components/layout/DashboardLayout.tsx).
- Update/add tests:
  - Backend matrix tests (role x section) to ensure policy parity and prevent regressions.
  - Backend dependency tests for market access and non-market section blocking.
  - Existing app settings/market endpoint tests to assert non-admin market access and default portfolio/strategy lock.

## Verification

- Backend: run targeted auth/release tests and market endpoint tests.
- Frontend: run route/nav tests to verify Market visible and Portfolio/Strategy hidden for non-admin defaults.
- Manual smoke check with admin vs non-admin accounts in local dev.

