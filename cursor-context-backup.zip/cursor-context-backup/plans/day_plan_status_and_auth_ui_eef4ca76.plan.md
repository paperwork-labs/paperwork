---
name: "Day Plan: Status and Auth UI"
overview: Full persona self-review of project state, followed by executing Task 2.2 (Frontend Auth + Protected Routes) as the main engineering work. Doc updates as identified.
todos:
  - id: free-file-analysis
    content: Add IRS Free File program competitive analysis to PRD.md and pricing page
    status: completed
  - id: cleanup
    content: Drop stale git stash, verify main is clean
    status: completed
  - id: auth-store
    content: Create Zustand auth store + React Query hooks for auth API
    status: completed
  - id: auth-pages
    content: Build register and login pages with Zod validation
    status: completed
  - id: middleware
    content: Add Next.js middleware for protected routes (/file/*, /dashboard/*)
    status: completed
  - id: session-timeout
    content: Implement 30-min inactivity detection with 'Still there?' modal
    status: completed
  - id: test-e2e
    content: Test full auth flow end-to-end (register -> login -> protected route -> logout)
    status: completed
  - id: pr-merge
    content: Create PR, request Copilot review, address feedback, merge
    status: completed
isProject: false
---

# Day Plan: Self-Review + Task 2.2 Frontend Auth

## Where We Stand (All-Persona Review)

### Engineering

- **52 tests pass.** Backend auth system merged (PR #9). Architecture docs, clean Docker names, Copilot review workflow -- all on main.
- **Next task**: 2.2 Frontend Auth (login/register pages, Zustand auth store, protected routes, session timeout). Backend endpoints are ready and waiting.
- `ARCHITECTURE.md` current. `engineering.mdc` current.
- Stale stash on `feat/1.1-camera-image-quality` -- should be dropped (Sprint 2 is complete and merged).

### UX/UI

- No auth UI exists. `web/src/app/auth/` is missing entirely. The demo flow and landing page work.
- Task 2.2 spec calls for: centered card on gradient bg, register (full name, email, password, confirm), login, session timeout modal.
- Mobile-first, dark theme, shadcn Form component with Zod validation.

### Growth

- Content foundation done (3 SEO guides, pricing page, sitemap, JSON-LD, pixels).
- Social not posting yet. Postiz is live but accounts not connected. No content published.

### Social Media

- Postiz + n8n running on Hetzner. MCP connected. 6 workflows wired.
- Gap: zero posts published. Accounts not connected in Postiz UI (human action).

### Legal

- Privacy policy and ToS live at `/privacy` and `/terms`.
- EFIN not applied (B.1, human action -- longest lead item at 45 days).

### CFO

- Burn: **$12.49/mo** (Render $7 + Hetzner $5.49). Neon/Upstash/Vercel all free tier.
- Tool Registry in `cfo.mdc`. `PITCH_PACKAGE.md` costs current.

### QA

- 52 tests. No formal security scan run yet (n8n QA workflow ready when needed).
- Will be triggered once Sprint 3 code ships.

### Tax Domain / CPA

- `tax-data/2025.json` exists with bracket data from Rev. Proc. 2024-40 + P.L. 119-21.
- Tax calculator not built yet (Task 2.4). CPA persona not yet needed.

### Strategy

- Decision log current through D31. Sprint 0 human actions pending.
- Key blocker: EFIN application (B.1) is the longest lead item and hasn't been started.

### Partnerships

- Playbook ([PARTNERSHIPS.md](docs/PARTNERSHIPS.md)) and persona ready. Notion Pipeline database set up.
- No outreach started yet. Waiting on product maturity for affiliate applications (B.8).

### Brand

- Logo assets pending. Favicon SVG in use. `brand.mdc` documents the generation plan.

### Workflows (n8n)

- 6 workflows imported and wired. Not yet triggered in production.
- Ready for: Social Content Generator, Growth Content Writer, Weekly Strategy Check-in, QA Scan, Partnership Drafter, CPA Review.

## Doc Updates Needed

1. **IRS Free File competitive gap** -- Our `PRD.md` Section 2.2 competitive table does NOT analyze the IRS Free File program (8 trusted partners). This is a real competitive landscape element that we should position against explicitly. FileFree wins on: no income limits, no eligibility maze, free state filing, modern mobile UX, AI-powered OCR, year-round value. The program's ~3% participation rate proves its UX fails. Add analysis to `PRD.md` and update the `/pricing` comparison table.
2. **Drop stale git stash** -- `stash@{0}` is WIP from `feat/1.1-camera-image-quality` which is already merged. Safe to drop.
3. **TASKS.md** -- add D32 entry to KNOWLEDGE.md when Task 2.2 ships (auth architecture decisions).
4. **Design system page** -- `web/src/app/design/page.tsx` is dev-only (returns 404 in production). Currently shows base shadcn components. Custom components from Task 2.6 (SSNInput, CurrencyDisplay, SecureBadge, etc.) should be added here when built.

## Carried Forward from Previous Audit

Cross-referenced with the [comprehensive status audit](comprehensive_status_and_next_steps_a3b55fab). Most items are now resolved. Three remain:

1. **Sentry DSN (Task 0.5 partial)** -- `@sentry/nextjs` is wired, error boundaries exist, PII scrubbing configured, but `NEXT_PUBLIC_SENTRY_DSN=` is empty in `web/.env.production`. Human action: create Sentry project, grab DSN, set in `.env.production` + Vercel env vars.
2. **Sprint 0 human blockers (CRITICAL)** -- These are the longest-lead items and none have started:
  - **B.1 EFIN Application** -- 45-day IRS processing. Every day of delay pushes MeF transmitter timeline. This is the single most time-sensitive action in the entire project.
  - **B.2 LLC/bank** -- Required before EFIN, partner agreements, and revenue collection.
  - **B.5/B.9 Column Tax** -- Needed for interim e-file (October 2026). Book demo call.
3. **OG image + Apple touch icon** -- `layout.tsx` has openGraph metadata but no actual image file (brand assets were deleted in D29). Blocked until logo/wordmark is generated (Ideogram v3 or Figma). Once available, add to `web/public/` and reference in layout.

## Task 2.2 -- Frontend Auth + Protected Routes

This is the main engineering work. The backend auth API is done; now build the UI.

### What to build

**Auth pages** ([TASKS.md lines 599-620](docs/TASKS.md)):

- `web/src/app/auth/layout.tsx` -- centered card on gradient background
- `web/src/app/auth/register/page.tsx` -- Full Name, Email, Password, Confirm Password, Zod validation
- `web/src/app/auth/login/page.tsx` -- Email, Password
- Shared: password strength indicator, error handling via sonner toasts

**State management**:

- Zustand store (`web/src/stores/auth-store.ts`) -- user, isAuthenticated, login/logout actions
- React Query mutations wrapping `POST /auth/register`, `POST /auth/login`, `POST /auth/logout`, `GET /auth/me`
- CSRF token stored in Zustand, sent as `X-CSRF-Token` header on state-changing requests

**Protected routes**:

- Next.js middleware (`web/src/middleware.ts`) -- protect `/file/`* and `/dashboard/`*, redirect to `/auth/login`
- Session validation via `GET /auth/me` on app load

**Session timeout**:

- 30-min inactivity detection -> "Still there?" modal with extend/logout options

### Key files to leverage

- Backend endpoints: `api/app/routers/auth.py` (register, login, logout, me, delete)
- API client: `web/src/lib/api.ts` (axios instance with withCredentials)
- Existing shadcn components: Form, Input, Button, Card, Dialog
- Zod validation: match backend password rules (8+ chars, uppercase, number)

