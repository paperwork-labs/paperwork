---
name: Dashboard Admin Fixes v2
overview: "Single-PR delivery: fix missing fundamentals, resolve red health dimensions (monotonicity + audit), surface schedules, refactor runbook, redesign MarketDashboard -- with acceptance criteria, tests, verification checklist, observability, and docs updates."
todos:
  - id: fill-fundamentals
    content: Add POST /market-data/admin/fundamentals/fill-missing endpoint + 'Fill Missing Fundamentals' button in AdminOperatorActions Maintenance section
    status: completed
  - id: repair-stage-button
    content: Add 'Repair Stage History' button wired to existing POST /market-data/admin/stage/repair in AdminOperatorActions Maintenance section
    status: completed
  - id: fix-monotonicity
    content: Fix monotonicity checker in stage_quality_summary to track as_of_date and skip weekend/holiday gaps
    status: completed
  - id: fix-audit-cron
    content: Add Render cron job for audit_market_data_quality in render.yaml (02:45 UTC daily)
    status: completed
  - id: fix-schedules
    content: Modify GET /admin/schedules to always include static beat_schedule defs with source labels, even when ENABLE_CELERY_BEAT=false
    status: completed
  - id: refactor-runbook
    content: "Refactor AdminRunbook: steps array, contextualSteps for stage_quality, inline metric values, updated content for all 4 entries"
    status: completed
  - id: dashboard-backend
    content: Enhance sector_etf_table with 5D/20D/RS fields; add entering_stage_3 and entering_stage_4 lists
    status: completed
  - id: dashboard-frontend
    content: Redesign MarketDashboard with Market Pulse hero, Sector Rotation heatmap, Trading Setups cards, Stage Transitions, improved matrices
    status: completed
  - id: tests
    content: Add backend tests (monotonicity, endpoints, schedules, dashboard service) + frontend tests (buttons, runbook contextual rendering)
    status: completed
  - id: docs-update
    content: Update docs/MARKET_DATA.md operator runbook section with new buttons, schedule ownership, and incident flows
    status: completed
isProject: false
---

# Dashboard Redesign and Admin Fixes (v2)

Single PR. All issues ship together with tests, verification checklist, and docs.

---

## Issue 1: Missing Name/Sector/Industry for 28 Symbols

**Root Cause**: 28/581 tracked symbols have NULL `name`, `sector`, `industry` in `market_snapshot` -- FMP rate-limited during the initial `recompute_indicators_universe` run.

**Changes**:

- [backend/api/routes/market_data.py](backend/api/routes/market_data.py): Add `POST /market-data/admin/fundamentals/fill-missing` calling `_enqueue_task(fill_missing_snapshot_fundamentals)`
- [frontend/src/components/admin/AdminOperatorActions.tsx](frontend/src/components/admin/AdminOperatorActions.tsx): Add "Fill Missing Fundamentals" button in Maintenance section + `taskEndpoints` entry `admin_fundamentals_fill_missing`
- Also add "Repair Stage History" button wired to existing `POST /market-data/admin/stage/repair` (line 1127 of market_data.py) + `taskEndpoints` entry `admin_stage_repair`

**Acceptance criteria**: After running "Fill Missing Fundamentals" in prod, `SELECT COUNT(*) FROM market_snapshot WHERE analysis_type='technical_snapshot' AND name IS NOT NULL` reaches 581 (or near -- 1-2 delisted symbols acceptable).

**Failure/rollback**: If FMP rate-limits again, the task logs `updated/skipped/errors` counters (already in the task). Admin can re-run; the task is idempotent. No destructive changes to roll back.

**Observability**: The existing `fill_missing_snapshot_fundamentals` task already writes `updated`, `skipped`, `errors` counters to `JobRun`. No additional instrumentation needed.

---

## Issue 2: Stage Quality and Audit Red

### Stage Quality (42 false-positive monotonicity issues)

**Root Cause**: The monotonicity loop in `stage_quality_summary()` ([market_data_service.py](backend/services/market/market_data_service.py) lines 2217-2236) discards the date with `for _, stage_label, current_days in series` and expects exact `+1` between every consecutive row. `market_snapshot_history` only contains trading-day rows, so Friday-to-Monday naturally gaps.

**Fix**: Change the loop to `for dt, stage_label, current_days in series` and track `prev_dt`. Only flag a monotonicity violation when `(dt - prev_dt).days == 1` (true consecutive calendar day) but the counter doesn't match. When gap > 1 day (weekend/holiday):

- Same stage: accept `cur_days > prev_days` without requiring exact `+1`
- New stage: accept `cur_days >= 1`

**Acceptance criteria**: Monotonicity issues drop from 42 to 0. Verified via `stage_quality_summary()` or the SQL:

```sql
-- After fix: should return 0
SELECT COUNT(*) FROM (
  SELECT symbol, as_of_date, stage_label, current_stage_days,
    LAG(as_of_date) OVER (PARTITION BY symbol ORDER BY as_of_date) as prev_date,
    LAG(stage_label) OVER (PARTITION BY symbol ORDER BY as_of_date) as prev_stage,
    LAG(current_stage_days) OVER (PARTITION BY symbol ORDER BY as_of_date) as prev_days
  FROM market_snapshot_history
  WHERE analysis_type = 'technical_snapshot'
    AND as_of_date >= (NOW() - INTERVAL '120 days')
    AND stage_label NOT IN ('UNKNOWN', '') AND stage_label IS NOT NULL
    AND current_stage_days IS NOT NULL AND current_stage_days >= 1
) sub
WHERE prev_stage IS NOT NULL AND prev_days IS NOT NULL
  AND (as_of_date - prev_date) = 1
  AND ((stage_label = prev_stage AND current_stage_days != prev_days + 1)
    OR (stage_label != prev_stage AND current_stage_days != 1));
```

### Audit (no audit data in Redis)

**Root Cause**: `audit_market_data_quality` is only in Celery Beat static schedule (02:45 UTC) but `ENABLE_CELERY_BEAT=false` in prod. No Render Cron Job exists for it.

**Fix**: Add to [render.yaml](render.yaml):

```yaml
- type: cron_job
  name: admin_market_data_audit
  runtime: docker
  plan: starter
  schedule: "45 2 * * *"
  dockerfilePath: ./Dockerfile.backend
  dockerCommand: python -m backend.scripts.run_task backend.tasks.market_data_tasks.audit_market_data_quality
```

**Acceptance criteria**: After deploy, the Redis key `market_audit:last` is populated after the next 02:45 UTC run, and the audit dimension turns green (daily fill >= 95%, snapshot fill >= 90%).

**Failure/rollback**: If the audit cron fails, it logs to `JobRun` and the audit dimension stays red with `error` instead of `no audit data in cache`. Non-destructive.

---

## Runbook Refactor ([AdminRunbook.tsx](frontend/src/components/admin/AdminRunbook.tsx))

### Structural changes

1. Change `RunbookEntry.fix` from `string` to `steps: string[]`. Render as numbered list.
2. Add `contextualSteps?: (dim: Record<string, unknown>) => string[]` for `stage_quality` to return only relevant steps based on which sub-check is failing.
3. Surface actual metric values inline below steps (e.g., `Unknown rate: 0.17% (ok) | Monotonicity: 42 (FAILING)`).

### Per-entry content

- `**coverage**`: Reformat existing text as 4 numbered steps (no content change needed).
- `**stage_quality**`: Context-aware: high unknowns -> "Recompute Indicators"; monotonicity > 0 -> "Repair Stage History"; missing fundamentals -> "Fill Missing Fundamentals"; always -> "If daily bars missing, backfill first".
- `**jobs**`: Reformat as 3 numbered steps (no content change).
- `**audit**`: Add step 1 for "no audit data in cache" scenario directing user to check schedules or trigger manually. Keep existing steps for low fill percentages.

**Acceptance criteria**: When `stage_quality` is red due to monotonicity only, the runbook shows "Repair Stage History" (not "Recompute Indicators"). When audit is red with no data, it shows the missing-data guidance.

**Failure/rollback**: If `contextualSteps` throws, fall back to the static `steps` array. Always render `steps` as baseline.

---

## Issue 3: Schedules Page Empty

**Root Cause**: `ENABLE_CELERY_BEAT=false` in prod -> `beat_schedule = {}`. RedBeat also off. Actual crons run via Render Cron Jobs.

**Schedule source-of-truth**:

- **Production**: Render Cron Jobs are canonical. Defined in `render.yaml`.
- **Local/dev**: Celery Beat static schedule (`celery_app.py`) or RedBeat are canonical.

**Fix**: Modify `GET /admin/schedules` in [admin_scheduler.py](backend/api/routes/admin_scheduler.py) to always include the static `ACCOUNT_BEAT_SCHEDULE` and `MARKET_DATA_BEAT_SCHEDULE` definitions from `celery_app.py` (lines 50-85), regardless of `ENABLE_CELERY_BEAT`. Add `source` field: `"redbeat"`, `"static"`, or `"infra"` so the UI can label the origin. Show `mode` badge as `"Static"` or `"Infra (Render)"` when Celery Beat is off.

**Observability**: Log the schedule source mode at startup: `logger.info("Schedule source mode: %s", mode)`.

**Acceptance criteria**: Schedules page shows 5+ entries in prod with correct cron expressions and "Static" or "Infra" badges. CRUD operations are disabled when source is static/infra (read-only display).

---

## Issue 4: MarketDashboard Redesign

### Backend ([market_dashboard_service.py](backend/services/market/market_dashboard_service.py))

1. **Enhance `sector_etf_table**`: Add `perf_5d`, `perf_20d`, `rs_mansfield_pct`, `atrx_sma_50` per ETF (data already in `_SummaryRow`)
2. **Add stage transition lists**: `entering_stage_3` and `entering_stage_4` alongside existing `entering_stage_2a`
3. **Breadth metrics**: Already computed (`above_sma50_count`, `above_sma200_count`, `up_1d_count`, `down_1d_count`) -- just ensure frontend consumes them

### Frontend ([MarketDashboard.tsx](frontend/src/pages/MarketDashboard.tsx))

```mermaid
flowchart TB
  subgraph hero [Market Pulse]
    breadth["% above 50DMA / 200DMA gauges"]
    advDec["Advance/Decline ratio"]
    stageBar["Stage distribution stacked bar"]
  end
  subgraph rotation [Sector Rotation]
    sectorETF["ETF table: 1D, 5D, 20D, Stage, RS, Days"]
    sectorMom["Sector momentum by GICS sector"]
  end
  subgraph setups [Trading Setups]
    cards["Breakout | Pullback | RS Leaders | Momentum"]
  end
  subgraph transitions [Stage Transitions]
    bullish["Entering 2A"]
    bearish["Entering 3/4"]
  end
  subgraph matrices [Ranked Metrics]
    topBottom["Top/Bottom 10 with stage badges"]
  end
  subgraph proximity [Entry/Exit Proximity]
    entryExit["Existing tables, moved lower"]
  end
  hero --> rotation --> setups --> transitions --> matrices --> proximity
```



### Data currently returned by backend but not displayed


| Data                                              | Displayed?    |
| ------------------------------------------------- | ------------- |
| `regime.stage_counts_normalized`                  | Yes (badges)  |
| `entry_proximity_top` / `exit_proximity_top`      | Yes           |
| `sector_etf_table`                                | Yes (1D only) |
| `entering_stage_2a`                               | Yes           |
| `top10_matrix` / `bottom10_matrix`                | Yes           |
| `leaders` (momentum scored)                       | **No**        |
| `setups.breakout_candidates`                      | **No**        |
| `setups.pullback_candidates`                      | **No**        |
| `setups.rs_leaders`                               | **No**        |
| `sector_momentum` (avg 20D, RS by sector)         | **No**        |
| `action_queue` (notable movers)                   | **No**        |
| `regime.above_sma50_count` / `above_sma200_count` | **No**        |
| `regime.up_1d_count` / `down_1d_count`            | **No**        |
| `coverage`                                        | **No**        |


### Section-by-section frontend specs

**Section 1 -- Market Pulse (hero)**

- Compact card row: % above 50DMA, % above 200DMA, advance/decline ratio, total tracked count
- Stage distribution as a colored horizontal stacked bar (1, 2A, 2B, 2C, 3, 4) with counts and percentages
- Color-coded regime indicator (bullish when >60% above 50DMA, bearish when <40%)

**Section 2 -- Sector Rotation (money flow)**

- Expanded sector ETF table: Sector, Stage, Days, 1D%, 5D%, 20D%, RS (7 columns)
- Heat-map style cell coloring (green for positive, red for negative, intensity by magnitude)
- Sorted by 20D momentum by default, with column sorting
- Sector momentum summary from `sector_momentum` data (stocks aggregated by GICS sector)

**Section 3 -- Trading Setups**

- Four-card horizontal layout: Breakout Candidates, Pullback Buys, RS Leaders, Momentum Leaders
- Each card shows top 5-8 symbols with: symbol, stage, perf_1d, perf_20d, RS Mansfield
- Momentum Leaders card showing top 12 by composite momentum score

**Section 4 -- Stage Transitions**

- Two-column layout: "Entering Stage 2A" (bullish) and "Entering Stage 3/4" (warnings)
- Each shows symbol, previous stage, days in new stage

**Section 5 -- Ranked Metrics Matrix**

- Keep existing Top/Bottom 10 matrices
- Add stage badge next to each symbol for context

**Section 6 -- Entry/Exit Proximity** (moved lower since it requires manual price setting)

- Keep existing but show empty-state more gracefully

**Acceptance criteria**: All backend fields from `build_dashboard()` response that are currently returned but not displayed are now rendered in the UI. Sector ETF table shows 7 columns. All 6 sections render with live data.

---

## Tests

### Backend tests

- **Monotonicity fix**: Test `stage_quality_summary()` with a series containing Friday-Monday gaps -- assert 0 monotonicity issues. Test with actual consecutive-day violations -- assert they are still caught.
- **Fundamentals endpoint**: Test `POST /market-data/admin/fundamentals/fill-missing` returns 202 and enqueues the task.
- **Stage repair endpoint**: Test `POST /market-data/admin/stage/repair` is accessible to admin users and calls `repair_stage_history_window`.
- **Schedules endpoint**: Test `GET /admin/schedules` returns non-empty list when `ENABLE_CELERY_BEAT=false` and static schedules are defined.
- **Dashboard service**: Test enhanced `sector_etf_table` includes `perf_5d`, `perf_20d`, `rs_mansfield_pct`. Test `entering_stage_3` and `entering_stage_4` lists are populated.

### Frontend tests

- **AdminOperatorActions**: Verify "Fill Missing Fundamentals" and "Repair Stage History" buttons render in Maintenance section.
- **AdminRunbook**: Test contextual rendering -- mock health with `monotonicity_issues: 5, unknown_rate: 0.01, invalid_count: 0` and assert "Repair Stage History" step appears but "Recompute Indicators" does not.

---

## Verification Checklist (post-deploy)

### SQL checks (run against prod Postgres)

```sql
-- 1. Fundamentals completeness (target: ~581)
SELECT COUNT(*) as total, COUNT(name) as has_name, COUNT(sector) as has_sector
FROM market_snapshot WHERE analysis_type='technical_snapshot';

-- 2. Monotonicity issues (target: 0)
-- (use the SQL from the monotonicity acceptance criteria above)

-- 3. Stage quality summary
SELECT stage_label, COUNT(*) as cnt, ROUND(AVG(current_stage_days)::numeric,0) as avg_days
FROM market_snapshot WHERE analysis_type='technical_snapshot'
GROUP BY stage_label ORDER BY cnt DESC;

-- 4. UNKNOWN count (target: <=1)
SELECT COUNT(*) FROM market_snapshot
WHERE analysis_type='technical_snapshot' AND (stage_label='UNKNOWN' OR stage_label IS NULL);
```

### UI checks

- Admin Dashboard: all 4 health dimensions green (or yellow at worst)
- Runbook: expand runbook -- shows "All systems healthy" or context-specific steps
- Schedules page: shows 5+ schedule entries with badges
- Market Dashboard: all 6 sections render with data; sector ETF table has 7 columns
- "Fill Missing Fundamentals" and "Repair Stage History" buttons visible under Show Advanced > Maintenance

---

## Docs Update ([docs/MARKET_DATA.md](docs/MARKET_DATA.md))

Add to the "Operator Runbook" section (line 209+):

- **Fill Missing Fundamentals**: When symbols show missing name/sector/industry, click "Fill Missing Fundamentals" under Show Advanced > Maintenance. Safe to re-run; idempotent. Logs updated/skipped/errors to Admin > Jobs.
- **Repair Stage History**: When monotonicity violations appear in stage quality, click "Repair Stage History" under Show Advanced > Maintenance. Recomputes `current_stage_days`, `previous_stage_label`, `previous_stage_days` for the last 120 days of history.
- **Schedule visibility**: Production schedules are managed by Render Cron Jobs (canonical). The Schedules page shows these as read-only "Infra" entries. In local dev, Celery Beat / RedBeat schedules are canonical and fully editable.

