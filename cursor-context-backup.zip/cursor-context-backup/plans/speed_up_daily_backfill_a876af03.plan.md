---
name: Speed up daily backfill
overview: Make daily backfills for ~500 tracked symbols run much faster in paid mode by adding controlled concurrency (not a 20-symbol cap), while remaining safe via automatic backoff/retry on 429/5xx. Keep it click-driven from the existing Admin Dashboard buttons.
todos:
  - id: provider-retry
    content: Add async-safe FMP fetch wrapper with backoff/retry in MarketDataService (429/5xx handling, asyncio.to_thread).
    status: completed
  - id: concurrent-daily-backfill
    content: Refactor backfill_last_200_bars/backfill_symbols to fetch concurrently and persist safely; add paid/free concurrency settings.
    status: completed
  - id: paid-batch-default
    content: Make /backfill/index-universe default batch_size policy-aware (paid=100, free=20) with sane upper bound.
    status: completed
  - id: tests-backfill-speed
    content: Add backend tests for retry/backoff + concurrency counters; ensure suite passes.
    status: completed
---

# Speed up daily backfill (paid mode, last-year, ~500 symbols)

## What’s slow today

- `backfill_last_200_bars` processes symbols **sequentially** (one-by-one), so ~500 symbols is inherently slow.
- The “20 at a time” you noticed is **only** the default `batch_size` for `/backfill/index-universe`; it is not capping tracked backfill.

## Goal

- Keep your operator UX the same (“Restore Daily Coverage (Tracked)” and “Backfill Last-200 (Tracked)” buttons), but make the underlying **daily** backfill use **high-throughput concurrency** in paid mode, with **backoff+retry** when FMP returns 429/5xx.

## Approach

### 1) Add a concurrency + retry layer for provider fetches

- Update [`backend/services/market/market_data_service.py`](backend/services/market/market_data_service.py)
- Introduce an internal async helper that runs FMP calls in `asyncio.to_thread(...)` (since `fmpsdk` is blocking), so we can run many symbol fetches concurrently without blocking the event loop.
- Add retry/backoff logic for transient failures:
    - Detect 429 and 5xx where possible
    - Exponential backoff with jitter, bounded (e.g. max 60s), then continue

### 2) Make tracked daily backfill concurrent (main win)

- Update [`backend/tasks/market_data_tasks.py`](backend/tasks/market_data_tasks.py)
- Refactor `backfill_last_200_bars` and `backfill_symbols` to fetch bars for many symbols concurrently.
- Keep DB writes safe:
    - Fetch concurrently (network-bound)
    - Persist in DB in a controlled way (either sequential writes, or per-symbol short-lived sessions) to avoid SQLAlchemy session/thread safety issues.
- Add settings-based concurrency default when `MARKET_PROVIDER_POLICY=paid`:
    - `MARKET_BACKFILL_CONCURRENCY_PAID` (default e.g. 25)
    - `MARKET_BACKFILL_CONCURRENCY_FREE` (default e.g. 5)

### 3) Remove the misleading “20 default” for paid index bootstrap

- Update [`backend/api/routes/market_data.py`](backend/api/routes/market_data.py)
- Change `/backfill/index-universe` default `batch_size` to be policy-aware:
    - paid default: 100
    - free default: 20
- Keep bounds (e.g. `ge=5, le=500`) so you can still override.

### 4) Keep it click-driven

- No new UI required.
- When you click **Restore Daily Coverage (Tracked)** it uses `backfill_last_200_bars` → now fast.
- When you click **Backfill Indices (Daily)** (advanced) it uses a higher paid-mode batch size by default.

### 5) Tests

- Add backend unit tests around:
- retry/backoff behavior (simulate 429/5xx)
- concurrency code path returning expected counters
- Ensure existing coverage/job behavior remains intact.

## Rollout / How you’ll use it

- For “I haven’t looked in days” (daily only): **Restore Daily Coverage (Tracked)**.