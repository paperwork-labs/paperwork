---
name: Wire Neon + Vercel Fix
overview: Wire the Neon DATABASE_URL to the live Render service via MCP, fix Vercel deployment by installing frontend dependencies, and complete infrastructure setup.
todos:
  - id: wire-neon
    content: Set DATABASE_URL on Render via MCP using Neon connection string
    status: completed
  - id: fix-vercel
    content: Check web/package.json and fix Vercel deployment configuration
    status: completed
  - id: status-check
    content: "Verify all 3 services healthy: Render API, Neon DB connected, Vercel frontend"
    status: completed
isProject: false
---

# Wire Neon to Render + Fix Vercel

## Current State

- Render API: **LIVE** at `https://filefree-api.onrender.com/health`
- Neon DB: **CREATED** (`filefree`, Postgres 17, US East 1, pooler enabled)
- Hetzner: **RUNNING** at `204.168.147.100`
- PR #3: **MERGED** to `main`
- Vercel: **DEPLOYING** (likely failing -- `web/package.json` has no dependencies installed and may need `next` properly configured)

---

## Step 1: Wire Neon DATABASE_URL to Render via MCP

Use `update_environment_variables` on service `srv-d6ni2khaae7s73b098pg` to set:

```
DATABASE_URL=postgresql+asyncpg://neondb_owner:<password>@ep-holy-dawn-adctn3l3-pooler.c-2.us-east-1.aws.neon.tech/neondb?sslmode=require
```

Note: Converting `postgresql://` to `postgresql+asyncpg://` to match the SQLAlchemy async convention used in [infra/env.dev.example](infra/env.dev.example). Dropping `channel_binding=require` as asyncpg handles this via SSL.

## Step 2: Fix Vercel Frontend Deployment

The `web/` directory has a [web/package.json](web/package.json) but likely needs:

1. Verify `next`, `react`, `react-dom` are listed as dependencies
2. The Vercel project must have **Root Directory** set to `web`
3. If Vercel shows "Other" as Application Preset, it needs to be changed to **Next.js** (this auto-detects when root dir is set to `web` which contains `next.config.mjs`)

Check the current `web/package.json` to see if deps are properly defined and if a `package-lock.json` or install step is needed.

## Step 3: Mark neon-setup TODO as Complete

Update the todo list to reflect completion of all infrastructure wiring.

## IMPORTANT: Security Note

The Neon connection string contains credentials. After setting it on Render via MCP, the password should be rotated in Neon if it was exposed in any logs. The Render MCP sets env vars securely (not visible in build logs).