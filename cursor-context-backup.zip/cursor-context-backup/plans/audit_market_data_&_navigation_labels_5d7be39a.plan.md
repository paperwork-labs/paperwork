---
name: Audit Market Data & Navigation Labels
overview: "Two-pass audit: verify jobs/coverage metrics accuracy and clean nav labels back to 'Coverage' and 'Tracked'."
todos:
  - id: audit-jobs-metrics
    content: Verify jobs API all=true totals and UI bindings
    status: in_progress
  - id: audit-coverage-metrics
    content: Verify coverage/tracked API data and UI mapping
    status: in_progress
  - id: rename-nav-coverage
    content: Rename nav labels to Coverage/Tracked and verify routes
    status: completed
---

# Audit Market Data Metrics & Nav Labels

## Scope (two passes)

- Pass 1 (metrics): Verify jobs and coverage/tracked data correctness. Check totals (all vs page), success/fail counts, coverage percentages, and tracked counts using API and UI wiring.
- Pass 2 (UX): Rename Market Coverage/Market Tracked labels back to Coverage/Tracked across menus/routes; keep logic intact.

## Steps

1) Jobs data accuracy

- Hit `/api/v1/market-data/admin/jobs?all=true` and ensure backend returns full job count and correct totals. Check UI bindings in `frontend/src/pages/AdminJobs.tsx` (Total Runs/Successful/Failed, range text) use API total, not page length.
- Adjust any remaining pagination/summary logic to reflect full counts.

2) Coverage/tracked data accuracy

- Call `/api/v1/market-data/coverage` and ensure status, sampled %, stale counts, universe/tracked totals are consistent with DB/Redis. Cross-check frontend mapping (CoverageSummaryCard, hero/kpis) displays correct values.
- Verify tracked table fill: backend `_load_tracked_details` (price/snapshot fallback) and frontend rendering show complete rows.

3) Nav label cleanup

- Rename menu labels back to “Coverage” and “Tracked” (Settings shell, any admin/market nav links, routes if labeled). Ensure no regressions in routing.

4) Quick regression checks

- Lint changed files; spot-check key screens after label changes.