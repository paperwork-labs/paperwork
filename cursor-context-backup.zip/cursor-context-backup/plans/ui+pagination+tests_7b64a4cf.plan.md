---
name: UI+Pagination+Tests
overview: Fix shell layout (no horizontal scroll), implement server-paged AdminJobs with modern pagination, fix coverage KPI at backend source, add robust tests for both frontend and backend, and document Ladle + Chakra v3 architecture.
todos:
  - id: layout-shell
    content: Fix DashboardLayout + SettingsShell layout so collapsed sidebar never causes horizontal scroll; implement hybrid icon-rail/overlay behavior
    status: completed
  - id: adminjobs-pagination
    content: Implement server-paged AdminJobs with reusable Pagination component (page size dropdown + totals + ellipsis paging)
    status: completed
  - id: coverage-kpi-backend
    content: Fix backend coverage meta.kpis generation so stale_m5==0 becomes “All 5m covered”; remove frontend override to avoid band-aids
    status: completed
  - id: tests-frontend-pagination
    content: Add Vitest/RTL tests for Pagination component and AdminJobs paging+dialog behavior
    status: in_progress
    dependencies:
      - adminjobs-pagination
  - id: tests-backend-coverage-kpis
    content: Add pytest coverage test asserting meta.kpis help text matches stale_m5 (incl. 0 => All covered)
    status: pending
    dependencies:
      - coverage-kpi-backend
  - id: docs-ladle-chakra
    content: Write docs for Ladle usage and Chakra v3 system architecture; confirm .ladle provider matches app provider
    status: pending
---

# Fix Shell Layout + AdminJobs Pagination + Coverage KPIs (with robust tests)

## Goal

- **Layout**: no horizontal scroll/left drift when sidebar collapses; Settings pages have consistent background and responsive sizing.
- **Admin Jobs**: server-paged pagination with page-size dropdown (10/25/50/100), page controls, and totals.
- **Coverage KPIs**: fix the KPI text at the **backend source** (no client band-aids).
- **Docs**: how to run/view Ladle; explain Chakra v3 architecture and how we keep UI libs current.
- **Tests**: add robust, regression-proof tests for the new behavior.

## Workstream A — Layout cleanup (hybrid collapse)

- Update [`frontend/src/components/layout/DashboardLayout.tsx`](frontend/src/components/layout/DashboardLayout.tsx):
- Hybrid behavior: **icon-rail on desktop**, **overlay drawer on small screens**.
- Remove width/margin math that causes negative offsets.
- Enforce `minW={0}` on flex children and `overflowX="hidden"` where appropriate.
- Update [`frontend/src/pages/SettingsShell.tsx`](frontend/src/pages/SettingsShell.tsx):
- Ensure sidebar/content use responsive widths and `minW={0}`.
- Ensure the content panel uses consistent semantic tokens so there’s no “different color strip”.

## Workstream B — AdminJobs pagination (server-side)

- Add/restore a reusable pagination component:
- [`frontend/src/components/ui/Pagination.tsx`](frontend/src/components/ui/Pagination.tsx)
- Features: page size dropdown (10/25/50/100), numbered pages with ellipsis, prev/next, range label `1–25 of 4585`.
- Update [`frontend/src/pages/AdminJobs.tsx`](frontend/src/pages/AdminJobs.tsx):
- Use backend `GET /api/v1/market-data/admin/jobs?limit=&offset=`.
- Default page size 25.
- Keep row Details/Error Log dialog.

## Workstream C — Coverage KPI correctness (backend source of truth)

- Update [`backend/api/routes/market_data.py`](backend/api/routes/market_data.py):
- In `_kpi_cards()` (which populates `snapshot.meta.kpis`), fix the help string so:
    - `stale_m5 == 0` → **“All 5m covered”**
    - else → **“N missing 5m”**
- Remove the frontend override logic in [`frontend/src/utils/coverage.ts`](frontend/src/utils/coverage.ts) so we’re not masking backend bugs.

## Workstream D — Docs (Ladle + Chakra v3)

- Confirm [`frontend/.ladle/components.tsx`](frontend/.ladle/components.tsx) uses the v3 system provider stack (it should match the app provider).
- Add docs file [`docs/frontend-ui.md`](docs/frontend-ui.md) (or extend [`frontend/README.md`](frontend/README.md)):
- How to run Ladle locally + build it.
- Chakra v3 architecture used here: `system` tokens + semantic tokens + primitives.
- How we keep UI deps current (where versions live; how to update safely).

## Tests (robust)

### Frontend (Vitest + Testing Library)

- Add tests under `frontend/src/pages/__tests__/AdminJobs.test.tsx`:
- **Server paging**: correct `limit/offset` passed for page changes and page-size changes.
- **Totals/range label**: `Showing 1–25 of N` computed correctly.
- **Details dialog**: opens from row action; renders payload and error log.
- Add tests under `frontend/src/components/ui/__tests__/Pagination.test.tsx`:
- Page number rendering with ellipsis logic.
- Page size menu behavior.

### Backend (pytest)

- Add a backend test for coverage KPI help string:
- Validate `/api/v1/market-data/coverage` returns `meta.kpis` with the corrected help message when `stale_m5 == 0`.

## Commands (you approved running terminal commands)

- Use docker-first execution for Python/backend commands (e.g., `docker compose exec backend pytest`) [[memory:4046366]].
- Run frontend tests/build via repo tooling (inside container if configured, otherwise via existing dev container workflow).

## Success criteria

- No horizontal scrolling / negative offsets when sidebar toggles.
- Settings pages have consistent background and sizing.
- Admin Jobs shows proper paging + totals; defaults to 25 per page.
- Coverage KPI text correct from backend source.
- Tests pass and cover the new functionality.

## Implementation Todos

- `layout-shell`
- `adminjobs-pagination`
- `coverage-kpi-backend`