---
name: UI Shell + Pagination Fix
overview: Fix SettingsShell/DashboardLayout sizing so collapsed sidebar never causes horizontal scroll or background bleed, implement server-paged Admin Jobs with a modern pagination control + page size menu, and fix coverage KPI generation at the backend (no band-aids). Also document Chakra v3 architecture + Ladle usage and ensure Ladle provider uses the refreshed v3 system.
todos:
  - id: layout-shell
    content: Fix DashboardLayout + SettingsShell layout so collapsed sidebar never causes horizontal scroll; implement hybrid icon-rail/overlay behavior
    status: completed
  - id: adminjobs-pagination
    content: Implement server-paged AdminJobs with page-size dropdown and modern pagination component (reusable)
    status: completed
  - id: coverage-kpi-backend
    content: Fix backend coverage meta.kpis generation so stale_m5==0 becomes “All 5m covered”; remove frontend override to avoid band-aids
    status: completed
  - id: docs-ladle-chakra
    content: Add docs explaining Chakra v3 architecture and how to run/view Ladle; confirm Ladle provider uses v3 system/tokens
    status: completed
---

# Fix Shell Layout, AdminJobs Pagination, and Coverage KPIs

## Goals

- Eliminate **horizontal scroll / left-right drift** when sidebar collapses; make layout responsive across screen sizes.
- Fix Settings pages background/bleed so the right side doesn’t look like a different “layer”.
- Restore **modern pagination** on `AdminJobs` with server paging and page-size dropdown (10/25/50/100), using total count.
- Fix Coverage KPI correctness **at the backend source** (no client-only band-aids).
- Add docs: how to run/view Ladle, and explain Chakra v3 architecture used in this repo.

## Changes

### 1) Layout: prevent horizontal scroll and weird flow

- Update [`frontend/src/components/layout/DashboardLayout.tsx`](frontend/src/components/layout/DashboardLayout.tsx):
- Use **hybrid** behavior: icon-rail on desktop, overlay drawer on small screens.
- Ensure main content container uses `minW=0` + `overflowX="hidden"` and sidebar + content don’t exceed viewport.
- Replace any fixed margins that cause negative left offsets; use flex sizing instead.
- Ensure the root layout uses `w="100%"` and avoids `position: fixed` width math issues.
- Update [`frontend/src/pages/SettingsShell.tsx`](frontend/src/pages/SettingsShell.tsx):
- Ensure shell uses responsive `Flex` with `minW=0` and sidebar width constraints.
- Ensure content panel background matches global tokens (`bg.app`/`bg.card`) and no “different color strip” appears.

### 2) Admin Jobs: server-paged pagination + page-size dropdown

- Update [`frontend/src/pages/AdminJobs.tsx`](frontend/src/pages/AdminJobs.tsx):
- Use backend `GET /api/v1/market-data/admin/jobs?limit=&offset=`.
- Implement pagination UI inspired by the reference images:
    - Page size menu: 10/25/50/100
    - Prev/Next, numbered pages with ellipsis
    - Display range text: `1–25 of 4585`
- Keep Details/Error Log dialog behavior.
- If a reusable pagination component exists already, extract/restore it under [`frontend/src/components/ui/Pagination.tsx`](frontend/src/components/ui/Pagination.tsx) (or reuse an existing file), and use it in `AdminJobs`.

### 3) Coverage KPI: fix at backend source (no frontend override)

- Update backend coverage KPI generator in [`backend/api/routes/market_data.py`](backend/api/routes/market_data.py):
- In `_kpi_cards()` (used for `snapshot.meta.kpis`), change help text so:
    - `stale_m5 == 0` shows “All 5m covered”
    - else shows “N missing 5m”
- Ensure `meta.kpis` is always consistent with `status.stale_m5`.
- Then remove the frontend-only normalization for that KPI in [`frontend/src/utils/coverage.ts`](frontend/src/utils/coverage.ts) so we’re not masking backend issues.

### 4) Ladle + Chakra v3 docs + Ladle provider check

- Confirm [`frontend/.ladle/components.tsx`](frontend/.ladle/components.tsx) wraps stories with the same v3 provider stack as the app (already uses `ChakraProvider value={system}` + `ColorModeProvider`).
- Add docs:
- [`frontend/README.md`](frontend/README.md) or [`docs/frontend-ui.md`](docs/frontend-ui.md):
    - How to run Ladle locally
    - How to build it
    - Chakra v3 architecture overview (system tokens, semantic tokens, component primitives)
    - “latest UI libs” policy: how we keep dependencies current (and where versions live)

## Smoke checks

- Verify no horizontal scroll when toggling sidebar.
- Visit `/settings/*` pages: no background bleed.
- Visit `/settings/admin/jobs`: pagination works, counts match backend.
- Verify coverage page shows “All 5m covered” when missing count is 0.
- Verify Ladle runs and renders stories with v3 styling.

## Implementation Todos

- `layout-shell`: Fix DashboardLayout + SettingsShell sizing and hybrid sidebar behavior.
- `adminjobs-pagination`: Implement server-paged AdminJobs with reusable pagination component.