---
name: Full Project Audit
overview: "Comprehensive all-persona audit of FileFree: fix TASKS.md readability, update stale persona files, fix Postiz outage, clean up docs, and document current capabilities."
todos:
  - id: tasks-md-format
    content: "Overhaul TASKS.md: replace ~~strikethrough~~ with [x] checkboxes, add sprint progress tables, mark all completed items clearly"
    status: completed
  - id: delete-root-tasks
    content: Delete root TASKS.md (3-line redirect) — docs/TASKS.md is canonical
    status: completed
  - id: fix-personas
    content: "Fix 6 stale persona files: cfo.mdc ($32.50->$12.49), strategy.mdc (costs), .cursorrules (Tailwind v4, 12 personas, api/ path), ux.mdc (docs/ prefix), tax-domain.mdc (api/ prefix), engineering.mdc (Vercel Hobby)"
    status: completed
  - id: fix-postiz
    content: SSH to Hetzner, diagnose Postiz 502, restart container
    status: completed
  - id: update-knowledge
    content: Add D24-D27 to KNOWLEDGE.md (PostHog, legal pages, agent autonomy, TASKS v7)
    status: completed
  - id: docs-consistency
    content: Audit and fix PRD.md, PRODUCT_SPEC.md, STRATEGY_REPORT.md for stale costs/references
    status: completed
isProject: false
---

# FileFree Full Audit — All Personas

## Where We Stand (Scoreboard)


| Area                       | Status                          | Health   |
| -------------------------- | ------------------------------- | -------- |
| **filefree.tax** (landing) | Live, all sections rendering    | OK       |
| **api.filefree.tax**       | Healthy, DB connected           | OK       |
| **n8n.filefree.tax**       | Running, 6 workflows imported   | OK       |
| **social.filefree.tax**    | **DOWN** (HTTP 502 Bad Gateway) | BROKEN   |
| **Neon DB**                | Connected, auto-migrating       | OK       |
| **PostHog**                | Code integrated, key not set    | INACTIVE |
| **16 tests**               | All passing                     | OK       |
| **Legal pages**            | /privacy + /terms live          | OK       |
| **Monthly burn**           | $12.49/mo                       | OK       |


---

## Issue 1: TASKS.md Readability (your main pain point)

The `~~strikethrough~~` syntax renders on GitHub but **not** in most editors (including Cursor's markdown preview). This is why you can't tell what's done vs not done. Additionally, sub-tasks buried in paragraphs make scanning impossible.

**Fix:** Replace `~~strikethrough~~` with a checkbox format: `- [x] Done item` / `- [ ] Not done`. Add a status summary table at the top of each sprint section. This renders correctly everywhere.

**Root `TASKS.md`**: Currently a 3-line redirect to `docs/TASKS.md`. Safe to delete — it's noise. Every persona and `.cursorrules` already reference `docs/TASKS.md`.

---

## Issue 2: Stale Persona Files (6 files need updates)

The persona audit found concrete inconsistencies:

- **[cfo.mdc](/.cursor/rules/cfo.mdc)**: Says "Vercel Pro $20/mo" and "Total Fixed ~$32.50/mo". Reality: Vercel Hobby ($0), total $12.49/mo. Unit economics table is wrong.
- **[strategy.mdc](/.cursor/rules/strategy.mdc)**: Same cost error: "$32.50/mo". Should be $12.49/mo. "Landing page live" milestone should be marked done.
- **[.cursorrules](/.cursorrules)**: Says "Tailwind CSS 3.4+" but project uses Tailwind v4 (4.2.1). Says "10 personas" but there are 12 .mdc files. `tax-data/{year}.json` path should be `api/tax-data/{year}.json`.
- **[ux.mdc](/.cursor/rules/ux.mdc)**: References `PRODUCT_SPEC.md` without `docs/` prefix.
- **[tax-domain.mdc](/.cursor/rules/tax-domain.mdc)**: `tax-data/2025.json` should be `api/tax-data/2025.json`.
- **[engineering.mdc](/.cursor/rules/engineering.mdc)**: Says "Vercel Pro ($20/mo)" in infrastructure section. Should say "Vercel Hobby (free)".

---

## Issue 3: Postiz is DOWN (502)

`social.filefree.tax` returns HTTP 502 from Caddy. The Postiz container has likely crashed or OOMed on the Hetzner VPS. Needs SSH investigation and restart.

---

## Issue 4: KNOWLEDGE.md Missing Recent Decisions

These decisions from the last session are not recorded:

- D24: PostHog analytics with PII scrubbing (posthog-js, sanitize_properties)
- D25: Legal pages v1 live (/privacy, /terms) with Circular 230 compliance
- D26: n8n workflows wired to Notion/GitHub outputs (agent autonomy)
- D27: TASKS.md v7.0 restructured (Task 0.4 split, Task 0.5 + B.11 added)

---

## Issue 5: PostHog Not Active

Code is integrated with PII scrubbing, but `NEXT_PUBLIC_POSTHOG_KEY` is empty in `web/.env.production`. You need to:

1. Create a PostHog account at posthog.com (free tier: 1M events/mo)
2. Get the project API key
3. Set it in Vercel environment variables (not in `.env.production` — that file is committed)

---

## Agent Status (n8n)

Your 6 persona agents are imported and have output nodes wired:


| Agent                        | Trigger         | Output       | Credential Status    |
| ---------------------------- | --------------- | ------------ | -------------------- |
| Social Content Generator     | Webhook         | Notion       | Needs Notion API key |
| Growth Content Writer        | Webhook         | Notion       | Needs Notion API key |
| Weekly Strategy Check-in     | Monday 9am cron | Notion       | Needs Notion API key |
| QA Security Scan             | Webhook         | GitHub Issue | Needs GitHub PAT     |
| Partnership Outreach Drafter | Webhook         | Notion       | Needs Notion API key |
| CPA Tax Review               | Webhook         | Notion       | Needs Notion API key |


**OpenAI**: Connected (DONE). **Notion/GitHub/Postiz**: Not yet added as credentials in n8n UI. Until those are added, the workflows will generate AI content but fail on the output step.

---

## Your "Super Powers" — What I Can Do

MCP integrations give me direct programmatic access to your infrastructure:

- **Render MCP** (24 tools): Deploy, read logs, set env vars, check metrics, manage services, query Postgres — all without the dashboard
- **Notion MCP** (12 tools): Create pages, search, update databases, manage your Notion workspace programmatically
- **Docker MCP** (28 tools): Browser automation, testing, form filling, screenshots, performance profiling
- **Browser MCP** (33 tools): Navigate pages, interact with elements, take screenshots, run performance profiles — useful for testing your live sites
- **Context7**: Look up any library's latest docs on-demand
- **GitHub** (via `.cursor/mcp.json`): PR management, issues
- **SSH to Hetzner**: Direct shell access to your ops VPS (n8n, Postiz, Caddy)
- **All standard tools**: File read/write, grep, glob, shell, subagents for parallel work

In short: I can deploy your code, manage your databases, update Notion, test your sites in a browser, restart services on Hetzner, read Render logs, and look up any library docs — all from this chat.

---

## Recommended Fixes (Execution Plan)

### 1. Overhaul TASKS.md formatting

Replace `~~strikethrough~~` with `[x]` checkboxes throughout. Add sprint-level progress summary tables at the top. Makes done/not-done instantly scannable.

### 2. Delete root TASKS.md

Remove the 3-line redirect. `docs/TASKS.md` is the canonical source.

### 3. Fix 6 stale persona files

Update costs, paths, and versions in: `cfo.mdc`, `strategy.mdc`, `.cursorrules`, `ux.mdc`, `tax-domain.mdc`, `engineering.mdc`.

### 4. Fix Postiz (SSH)

SSH to Hetzner, check container status, restart Postiz if needed.

### 5. Update KNOWLEDGE.md

Add decisions D24-D27 for PostHog, legal pages, agent autonomy, TASKS.md restructure.

### 6. Move PostHog key to Vercel

The `NEXT_PUBLIC_POSTHOG_KEY` should be set as a Vercel environment variable, not in `.env.production` (which is committed). Remove the empty placeholder from `.env.production`.

### 7. Update docs/ consistency

- `PRODUCT_SPEC.md`: Check for stale references
- `PRD.md`: Verify revenue model matches D14
- `STRATEGY_REPORT.md`: Verify unit economics match current costs

