---
name: Tracked UI Cleanup
overview: "Tighten Tracked page: remove admin actions, add sort indicators, ensure rows are populated."
todos:
  - id: tracked-remove-actions
    content: Remove admin actions from Tracked page
    status: completed
  - id: tracked-sort-indicator
    content: Add sort arrow to sorted column header
    status: completed
  - id: tracked-fill-rows
    content: Ensure tracked rows use available fallback data
    status: completed
---

# Tracked Page Cleanup

## Scope
- Remove admin action buttons from Tracked page (admin flows live in Admin Dashboard).
- Add sort indicator (▲/▼) on the currently sorted column header.
- Ensure tracked table rows are populated where data exists; rely on latest snapshot or price_data fallback.

## Steps
1) Remove Tracked admin actions
- Drop action buttons block from `AdminTracked.tsx`.
- Confirm Admin Dashboard already exposes backfill/refresh tasks.

2) Sort indicators
- Show an arrow on the active sorted column header reflecting asc/desc.

3) Row completeness
- Verify table uses snapshot/price_data fallback; ensure no blank cells when data is available (handled server-side, confirm client renders fallback).

## Files to touch
- `frontend/src/pages/AdminTracked.tsx`
- (Optional) `frontend/src/utils/table helpers` if needed for sort icons.