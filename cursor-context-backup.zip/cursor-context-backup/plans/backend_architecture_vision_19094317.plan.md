---
name: Backend Architecture Vision
overview: A Principal Architect's blueprint for evolving AxiomFolio from a read-only portfolio viewer into an intelligent, auto-trading portfolio manager -- covering the execution pipeline, strategy engine, smart categories, and the UX philosophy that ties it all together.
todos:
  - id: fix-sync-lifecycle
    content: "Fix portfolio sync: remove dead endpoints, make sync-all async, auto-sync on account add"
    status: pending
  - id: reenable-strategies
    content: Fix import errors and re-enable strategies.py route in main.py
    status: pending
  - id: rule-evaluator
    content: "Build RuleEvaluator service: evaluate JSON condition trees against MarketSnapshot + Position context"
    status: pending
  - id: category-engine
    content: "Build CategoryEngine: auto-categorization rules (CategoryRule model), drift detection, rebalance computation"
    status: pending
  - id: order-model
    content: Create Order model with idempotency_key, status lifecycle, bracket order support
    status: pending
  - id: order-engine
    content: "Build OrderEngine service: order factory, broker routing, fill recording, position reconciliation"
    status: pending
  - id: risk-gate
    content: "Build RiskGate service: pre-trade checks, concentration limits, daily loss limits, circuit breakers, kill switch"
    status: pending
  - id: paper-executor
    content: "Build PaperExecutor: simulate fills with configurable slippage, same code path as live"
    status: pending
  - id: strategy-pipeline
    content: Wire Strategy -> RuleEvaluator -> Signal -> OrderEngine pipeline end-to-end (paper mode first)
    status: pending
  - id: ux-redesign-portfolio
    content: "Redesign Portfolio UX: invisible sync, progressive disclosure, category bands, single hero number"
    status: pending
isProject: false
---

# AxiomFolio: Principal Architect's Blueprint

## Current State Assessment

You already have an impressive foundation. 50+ models, a sophisticated market data pipeline (Weinstein stages, RS Mansfield, TD Sequential, ATR matrix), multi-broker sync (IBKR, TastyTrade, Schwab), and strategy/signal models that are well-designed but not yet wired up. The `strategies.py` route is literally commented out in `main.py` due to import errors.

The gap is not in the data model -- it is in the **execution pipeline** and the **intelligence layer** that connects signals to actions.

---

## The Three Pillars

```mermaid
flowchart TB
  subgraph pillar1 [Portfolio - READ ONLY]
    BrokerSync["Broker Sync"]
    Positions["Positions + Tax Lots"]
    Snapshots["Daily Snapshots"]
    Categories["Smart Categories"]
    BrokerSync --> Positions --> Snapshots
    Positions --> Categories
  end

  subgraph pillar2 [Intelligence - BRAIN]
    MarketData["Market Data Pipeline"]
    Indicators["Indicator Engine"]
    SignalGen["Signal Generator"]
    RuleEngine["Rule Engine"]
    MarketData --> Indicators --> SignalGen --> RuleEngine
  end

  subgraph pillar3 [Strategy - EXECUTION]
    StrategyDef["Strategy Definition"]
    Evaluator["Strategy Evaluator"]
    RiskGate["Risk Gate"]
    OrderEngine["Order Engine"]
    Reconciler["Trade Reconciler"]
    StrategyDef --> Evaluator
    RuleEngine --> Evaluator
    Evaluator --> RiskGate --> OrderEngine --> Reconciler
  end

  Categories -.->|"allocation drift"| RuleEngine
  Positions -.->|"current state"| Evaluator
  Reconciler -.->|"fills"| Positions
```



---

## Pillar 1: Portfolio (Read-Only) -- What to Fix

**Current pain:** No auto-sync, dead endpoints, N+1 queries.

### 1.1 Fix the sync lifecycle

The three endpoints in `[portfolio.py](backend/api/routes/portfolio.py)` calling missing `IBKRSyncService` methods (`get_user_portfolio_summary`, `get_user_positions`, `get_user_performance`) should be **deleted**. The working routes are in `portfolio_dashboard.py`, `portfolio_stocks.py`, and `portfolio_live.py`. Don't maintain dead code.

### 1.2 Auto-sync on account connection

When a user links a brokerage account (`POST /accounts/add`), enqueue a Celery sync task immediately. Don't make them hunt for a Sync button. The current flow:

```
Add Account → Nothing happens → User confused → Clicks Sync → Waits
```

Should become:

```
Add Account → Auto-enqueue sync → Show progress → Data appears
```

### 1.3 Make `/accounts/sync-all` async

Currently blocks the HTTP request. Move to Celery like individual account sync already does. Return a batch task ID and let the frontend poll.

### 1.4 Smart Categories (the big opportunity)

Your `Category` model already has `auto_rebalance`, `rebalance_threshold_pct`, `min/max_allocation_pct` -- but none of it is wired up. This is the bridge between Portfolio and Strategy.

**Auto-categorization rules engine:**

```python
# New model: CategoryRule
class CategoryRule(Base):
    category_id: FK -> categories.id
    rule_type: Enum  # SECTOR, INDUSTRY, MARKET_CAP, STAGE, SYMBOL_LIST, CUSTOM
    operator: Enum   # EQUALS, IN, BETWEEN, GREATER_THAN, REGEX
    field: str       # "sector", "industry", "market_cap", "stage_label"
    value: JSON      # {"values": ["Technology", "Healthcare"]} or {"min": 1e9, "max": 10e9}
    priority: int    # Higher priority rules win conflicts
```

When positions sync, run rules to auto-assign categories. User can override. This gives you:

- "Large Cap Tech" = `sector IN (Technology) AND market_cap > 100B`
- "Stage 2 Momentum" = `stage_label IN (2A, 2B) AND rs_mansfield_pct > 0`
- "Income" = `dividend_yield > 2%`
- "Trim Candidates" = `stage_label IN (3, 4) OR unrealized_pnl_pct < -15%`

**Allocation drift detection:**

A service that computes per-category: `actual_pct - target_pct`. When `abs(drift) > rebalance_threshold_pct`, emit a `REBALANCE_NEEDED` event. If `auto_rebalance` is on and the user has auto-trade enabled, this feeds into the Strategy pillar.

---

## Pillar 2: Intelligence -- What You Have vs What You Need

**What you already have (and it is excellent):**

- Weinstein Stage analysis (1/2A/2B/2C/3/4)
- RS Mansfield relative strength
- ATR matrix (distance-based entry/exit zones)
- TD Sequential (buy/sell setups and countdowns)
- RSI, MACD, SMA/EMA battery
- Gap detection, trendline counting
- Fundamentals (PE, PEG, ROE, EPS growth)

**What is missing: a composable Rule Engine.**

The current `ATRSignalGenerator` is monolithic -- hardcoded entry/exit conditions. For auto-trading, you need users to compose rules from your indicator library.

### 2.1 Rule Engine Architecture

```mermaid
flowchart LR
  subgraph inputs [Signal Inputs]
    Stage["Stage Analysis"]
    ATR["ATR Matrix"]
    TD["TD Sequential"]
    RSI["RSI / MACD"]
    Fundamental["Fundamentals"]
    Category["Category Drift"]
  end

  subgraph engine [Rule Engine]
    Condition["Condition Tree"]
    Scorer["Signal Scorer"]
    Prioritizer["Action Prioritizer"]
  end

  subgraph outputs [Actions]
    Entry["ENTRY Signal"]
    Exit["EXIT Signal"]
    Trim["TRIM Signal"]
    Rebalance["REBALANCE Signal"]
    Alert["ALERT Only"]
  end

  inputs --> Condition --> Scorer --> Prioritizer --> outputs
```



**Condition Tree** (JSON-serializable, stored in `Strategy.parameters`):

```json
{
  "operator": "AND",
  "conditions": [
    {"field": "stage_label", "op": "in", "values": ["2A", "2B"]},
    {"field": "rs_mansfield_pct", "op": ">", "value": 0},
    {
      "operator": "OR",
      "conditions": [
        {"field": "rsi", "op": "<", "value": 30},
        {"field": "td_buy_setup", "op": ">=", "value": 9}
      ]
    }
  ]
}
```

This is already representable in your `Strategy.parameters` JSON field. No new model needed -- just a `RuleEvaluator` service that walks the tree against a `MarketSnapshot + Position` context.

### 2.2 Signal Types to Add

Your current `SignalType` enum has: ENTRY, EXIT, SCALE_OUT, STOP_LOSS, ALERT. Add:

- `TRIM` -- reduce position size (e.g., "sell 25% of RXRX")
- `REBALANCE` -- category allocation drift correction
- `ROTATE` -- exit one position, enter another (sector rotation)

---

## Pillar 3: Strategy + Execution -- The Hard Part

This is where the money is (literally). The architecture must be **paranoid about correctness**.

### 3.1 Strategy Lifecycle

```mermaid
stateDiagram-v2
  [*] --> Draft
  Draft --> Backtesting: Run Backtest
  Backtesting --> Draft: Failed
  Backtesting --> Validated: Passed
  Validated --> PaperTrading: Enable Paper
  PaperTrading --> Validated: Pause
  PaperTrading --> Live: Promote to Live
  Live --> Paused: Pause
  Paused --> Live: Resume
  Live --> Stopped: Stop
  Stopped --> [*]
```



Your `StrategyStatus` enum already has DRAFT, ACTIVE, PAUSED, STOPPED, ARCHIVED. Add `PAPER_TRADING` and `BACKTESTING` states. **No strategy should go live without passing through paper trading first.** This is a PM decision: protect users from themselves.

### 3.2 Order Engine (new service)

This is the most critical new component. It sits between strategy signals and broker APIs.

**Key design principles:**

- **Idempotent submissions** -- every order has a client-generated `idempotency_key` (hash of strategy_id + symbol + signal_id + timestamp_bucket). Prevents duplicate orders on retry.
- **Two-phase commit** -- Order created in DB as PENDING, submitted to broker, updated to SUBMITTED/FILLED/REJECTED. Never lose track of an order.
- **Kill switch** -- Global and per-strategy circuit breakers. If daily loss exceeds threshold, halt all execution.
- **Paper trading as first-class** -- Same code path, different executor. Paper executor simulates fills using current market price + configurable slippage.

```mermaid
flowchart TB
  Signal["Strategy Signal"] --> OrderFactory["Order Factory"]
  OrderFactory --> RiskCheck["Risk Gate"]
  RiskCheck -->|"PASS"| OrderPersist["Persist PENDING"]
  RiskCheck -->|"FAIL"| Reject["Reject + Alert"]
  OrderPersist --> Router["Broker Router"]

  Router -->|"PAPER"| PaperExec["Paper Executor"]
  Router -->|"IBKR"| IBKRExec["IBKR Order API"]
  Router -->|"TastyTrade"| TTExec["TastyTrade Order API"]
  Router -->|"Schwab"| SchwabExec["Schwab Order API"]

  PaperExec --> Fill["Record Fill"]
  IBKRExec --> Fill
  TTExec --> Fill
  SchwabExec --> Fill

  Fill --> Reconciler["Position Reconciler"]
  Reconciler --> Notify["Notify User"]
```



**New models needed:**

```
Order (orders table):
- id, strategy_id, signal_id, user_id, account_id
- idempotency_key (unique)
- symbol, side (BUY/SELL), order_type (MARKET/LIMIT/STOP)
- quantity, limit_price, stop_price
- time_in_force (DAY/GTC/IOC)
- status (PENDING/SUBMITTED/PARTIAL/FILLED/CANCELLED/REJECTED/EXPIRED)
- broker_order_id, broker_execution_id
- filled_quantity, filled_avg_price
- submitted_at, filled_at, cancelled_at
- is_paper_trade
- parent_order_id (for bracket orders)
- notes, error_message
```

### 3.3 Risk Gate (new service)

Every order passes through the Risk Gate before submission:

**Pre-trade checks:**

- Position concentration: Is this position > `max_position_size_pct` of portfolio?
- Daily loss limit: Has the strategy lost > `max_daily_loss` today?
- Portfolio heat: Total open risk > `max_portfolio_risk`?
- Duplicate check: Is there already a pending order for this symbol?
- Market hours: Is the market open? (Or is this a pre-market/after-hours order?)
- Account buying power: Can the account afford this trade?
- Kill switch: Is the global or strategy kill switch engaged?

**Circuit breakers:**

- 3 consecutive failed orders → pause strategy, notify user
- Daily P&L < -2% of portfolio → halt all auto-execution
- Single trade > 5% of portfolio → require manual approval

### 3.4 The "Trim RXRX" Flow (your example)

Here is exactly how "market data says sell 9, auto-trim RXRX" would work:

```
1. Market data task runs → computes MarketSnapshot for RXRX
2. MarketSnapshot shows td_sell_setup = 9 (TD Sequential sell signal)
3. Signal Generator evaluates strategy rules:
   - Strategy "Momentum Guard" has rule:
     IF td_sell_setup >= 9 AND stage_label NOT IN (2A, 2B)
     THEN TRIM 25%
4. Signal created: type=TRIM, symbol=RXRX, quantity_pct=25%
5. Order Factory: lookup RXRX position → 100 shares → trim 25 = sell 25 shares
6. Risk Gate: checks concentration, daily loss, buying power → PASS
7. Order persisted: SELL 25 RXRX MARKET DAY
8. Broker Router: routes to IBKR Order API (or Paper Executor)
9. Fill recorded → Position updated: 100 → 75 shares
10. User notified: "Trimmed 25 shares RXRX @ $X.XX (TD Sell 9)"
```

---

## PM Decisions: What to Build and When

### Phase 1: Foundation (Now)

- Fix Portfolio sync lifecycle (auto-sync, async sync-all, remove dead endpoints)
- Wire up strategy routes (currently disabled)
- Build Rule Engine evaluator for `Strategy.parameters` JSON
- Auto-categorization rules for categories
- Paper trade executor (simulate fills, no broker API needed)

### Phase 2: Paper Trading (Next)

- Order model + Order Engine service
- Risk Gate with basic checks
- Strategy → Signal → Order pipeline (paper only)
- Strategy dashboard: P&L tracking, signal history, execution log
- Backtest runner using historical `MarketSnapshotHistory` data

### Phase 3: Live Execution (Later)

- IBKR order API integration (TWS API or Client Portal)
- TastyTrade order API integration
- Position reconciliation (broker state vs DB state)
- Circuit breakers and kill switch
- Allocation drift → auto-rebalance pipeline

### Phase 4: Intelligence (Ongoing)

- Strategy marketplace (share/clone strategies)
- ML-enhanced signal scoring
- Multi-timeframe analysis
- Options strategy execution (covered calls, iron condors)

---

## Jon Ive Design Philosophy

### The Invisible Complexity Principle

The system described above is enormously complex. The design challenge is making it feel **simple and inevitable**. Here is how:

### Portfolio: The Calm Dashboard

The portfolio should feel like opening a beautifully designed financial statement. No clutter, no noise.

- **One number that matters**: Total portfolio value, large and centered, with a subtle daily change indicator. Not 8 stat cards competing for attention.
- **Progressive disclosure**: The overview shows 3 things: value, allocation donut, performance spark. Tap/click to drill into holdings, options, transactions.
- **Categories as colored bands**: Instead of a separate page, show category allocation as a stacked bar at the top of Holdings. Each band is clickable. The user sees "I'm 45% Tech, 30% Healthcare, 25% Cash" at a glance.
- **The sync should be invisible**: No sync button on every page. Sync happens automatically. A tiny, unobtrusive indicator (like iCloud sync) shows freshness. "Updated 2m ago" in the footer, not a button that implies the data might be stale.

### Strategy: The Control Room

This is where complexity lives -- but it should feel like a well-designed cockpit, not a spreadsheet.

- **Strategy as a card**: Each strategy is a card showing: name, status (green/yellow/red dot), P&L, last action. Not a table.
- **Rule builder as sentence**: Instead of a JSON tree, the UI presents rules as natural language: "Buy when stage enters 2A **and** RS Mansfield > 0 **and** RSI < 30". Each clause is a chip that can be tapped to edit. This is the Shortcuts.app pattern.
- **The timeline**: Every strategy has a timeline showing signals, orders, fills, P&L changes. It tells the story of what the strategy did and why.
- **Paper → Live as a toggle**: A single toggle with a confirmation dialog. "Switch to live trading? This strategy has been paper trading for 14 days with +3.2% return." The confidence comes from the data, not from the UI shouting warnings.

### Categories: The Allocation Palette

- **Target vs actual as concentric rings**: Inner ring = target allocation, outer ring = actual. Deviation is immediately visible as misalignment.
- **Auto-categorize as a magic wand**: A button that says "Auto-organize" -- it runs the rules, shows a preview ("Move AAPL to Large Cap Tech, Move RXRX to Biotech"), and asks for confirmation. One tap to accept all, or cherry-pick.
- **Rebalance as a shopping list**: When drift exceeds threshold, show a "Rebalance" card that reads like a to-do list: "Sell 12 shares AAPL (-2.3%), Buy 8 shares VTI (+1.8%)". One button: "Execute Rebalance" (or "Review Orders" for the cautious).

### The Notification Philosophy

- **Don't notify, narrate**: Instead of push notifications that interrupt, build a "Morning Brief" (you already have Discord webhooks). A daily digest: "Your portfolio is up 0.3%. Momentum Guard trimmed 25 RXRX (TD Sell 9). 2 positions entering Stage 3 -- review?"
- **Severity as subtlety**: Critical alerts (circuit breaker triggered) get red. Information (signal generated) gets a quiet blue dot in the sidebar. The app never screams.

---

## Key Backend Files to Change


| Area        | File                                            | Change                                                              |
| ----------- | ----------------------------------------------- | ------------------------------------------------------------------- |
| Dead code   | `backend/api/routes/portfolio.py`               | Remove endpoints calling missing service methods (lines ~80-140)    |
| Sync        | `backend/api/routes/account_management.py`      | Make `/sync-all` async via Celery; auto-sync on account add         |
| Strategy    | `backend/api/main.py`                           | Re-enable `strategies.py` route (fix import errors)                 |
| Rule Engine | `backend/services/strategies/rule_evaluator.py` | **New**: Evaluate condition trees against MarketSnapshot + Position |
| Categories  | `backend/services/portfolio/category_engine.py` | **New**: Auto-categorization rules + drift detection                |
| Orders      | `backend/services/trading/order_engine.py`      | **New**: Order lifecycle management                                 |
| Risk        | `backend/services/trading/risk_gate.py`         | **New**: Pre-trade risk checks + circuit breakers                   |
| Execution   | `backend/services/trading/broker_executor.py`   | **New**: Broker-specific order submission (paper + live)            |
| Models      | `backend/models/order.py`                       | **New**: Order model                                                |
| Models      | `backend/models/portfolio.py`                   | Add `CategoryRule` model                                            |


