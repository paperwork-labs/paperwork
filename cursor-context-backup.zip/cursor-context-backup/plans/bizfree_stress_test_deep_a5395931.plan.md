---
name: BizFree Stress Test Deep
overview: "McKinsey-style deep stress test of BizFree (free LLC formation) as a real business opportunity, evaluation of \"we don't sell customers anything\" as the core strategy, and systematic identification of every other business that fits the exact same pattern: give away tedious government paperwork for free, acquire users for pennies, monetize through established referral channels."
todos:
  - id: bizfree-decision
    content: "Co-founder decision: confirm BizFree as the second product for Summer 2026 launch"
    status: pending
  - id: bizfree-domain
    content: Research and secure domain name for BizFree (brand naming session needed - 'BizFree' is placeholder)
    status: pending
  - id: bizfree-affiliate-apps
    content: "Apply to affiliate programs: Novo (banking), Gusto (payroll), QuickBooks (bookkeeping), Next Insurance, Hiscox (insurance)"
    status: pending
  - id: bizfree-repo
    content: Create new repo with same stack as FileFree (Next.js + FastAPI + PostgreSQL) after FileFree Sprint 4 state tax work is complete
    status: pending
  - id: filefree-sprint4
    content: "Continue FileFree Sprint 4 (state taxes, PDF generation, production polish) -- this remains priority #1 through May 2026"
    status: pending
isProject: false
---

# BizFree Stress Test + The "Free Tedious Process" Portfolio

**Classification**: Internal -- Founders + Advisors
**Prepared by**: AI Strategy Team (multi-persona deep dive)
**Date**: March 2026

---

## 1. "We're Not Selling Customers Anything" -- Why That IS the Business

This is the single most important strategic insight across all three products (FileFree, BizFree, and any future product). You are NOT selling customers anything. You are the distribution channel.

**The Credit Karma Playbook Explained:**

```
TRADITIONAL MODEL (LegalZoom, TurboTax):
  User pays YOU for service → you keep the money
  Problem: users resist paying, churn is high (LegalZoom: 42% annual churn)

YOUR MODEL (FileFree, BizFree):
  User pays you NOTHING → you give them a free service
  Partners pay YOU for introducing customers they would have paid $50-500 to acquire
  Win/Win/Win: user gets free service, partner gets customer, you get referral fee
```

**Why partners pay you gladly:**

- Mercury/Novo spend $50-200 in paid ads to acquire ONE business bank account customer
- Gusto spends $300-1,000 to acquire ONE payroll customer
- Next Insurance spends $25+ to get ONE quote
- You deliver these customers at the HIGHEST intent moment: they just formed their LLC and NEED these products RIGHT NOW

**What you're really building**: A **customer acquisition machine** for financial product companies. The free service is the magnet. The referral engine is the business. You never sell. You recommend.

This is why LegalZoom's 42% annual churn rate is actually your tailwind -- they're a subscription business trying to extract $249/yr from customers who resist it. You're a referral business that gives everything away for free. Users have zero reason to leave because they're paying zero.

---

## 2. BizFree: Full Stress Test

### 2.1 Market Size (Validated)


| Metric                                         | Value                                   | Source              |
| ---------------------------------------------- | --------------------------------------- | ------------------- |
| New business applications/year (US)            | 5.5M (2023), projected 6M (2025)        | Census Bureau BFS   |
| LLC formations specifically                    | ~4M/year (72.7% of all formations)      | IRS + Census        |
| LegalZoom revenue from this market             | $756M (2025, 11% YoY growth)            | LZ public filings   |
| LegalZoom subscription revenue                 | $492M (65% of total)                    | LZ public filings   |
| Average spend on formation + Year 1 compliance | $700-1,000                              | Industry reviews    |
| LegalZoom subscriber retention                 | **58%** (42% churn annually)            | LZ investor reports |
| LegalZoom market share trend                   | **Losing share** (grew 4% vs market 9%) | LZ investor reports |


**Key insight**: LegalZoom is a $756M business with 42% churn and declining market share. That's a massive pool of dissatisfied customers looking for alternatives.

### 2.2 Revenue Model: Referral Commissions (Research-Backed)

Every LLC owner MUST complete a post-formation checklist. Each step is a monetization touchpoint:


| Post-Formation Need   | Partner                            | Commission            | Attach Rate (Est.)       | Revenue/User |
| --------------------- | ---------------------------------- | --------------------- | ------------------------ | ------------ |
| Business bank account | Novo ($40), Mercury (partner rate) | $40-150/funded        | 70% (everyone needs one) | $28-105      |
| Payroll (if hiring)   | Gusto                              | **$300-1,000/signup** | 8% (most LLCs are solo)  | $24-80       |
| Bookkeeping software  | QuickBooks                         | $50/signup            | 25%                      | $12.50       |
| Business insurance    | Next Insurance, Hiscox             | $25/quote             | 30%                      | $7.50        |
| Registered domain     | Namecheap, GoDaddy                 | $5-15/signup          | 20%                      | $1-3         |
| Business credit card  | Various                            | $100-200/approval     | 10%                      | $10-20       |
| **TOTAL ARPU**        |                                    |                       |                          | **$83-230**  |


**Conservative ARPU estimate: $85** (assuming low attach rates on everything)
**Moderate ARPU estimate: $140** (reasonable attach rates)

Compare to FileFree: $8.05 ARPU. BizFree is **10-17x higher ARPU**.

### 2.3 Unit Economics


| Metric                                  | Value          | Notes                             |
| --------------------------------------- | -------------- | --------------------------------- |
| Cost per user (AI form generation)      | $0.02          | GPT-4o-mini structured output     |
| Cost per user (state filing guidance)   | $0.00          | Static data, JSON-driven          |
| Cost per user (EIN generation guidance) | $0.00          | IRS is free, we just guide        |
| Registered agent cost at scale          | $5-15/yr       | Amortized address + mail handling |
| Infrastructure                          | $15/mo fixed   | Same stack as FileFree            |
| **Total cost per user**                 | **$0.02-0.15** | Year 1                            |
| **Gross margin**                        | **99%+**       | Before RA costs                   |
| **Gross margin (including free RA)**    | **93-98%**     | At $85+ ARPU                      |


### 2.4 What Breaks? (Adversarial Stress Test)

**Scenario 1: Users form and never come back (no referrals)**

- Probability: LOW
- Why: The post-formation checklist IS the product. They literally CANNOT operate without a bank account and EIN. We walk them through it step-by-step. The formation is just Step 1 of a 7-step onboarding.
- Mitigation: Immediate post-formation email sequence: "Congrats! Your LLC is formed. Here are the 6 things you need to do this week." Each step is a monetization touchpoint.

**Scenario 2: LegalZoom/ZenBusiness drop prices to match**

- Probability: LOW
- Why: LegalZoom's registered agent revenue ($249/yr x millions of subs) is their CASH COW. They'd be cutting their own throat. This is the exact same structural problem TurboTax has -- they CAN'T compete on free without destroying their business model.
- Evidence: LegalZoom has 42% annual churn and is LOSING market share, yet hasn't dropped RA pricing. They're structurally trapped.

**Scenario 3: Referral programs change terms / lower commissions**

- Probability: MEDIUM (over years)
- Impact: Moderate
- Mitigation: Diversified across 6+ referral partners across 4 categories. No single partner is >40% of revenue. Same risk profile as FileFree.

**Scenario 4: State filing requirements change**

- Probability: LOW
- Impact: Low
- Mitigation: JSON-driven state data (same pattern as FileFree's state tax engine). Updating one state means updating one JSON file.

**Scenario 5: Users don't trust a free service with their business**

- Probability: MEDIUM
- Impact: High
- Mitigation: Same playbook as FileFree -- try-before-signup, founder-led content, transparent "how we make money" page. The fact that LegalZoom has trust issues (aggressive upselling reputation) makes "genuinely free" a differentiated trust signal.

**Scenario 6: Gusto cuts their $300-1,000 referral commission**

- Probability: LOW-MEDIUM
- Impact: Moderate (Gusto is 15-30% of ARPU)
- Why unlikely: Gusto's CAC through paid ads is $200+. Paying $300 for a pre-qualified, high-intent customer who just formed an LLC is a bargain for them. They've maintained these rates for years.
- Mitigation: Even without Gusto, ARPU stays at $60+ from banking + insurance + bookkeeping alone.

### 2.5 Sensitivity Analysis


| Variable               | Base Case | Break-Even Threshold | What Happens                                    |
| ---------------------- | --------- | -------------------- | ----------------------------------------------- |
| Banking attach rate    | 70%       | <15%                 | ARPU drops below $50. Still profitable.         |
| Gusto referral         | $300      | $0 (program killed)  | ARPU drops to $60. Still 10x FileFree.          |
| All commissions halved | $85 ARPU  | $42.50 ARPU          | Still 5x FileFree. Still 95%+ margin.           |
| RA cost doubles        | $10/yr    | $30/yr               | Still profitable at any ARPU above $30.         |
| User acquisition cost  | $2-5      | >$42                 | Model breaks only if CAC exceeds ARPU by a lot. |


**Most fragile assumption**: Banking attach rate. If users form their LLC but never open a business bank account through us, the biggest revenue line dies.

**Most robust assumption**: Cost structure. Even if ARPU drops 75%, margins stay above 80%. The cost to provide the service is essentially zero.

### 2.6 Competitive Moat

**LegalZoom's structural trap** (same as TurboTax's):

- $492M/yr in subscription revenue = they CANNOT make RA free
- 42% annual churn = customers are actively unhappy
- Growing 4% vs market at 9% = losing share
- "Notorious for aggressive upselling" = brand trust eroding

**BizFree's positioning**: "LegalZoom says 'free.' Then charges you $249/year. We say free. And mean it."

Sound familiar? It's literally the same sentence as FileFree vs TurboTax.

### 2.7 Timeline: Summer 2026 Launch


| Week | Milestone                                                                                                      |
| ---- | -------------------------------------------------------------------------------------------------------------- |
| 1-2  | New repo, same stack (Next.js + FastAPI + PostgreSQL). Formation questionnaire, articles of incorporation PDF. |
| 3    | State filing guide for all 50 states (JSON-driven, same as state tax engine). EIN walkthrough.                 |
| 4    | Post-formation dashboard: checklist with partner referral cards (banking, insurance, payroll, bookkeeping).    |
| 5    | Landing page, SEO content ("how to start an LLC for free 2026"), social media accounts.                        |
| 6    | Polish, affiliate program applications (Novo, Gusto, QuickBooks, Next Insurance), deploy to Vercel + Render.   |
| 7-8  | Content push, TikTok/IG ("I started my LLC in 3 minutes for free"), paid amplification on winners.             |


**Cost to launch**: ~$15/mo incremental infrastructure (one more Render service). Same Vercel, same pattern.

**Code reuse from FileFree**: 70%+

- PDF generation pipeline (articles of incorporation = same as 1040 PDF)
- Auth system (same)
- State-by-state JSON data engine (same pattern as state tax)
- Landing page components (same)
- Referral tracking infrastructure (same as Refund Plan)
- Analytics (PostHog, same)
- CI/CD (GitHub Actions, same)

---

## 3. The Master Pattern: "Free Tedious Process" Businesses

Here is the formula, written as a repeatable playbook:

```
1. IDENTIFY a tedious government/institutional process that causes anxiety
2. PEOPLE CURRENTLY PAY $100-1,000+ to get it done (or avoid it)
3. AI CAN AUTOMATE IT to near-zero marginal cost
4. THERE IS A NATURAL "DECISION MOMENT" where the user needs financial products
5. ESTABLISHED REFERRAL PROGRAMS exist for those products (proven commissions)
6. THE INCUMBENT is a subscription/upsell business that CANNOT compete on free
```

### Every Business That Fits This Pattern (Ranked)

#### TIER 1: BUILD THIS YEAR

**A. BizFree -- Free LLC Formation + Compliance**

- Process: LLC formation, EIN, operating agreement, compliance
- People pay: $300-1,000 (LegalZoom/ZenBusiness Year 1)
- Decision moment: "Your LLC is formed! Now open a business bank account."
- Referral revenue: $85-230/user (banking $40-150, payroll $300-1,000, insurance $25, bookkeeping $50)
- Trapped incumbent: LegalZoom ($756M rev, 42% churn, can't drop $249/yr RA)
- Vibe-codeable: YES (6-8 weeks, same stack)
- **VERDICT: BUILD. Summer 2026 launch.**

#### TIER 2: EVALUATE FOR 2027

**B. AppealFree -- Free Property Tax Reduction**

- Process: Property tax appeal (research comps, fill forms, file with county)
- People pay: 25-35% of savings to Ownwell, or $200-500/hr to attorneys
- OUR MODEL: $49 flat fee OR contingency (25% of savings). Average savings $774 = $193/customer revenue.
- Decision moment: "You just saved $774/year! Want to save more on home insurance too?"
- Cross-sell: Home insurance comparison ($30-100/policy), mortgage refinancing ($100-300/funded loan)
- Trapped incumbent: Ownwell (only 9 states, charges 25-35% contingency)
- AI automation: OCR property tax bill, pull Zillow/Redfin comps, generate appeal packet
- Vibe-codeable: YES (6-8 weeks for appeal packet generator)
- Complication: Ownwell has $74M in funding and head start. But only 9 states. AppealDesk does $49 flat fee in all 50 states and appears smaller.
- **VERDICT: STRONG OPPORTUNITY but more complex than BizFree. Evaluate after BizFree launches.**

**C. LoanFree -- Free Student Loan Optimizer**

- Process: Analyze all student loans, calculate optimal repayment plan, compare refinancing options
- People pay: financial advisors $200-500/session, or just suffer in confusion
- Decision moment: "Your interest rate is 6.5%. Refinancing could save you $8,400."
- Referral revenue: SoFi ($100-150/lead), Earnest ($200/referral)
- TAM: 45M borrowers, $1.77T outstanding
- Vibe-codeable: YES (FSA API + calculation engine)
- Complication: Refinancing is not always right (loses federal protections). Requires careful CPA-level advisory.
- **VERDICT: STRONG OPPORTUNITY. Best as a 2027 product when FileFree users graduate from "first tax filing" to "managing student loans."**

#### TIER 3: INTERESTING BUT NOT NOW

**D. SwitchFree -- Free Car Insurance Comparison**

- Revenue per user: $30-100 (carrier commissions)
- Problem: Carrier API access is a multi-month partnership process, not vibe-codeable
- Competitor moat: Jerry ($160M+ raised, 5M users), Gabi (acquired by Experian)
- **VERDICT: SKIP. Too crowded, carrier partnerships are the moat and can't be vibe-coded.**

**E. WillFree -- Free Estate Planning**

- Revenue per user: $200-500 (life insurance referrals are HUGE)
- Problem: Legal complexity varies by state, closer to unauthorized practice of law
- Competitor: Trust & Will ($75M raised, hundreds-of-millions valuation)
- **VERDICT: CONSIDER for 2028. Life insurance referral commissions are the highest of any category ($200-500/policy) but legal risk is real.**

**F. PassportFree -- Free Passport Renewal Assistance**

- Market: $1.5B growing to $2.9B by 2032
- Problem: Monetization is weak (travel insurance? travel credit cards? Low commissions)
- No natural "decision moment" with high-value financial products
- **VERDICT: SKIP. Doesn't fit the referral monetization pattern.**

---

## 4. Stress Testing "We Don't Sell Anything"

Let me be adversarial about this claim because it IS the entire strategy:

### 4.1 Is "We Don't Sell Anything" Actually True?

**YES, technically.** You never charge the user. You never upsell. You never bait-and-switch. The user gets exactly what was promised: free LLC formation, free registered agent, free compliance tracking.

**BUT** you ARE influencing their purchasing decisions by recommending specific partners. The question is: **is this ethical and sustainable?**

### 4.2 Ethical Stress Test

**Test**: Would a user feel deceived if they learned how you make money?

**Answer**: NO -- because:

1. You're recommending products they genuinely need (they MUST open a bank account)
2. The recommended products are legitimate, well-known brands (Novo, Gusto, QuickBooks)
3. You include clear FTC disclosure ("we may earn a commission")
4. The user saves $300-1,000 vs LegalZoom even AFTER you earn referral fees
5. Credit Karma, NerdWallet, and Bankrate ALL use this exact model and are trusted brands

**The user value proposition in dollars**:

- LegalZoom Year 1: $0 formation + $249 RA + $159 EIN + $249 operating agreement = **$657**
- BizFree Year 1: $0 formation + $0 RA + $0 EIN + $0 operating agreement = **$0** (+ state fee)
- User saves: **$657** even though you earn $85-230 in referral fees from their bank/insurance/payroll
- Everyone wins. The math works because the user was going to open a bank account ANYWAY. The question is just whether they click YOUR link or Google it themselves.

### 4.3 What if Users Bypass Our Referrals?

This is the real risk. If users form their LLC through us but open their bank account directly with Mercury (not through our link), we earn $0.

**Mitigation strategies** (same as Credit Karma):

1. **Make the referral integral to the workflow**: "Step 3: Open Your Business Bank Account" with pre-filled application link. It's the path of least resistance.
2. **Add genuine value to the referral**: "Based on your LLC type and state, we recommend Novo because they have no minimum balance and free ACH transfers." This is useful advice, not just a link.
3. **Offer exclusive partner perks**: Negotiate "BizFree customers get 3 months free" deals with partners. This gives users a reason to use your link.
4. **Multi-touchpoint**: Even if they skip banking, they might convert on insurance or payroll. Diversification protects against any single bypass.

### 4.4 Regulatory Risk

**FTC Disclosure**: Required. Simple. One line: "We may earn a referral fee when you sign up for partner services. This doesn't affect the price you pay."

**Practicing law concerns**: NONE for formation. LegalZoom fought and won this battle in multiple state bar cases (2003-2015). Document preparation from user-provided information is NOT practicing law. We're filling out forms, not giving legal advice.

**Insurance referral licensing**: Some states require a license to sell insurance. We're NOT selling -- we're referring to licensed providers (Next Insurance, Hiscox). This is the standard affiliate model.

---

## 5. The 2026 Portfolio Plan


| Product        | Launch          | Status                         | ARPU    | Revenue Model                           |
| -------------- | --------------- | ------------------------------ | ------- | --------------------------------------- |
| **FileFree**   | Live (MVP done) | Sprint 4, full launch Jan 2027 | $8.05   | Refund routing + financial referrals    |
| **BizFree**    | Summer 2026     | Not started                    | $85-230 | Banking + payroll + insurance referrals |
| **AxiomFolio** | Personal tool   | Running                        | N/A     | Personal wealth compounding             |


**Shared infrastructure**:

- Same tech stack (Next.js + FastAPI + PostgreSQL)
- Same deployment (Vercel + Render + Neon)
- Same CI/CD, same auth patterns, same PDF generation
- Same brand voice ("free, simple, honest")
- Different domains, different repos, but same playbook

**Time allocation**:

- March-May 2026: FileFree Sprint 4 (state taxes, PDF, polish)
- May-July 2026: BizFree MVP (6-8 week build)
- August-September 2026: BizFree content push + affiliate activation
- October 2026: FileFree e-file launch (Column Tax)
- January 2027: FileFree MeF transmitter (NORTH STAR)

The builds don't compete for time because FileFree's Sprint 4 is mostly data work (50 state tax JSON files) and BizFree's build is AFTER that sprint.

---

## 6. Final Verdict

### BizFree: CONFIRMED OPPORTUNITY


| Criterion          | FileFree                 | BizFree                          | Verdict                      |
| ------------------ | ------------------------ | -------------------------------- | ---------------------------- |
| Market validated?  | Yes (Credit Karma $7.1B) | Yes (LegalZoom $756M/yr)         | Both proven                  |
| ARPU               | $8.05                    | $85-230                          | **BizFree 10-28x higher**    |
| Seasonal?          | Yes (Jan-Apr)            | No (year-round)                  | **BizFree better**           |
| Recurring revenue? | Mostly one-time          | Yes (RA + compliance)            | **BizFree better**           |
| Cost per user      | $0.05                    | $0.02-0.15                       | Comparable                   |
| Trapped incumbent? | TurboTax ($4.9B rev)     | LegalZoom ($756M rev, 42% churn) | Both have trapped incumbents |
| Vibe-codeable?     | Yes (done)               | Yes (same stack)                 | Both yes                     |
| Cross-sell?        | BizFree users need taxes | FileFree users start businesses  | **Natural flywheel**         |


### Is There Another Business This Good?

Honestly: **no, not at this quality level.** BizFree is the cleanest #2 because:

1. The incumbent (LegalZoom) is publicly validated at $756M/yr AND visibly struggling (42% churn, losing share)
2. The referral commissions are the highest of any category (Gusto alone pays $300-1,000)
3. The formation-to-referral funnel is the most natural (users MUST open a bank account)
4. It's the most vibe-codeable (70%+ code reuse from FileFree)
5. It has the strongest cross-sell synergy with FileFree

Property tax appeals (AppealFree) is the next best, but Ownwell's $74M head start and the more complex execution (county-by-county comp analysis) makes it a 2027 consideration, not a 2026 build.

### The Honest Bottom Line

You've found a repeatable playbook. FileFree applies it to tax filing. BizFree applies it to business formation. The pattern is:

**"Take a $500+ anxiety-inducing government process, make it free with AI, and earn $50-300/user from partners who gladly pay you to deliver high-intent customers at the exact moment they need financial products."**

You never sell the customer anything. The customer saves hundreds of dollars. The partners get customers cheaper than paid ads. You collect the margin in between. Everyone wins. That's not a pitch -- it's just math.