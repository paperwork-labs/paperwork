---
name: Ops UI simplification
overview: Simplify admin ops by replacing fixed snapshot-history day buttons with period/since controls, removing AdminRunbook, and moving the snapshot-indicators table to MarketTracked (MarketCoverage becomes coverage-only).
todos:
  - id: admin-history-period
    content: Replace 200d snapshot history action with since-date + period controls in AdminDashboard; wire period→days mapping and calls
    status: pending
  - id: remove-admin-runbook
    content: Remove AdminRunbook page/route and clean up any navigation links
    status: pending
    dependencies:
      - admin-history-period
  - id: marketcoverage-coverage-only
    content: Remove snapshot indicators table from MarketCoverage; keep coverage summary + histogram
    status: pending
    dependencies:
      - admin-history-period
  - id: markettracked-snapshot-table
    content: Refactor MarketTracked to display Level 1–4 snapshot indicators table backed by MarketSnapshot snapshots endpoint, using SortableTable
    status: pending
    dependencies:
      - marketcoverage-coverage-only
  - id: tests-update
    content: Update/add frontend tests for new AdminDashboard controls, MarketCoverage, and MarketTracked; add backend test for /technical/snapshots if needed
    status: pending
    dependencies:
      - markettracked-snapshot-table
      - remove-admin-runbook
---

# Simplify Ops UI + Move Snapshot Table

## Decisions captured

- Remove the fixed **200d** snapshot history button and replace with **since-date** + **period** controls.
- Remove **AdminRunbook** page entirely.
- Remove **snapshot indicators table** from MarketCoverage; make **MarketTracked** the detailed Level 1–4 snapshot table. MarketCoverage becomes coverage-only.

## 1) Admin Dashboard: Snapshot history controls

**File:** [frontend/src/pages/AdminDashboard.tsx](frontend/src/pages/AdminDashboard.tsx)

- Remove **Backfill Snapshot History (200d)**.
- Keep **Backfill Snapshot History (since)** using the existing date picker.
- Add **Backfill Snapshot History (period)**:
- Period dropdown: `6mo / 1y / 2y / 5y / max` (max maps to a safe upper bound, e.g. 3000 days, or uses `since_date` if you prefer).
- Map period → trading-day count (approx): `6mo→126`, `1y→252`, `2y→504`, `5y→1260`.
- POST to existing backend endpoint: `POST /api/v1/market-data/admin/snapshots/history/backfill-last-n-days?days=<mapped>`.

## 2) Remove AdminRunbook

**Files:**

- [frontend/src/pages/AdminRunbook.tsx](frontend/src/pages/AdminRunbook.tsx)
- [frontend/src/App.tsx](frontend/src/App.tsx)
- Any settings/admin navigation links to runbook

Actions:

- Delete the page and remove the route/import.
- Ensure no dead links remain.

## 3) MarketCoverage becomes coverage-only

**File:** [frontend/src/pages/MarketCoverage.tsx](frontend/src/pages/MarketCoverage.tsx)

- Remove the “Latest Market Snapshots” table section.
- Keep:
- Coverage summary card
- KPIs/trend/buckets
- Daily fill histogram

## 4) MarketTracked becomes the Level 1–4 snapshot table

**File:** [frontend/src/pages/MarketTracked.tsx](frontend/src/pages/MarketTracked.tsx)

- Replace the current `/market-data/tracked` table with a `SortableTable` backed by the latest snapshot view:
- Prefer `MarketSnapshot` (one row per symbol, fast) via `GET /api/v1/market-data/technical/snapshots`.
- Columns should directly reflect your Level 1–4 list:
    - **Level 1**: SMA 5/14/21/50/100/150/200, EMA 8/21, ATR 14/30, range_pos 20d/50d/52w
    - **Level 2**: atrp_14/atrp_30, atrx_sma_21/50/100/150
    - **Level 3**: rs_mansfield_pct
    - **Level 4**: stage_label, stage_label_5d_ago
- Keep the page readable:
- Default columns visible: symbol, price, stage, RS, 52w range %, ATR%14, atrx_sma_50/150, sector/industry
- Extra columns available but still sortable.

## 5) Backend support

**File:** [backend/api/routes/market_data.py](backend/api/routes/market_data.py)

- Ensure `GET /technical/snapshots` returns the needed fields from `MarketSnapshot`.
- No changes needed for snapshot history backfill endpoint (already takes `days` and `since_date`).

## 6) Tests

### Frontend

- Update [frontend/src/pages/__tests__/AdminDashboardCoverageRefresh.test.tsx](frontend/src/pages/__tests__/AdminDashboardCoverageRefresh.test.tsx) to reflect the new period control and removal of 200d.
- Update/add MarketCoverage test to no longer expect the snapshots table.
- Add MarketTracked test verifying:
- it fetches snapshots and renders key Level 1–4 columns
- columns are sortable (at least one numeric + one string)

### Backend

- Keep existing coverage; add a small unit test for `/technical/snapshots` if not already covered.

## Validation