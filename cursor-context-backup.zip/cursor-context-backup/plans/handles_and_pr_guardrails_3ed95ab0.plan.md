---
name: Handles and PR Guardrails
overview: Update social handles to filefree.tax across the codebase, add a Cursor rule enforcing branch-based PR workflow, and install a pre-push git hook to prevent direct pushes to main.
todos:
  - id: social-handles
    content: Update social handles to filefree.tax in footer.tsx and social.mdc
    status: completed
  - id: cursor-rule
    content: Create .cursor/rules/git-workflow.mdc enforcing branch+PR workflow, update .cursorrules
    status: completed
  - id: pre-push-hook
    content: Create pre-push hook blocking direct pushes to main, install it, add infra/git-hooks/pre-push
    status: completed
  - id: makefile-hooks
    content: Add make setup-hooks target to Makefile
    status: completed
isProject: false
---

# Social Handles + PR Guardrails

## 1. Social Handles: Standardize to `filefree.tax`

Update handles to match what was actually claimed:

- **TikTok**: `@filefree.tax` (confirmed via tiktok.com/@filefree.tax)
- **Instagram**: `filefree.tax` (confirmed via instagram.com/filefree.tax)
- **X**: `@filefreetax` (confirmed, X doesn't allow dots)
- **YouTube**: `@FileFreeTax` (confirmed via youtube.com/@FileFreeTax)

**Files to update:**

- [web/src/components/landing/footer.tsx](web/src/components/landing/footer.tsx) -- update TikTok URL from `tiktok.com/@filefree` to `tiktok.com/@filefree.tax`, YouTube from `youtube.com/@FileFree` to `youtube.com/@FileFreeTax`
- [.cursor/rules/social.mdc](.cursor/rules/social.mdc) -- document official handles, update hashtag section

## 2. Cursor Rule: Enforce PR Workflow

Create a new always-apply rule at `.cursor/rules/git-workflow.mdc` that instructs the AI to:

- **Never push directly to main** -- always create a feature branch
- **Branch naming**: `feat/short-desc`, `fix/short-desc`, `chore/short-desc`
- **Always create a PR** via `gh pr create` after pushing the feature branch
- **Never force push to main/master**
- This will be `alwaysApply: true` so it governs every coding session

Also update [.cursorrules](.cursorrules) to reference this new rule in the persona list comment block.

## 3. Git Pre-Push Hook: Block Direct Pushes to Main

Install `.git/hooks/pre-push` that rejects any push to `main` or `master` unless an env var override is set. This is a safety net independent of GitHub's branch protection (which requires Pro for private repos).

The hook script:

- Reads the remote ref being pushed
- If target branch is `main` or `master`, print an error and `exit 1`
- Allow override via `ALLOW_PUSH_TO_MAIN=1` for emergency hotfixes

Since `.git/hooks/` isn't tracked by git, also create a shareable copy at `infra/git-hooks/pre-push` and document in the Makefile how to install it (`make setup-hooks`).

## 4. Makefile: Add Hook Setup Command

Add a `setup-hooks` target to the root Makefile that symlinks `infra/git-hooks/pre-push` into `.git/hooks/pre-push`, so any contributor (or fresh clone) can run `make setup-hooks` once.