---
name: Render API schedule sync
overview: "Replace the triple-source schedule architecture (render.yaml + Celery Beat static + RedBeat Redis) with a single-source-of-truth model: schedules live in PostgreSQL, code seeds defaults from job_catalog.py, the Admin UI does full CRUD, and a Render API sync layer automatically creates/updates/deletes Render cron jobs to match the DB state."
todos:
  - id: db-model
    content: Create CronSchedule SQLAlchemy model + Alembic migration
    status: completed
  - id: config
    content: Add RENDER_API_KEY and RENDER_OWNER_ID to Settings
    status: completed
  - id: seed-script
    content: Create seed_schedules.py that inserts CATALOG defaults into cron_schedule table
    status: completed
  - id: render-sync-service
    content: Build RenderCronSyncService with Render REST API client (create/update/delete/suspend/resume cron jobs)
    status: completed
  - id: sync-script
    content: Create sync_render_crons.py CLI + update render.yaml preDeployCommand
    status: completed
  - id: rewrite-api
    content: Rewrite admin_scheduler.py routes to use CronSchedule DB model + sync on mutation
    status: completed
  - id: frontend-update
    content: "Update AdminSchedules.tsx: enable full CRUD, inline edit, sync status, sync button"
    status: completed
  - id: cleanup
    content: Remove RedBeat dep, schedule_metadata.py, static beat schedules, cron blocks from render.yaml, ENABLE_CELERY_BEAT/ENABLE_REDBEAT config
    status: completed
  - id: tests
    content: Add backend tests (model, sync service, API) + frontend tests (CRUD, sync button)
    status: completed
  - id: docs
    content: Update docs/MARKET_DATA.md with new schedule architecture and admin operations
    status: completed
isProject: false
---

# Unified Schedule Management via Render API Sync

## Problem

Schedules are defined in 3 places today, causing confusion and making UI CRUD pointless in production:

- `render.yaml` -- static cron job definitions (production truth)
- `celery_app.py` `ALL_STATIC_SCHEDULES` -- Python dicts (displayed in UI when Beat is off)
- RedBeat (Redis) -- CRUD target in dev, but disabled in production

The Admin Schedules page shows read-only entries in production because the real schedules live in render.yaml, which is code.

## Target Architecture

```mermaid
flowchart LR
    subgraph code [Code]
        Catalog["job_catalog.py\n(CATALOG defaults)"]
    end
    subgraph db [PostgreSQL]
        CronSchedule["cron_schedule table\n(source of truth)"]
    end
    subgraph api [Admin UI / API]
        CRUD["Create / Edit / Delete\nPause / Resume"]
    end
    subgraph render [Render.com]
        RenderCrons["Cron Job Services\n(execution layer)"]
    end
    
    Catalog -->|"seed on deploy\n(insert if missing)"| CronSchedule
    CRUD -->|"mutations"| CronSchedule
    CronSchedule -->|"Render REST API\n(sync on deploy + on mutation)"| RenderCrons
    RenderCrons -->|"python -m run_task"| Worker["Celery Worker"]
```



**Key principle**: Code defines defaults. DB stores state. UI mutates state. Render API is the execution layer that mirrors DB state.

## New Config

Add to [backend/config.py](backend/config.py):

```python
RENDER_API_KEY: Optional[str] = None
RENDER_OWNER_ID: Optional[str] = None
```

These get set as env vars on `axiomfolio-api` in Render Dashboard. The API key is created from Render Account Settings.

## Phase 1: DB Model + Migration

**New model** in [backend/models/market_data.py](backend/models/market_data.py):

```python
class CronSchedule(Base):
    __tablename__ = "cron_schedule"
    
    id = Column(String(100), primary_key=True)       # e.g. "admin_coverage_backfill"
    display_name = Column(String(200), nullable=False)
    group = Column(String(50), nullable=False)        # market_data | accounts
    task = Column(String(300), nullable=False)         # dotted task path
    description = Column(Text)
    cron = Column(String(100), nullable=False)         # 5-field cron expression
    timezone = Column(String(50), default="UTC")
    args_json = Column(JSON, default=list)
    kwargs_json = Column(JSON, default=dict)
    enabled = Column(Boolean, default=True)
    
    # Safety
    timeout_s = Column(Integer, default=3600)
    singleflight = Column(Boolean, default=True)
    
    # Render integration
    render_service_id = Column(String(100))            # Render cron service ID
    render_synced_at = Column(DateTime(timezone=True))
    render_sync_error = Column(Text)
    
    # Audit
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    created_by = Column(String(200))
```

**Alembic migration**: Standard `alembic revision --autogenerate -m "add cron_schedule table"`.

## Phase 2: Seed Script

**New file**: `backend/scripts/seed_schedules.py`

- Reads all entries from `CATALOG` in [backend/tasks/job_catalog.py](backend/tasks/job_catalog.py)
- For each `JobTemplate`: if no `CronSchedule` row with that `id` exists, insert one with the default cron/task/args
- Idempotent -- safe to run on every deploy
- Logs: `"Seeded N new schedules, M already existed"`

This replaces `seed_redbeat_if_empty()`.

## Phase 3: Render API Sync Service

**New file**: `backend/services/render_sync_service.py`

Core class `RenderCronSyncService` with methods:

- `list_render_crons()` -- `GET /v1/services?type=cron_job&ownerId={RENDER_OWNER_ID}`, filter by name prefix or tag
- `create_render_cron(schedule: CronSchedule)` -- `POST /v1/services` with type `cron_job`, Docker config, env vars from `os.environ`, returns service ID
- `update_render_cron(schedule: CronSchedule)` -- `PATCH /v1/services/{render_service_id}` to update schedule/command
- `delete_render_cron(service_id: str)` -- `DELETE /v1/services/{service_id}`
- `suspend_render_cron(service_id: str)` -- `POST /v1/services/{service_id}/suspend`
- `resume_render_cron(service_id: str)` -- `POST /v1/services/{service_id}/resume`
- `sync_all(db: Session)` -- The main diff-and-reconcile loop:
  1. Read all `CronSchedule` rows from DB
  2. List all Render cron jobs via API
  3. Match by `render_service_id` or by name
  4. **Create** new cron jobs for DB rows without a Render match
  5. **Update** existing cron jobs where schedule/command changed
  6. **Delete** Render cron jobs that have no matching DB row (with safety: only delete jobs whose name matches the app prefix)
  7. **Suspend/Resume** based on `enabled` flag
  8. Store `render_service_id` and `render_synced_at` back to DB

**Docker config for all cron jobs** (standardized):

```python
{
    "type": "cron_job",
    "name": schedule.id,
    "ownerId": settings.RENDER_OWNER_ID,
    "plan": "starter",
    "region": "oregon",
    "schedule": schedule.cron,
    "runtime": "docker",
    "dockerDetails": {
        "dockerfilePath": "./Dockerfile.backend",
        "dockerCommand": f"python -m backend.scripts.run_task {schedule.task}"
    },
    "repo": "<repo-url>",
    "envVars": _collect_cron_env_vars()  # reads from os.environ
}
```

**Env vars for cron jobs** (collected from the running process):

- `ENVIRONMENT`, `DATABASE_URL`, `REDIS_URL`, `CELERY_BROKER_URL`, `CELERY_RESULT_BACKEND`
- Plus `FMP_API_KEY` if set (needed by some market data tasks)

**Failure handling**:

- Each sync operation is wrapped in try/except; failures are logged and stored in `render_sync_error`
- Partial failures don't block other schedules from syncing
- The sync returns a summary: `{"created": N, "updated": N, "deleted": N, "errors": N}`

## Phase 4: Sync Script (CLI)

**New file**: `backend/scripts/sync_render_crons.py`

```python
if __name__ == "__main__":
    db = SessionLocal()
    service = RenderCronSyncService()
    result = service.sync_all(db)
    print(json.dumps(result))
    db.close()
```

**Updated pre-deploy command** in [render.yaml](render.yaml):

```yaml
preDeployCommand: >
  alembic -c backend/alembic.ini upgrade head &&
  python -m backend.scripts.seed_schedules &&
  python -m backend.scripts.sync_render_crons
```

This means: on every deploy, DB schema is updated, new catalog entries are seeded, and Render cron jobs are synced to match.

## Phase 5: Rewrite Admin Scheduler API

Rewrite [backend/api/routes/admin_scheduler.py](backend/api/routes/admin_scheduler.py) to operate on the `CronSchedule` DB model instead of RedBeat:

- `**GET /admin/schedules**` -- Query `CronSchedule` table, join with `JobRun` for last-run info, return with render sync status
- `**POST /admin/schedules**` -- Insert `CronSchedule` row, then call `RenderCronSyncService.sync_one()` to create the Render cron job immediately
- `**PUT /admin/schedules/{id}**` -- Update DB row (cron, timezone, enabled, kwargs), then sync to Render
- `**DELETE /admin/schedules/{id}**` -- Delete Render cron job via API, then delete DB row
- `**POST /admin/schedules/{id}/pause**` -- Set `enabled=False`, suspend Render cron job
- `**POST /admin/schedules/{id}/resume**` -- Set `enabled=True`, resume Render cron job
- `**POST /admin/schedules/sync**` -- Manual full sync (admin button)
- Keep `**POST /admin/schedules/run-now**` -- Still enqueues via Celery (unchanged)
- Keep `**GET /admin/schedules/preview**` -- Cron preview (unchanged)

**Remove**: All RedBeat-specific code (`_read_redbeat_entries`, pause/resume via Redis, export/import via RedBeat).

## Phase 6: Frontend Updates

Update [frontend/src/pages/AdminSchedules.tsx](frontend/src/pages/AdminSchedules.tsx):

- **Full CRUD enabled for all schedules** -- no more read-only items
- **Inline edit**: Click on cron expression to edit in-place, save calls `PUT /admin/schedules/{id}`
- **Sync status column**: Show green checkmark (synced), yellow clock (pending), red X (error) based on `render_synced_at` and `render_sync_error`
- **"Sync to Render" button**: Calls `POST /admin/schedules/sync`, shows summary toast
- **Remove**: Source badges ("Infra (Render)", "RedBeat", "Static") -- there's only one source now
- **Update**: Mode badge to show "DB + Render" instead of "Static" or "RedBeat"
- **New schedule dialog**: Populate task dropdown from `GET /admin/tasks/catalog` instead of free-text input

## Phase 7: Cleanup

- **render.yaml**: Remove all 5 `type: cron` blocks. Keep only: `axiomfolio-api`, `axiomfolio-worker`, `axiomfolio-frontend`, `axiomfolio-redis`, `axiomfolio-db`
- **Remove** `ENABLE_CELERY_BEAT` and `ENABLE_REDBEAT` from config and render.yaml env vars
- **Remove** RedBeat dependency from `requirements.txt` / `pyproject.toml`
- **Remove** `backend/tasks/schedule_metadata.py` (Redis-based metadata storage)
- **Remove** `seed_redbeat_if_empty()` from `job_catalog.py`
- **Simplify** `celery_app.py`: Remove `ALL_STATIC_SCHEDULES`, `ACCOUNT_BEAT_SCHEDULE`, `MARKET_DATA_BEAT_SCHEDULE` -- no longer needed
- **Update** `AdminRunbook.tsx` references to schedules

## Phase 8: Tests

**Backend tests:**

- `test_cron_schedule_model.py` -- CRUD on `CronSchedule` model
- `test_render_sync_service.py` -- Mock Render API responses, test sync logic (create/update/delete/suspend/resume)
- `test_admin_scheduler_api.py` -- Test new DB-backed endpoints
- `test_seed_schedules.py` -- Test idempotent seeding from catalog

**Frontend tests:**

- Update `AdminSchedules` tests for new CRUD flow and sync button

## Acceptance Criteria

- Admin Schedules page shows all 10 catalog jobs with full CRUD (edit cron, pause, resume, delete, create new)
- Changing a schedule in the UI immediately syncs to Render (visible in Render Dashboard)
- `render.yaml` has zero `type: cron` entries
- Pre-deploy automatically seeds new catalog entries and syncs to Render
- Deleting a schedule from the UI deletes the Render cron job
- Pausing a schedule suspends the Render cron job (stops executing)
- No RedBeat dependency in production
- Local dev: schedules are viewable/editable in UI, "Run Now" works via Celery, Render sync is skipped when `RENDER_API_KEY` is not set

## Rollback

- If Render API sync fails, schedules still exist in DB -- the cron jobs just don't get created/updated
- The `render_sync_error` column captures what went wrong
- Admin can re-trigger sync via "Sync to Render" button
- Worst case: manually create cron jobs in Render Dashboard (same as today)
- To revert the entire feature: restore the cron blocks in render.yaml, re-enable RedBeat

## Observability

- Sync script logs: `render.sync.created`, `render.sync.updated`, `render.sync.deleted`, `render.sync.errors`
- Each schedule row has `render_synced_at` timestamp visible in UI
- `render_sync_error` shown as tooltip on error badge in UI

