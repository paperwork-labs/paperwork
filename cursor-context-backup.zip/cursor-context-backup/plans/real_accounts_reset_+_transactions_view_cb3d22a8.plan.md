---
name: Real accounts reset + transactions view
overview: Wipe sandbox data and start fresh for real Plaid connections under sankalp404@gmail.com, rename the dev DB to jointly_dev, and add a read-only Transactions page that groups transactions by day and category.
todos:
  - id: rename-db
    content: Change DB_NAME in infra/env.dev.example to jointly_dev and update local env.dev accordingly.
    status: completed
  - id: reset-stack
    content: Run down-reset/up and apply migrations to reinitialize DB for the new DB_NAME.
    status: completed
    dependencies:
      - rename-db
  - id: transactions-page
    content: Implement an All Transactions web page grouped by day and category, and add a navbar link.
    status: completed
    dependencies:
      - reset-stack
---

# Real accounts reset + DB rename + Transactions page

## Goals
- Start clean for real accounts: remove sandbox-linked items and reset local DB state.
- Rename local DB from `moneyapp_dev` → `jointly_dev` (cleaner naming).
- Add a Web page that shows **all transactions** in date order, grouped by category per day.

## Changes

### 1) Rename DB_NAME to jointly_dev
- Update `[infra/env.dev.example](/Users/sankalpsharma/development/jointly/infra/env.dev.example)` to use:
  - `DB_NAME=jointly_dev`
- Your local `infra/env.dev` is gitignored; we’ll update it locally too.

### 2) Wipe sandbox data and restart stack cleanly
- Use the reset target so Postgres/Redis volumes are recreated:
  - `make down-reset`
  - `make up`
- Re-run migrations inside the backend container so tables exist.

### 3) Web: add an All Transactions view
- Add a new page (or update existing) that:
  - Fetches `/transactions` and `/categories`
  - Sorts by `date_posted` descending
  - Groups by day, then by category name
  - Renders sections like:
    - `2025-12-05`
      - `Food (3)`
      - `Childcare (2)`
- Add a navbar link (e.g. `Transactions`) so it’s discoverable.

## Files to change
- Config:
  - `[infra/env.dev.example](/Users/sankalpsharma/development/jointly/infra/env.dev.example)`
  - (local only) `infra/env.dev` (gitignored)
- Web UI:
  - `[web/app/layout.js](/Users/sankalpsharma/development/jointly/web/app/layout.js)` (add link)
  - New page under `web/app/transactions/` (server component)

## Execution / validation
- After reset:
  - Confirm `http://localhost:1814/health` returns `{"ok":true}`
  - Log in as `sankalp404@gmail.com`
  - Connect real accounts via Plaid
  - Confirm the new Transactions page renders grouped results.