---
name: foundational-setup
overview: Set up a Next.js + Vercel + Neon base with Google OAuth, Prisma schema, and initial Doorvest agent plumbing for private access.
todos:
  - id: landing-page
    content: Design/build landing page at /
    status: completed
  - id: dx-shortcuts
    content: Add Makefile/npm shortcuts for docker-compose
    status: completed
---

# Landing + Dev UX Plan

## Goals

- Add a polished personal landing page at `/` that feels like your site (hero, bio, resume, highlights, "Now" strip, family teaser, sign-in CTA, Phase 2/3 roadmap blurb).
- Add Makefile/NPM shortcuts for docker-compose (up/down/logs/rebuild) and document them for quick use.

## Scope

- No backend changes; keep existing auth/dashboard as-is.
- Pure UI/content for landing, plus DX helpers.

## Implementation outline

- Landing structure: hero (name/tagline), quick bio + resume link, highlights grid (work/projects/writing), "Now" strip (status bullets), small family/personal gallery teaser, Phase 2/3 roadmap blurb, and a clear “Sign in” button to the private app.
- Theming: clean, minimal, with room for future posts/gallery.
- DX: Makefile targets (up/down/logs/rebuild), npm scripts mirror, README snippet update.