---
name: PDF Loom Link + Expansion
overview: Add the Loom video link to the PDF header and insert one sentence in "The Company" section acknowledging the existing OpenAI-Discord relationship, reframing the proposal as an account expansion.
todos:
  - id: add-loom-link
    content: Add Loom video URL to the PDF header area below the subtitle
    status: completed
  - id: add-partnership-caveat
    content: Add one sentence to The Company section acknowledging existing OpenAI-Discord relationship and framing as expansion
    status: completed
  - id: verify-layout
    content: Verify the PDF still fits cleanly on 2 pages after the additions
    status: completed
isProject: false
---

# Add Loom Link and Existing Partnership Caveat to PDF

Two targeted edits to [discord-openai-proposal.html](olgaSharma/discord-openai-proposal.html):

## 1. Add Loom link to header (line 240)

Add a small line below the existing subtitle with the Loom URL. Keep it understated so it doesn't compete with the title.

Current:

```html
<div class="header-subtitle">Olga Klinger&ensp;&bull;&ensp;Account Director, Digital Native Large Enterprise&ensp;&bull;&ensp;March 2026</div>
```

New (add a second line below):

```html
<div class="header-subtitle">Olga Klinger&ensp;&bull;&ensp;Account Director, Digital Native Large Enterprise&ensp;&bull;&ensp;March 2026</div>
<div class="header-subtitle" style="margin-top: 2px; font-size: 9pt;">Video walkthrough: <a href="https://www.loom.com/share/38db63930f3b494d9dc980d4ca086273" style="color: #555;">loom.com/share/38db63930f3b494d9dc980d4ca086273</a></div>
```

## 2. Add existing partnership acknowledgment (line 249-250)

Insert one sentence at the end of "The Company" paragraph, after "AI is the key." This reframes from "new sale" to "account expansion" without disrupting the flow or adding significant length.

Current ending:

```
...enterprise adoption is its next frontier. AI is the key.
```

New ending:

```
...enterprise adoption is its next frontier. AI is the key. Discord already
uses OpenAI for Clyde and AutoMod AI. This proposal expands that foundation
into untapped territory: voice intelligence, semantic search, and community analytics.
```

This adds ~25 words total. The 2-page layout should absorb it easily.

## Re-generate the docx

After editing the HTML, re-run pandoc on the loom-talking-points.md to regenerate the docx (no changes needed to the markdown itself for this update).