---
name: Brand Identity Rollout
overview: Update the brand color palette in the Chakra theme, replace old logo references with new star mark, update favicon, and refresh Ladle stories to reflect the new AxiomFolio brand identity.
todos:
  - id: update-brand-scale
    content: "Replace brand color ramp in system.ts with new palette anchored on #1D4ED8/#60A5FA"
    status: completed
  - id: add-semantic-tokens
    content: Add status semantic tokens (success/warning/danger/info) and update bg.canvas values
    status: completed
  - id: fix-hardcoded-colors
    content: "Replace hardcoded #2A79F0 in Login.tsx, Register.tsx, AuthLayout.tsx with token references"
    status: completed
  - id: wire-logo
    content: Import and render new star logo SVGs in DashboardLayout (3 locations)
    status: completed
  - id: update-favicon
    content: Copy icon SVG to public/favicon.svg and update index.html
    status: completed
  - id: update-stories
    content: Update Brand.stories.tsx and Tokens.stories.tsx with new logo and palette
    status: completed
  - id: update-readme
    content: Add full production palette and accessibility docs to logos README.md
    status: completed
isProject: false
---

# AxiomFolio Brand Identity Rollout

## Context

The new brand identity is locked: 4-point star icon (r=11 petals) with amber center dot, Inter semibold wordmark, and a research-validated accessible color palette. The existing theme at [frontend/src/theme/system.ts](frontend/src/theme/system.ts) still uses the old `#2A79F0` brand scale and several files hardcode that color.

## 1. Update brand color scale in theme

Replace the entire `brand` color ramp in [frontend/src/theme/system.ts](frontend/src/theme/system.ts) (lines 47-57) with the new palette anchored on `#1D4ED8` (light primary) and `#60A5FA` (dark primary):

```
brand.50  → #EFF6FF
brand.100 → #DBEAFE
brand.200 → #BFDBFE
brand.300 → #93C5FD
brand.400 → #60A5FA   (dark-mode primary)
brand.500 → #3B82F6   (secondary)
brand.600 → #2563EB   (brand.secondary)
brand.700 → #1D4ED8   (light-mode primary)
brand.800 → #1E40AF
brand.900 → #1E3A8A
```

Update `focusRing` (line 60) to `rgba(29,78,216,0.22)`.

## 2. Add new semantic tokens for palette

Add these missing semantic tokens to [frontend/src/theme/system.ts](frontend/src/theme/system.ts):

- `status.success` light `#16A34A` / dark `#34D399`
- `status.warning` light `#D97706` / dark `#F59E0B`
- `status.danger` light `#DC2626` / dark `#F87171`
- `status.info` light `#0EA5E9` / dark `#38BDF8`

Update `bg.canvas` light from `#F6F7FB` to `#F8FAFC` and dark from `#070B12` to `#0F172A` to match the approved palette.

## 3. Replace hardcoded old brand color

Files with hardcoded `#2A79F0` or its rgba equivalent:

- [frontend/src/pages/Login.tsx](frontend/src/pages/Login.tsx) line 95 → use `brand.700`
- [frontend/src/pages/Register.tsx](frontend/src/pages/Register.tsx) line 84 → use `brand.700`
- [frontend/src/components/layout/AuthLayout.tsx](frontend/src/components/layout/AuthLayout.tsx) line 21 → update rgba to new brand color

## 4. Wire new logo into DashboardLayout

[frontend/src/components/layout/DashboardLayout.tsx](frontend/src/components/layout/DashboardLayout.tsx) currently uses a placeholder colored box with "A". Replace in all 3 locations (desktop sidebar ~L372, mobile drawer ~L436, collapsed header ~L468) with:

- Import `axiomfolio-icon-star.svg` for collapsed/mobile views
- Import `axiomfolio-lockup.svg` for expanded sidebar view

## 5. Update favicon

[frontend/index.html](frontend/index.html) line 6 still uses default Vite favicon. Copy `axiomfolio-icon-star.svg` to `frontend/public/favicon.svg` and update the link tag.

## 6. Update Ladle brand stories

- [frontend/src/stories/Brand.stories.tsx](frontend/src/stories/Brand.stories.tsx) — replace import of old `axiomfolio.svg` with new `axiomfolio-lockup.svg`, update palette swatches to show new colors
- [frontend/src/stories/Tokens.stories.tsx](frontend/src/stories/Tokens.stories.tsx) — update brand token references to reflect new scale

## 7. Update logo README with palette section

Add the full production palette (light/dark tokens, accessibility contrast ratios, border token guidance, color-blind usage rules) to [frontend/src/assets/logos/README.md](frontend/src/assets/logos/README.md).

## Files changed (summary)

- `frontend/src/theme/system.ts` — brand scale, focusRing, semantic tokens, bg.canvas
- `frontend/src/components/layout/DashboardLayout.tsx` — logo swap (3 locations)
- `frontend/src/pages/Login.tsx` — remove hardcoded color
- `frontend/src/pages/Register.tsx` — remove hardcoded color
- `frontend/src/components/layout/AuthLayout.tsx` — update gradient rgba
- `frontend/index.html` — favicon
- `frontend/src/stories/Brand.stories.tsx` — new logo + palette
- `frontend/src/stories/Tokens.stories.tsx` — updated swatches
- `frontend/src/assets/logos/README.md` — palette docs
- `frontend/public/favicon.svg` — new file (copy of icon)

