---
name: Filing Strategy + Brand Update
overview: "Comprehensive update to PRD.md, VENTURE_MASTER_PLAN.md, TASKS.md, 6 persona files (.mdc), and Slack/agent infrastructure to: (1) replace factually incorrect filing submission model with State Filing Engine architecture, (2) expand Distill from tax-only B2B to umbrella B2B brand covering tax + formation + compliance APIs, (3) update personas and agent flows to reflect new brand/product scope, (4) fix 23 identified loose ends and cross-doc contradictions."
todos:
  - id: vmp-filing-engine
    content: "VMP: Replace 'Submit LLC Reality Check' (lines 3675-3688) with State Filing Engine architecture. Fix line 3647. Update LaunchFree Free Framing (line 874)."
    status: completed
  - id: vmp-distill-expand
    content: "VMP: Expand Distill (Section 1C) to B2B umbrella brand. Add Formation API + Compliance API product lines. Add brand architecture section."
    status: completed
  - id: vmp-entity-refs
    content: "VMP: Fix domain list (add distill.tax), DBA list (add Distill), legal footer, portfolio page, subsidiary structure. Add CorpNet context. Add Delaware ICIS. Add Formation API revenue."
    status: completed
  - id: vmp-slack-agents
    content: "VMP: Update Section 12 Slack channels (add #filing-engine). Update email aliases (add distill.tax). Update agent roster (Compliance Monitor covers filing engine health). Update Section 6 agent table."
    status: completed
  - id: prd-filing-engine
    content: "PRD: Replace Section 3.4 with State Filing Engine. Update line 285. Add filing engine data models, API endpoints, infrastructure entries, port map."
    status: completed
  - id: prd-distill-expand
    content: "PRD: Expand Distill section to umbrella brand. Update product table. Add brand architecture section. Add Distill palette. Add Formation API revenue stream."
    status: completed
  - id: tasks-filing-engine
    content: "TASKS: Add State Filing Engine tasks (P3.4a-h) to Phase 3 with full specs. Update Phase 3 scope note. Add DCIS/Stripe Issuing/formationapi.com to background tasks."
    status: completed
  - id: tasks-distill-formation
    content: "TASKS: Add Distill Formation API tasks to Phase 9 or new phase. Fix port map."
    status: completed
  - id: personas-update
    content: "Update 6 persona files: partnerships.mdc (add LaunchFree/Distill partners, venture-wide scope), legal.mdc (add UPL, FTC Free, DPA, formation disclaimers), agent-ops.mdc (add Distill, Filing Engine routing), workflows.mdc (add formation ops, Distill onboarding workflows), engineering.mdc (State Filing Engine, Distill umbrella), ea.mdc (filing engine health in briefing, new Slack channels)."
    status: completed
  - id: consistency-sweep
    content: "Cross-doc consistency sweep: verify all 17 checkpoints (state counts, Distill scope, domains, DBAs, footer, portfolio, filing model, ports, revenue, brand arch, Phase 3 scope, CorpNet, ICIS, persona titles, Slack channels, email aliases, agent roster)."
    status: completed
  - id: reality-check
    content: "Reality-check pass: verify all numbers are sourced/caveated. Flag estimates vs confirmed data. Ensure no hallucinated stats (state counts, pricing, revenue, market size)."
    status: completed
isProject: false
---

# Filing Strategy + Distill Brand Architecture Update

## Scope

Three files, 17 identified loose ends across three categories: factual corrections, Distill brand expansion, and infrastructure gaps.

## Source of Truth Order

Edit VMP first (source of truth), then PRD (product spec), then TASKS (execution plan). Cross-doc consistency sweep at the end.

---

## 1. VENTURE_MASTER_PLAN.md Updates

### 1A. Fix "Submit LLC Reality Check" (lines 3675-3688)

Replace the incorrect state filing table and "Honest UX" paragraph with the researched **State Filing Engine** architecture:

- Correct state counts: ~48/50 states have online filing portals, ~2 are mail-only (Maine + possibly 1 other)
- Three-tier filing approach:
  - Tier 1: State APIs (Delaware ICIS confirmed, others TBD)
  - Tier 2: Portal automation (Playwright, ~45 states)
  - Tier 3: Print-and-mail (Lob API, 2-3 states)
- Payment orchestration via Stripe Issuing (virtual cards per transaction, ~$0.24/filing)
- RA filing paths bypass anti-bot (authorized agent access)
- Bottleneck analysis: payment orchestration (critical), portal fragility (high), anti-bot (medium, solved by RA), state quirks (medium), verification (medium)
- Updated "Honest UX": LaunchFree files your LLC with the state on your behalf

Also update **line 3647** — remove "submit LLC step is hand-waved" and note State Filing Engine scope.

### 1B. Fix "LaunchFree Free Framing" (line 874)

Change "LLC formation filing (prep + submit)" to "LLC formation filing (document preparation + state submission)" — reflects that we actually submit.

### 1C. Expand Distill to B2B Umbrella Brand

Update Section 1C (lines 1028-1085) to redefine Distill as the **B2B umbrella brand** for all compliance automation:

**Current scope:** B2B tax automation for CPAs (SaaS + Tax API)
**New scope:** B2B compliance automation platform with three product lines:

- **Distill for CPAs** (SaaS dashboard at distill.tax, Phase 9) — unchanged
- **Distill Tax API** (api.distill.tax/tax, Year 2) — unchanged
- **Distill Formation API** (api.distill.tax/formation, Year 2-3) — NEW: per-filing pricing ($20-40/filing), powered by same State Filing Engine as LaunchFree
- **Distill Compliance API** (api.distill.tax/compliance, Year 3+) — NEW: annual reports, amendments, dissolutions

Add the brand architecture diagram:

```
Consumer: filefree.ai, launchfree.ai, tools.filefree.ai
B2B: Distill (distill.tax / api.distill.tax / docs.distill.tax)
Holding: paperworklabs.com
```

Add the Stripe/Twilio/Plaid precedent analysis (one B2B brand, multiple product lines).

### 1D. Fix Domain and Entity References

- **Line 26** (purchased domains): Add `distill.tax` to the list
- **Lines 22, 97** (DBA filings): Add "Distill" to DBA list: "FileFree", "LaunchFree", "Trinkets", and "Distill"
- **Line 70** (legal footer): Update to include Distill: "FileFree, LaunchFree, Trinkets, and Distill are products of Paperwork Labs LLC"
- **Line 1385** (portfolio page): Add Distill card alongside FileFree, LaunchFree, Trinkets
- **Line 109** ($50K+ revenue structure): Add "Distill LLC" as potential subsidiary alongside FileFree LLC and LaunchFree LLC

### 1E. Add Brand Architecture Section

Add a new subsection (after Section 0C trademarks or in Section 0B naming) that documents the full brand architecture:

- Consumer brands: own domains, own palettes, free products
- B2B brand: Distill, one platform, paid products
- Holding company: paperworklabs.com, corporate + command center
- Domain map with roles
- Why this architecture (Stripe/Twilio model, not Intuit model)

### 1F. Add Formation API Revenue to Financial Model

Update revenue sections to include Distill Formation API projections:

- Year 2: $15K-$60K (500-2K API filings @ $30 avg)
- Year 3: $150K-$600K (5K-20K API filings)
- Add to combined revenue scenarios

### 1G. CorpNet Context Update

Update line 844 (CorpNet partnership) to note CorpNet as BOTH RA wholesale partner AND formation API alternative (with pricing context: $69-79/filing wholesale, too expensive at $0 service fee, hence building our own State Filing Engine).

### 1H. Add Delaware ICIS to Infrastructure

Add DCIS credential application as a Phase 0/1 background task. Document:

- What ICIS PublicXMLService provides
- Requirements: DCIS ID, RA number, IP registration, sandbox testing
- Strategic value: gated credential, same-day filing, API reliability

---

## 2. PRD.md Updates

### 2A. Replace Section 3.4 "Submit LLC Reality Check" (lines 315-325)

Replace with "State Filing Engine" section matching VMP content but in PRD format:

- Corrected state counts
- Three-tier architecture (API / portal automation / mail)
- Payment orchestration (Stripe Issuing)
- Bottleneck summary
- Updated UX language

### 2B. Update Section 3.2 (line 285)

"LLC formation filing (prep + submit)" -> "LLC formation filing (document preparation + state submission via Filing Engine)"

### 2C. Expand Distill Section (lines 395-464)

Rewrite the Distill product section header and intro to reflect B2B umbrella brand. Add Formation API and Compliance API product lines with pricing, scope, and timeline. Keep existing CPA SaaS and Tax API content intact.

### 2D. Update Product Table (lines 24-32)

Change Distill row from "B2B tax automation platform for CPAs" to "B2B compliance automation platform. Tax, formation, and compliance APIs + CPA SaaS dashboard."

### 2E. Add Brand Architecture Section

New section in PRD (after product table or in architecture section):

- Consumer vs B2B brand split diagram
- Domain mapping table
- Distill umbrella explanation

### 2F. Add Distill Brand Palette

Add to Section 8.5 Brand Palettes (lines 661-684). Suggested: Deep blue / slate — professional, distinct from consumer palettes.

### 2G. Update Infrastructure Section (lines 891-901)

- Add Stripe Issuing for payment orchestration
- Add Playwright/automation compute (runs on existing Render or dedicated worker)
- Add distill.tax to DNS/Domains line
- Add Distill API backend to hosting table

### 2H. Update Port Map

Add `apps/distill` at 3005 (matches TASKS.md) and `apis/distill` (if separate from filefree API).

### 2I. Add Formation API Revenue Stream

Add to Section 7 revenue model:

- Formation API revenue stream (Year 2-3)
- Update combined projections table

### 2J. Add Filing Engine Data Models

Add to Section 9 data models:

- **FilingSubmission**: id, formation_id, state, tier (api/portal/mail), status (pending/submitting/submitted/confirmed/failed), filing_number, submitted_at, confirmed_at, screenshots (JSONB), error_log
- **StatePortalConfig**: state_code, portal_url, filing_method_tier, field_mappings (JSONB), fee_schedule (JSONB), captcha_type, ra_login_path, last_health_check, health_status

### 2K. Add Filing Engine API Endpoints

Add to Section 10 API design:

- `POST /api/v1/formations/{id}/submit` -- trigger state filing
- `GET /api/v1/formations/{id}/submission-status` -- check filing status
- `GET /api/v1/states/{code}/portal-health` -- state portal health check

### 2L. Add Distill Formation API Endpoints

Add to Section 10.3 or new Section 10.4:

- `POST /api/v1/pro/formations` -- create + submit formation (B2B)
- `GET /api/v1/pro/formations/{id}` -- check status
- `GET /api/v1/pro/states` -- available states and fees

---

## 3. TASKS.md Updates

### 3A. Add State Filing Engine Tasks to Phase 3

Insert new tasks in Phase 3 (LaunchFree MVP) section (after P3.4):

- **P3.4a**: State Filing Engine orchestrator (`apis/launchfree/services/filing_engine/`)
- **P3.4b**: Per-state portal configs (top 10 states: CA, TX, FL, DE, WY, NY, NV, IL, GA, WA)
- **P3.4c**: Delaware ICIS API integration (using DCIS credentials)
- **P3.4d**: Playwright automation scripts (top 10 states)
- **P3.4e**: Stripe Issuing integration (virtual cards for state fee payment)
- **P3.4f**: Filing status tracker + confirmation verification
- **P3.4g**: Portal health monitoring (daily automated checks)
- **P3.4h**: Manual fallback queue (for portal failures)

Each with full specs: acceptance criteria, branch name, files, dependencies.

### 3B. Update Phase 3 Scope Note

Remove "Most states do NOT have filing APIs" (line 420). Replace with State Filing Engine scope note. Update realistic timeline estimate (8-12 weeks may need to extend to 10-14 weeks with Filing Engine).

### 3C. Add Background Tasks

Add to Background Tasks section:

- **DCIS application** (Delaware Division of Corporations): Apply for ICIS API credentials. Owner: Founder 1. Timeline: Phase 0-1. Takes 2-4 weeks for approval.
- **formationapi.com**: Buy domain (~$12/yr) as redirect to distill.tax/formation. Defensive registration.
- **Stripe Issuing**: Apply for Stripe Issuing access (requires Stripe account verification). Timeline: before Phase 3.

### 3D. Expand Phase 9 or Add New Phase for Formation API

Add Distill Formation API tasks — either expand Phase 9 or create Phase 9.5:

- **P9.x**: Distill Formation API scaffold (api.distill.tax/formation)
- **P9.x**: B2B formation endpoint (uses LaunchFree's State Filing Engine)
- **P9.x**: B2B billing for formation (per-filing pricing)
- **P9.x**: API documentation (docs.distill.tax)
- **P9.x**: Partner onboarding flow

### 3E. Fix Port Map

Add `apps/distill | 3005` if not present. Add any new services.

---

## 4. VMP Slack + Agent Infrastructure Updates

### 4A. Update Slack Channel Structure (VMP Section 12, line 3890)

Add to channel table:

- `#filing-engine` | State Filing Engine health, submission status, portal failures | Filing Engine Monitor (n8n)

### 4B. Update Email Aliases (VMP Section 12, line 3933)

Add distill.tax aliases:

- [hello@distill.tax](mailto:hello@distill.tax) — General Distill inquiries
- [support@distill.tax](mailto:support@distill.tax) — Distill technical support
- [api@distill.tax](mailto:api@distill.tax) — API partner inquiries, developer support

### 4C. Update Agent Roster (VMP Section 6)

- **Compliance Monitor (#33)**: Add State Filing Engine health tracking to scope — portal health status, filing failure rates, state-specific issues
- **Partnership Intelligence (#34)**: Add formation API partner monitoring (FileForms, CorpNet program changes, new entrants)
- Add note about Filing Engine Monitor as a function within existing Infra Health Monitor or Compliance Monitor (not a new agent — keep agent count lean)

### 4D. Update n8n Workflow Table (VMP Section 6F)

Add planned workflows:

- `filing-engine-health` — Hourly health check of top 10 state portals, posts failures to #filing-engine
- `compliance-deadline-check` — Daily check for upcoming formation compliance deadlines (already mentioned in Compliance-as-a-Service section, ensure consistency)

---

## 5. Persona File Updates (6 files in .cursor/rules/)

### 5A. partnerships.mdc

- **Title**: Change "FileFree Partnerships Context" -> "Venture Partnerships Context"
- **Revenue Context**: Add LaunchFree revenue streams (RA credits, compliance SaaS, banking/payroll referrals from formation users)
- **Partnership Hit List**: Add LaunchFree-specific partners:
  - CorpNet — RA wholesale ($49/yr, negotiate better rate at volume)
  - Mercury / Relay / Novo — Business banking for newly formed LLCs ($25 RA credit per signup)
  - Gusto — Payroll for new businesses ($25 RA credit per signup)
  - Next Insurance — Business insurance ($15 RA credit per signup)
- **Partnership Hit List**: Add Distill-specific:
  - CPA associations — Distill SaaS distribution
  - Tax software vendors — Distill API integration partnerships
- **Positioning section**: Add LaunchFree pitch ("LaunchFree is a free LLC formation service...") and Distill pitch ("Distill is the compliance automation API...")
- **Tiered Strategy**: Add Phase 5 — B2B API Partners (formation API integrations for Distill)

### 5B. legal.mdc

- **Title**: Change "FileFree Legal & Compliance Context" -> "Venture Legal & Compliance Context"
- **Add section: UPL (Unauthorized Practice of Law)** — Formation content compliance:
  - LaunchFree provides BUSINESS FORMATION SERVICES, not LEGAL ADVICE
  - Never recommend a state ("you should form in Delaware")
  - Operating agreement = TEMPLATES, not AI-generated documents
  - Every formation page includes UPL disclaimer
- **Add section: FTC "Free" Compliance for LaunchFree**:
  - Never use "Free LLC" standalone — always "Free LLC Formation Service" or "$0 Service Fee"
  - State filing fees in same visual field as any "free" claim
  - RA credits: never "Free RA" — always "$49/yr, earn credits to reduce"
- **Add section: Distill B2B Legal**:
  - Data Processing Agreement (DPA) required for CPA firms
  - Multi-tenant data isolation (RLS, firm-scoped middleware)
  - No cross-product data usage without explicit consent
- **Add formation disclaimers** to "Disclaimers Required" section:
  - State data accuracy: "Filing fees and requirements sourced from state government websites. Verify with your state's Secretary of State before filing."
  - Formation disclaimer: "LaunchFree provides business formation services. We are not a law firm and do not provide legal advice."
- **Update Quality Gate**: Add LaunchFree and Distill checkpoints

### 5C. agent-ops.mdc

- **Line 9**: Change "FileFree/LaunchFree/Trinkets venture" -> "FileFree/LaunchFree/Distill/Trinkets venture"
- **Add Filing Engine model routing**: Portal automation (Playwright) doesn't use AI models. State data extraction (Phase 2) uses Gemini 2.5 Flash. Formation document generation uses GPT-4o-mini.
- **Add Distill B2B model routing**: CPA dashboard uses same models as FileFree. Formation API uses same Filing Engine (no AI models in critical path).

### 5D. workflows.mdc

- **Title**: Change "FileFree Workflow Playbooks" -> "Venture Workflow Playbooks"
- **Add Workflow 8: Formation Filing Operations**:

```
  Filing Engine submits -> state portal confirms/fails
  -> If fail: manual fallback queue -> staff submits within 4hrs -> script fix within 48hrs
  -> If confirm: update formation status, notify user, trigger compliance calendar
  

```

- **Add Workflow 9: State Data Refresh**:

```
  State Data Validator (n8n) flags stale data -> EA alerts founder
  -> Engineering updates state JSON config -> QA validates against state SOS website
  -> Deploy updated config
  

```

- **Add Workflow 10: Distill B2B Onboarding**:

```
  CPA signs up -> auto-provision firm account -> DPA acceptance flow
  -> Onboarding email sequence -> first upload guided walkthrough
  

```

### 5E. engineering.mdc

- **Add State Filing Engine** to Architecture Overview:
  - Three-tier architecture (API / portal automation / mail)
  - `packages/filing-engine/` shared between LaunchFree and Distill Formation API
  - Playwright automation worker infrastructure
  - Stripe Issuing for payment orchestration
- **Update Infrastructure section**: Add Stripe Issuing, Playwright workers, distill.tax
- **Add Distill umbrella brand** to code conventions: Distill API routes at `/api/v1/pro/`*
- **Update monorepo structure** if different from current description

### 5F. ea.mdc

- **Update daily briefing** to include:
  - Filing Engine health status (any portal failures overnight?)
  - Formation submission queue status (any stuck/failed submissions?)
  - Distill API health (if active)
- **Update Slack channel references**: Include #filing-engine in monitored channels
- **Add filing-engine-specific alerts** to escalation priorities

---

## 6. Reality-Check Pass

Before finalizing all edits, verify every number and claim:

- **State online filing count**: Use "nearly all 50 states" or "~48 states" — sourced from SmartLegalForms and multiple corroborating search results. Note: exact count varies by source and definition of "online filing." Some states have online portals but may require additional paper documents.
- **Delaware ICIS API**: Confirmed via Delaware state website (icis.corp.delaware.gov) and Diligent documentation. Requirements verified: DCIS ID, RA number, IP registration.
- **CorpNet wholesale pricing**: "20-30% off retail" from CorpNet partner FAQ page. Retail $99 (Basic). Wholesale estimated $69-79. Label as "based on partner program documentation."
- **FileForms wholesale pricing**: Estimated $30-60/filing from ROI calculator ($6K annual / est. 100-200 filings). Label as "estimated — contact for actual rates."
- **Stripe Issuing pricing**: Do NOT hardcode specific pricing ($0.10/card). Instead say "Stripe Issuing for programmatic virtual card creation (pricing per Stripe's current schedule)." Verify before Phase 3 implementation.
- **$0.30/filing marginal cost**: Label as "estimated blended marginal cost (virtual card fees + CAPTCHA solving + compute). Actual costs to be validated during Phase 3 development."
- **5.25M/year business applications**: From SBA press release (January 2025, 21M over 4 years). These are Census Bureau EIN APPLICATIONS, not completed entity formations. Many are sole proprietorships. Actual LLC/Corp formations estimated at ~2-3M/year. Use conservative language.
- **LegalZoom revenue**: Do NOT cite specific revenue figures ($600-700M) without a verified source from this session. Instead reference "LegalZoom (NYSE: LZ, public company)" and "dominant market position."
- **Formation API pricing ($20-40/filing)**: This is our PROPOSED wholesale price, not a market observation. Label as "target pricing, undercutting incumbent API providers."
- **Lob for print-and-mail**: Lob (lob.com) is a real print-and-mail API. Do not cite specific pricing without verification. Say "print-and-mail API service (e.g., Lob)."

---

## 7. Cross-Doc + Persona Consistency Sweep

After all edits, verify ALL of these (17 → 23 checkpoints):

**Docs (13):**

- State counts consistent across all 3 docs ("nearly all 50 states" online, ~2 mail-only)
- Distill scope consistent (B2B umbrella: tax + formation + compliance)
- Domain lists consistent (all include distill.tax)
- DBA list consistent (all include Distill)
- Legal footer consistent (all include Distill)
- Portfolio page consistent (all include Distill card)
- Filing model consistent ("we file for you via State Filing Engine")
- Port maps consistent between PRD and TASKS
- Revenue model includes Formation API stream
- Brand architecture section exists in both VMP and PRD
- Phase 3 scope reflects State Filing Engine
- CorpNet context updated (RA partner + formation API alternative)
- Delaware ICIS documented in architecture + background tasks

**Personas + Agent Infra (10):**

- All persona file titles say "Venture" not "FileFree" (partnerships, legal, workflows, engineering)
- agent-ops.mdc includes Distill in venture scope
- legal.mdc has UPL, FTC "Free", DPA, formation disclaimer sections
- partnerships.mdc has LaunchFree + Distill partner lists
- workflows.mdc has formation ops, state data refresh, Distill onboarding workflows
- engineering.mdc has State Filing Engine architecture
- ea.mdc has filing engine health in daily briefing
- Slack #filing-engine channel in VMP Section 12
- distill.tax email aliases in VMP Section 12
- Agent roster reflects Filing Engine monitoring scope

