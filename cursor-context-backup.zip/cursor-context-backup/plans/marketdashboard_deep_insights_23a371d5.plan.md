---
name: MarketDashboard Deep Insights
overview: Enhance the Market Dashboard with deeper, research-backed insights by surfacing unused indicators already in the DB, adding time-series breadth analysis, sector rotation visualization, and actionable signal detection.
todos:
  - id: action-queue
    content: Surface existing action_queue data in frontend (zero backend work)
    status: pending
  - id: range-histogram
    content: Add 52-week range distribution histogram (backend + frontend)
    status: pending
  - id: breadth-trend
    content: Compute breadth time series from MarketSnapshotHistory and render sparkline
    status: pending
  - id: rrg-sectors
    content: Build Relative Rotation Graph scatter for sector ETFs
    status: pending
  - id: earnings-proximity
    content: Surface upcoming earnings and fundamental leaders
    status: pending
  - id: td-sequential
    content: Filter and display actionable TD Sequential signals
    status: pending
  - id: rsi-divergence
    content: Detect and display RSI divergences
    status: pending
  - id: gap-analysis
    content: Surface symbols with notable unfilled gap counts
    status: pending
isProject: false
---

# Market Dashboard Deep Insights Enhancement

## What You Have But Don't Show

Your `MarketSnapshot` model already stores **50+ indicators per symbol** but the dashboard only uses ~15 of them. Here's what's sitting in the DB unused:

- **RSI, MACD, MACD Signal** — classic momentum/overbought-oversold
- **TD Sequential** — buy/sell setup/countdown signals (6 columns!)
- **Range position** — `range_pos_20d`, `range_pos_50d`, `range_pos_52w` (where in range)
- **Extended performance** — `perf_60d`, `perf_120d`, `perf_252d`, `perf_mtd`, `perf_qtd`, `perf_ytd`
- **Fundamentals** — `pe_ttm`, `peg_ttm`, `roe`, `eps_growth_yoy`, `revenue_growth_yoy`, `analyst_rating`
- **Earnings dates** — `next_earnings`, `last_earnings`
- **Gap counts** — `gaps_unfilled_up`, `gaps_unfilled_down`
- **Stage details** — `stage_slope_pct`, `stage_dist_pct`, `stage_label_5d_ago`
- **Trend counts** — `trend_up_count`, `trend_down_count`
- **Action queue** — already computed in `build_dashboard()` but never rendered on the frontend!

## Proposed Enhancements (Priority Order)

### 1. Market Breadth Over Time (High Impact)

Currently you show "% above 50DMA" and "% above 200DMA" as static numbers. The real power is the **trend** of breadth — is it expanding or contracting?

- **Backend**: Query `MarketSnapshotHistory` for the last 30-60 days, compute daily `above_sma50_pct` and `above_sma200_pct` time series
- **Frontend**: Render a small sparkline/area chart showing breadth trend
- **Insight**: A market making new highs while breadth narrows = divergence warning

### 2. Relative Rotation Graph (RRG) for Sectors (High Impact)

The gold standard for visualizing sector rotation. Each sector ETF is plotted on a 2D chart:

- **X-axis**: RS-Ratio (relative strength vs SPY, normalized)
- **Y-axis**: RS-Momentum (rate of change of RS-Ratio)
- This creates 4 quadrants: **Leading** (top-right), **Weakening** (bottom-right), **Lagging** (bottom-left), **Improving** (top-left)
- Sectors rotate clockwise through these quadrants
- **Backend**: Compute RS-Ratio and RS-Momentum from `rs_mansfield_pct` and its 5d change for each sector ETF, return as `rrg_sectors` in the dashboard payload
- **Frontend**: Scatter plot with quadrant labels showing each ETF as a labeled dot
- **Data available**: `rs_mansfield_pct` + `perf_5d` already in `MarketSnapshot` for all 14 sector ETFs

### 3. Surface the Action Queue (Easy Win)

The backend already computes `action_queue` (stage changes, large 1d moves, large RS moves) but the frontend never renders it.

- **Frontend only**: Add an "Alerts" or "Action Queue" card showing the top 20 notable events
- **Zero backend work needed**

### 4. Earnings Proximity & Fundamental Overlay

`next_earnings` and fundamentals (`pe_ttm`, `eps_growth_yoy`, etc.) are stored but hidden.

- **Backend**: Add `upcoming_earnings` list (symbols with earnings in next 7 days) and `fundamental_leaders` (top 10 by composite of EPS growth + RS)
- **Frontend**: "Upcoming Earnings" card + optionally a "Value x Momentum" quadrant (PE on one axis, momentum_score on the other)

### 5. RSI Divergence Detection (High Signal)

RSI is in the DB. Divergences (price new 20d high but RSI declining) are one of the most reliable warning signals.

- **Backend**: For each symbol in the tracked universe, compare current `perf_20d` direction vs `rsi` direction. Flag symbols where price is rising but RSI is falling (bearish divergence) or vice versa (bullish divergence)
- **Frontend**: "Divergence Watch" card with bearish/bullish lists

### 6. TD Sequential Signals (Already Computed)

Six TD Sequential columns are stored but completely unused:

- `td_buy_setup`, `td_sell_setup` (counts 1-9)
- `td_buy_countdown`, `td_sell_countdown` (counts 1-13)
- `td_perfect_buy`, `td_perfect_sell` (boolean)
- **Backend**: Filter for actionable signals (setup = 9, countdown = 13, or perfect signals)
- **Frontend**: "Sequential Signals" card listing symbols at exhaustion points

### 7. 52-Week Range Context

`range_pos_52w` (0.0 = 52w low, 1.0 = 52w high) is stored but unused.

- **Backend**: Add distribution histogram data (how many symbols are at 0-10%, 10-20%, etc. of their 52w range)
- **Frontend**: Small histogram showing where the market "lives" on the 52w range — skewed right = euphoria, skewed left = capitulation

### 8. Gap Analysis

`gaps_unfilled_up` and `gaps_unfilled_down` counts are stored.

- **Backend**: Surface symbols with the most unfilled gaps (potential magnets for price)
- **Frontend**: Small "Open Gaps" card

## Suggested Implementation Order


| Phase   | Items                                                     | Effort |
| ------- | --------------------------------------------------------- | ------ |
| Phase 1 | Action Queue (render existing data) + 52w Range Histogram | Small  |
| Phase 2 | Breadth Over Time + RRG Scatter                           | Medium |
| Phase 3 | Earnings + TD Sequential + RSI Divergences                | Medium |
| Phase 4 | Fundamental Overlay + Gap Analysis                        | Small  |


## Files Involved

- Backend: [backend/services/market/market_dashboard_service.py](backend/services/market/market_dashboard_service.py) — add new sections to `build_dashboard()`
- Frontend: [frontend/src/pages/MarketDashboard.tsx](frontend/src/pages/MarketDashboard.tsx) — new sub-components for each section
- Models (read-only): [backend/models/market_data.py](backend/models/market_data.py) — MarketSnapshot already has all needed columns

