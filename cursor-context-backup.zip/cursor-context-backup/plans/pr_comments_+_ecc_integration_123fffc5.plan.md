---
name: PR Comments + ECC Integration
overview: Address 20 Copilot PR comments across 7 files, then integrate selected patterns from the everything-claude-code (ECC) repo to improve agent infrastructure, verification loops, and operational reliability.
todos: []
isProject: false
---

# PR Comments Resolution + ECC Infrastructure Integration

## Part 1: PR Comment Fixes (7 files, ~20 comments)

### 1. `[.cursor/rules/ea.mdc](.cursor/rules/ea.mdc)` — 6 comments

- **Line 3**: Fix frontmatter — set `globs: []` or remove `globs:` key (null value may break Cursor rule loading)
- **Lines 26, 111, 135**: Replace all Discord references (`#ops-alerts`, slash command) with Slack — VMP standardizes on Slack. Route daily briefing to `#daily-briefing`, alerts to `#ops-alerts`
- **Line 67**: Change `sankalpsharma.com/docs/`* to `paperworklabs.com/docs/`* (company domain per VMP)

### 2. `[.cursor/rules/agent-ops.mdc](.cursor/rules/agent-ops.mdc)` — 1 comment

- **Line 3**: Fix frontmatter — set `globs: []` or remove `globs:` key

### 3. `[.cursor/rules/social.mdc](.cursor/rules/social.mdc)` — 2 comments

- **Line 12**: Reconcile filefree.tax vs filefree.ai — either (a) note "use filefree.tax until Phase 0 migration, then filefree.ai" or (b) align with current domain strategy (filefree.ai is canonical per brand.mdc). Add explicit migration-trigger note.

### 4. [docs/VENTURE_MASTER_PLAN.md](docs/VENTURE_MASTER_PLAN.md) — 5 comments

- **Line 1**: Fix source-of-truth note — either create `.cursor/plans/` with a stub or change to "This file is the venture source of truth" (no .cursor/plans reference)
- **Line 47**: Fix "TradmarkLens" typo to "TrademarkLens" (or correct source name)
- **Line 234**: Fix malformed Legal Risk Matrix table — close quoted string, add terminating `|` for the row
- **Lines 2384, 2404**: Resolve port swap — Port Map says trinkets=3003, studio=3004; Phase 1 tasks say the opposite. Pick one: use Port Map as source (trinkets 3003, studio 3004) and update Phase 1/Verify steps to match

### 5. [docs/KNOWLEDGE.md](docs/KNOWLEDGE.md) — 2 comments

- **Lines 324-325 (D36)**: D36 says "Wyoming LLC" but VMP/KNOWLEDGE D54 say California LLC. Mark D36 as superseded: "Superseded by D54 — California LLC (Paperwork Labs LLC)."

### 6. [docs/FINANCIALS.md](docs/FINANCIALS.md) — 2 comments

- **Line 61**: Fix double-count — Annual fixed costs should NOT double-count CA franchise tax. The $284/mo already includes ~$67/mo amortized. Clarify: "Annual fixed costs = $284/mo x 12 = $3,408 (includes amortized franchise tax)"
- **Line 92**: Reconcile Google Workspace — recurring says $12/mo (x2 seats), March actuals say $6. Either: (a) March reflects 1 seat (update actuals note) or (b) update recurring to match current spend

### 7. [docs/TASKS.md](docs/TASKS.md) — 5 comments

- **Line 1184**: Pre-Code Blockers — "Decide LLC name" is DONE; remove "2 weeks from now" or replace with completion date. Reflect Paperwork Labs LLC decision.
- **Line 1201 (Phase 0.7)**: Change `ops/social.sankalpsharma.com` to `ops.paperworklabs.com` and `social.paperworklabs.com`
- **Line 1276**: Phase 4 / Studio — change sankalpsharma.com references to paperworklabs.com
- **Line 1365**: TikTok Spark Ads — align with VMP: use `$100-300/mo max` (not $200-500)

---

## Part 2: Leveraging everything-claude-code (ECC)

[everything-claude-code](https://github.com/affaan-m/everything-claude-code) is an agent harness performance system (skills, hooks, commands, rules, verification loops). Paperwork Labs can adopt selected pieces without full installation.

### High-value adoptions (minimal friction)


| ECC component                  | Paperwork Labs use case                                        | Action                                                                                                                                               |
| ------------------------------ | -------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Verification loop**          | Pre-merge quality gate (tests, lint, typecheck, PII grep)      | Add `make verify` or `/verify`-style checklist to git-workflow.mdc; consider `quality-gate` skill pattern                                            |
| **Security scan**              | AgentShield scans .cursor configs for secrets, injection risks | Run `npx ecc-agentshield scan` in CI or pre-commit; document in qa.mdc                                                                               |
| **Rules structure**            | Python (api/) + TypeScript (web/) specific rules               | Add `.cursor/rules/python.mdc` and `.cursor/rules/typescript.mdc` with language-specific globs (or keep engineering.mdc as single source if simpler) |
| **Token optimization**         | Reduce cost for long sessions                                  | Document in agent-ops.mdc: `MAX_THINKING_TOKENS=10000`, `/compact` at milestones, model routing (Haiku for simple tasks)                             |
| **Pre-edit / post-edit hooks** | Auto-format, typecheck, secret detection on file edit          | ECC uses `afterFileEdit` → format + grep. We could add a Makefile target `make pre-commit` and reference in git-workflow                             |


### Medium-value (requires more setup)


| ECC component                 | Paperwork Labs use case                                      | Action                                                                                                                                                                       |
| ----------------------------- | ------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Skills (SKILL.md)**         | Reusable workflows for Filing Engine, OCR pipeline, tax calc | Create `.cursor/skills/` or `docs/skills/` with SKILL.md for: `filing-engine-health`, `tax-reconciliation`, `state-data-refresh` — invoked when agent works on those domains |
| **Continuous learning**       | Extract patterns from sessions into instincts/skills         | Defer — ECC's instinct system is complex; we already have KNOWLEDGE.md for decisions                                                                                         |
| **Multi-agent orchestration** | Planner → executor → reviewer                                | We have personas; ECC's `/multi-plan`, `/multi-execute` could inform workflows.mdc handoff chains                                                                            |


### Low-priority / out of scope

- Full ECC plugin install (adds 65 skills, 40 commands — overkill for our curated persona model)
- PM2 / multi-service commands (we use Makefile + Docker Compose)
- Claude Code–specific hooks (we use Cursor; ECC has Cursor adapters in `.cursor/`)

### Concrete next steps for ECC integration

1. **Add AgentShield to QA persona** — In [qa.mdc](.cursor/rules/qa.mdc), add: "Run `npx ecc-agentshield scan` before major config changes. Exit code 2 on critical findings."
2. **Add verification checklist to git-workflow** — In [git-workflow.mdc](.cursor/rules/git-workflow.mdc), add pre-merge verification: `make test && make lint && rg -i "ssn|\\d{3}-\\d{2}-\\d{4}" --type-add 'skip:!*.py' -g '!*test*' -g '!*mock*' || true` (PII grep as advisory)
3. **Document token / model routing in agent-ops** — Add section: "Use Haiku/Sonnet for routine edits; Opus for architecture. Compact at task milestones. See ECC Token Optimization if costs spike."
4. **Optional: Try ECC Cursor installer** — `git clone ... && ./install.sh --target cursor typescript python` to get rules only; evaluate if the common + language-specific rules add value over our current engineering.mdc

---

## Execution order

1. Fix PR comments (Part 1) — unblocks merge
2. Add AgentShield + verification + token notes (Part 2 high-value) — improves infra
3. Re-evaluate ECC skills/hooks after summer launch — once Distill APIs and agent-maintained ops are live

