---
name: BizFree Naming Strategy
overview: Growth + McKinsey-style naming analysis for the business formation product, evaluating brand family strategy, domain availability, and competitive positioning to select the strongest name and domain.
todos:
  - id: name-decision
    content: "Co-founder decision: pick final name (LaunchFree vs BizFree vs IncFree)"
    status: pending
  - id: domain-register
    content: Register chosen .ai domain immediately (and optionally .co / .app as defensive)
    status: pending
  - id: social-handles
    content: Secure social handles on TikTok, Instagram, X, YouTube for chosen name
    status: pending
  - id: filefree-priority
    content: "Continue FileFree Sprint 4 as priority #1 -- new product build starts after Sprint 4 completes (May/June 2026)"
    status: pending
isProject: false
---

# BizFree Product Naming: Growth + Strategy Assessment

## Strategic Framework: The "[X]Free" Brand Family

FileFree uses the pattern `[Verb]Free.[industry-TLD]`. This creates a powerful brand architecture:

- **FileFree** = "File [your taxes], Free" on `.tax`
- **[X]Free** = "[Action] [your business], Free" on `.ai` / `.co`

Building a brand family compounds equity. When someone already trusts FileFree, a sibling product with the same naming convention gets instant credibility. Future products (e.g., "BookFree" for bookkeeping) can join the family later.

**Growth take**: "Free" in the name IS the marketing. You never have to explain the value prop -- it's in the URL. Every ad, every TikTok caption, every word-of-mouth mention carries the message.

---

## Domain Availability Matrix (DNS-verified)


| Name            | .com                       | .ai   | .co   | .app  | .tax  |
| --------------- | -------------------------- | ----- | ----- | ----- | ----- |
| **LaunchFree**  | TAKEN                      | AVAIL | AVAIL | AVAIL | AVAIL |
| **BizFree**     | TAKEN                      | AVAIL | AVAIL | AVAIL | AVAIL |
| **IncFree**     | TAKEN                      | AVAIL | AVAIL | AVAIL | AVAIL |
| **FounderFree** | TAKEN                      | AVAIL | AVAIL | AVAIL | n/a   |
| **StartFree**   | TAKEN                      | AVAIL | n/a   | AVAIL | AVAIL |
| **FreeLaunch**  | **AVAIL**                  | AVAIL | AVAIL | n/a   | n/a   |
| FormFree        | TAKEN (active fintech co.) | TAKEN | AVAIL | AVAIL | AVAIL |


**FormFree is disqualified** -- it's an established mortgage lending company (FormFree.com, since 2003). Using any FormFree TLD risks trademark confusion and brand dilution.

---

## Tier 1 Recommendations (Ranked)

### 1. LaunchFree (launchfree.ai) -- TOP PICK

**Why it wins:**

- **Emotional resonance**: "Launch" is aspirational. Starting a business is a launch, a liftoff. It carries momentum and energy. "Biz" is bureaucratic by comparison.
- **Perfect brand pairing**: FileFree = file free. LaunchFree = launch free. The pattern clicks instantly.
- **Verb-action alignment**: "Launch your LLC" is how people think about it. Nobody says "biz my LLC."
- **Gen Z appeal**: "Launch" is TikTok energy. "Biz" is LinkedIn energy. Your audience is 22-35 first-time founders.
- **Future-proof**: "Launch" isn't limited to LLCs. It works for any business type, any formation, any future product expansion.
- **SEO**: "launch LLC free", "launch business free", "launch company free" are all natural search queries.
- **Tagline writes itself**: "Launch your business. Free." / "Ready to launch?" / "3 minutes to launch."

**Domain**: `launchfree.ai` (~$50-90/yr for .ai). The `.ai` TLD signals AI-powered, which is exactly what this product is. It mirrors the tech-forward positioning of filefree.tax using an industry-relevant TLD.

**Brand name**: LaunchFree (one word, camelCase capital L and F, matching FileFree convention).

**Social handles to secure**: @launchfree (TikTok, Instagram, X, YouTube).

---

### 2. IncFree (incfree.ai) -- STRONG ALTERNATIVE

**Why it works:**

- "Inc" is universally understood as business incorporation
- Short (7 chars), clean, professional
- Strong brand family pairing: FileFree, IncFree
- SEO: "incorporate free" is a high-intent search query

**Why it's #2:**

- "Inc" sounds more corporate/serious than "Launch" -- less emotional hook
- Could be confused with Inc. Magazine in organic search
- Limits perception to incorporation only (not compliance, RA, etc.)

**Domain**: `incfree.ai` (~$50-90/yr)

---

### 3. BizFree (bizfree.ai) -- VIABLE, USER'S ORIGINAL

**Why it works:**

- You already identified and like this name
- Short (7 chars), punchy, immediately clear
- Broadest scope -- "Biz" covers everything business-related
- bizfree.ai confirmed available

**Why it's #3:**

- "Biz" reads slightly informal/dated. It's a 1990s-internet abbreviation.
- Doesn't carry the aspirational energy of "Launch"
- Harder to build emotional marketing around ("Biz your business free" doesn't work as a tagline)
- Social handles: @bizfree may be taken on some platforms (common abbreviation)

**Domain**: `bizfree.ai` (~$50-90/yr)

---

## Honorable Mention: FreeLaunch (freelaunch.com)

**The .com wildcard**: `freelaunch.com` appears to be AVAILABLE, which is exceptionally rare for a two-word English domain. A .com domain carries inherent trust and SEO authority that no other TLD matches.

**Trade-off**: It breaks the `[X]Free` brand family pattern (puts "Free" first instead of last). This means less brand cohesion with FileFree, but you get a .com.

**Verdict**: If you value .com availability over brand family consistency, this is worth serious consideration. But the brand family strategy is more powerful long-term if you plan to launch more products.

---

## TLD Strategy Recommendation

Since .com is taken for all [X]Free candidates, the TLD choice matters:

- `**.ai`** (RECOMMENDED): Signals AI-powered product. Trendy, tech-forward. ~$50-90/yr. This is the market's current premium TLD for AI products. Users immediately understand "this is an AI tool."
- `**.co`**: Startup-friendly, established. ~$10-15/yr. Less distinctive than .ai.
- `**.app`**: Mobile-first signal. ~$15-20/yr. Google-owned, requires HTTPS.
- `**.tax`**: Only makes sense for FileFree (tax-specific). Doesn't fit business formation.

---

## Growth Persona Scoring


| Criteria                             | LaunchFree | IncFree   | BizFree   |
| ------------------------------------ | ---------- | --------- | --------- |
| Memorable (say it once, remember it) | 9/10       | 8/10      | 7/10      |
| Emotional hook                       | 9/10       | 5/10      | 6/10      |
| Brand family cohesion w/ FileFree    | 10/10      | 9/10      | 8/10      |
| Tagline / ad copy flexibility        | 10/10      | 7/10      | 6/10      |
| SEO keyword alignment                | 8/10       | 9/10      | 7/10      |
| Gen Z / young founder appeal         | 9/10       | 6/10      | 6/10      |
| Verbal shareability ("go to...")     | 9/10       | 8/10      | 8/10      |
| Scope flexibility (beyond LLC)       | 10/10      | 6/10      | 9/10      |
| **Total**                            | **74/80**  | **58/80** | **57/80** |


---

## Recommended Next Steps

1. **Decide on the name** -- LaunchFree is the recommendation, but BizFree or IncFree are viable if you prefer
2. **Register the domain immediately** -- .ai domains are getting snapped up fast. Register launchfree.ai (or your choice) today
3. **Secure social handles** -- @launchfree on TikTok, Instagram, X, YouTube before someone else does
4. **Optional: register backup TLDs** -- grab .co and .app as defensive registrations (~$25 total)
5. **Do NOT register .com** of the chosen name if it's parked/taken -- don't waste money trying to acquire it this early

---

## The "Free" Brand Family Vision

Looking ahead, this naming convention creates a portfolio:

- **FileFree** (.tax) -- Free tax filing
- **LaunchFree** (.ai) -- Free business formation
- **BookFree** (.ai) -- Free bookkeeping (future)
- **PayFree** (.ai) -- Free payroll (future, if ever)

Each product is the free acquisition channel. Each monetizes through financial product referrals. The "Free" brand becomes the moat.