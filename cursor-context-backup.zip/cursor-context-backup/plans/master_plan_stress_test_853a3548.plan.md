---
name: Master Plan Stress Test
overview: "Comprehensive self-review, critique, and structural improvements to the Venture Master Plan based on four-angle stress testing: strategic gaps, task detail parity, agent architecture realism, and legal/revenue risks."
todos:
  - id: critical-pre-code
    content: "Add pre-code actions to master plan: cyber insurance, breach response plan, attorney consultation, LLC name deadline, EFIN application urgency. These block everything."
    status: completed
  - id: user-acquisition
    content: "Add Section 5K: User Acquisition Strategy with CAC model, channel projections, paid budget, pre-launch audience building. Currently the biggest strategic gap."
    status: completed
  - id: partnership-contingency
    content: Add Plan B revenue scenario and partnership milestone deadlines. Model revenue with ZERO partnerships closed.
    status: completed
  - id: realistic-timeline
    content: Add realistic timeline column to Phase table. Identify critical path. Fix MeF transmitter start date (June, not January). Address LaunchFree 'submit' hand-wave.
    status: completed
  - id: agent-right-sizing
    content: Reduce agent count from 43 to ~18-20. Add build triggers. Split EA into interactive persona + ops monitor. Resolve persona overlaps (CFO/EA, Strategy/EA).
    status: completed
  - id: legal-gaps
    content: Add 50-state data accuracy disclaimers, FTC-safe 'free' language rules, UPL-safe operating agreement strategy (templates not generation), cross-sell consent language fix.
    status: completed
  - id: detail-phases-0-1
    content: "Expand Phase 0 and Phase 1 tasks to Sprint-level detail: branch names, file specs, acceptance criteria, dependency ordering. These are next to execute."
    status: completed
  - id: reconcile-sprints-phases
    content: Reconcile Sprint 4-6 overlap with Phase 7-8. Mark superseded tasks. Add missing tasks (3.7, 3.8, 5.5, 5.6). Fix B.1/B.9 status contradictions.
    status: completed
  - id: fix-revenue-model
    content: Add pessimistic scenario to revenue model. Adjust Year 1 attach rates to realistic comps. Fix burn rate to include franchise tax, AI at scale, Stripe fees.
    status: completed
  - id: plan-hygiene
    content: Merge Section 0D and 11 (dedupe valuation). Fix Formation Nation comp framing. Update burn to real numbers. Add repo rename note.
    status: completed
isProject: false
---

# Master Plan v1: Stress Test Findings and Remediation

## Repo Rename Note

The repo is currently `fileFree`. When the venture LLC name is decided, rename to match (e.g., `butterside-labs` or whatever is chosen). Do this during a quiet period when no PRs are open, no agents are running, and no CI is in-flight. Update: GitHub repo name, Render blueprint references, Vercel project, all `package.json` names, import paths, and DNS CNAME records. **Not now -- park this for post-LLC-filing.**

---

## Critical Pre-Code Actions (Do Before Writing Any Product Code)

These are existential risk mitigations that cost under $5K total and prevent company-ending outcomes:

- **Get cyber liability insurance**: $1,500-3,000/yr for $1M E&O + cyber coverage. Non-negotiable for SSN handling. A single breach without it is fatal.
- **Draft a data breach response plan**: 2-page doc covering notification timelines by state tier, template notification letter, forensics firm contact, who to call first. Can be templated from SANS or NIST frameworks.
- **1-hour startup attorney consultation (~$300-500)**: Two specific questions: (a) does AI-generated operating agreement survive UPL analysis? (b) is wholesale RA arrangement structured to minimize agency liability?
- **Decide LLC name**: This blocks Phase 0.6, which blocks EIN, bank account, Stripe, trademarks. It's on the critical path and treated as optional. Set a hard deadline.
- **Apply for EFIN NOW**: Task B.1 is still "Not started" with 45-day processing. This is a silent blocker on the January 2027 North Star. EFIN -> Software Dev ID -> ATS testing (October) -> Comms test (November) -> Go-live. The chain starts here.

---

## Finding 1: Zero User Acquisition Strategy

The plan projects 10K-30K FileFree filers and 2K-5K LaunchFree users but never models how they arrive. Social content pipeline produces quantity, not quality (90%+ of faceless finance TikToks get <500 views). "Product Hunt + HN" is Phase 8 -- too late.

**What's missing:**

- Customer acquisition cost (CAC) model
- Paid marketing budget (even $200-500/month for TikTok Spark Ads is mentioned but not budgeted)
- Organic growth timeline (SEO takes 6-12 months to drive meaningful traffic)
- Influencer/creator partnership strategy with specific targets and budgets
- Pre-launch audience building (waitlist is live but no growth plan for it)
- Launch strategy beyond "Product Hunt + HN" -- Reddit, personal finance communities, tax prep forums

**Add**: New Section 5K (User Acquisition Strategy) with CAC model, channel-by-channel growth projections, and budget. Reference the LLC Journey Content Series (5J) as one channel, not the only channel.

---

## Finding 2: Partnership-Dependent Revenue with No Contingency

Every revenue stream requires a signed partner. Founder 2 is a 2-3 hr/week contributor. If partnerships don't close, revenue = $0 from all streams except $29/yr Tax Opt Plan and AdSense ($50-300/yr).

**What's missing:**

- Contingency plan if Founder 2 doesn't close any deals by H2 2026
- Self-serve affiliate applications (Impact.com, CJ Affiliate) as the Plan B -- these are online forms, no calls needed, Founder 1 can do them
- Revenue without partnerships: what does the business look like with ONLY the Tax Opt Plan and Trinkets AdSense?
- Hard deadlines for partnership milestones (not "TBD" or "when ready")

**Add**: Partnership milestone deadlines to Phase 0 and Background Tasks. Add "Plan B Revenue" scenario to Section 1.

---

## Finding 3: Revenue Attach Rates Are Optimistic for Year 1

Comparing to Credit Karma (2-4% at maturity, after years of trust-building) and FreeTaxUSA (8-12% audit shield on an established brand), the Year 1 rates should be:

- Refund routing HYSA: 1-2% (not 4%)
- Audit Shield: 2-3% (not 5%)
- Realistic conservative Year 1 from 10K filers: ~$25-30K (not $47K)

This doesn't break the model -- just means the path to profitability takes longer. The plan should have a "Pessimistic" scenario alongside Conservative/Moderate/Aggressive.

---

## Finding 4: Timeline Is 18-24 Months of Work Crammed Into 10

The "Timeline Reality Check" adds a 2-week buffer for a 10-month plan. Realistic adjustments needed:

- Phase 1 (monorepo): 4-6 weeks, not 2-3
- Phase 3 (LaunchFree MVP): 8-12 weeks, not 4-5 (this is an entire product)
- LaunchFree's "submit LLC" step is hand-waved -- most states don't have filing APIs
- Parallel tracks assume context-switching is free (research shows 20-40% productivity loss)
- MeF transmitter preparation needs to start by June 2026, not January 2027

**Add**: Realistic timeline column next to the aspirational one. Identify the critical path and which phases can actually overlap vs which are sequential.

---

## Finding 5: Agent Architecture Is Prematurely Scaled

43 agents for a pre-revenue, one-person venture. Only ~4 new agents are needed in the next 3 months. Specific issues:

- EA agent does 6 jobs (should be 2: interactive logging + separate ops monitor)
- CFO/EA, Strategy/EA, Agent-Ops/EA all overlap on financial tracking, planning, and auditing
- Social pipeline cost is ~$15-17/month, not $3 (ElevenLabs plan + Hetzner upgrade for FFmpeg)
- Multiple Cursor persona pairs will concatenate conflicting advice when both activate via overlapping globs

**Add**: "Build trigger" for each agent -- not "Phase X" but "build when [metric] > [threshold]" (e.g., "build L1 support bot when support emails exceed 10/day"). Reduce planned count from 43 to ~18-20.

---

## Finding 6: Legal Gaps


| Risk                                          | Severity | Gap                                                                                                                                                                                                                      |
| --------------------------------------------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 50-state data errors -> incorrect LLC filings | CRITICAL | Disclaimers cover opinions, not facts. Wrong filing fees/deadlines = negligence exposure. Need source-linking, "last verified" prominence, user confirmation step, ToS data accuracy disclaimer.                         |
| FTC "Free" scrutiny                           | HIGH     | "Free LLC" headline is misleading re: state fees. RA credit system is landmine ("free RA" claim). Intuit precedent heightens scrutiny. Need: never use "Free LLC" standalone, state fee disclosure in same visual field. |
| AI operating agreements (UPL)                 | HIGH     | "AI generates operating agreement" crosses from template to drafting. LegalZoom survived UPL challenges by NOT auto-generating. Start with template model, limit AI to explaining clauses not selecting them.            |
| Cross-sell opt-in                             | MEDIUM   | Consent language too vague. Missing per-brand unsubscribe. TCPA gap if SMS added. Need explicit cross-product data use in consent text.                                                                                  |


---

## Finding 7: Task Detail Gap

Sprint 0-6 tasks have branch names, file-level specs, 20-30 lines of implementation detail, and acceptance criteria. Venture Phase 0-8 tasks are one-line table summaries. This creates two tiers of clarity.

**Strategy for detailing:**

- **Detail NOW**: Phase 0 (P0.2, P0.6, P0.7, P0.9) and ALL Phase 1 tasks (P1.1-P1.11) -- these are next up
- **Detail by Q3 2026**: Phase 1.5, Phase 2, Phase 3 -- need Sprint-level treatment before execution
- **Keep as summaries**: Phase 4 Tier 2-3, Phase 5, Phase 6, Phase 8 -- too far out
- **Reconcile overlaps**: Sprint 4-6 tasks overlap with Phase 7-8. Mark Sprint 4-6 as "superseded -- see Phase X" or keep as detailed reference with Phase 7-8 pointing back. Several tasks are missing from venture phases entirely (Task 3.7 Refund Advance, 3.8 Affiliate Upgrade, 5.5 Accessibility, 5.6 Dependent Support).

**Add dependency chain**: P0.6 blocks P0.8. Phase 2 blocks Phase 3 AND Phase 7. EFIN (B.1) blocks Phase 8. Column Tax status contradicts itself ("confirmed" in critical dates vs "not started" in task status).

---

## Finding 8: Plan Hygiene Issues

- Section 0D and Section 11 duplicate valuation data (will drift apart)
- Formation Nation comp is misapplied (mature company vs pre-revenue startup)
- "Home run" 8-12x multiple is unsupported for a single-founder bootstrapped operation
- Monthly burn ($46-56/mo) excludes franchise tax ($800/yr), variable AI costs at scale, Stripe fees, partner wholesale costs, and ElevenLabs
- The plan is 2,500 lines -- planning time vs building time is itself a risk

