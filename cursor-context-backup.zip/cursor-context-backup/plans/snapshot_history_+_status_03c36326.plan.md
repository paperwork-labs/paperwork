---
name: Snapshot history + status
overview: Wire 200-trading-day snapshot history into operator flows, add UI buttons + schedule hooks, and make daily coverage status trading-day aware with an 18h post-close grace window while keeping UTC storage everywhere.
todos:
  - id: wire-guided-flow-200d
    content: Add snapshot history (200 trading days) step into bootstrap_daily_coverage_tracked + runbook wiring
    status: completed
  - id: progress-observability
    content: "Add “not hung” UX: estimate rows + show progress counters for 200d snapshot history backfill in Admin UI/Jobs"
    status: completed
  - id: ui-buttons-runbook
    content: Add AdminDashboard Advanced button + AdminRunbook step for snapshot history backfill (200d) and wire taskActions mapping
    status: completed
    dependencies:
      - wire-guided-flow-200d
      - progress-observability
  - id: schedule-rolling-5d
    content: Add nightly schedule template for rolling 5 trading days snapshot history refresh; surface preset in AdminSchedules
    status: completed
    dependencies:
      - wire-guided-flow-200d
  - id: coverage-market-closed
    content: Implement trading-day aware daily coverage status with 18h post-close grace and “market closed” hint
    status: completed
  - id: tests
    content: Add/adjust backend+frontend tests for new actions, schedules, and market-closed status behavior
    status: completed
    dependencies:
      - ui-buttons-runbook
      - schedule-rolling-5d
      - coverage-market-closed
      - progress-observability
isProject: false
---

# Snapshot history + trading-day aware coverage

## Goals

- Make **snapshot history (200 trading days)** a first-class part of the market-data pipeline.
- Ensure **UTC storage everywhere** (DB + backend timestamps), while UI displays in user timezone.
- Fix daily coverage status so it doesn’t falsely show **DEGRADED when the market is closed**, using an **18h post-close grace window**.

## Design (latest view + daily ledger)

- **Latest view**: `market_snapshot` (`MarketSnapshot`) remains the fast per-symbol cache.
- **Daily ledger**: `market_snapshot_history` (`MarketSnapshotHistory`) is the immutable per-day store keyed by `(symbol, analysis_type, as_of_date)`.

```mermaid
flowchart TD
  priceData[price_data_1d] --> recompute[recompute_indicators_universe]
  recompute --> persistLatest[MarketSnapshot_latest]
  recompute --> persistLedger[MarketSnapshotHistory_daily]
  persistLedger --> coverageDot[snapshot_fill_by_date]
  coverageDot --> adminDashboard[AdminDashboard_histogram_dots]

  adminActions[Admin_actions] --> backfill200[backfill_snapshot_history_last_n_days_200]
  backfill200 --> persistLedger

  schedules[CeleryBeat] --> nightly5[backfill_snapshot_history_last_n_days_5]
  nightly5 --> persistLedger
```



## Implementation steps

### 1) Make snapshot history part of the guided flow + runbooks

- Update `[backend/tasks/market_data_tasks.py](/Users/sankalpsharma/development/quantmatrix/backend/tasks/market_data_tasks.py)`:
- In `bootstrap_daily_coverage_tracked`, add a history step that triggers **full 200 trading days** snapshot ledger backfill.
- Clarify `record_daily_history` semantics (it was “today-only” legacy history). Prefer ledger-first moving forward.

### 2) Add UI actions to click it

- Update `[frontend/src/utils/taskActions.ts](/Users/sankalpsharma/development/quantmatrix/frontend/src/utils/taskActions.ts)`:
- Add endpoint mapping for `backfill_snapshot_history_last_n_days` (days=200).
- Update `[frontend/src/pages/AdminDashboard.tsx](/Users/sankalpsharma/development/quantmatrix/frontend/src/pages/AdminDashboard.tsx)`:
- Add **Advanced** button: “Backfill Snapshot History (200d)”.
- Add a small callout on the confirmation modal/button tooltip:
- estimated rows tracked_count × 200
- “This can take a few minutes; progress is visible in Admin → Jobs”
- Update `[frontend/src/pages/AdminRunbook.tsx](/Users/sankalpsharma/development/quantmatrix/frontend/src/pages/AdminRunbook.tsx)`:
- Add it as a runbook step.

### 3) Add schedule support

- Update `[backend/tasks/celery_app.py](/Users/sankalpsharma/development/quantmatrix/backend/tasks/celery_app.py)` and `[backend/tasks/job_catalog.py](/Users/sankalpsharma/development/quantmatrix/backend/tasks/job_catalog.py)`:
- Add a nightly schedule entry to run **rolling 5 trading days** ledger refresh (your preference).
- Update `[frontend/src/pages/AdminSchedules.tsx](/Users/sankalpsharma/development/quantmatrix/frontend/src/pages/AdminSchedules.tsx)`:
- Add a guided preset for the schedule.

### 4) Trading-day aware daily coverage status (18h grace)

- Update `[backend/services/market/market_data_service.py](/Users/sankalpsharma/development/quantmatrix/backend/services/market/market_data_service.py)`:
- Compute `expected_daily_date` as the **latest observed tracked-universe daily bar date**.
- Compute a market-state hint using **America/New_York** hours and a **close+18h** grace window.
- Only mark daily as **DEGRADED** when last-bar date meaningfully lags `expected_daily_date` beyond grace; otherwise show `ok` with a “market closed / within grace” hint.
- Update `[frontend/src/pages/AdminDashboard.tsx](/Users/sankalpsharma/development/quantmatrix/frontend/src/pages/AdminDashboard.tsx)`:
- Display “Market closed” hint when status is OK but market is closed/within grace.

### 5) Tests

- Backend:
- Extend snapshot-history tests to cover the guided flow wiring + schedule template.
- Add coverage-status tests for “market closed / within grace” vs “true degraded”.
- Frontend:
- Add a small test ensuring the new AdminDashboard button triggers the correct endpoint.

## Notes on UTC

