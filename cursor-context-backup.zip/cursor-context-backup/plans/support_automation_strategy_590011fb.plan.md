---
name: Support Automation Strategy
status: archived
overview: "ARCHIVED — Duplicate of support_automation_strategy_3ed0ae08. Content integrated into Venture Master Plan."
todos:
  - id: deploy-chatwoot
    content: Add Chatwoot to Hetzner Docker Compose
    status: pending
  - id: configure-zoho-chatwoot
    content: Configure Zoho Mail forwarding to Chatwoot
    status: pending
  - id: build-n8n-support-agent
    content: Build n8n L1 Support Agent Workflow
    status: pending
isProject: false
---

# Support Automation Strategy: The "Zero Human" Protocol

**Status**: Draft
**Date**: March 11, 2026
**Goal**: Resolve 95%+ of inquiries via AI Agents. Escalation to founders is a failure state.
**Philosophy**: Support is an engineering problem, not an operations problem.

## 1. Executive Summary

Traditional support scales linearly with users (hire more agents). **"Zero Human" support scales logarithmically** (fix the bug/doc that caused the ticket).
We will build a **Unified Support Stack** hosted on our existing infrastructure (`ops.sankalpsharma.com`) that handles Email, Chat, and (eventually) Voice.

## 2. The Stack (Vibe-Coded & Self-Hosted)


| Component          | Tool          | Hosting          | Cost  | Why?                                                      |
| ------------------ | ------------- | ---------------- | ----- | --------------------------------------------------------- |
| **Inbox UI**       | **Chatwoot**  | Hetzner (Docker) | Free  | Open-source, supports all channels, API-first.            |
| **Orchestrator**   | **n8n**       | Hetzner (Docker) | Free  | Already set up. Handles logic, RAG, and tools.            |
| **Brain**          | **OpenAI**    | API              | Usage | GPT-4o-mini for speed/cost, GPT-4o for complex reasoning. |
| **Email Provider** | **Zoho Mail** | Cloud            | Free  | Reliable delivery. Forwards to Chatwoot.                  |
| **Voice**          | **Vapi.ai**   | Cloud            | Usage | Best developer experience, connects to n8n tools.         |


## 3. Architecture Diagram

```mermaid
graph TD
    subgraph Channels
        Email[Zoho Mail] -->|IMAP/Forward| Chatwoot
        Widget[Website Widget] -->|WebSocket| Chatwoot
        Phone[Phone Number] -->|SIP/PSTN| Vapi
    end

    subgraph "Ops Server (Hetzner)"
        Chatwoot[Chatwoot Inbox]
        n8n[n8n Automation]
        Postgres[Database]
    end

    subgraph "AI Layer"
        OpenAI[GPT-4o]
        Vapi[Vapi.ai Voice Engine]
    end

    Chatwoot -->|Webhook: New Message| n8n
    Vapi -->|Function Call| n8n

    n8n -->|RAG Search| OpenAI
    n8n -->|Look up User| Postgres
    n8n -->|Reply| Chatwoot
```



## 4. The 3-Level Defense System

### Level 1: Instant Deflection (The Librarian)

- **Trigger**: User sends message.
- **Agent**: "DocBot" (GPT-4o-mini).
- **Action**: Searches the Knowledge Base (Docs, FAQs, past tickets).
- **Outcome**: "Here is how you file an amendment..."
- **Target Resolution**: 60%.

### Level 2: Action Agent (The Doer)

- **Trigger**: User needs *data* or *action* (e.g., "Where is my refund?").
- **Agent**: "OpsBot" (GPT-4o + Tools).
- **Tools**:
  - `check_filing_status(email)`
  - `resend_confirmation_email(email)`
  - `check_refund_status(ssn_last_4)`
- **Outcome**: "I checked the IRS status. It was accepted on Oct 15."
- **Target Resolution**: 30%.

### Level 3: Escalation (The Founder)

- **Trigger**: Sentiment analysis detects anger, legal threat, or complex edge case.
- **Action**:
  1. AI tags conversation as `High Priority`.
  2. AI summarizes the issue + drafts a suggested reply.
  3. Founder gets a push notification (Chatwoot Mobile App).
  4. Founder approves/edits/sends the reply.
- **Target Volume**: <5% of tickets.

## 5. Voice Support (Phase 2)

- **Tool**: **Vapi.ai**.
- **Experience**:
  - User calls number.
  - Vapi Agent answers instantly with "FileFree Support, I'm an AI assistant. How can I help?"
  - Vapi Transcribes -> Sends to n8n -> Gets Answer -> Speaks back (Latency <800ms).
  - **Escalation**: "I can't solve that. I will have a founder email you." (No live transfer to human phone).

## 6. Implementation Plan

### Phase 1: Text Foundation (Immediate)

- **Infrastructure**: Add `chatwoot` service to `infra/hetzner/compose.yaml`.
- **Config**: Connect Zoho Mail (`support@launchfree.ai`) to Chatwoot Inbox.
- **Workflow**: Build "L1 Support Agent" in n8n (Webhook -> OpenAI -> Reply).
- **Widget**: Embed Chatwoot widget on `filefree.tax` and `launchfree.ai`.

### Phase 2: Action Tools (Summer 2026)

- **Tools**: Expose API endpoints for `status`, `refund`, `resend` to n8n.
- **Logic**: Upgrade n8n workflow to use "Function Calling" to select tools.

### Phase 3: Voice (Winter 2026)

- **Setup**: Buy phone number on Vapi.
- **Connect**: Link Vapi to n8n "Action Agent".
- **Launch**: "24/7 AI Phone Support" (Premium feature?).

## 7. Cost Analysis (At Scale)

- **Chatwoot**: $0 (Self-hosted on existing VPS).
- **Zoho**: $0.
- **OpenAI**: ~$0.01 per ticket (avg 5 turns).
- **Vapi**: ~$0.10 per minute (only if they call).
- **Comparison**: Zendesk ($59/agent/mo) + Intercom ($74/mo) = **$133/mo saved**.

## 8. Note to Agents

- **Source of Truth**: The `n8n` workflow is the "Brain". Do not hardcode logic in the frontend widget.
- **Knowledge Base**: We must sync our Docs (Google Drive/Markdown) to the Vector Store (in n8n/Postgres) automatically.

