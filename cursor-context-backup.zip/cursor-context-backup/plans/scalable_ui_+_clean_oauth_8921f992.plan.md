---
name: Scalable UI + Clean OAuth
overview: Convert the prototype UI into a scalable Next.js routed app with a real design system and a clean Google OAuth flow that redirects to Home and uses HTTP-only cookie auth.
todos:
  - id: routing-shell
    content: Create Next.js routes (/onboarding, /search, /jobs, /docs) and shared shell layout with real URL navigation.
    status: completed
  - id: ui-components
    content: Add reusable Apple-esque UI components and refactor pages to use them.
    status: completed
    dependencies:
      - routing-shell
  - id: oauth-start-clean
    content: Update backend /auth/google/start to use configured redirect_uri (8001) and optional state.
    status: completed
  - id: oauth-callback-code-exchange
    content: Implement GET OAuth callback with code→token exchange, userinfo, allowlist, upsert, HttpOnly cookies, redirect to frontend /.
    status: completed
    dependencies:
      - oauth-start-clean
  - id: tests-frontend-routing
    content: Add/update frontend tests for routing and onboarding connect CTA.
    status: completed
    dependencies:
      - routing-shell
      - ui-components
  - id: tests-backend-oauth
    content: "Add backend tests for OAuth callback: allowlist enforcement, cookie set, redirect."
    status: completed
    dependencies:
      - oauth-callback-code-exchange
---

# Scalable Frontend + Clean OAuth (redirect to Home)

## Goals

- Make the UI **shareable and scalable**: each section is a real Next.js App Router route.
- Make OAuth **clean**: “Connect Google” performs a direct redirect to Google (no JSON pages), and callback finishes the flow and redirects to **`/`**.
- Make auth **production-shaped**: backend sets **HTTP-only cookies** for JWTs; frontend uses `/assistant/api/auth/me` for session state.

## What will change

### Frontend (Next.js App Router)

- Create route structure:
- `/` (Home dashboard)
- `/onboarding` (connect flow)
- `/search`
- `/jobs`
- `/docs`
- Add shared shell layout (left rail + top bar) that wraps all routes.
- Introduce a small design system (Apple-esque tokens already exist in CSS): `Button`, `Card`, `Input`, `Pill`, `Table`, `EmptyState`.
- Replace in-page view switching with `<Link>` navigation so URLs change and can be shared.
- OAuth button behavior:
- call `GET /assistant/api/auth/google/start`
- browser redirects to the returned `authorization_url`

### Backend (FastAPI OAuth + cookies)

- Fix hardcoded redirect URI in `backend/app/routes.py` to use the running API base (8001) and a configured frontend base.
- Implement standard OAuth callback:
- `GET /assistant/api/auth/google/callback?code=...&state=...`
- exchange code→tokens via `httpx` (already in `backend/requirements.txt`)
- fetch user profile/email (Google OIDC/UserInfo)
- enforce allowlist
- upsert `User`/`Account`
- set cookies: `access_token`, `refresh_token` as **HttpOnly, SameSite=Lax** (Secure in non-dev)
- redirect (303) to `FRONTEND_BASE_URL/` (user chose Home)
- Keep existing POST callback (optional) for backwards-compat temporarily, or deprecate behind a feature flag.

### Testing

- Update frontend tests to cover routing/nav and the onboarding CTA.
- Add backend tests for:
- callback rejects non-allowlisted email
- callback sets cookies and redirects to `/`

## Key files

- Frontend:
- `frontend/src/app/layout.tsx` (shell layout)
- `frontend/src/app/page.tsx` (Home)
- `frontend/src/app/onboarding/page.tsx`
- `frontend/src/app/search/page.tsx`
- `frontend/src/app/jobs/page.tsx`
- `frontend/src/app/docs/page.tsx`
- `frontend/src/app/components/*`
- Backend:
- `backend/app/routes.py`
- `backend/app/config.py` (add `FRONTEND_BASE_URL`, `API_BASE_URL` if needed)
- `backend/tests/*` (new test module for OAuth callback)

## Diagrams

```mermaid
flowchart TD
  browser[Browser] --> ui[NextRoutes]
  ui --> api[FastAPI_Assistant_API]
  api --> google[GoogleOAuth]
  api --> db[Postgres]
  api --> redis[Redis]
  api --> worker[WorkerJobs]
```



```mermaid
sequenceDiagram
  participant U as User
  participant F as Frontend
  participant A as API
  participant G as Google
  U->>F: ClickConnectGoogle
  F->>A: GET auth/google/start
  A-->>F: authorization_url
  F->>G: RedirectToAuthURL
  G-->>A: Redirect callback (code)
  A->>G: Exchange code for tokens
  A->>G: Fetch userinfo
  A-->>U: Set HttpOnly cookies + Redirect 303 to / 
```



## Rollout / Backwards compatibility

- For dev, cookies will work with `SameSite=Lax`; secure flag off.
- For prod, set `Secure=true` and restrict CORS/allowed origins.

## Implementation todos

- **routing-shell**: Create routed pages + shared shell layout/nav.
- **ui-components**: Add reusable UI components (`Button`, `Card`, `Pill`, etc.) and migrate pages to use them.
- **oauth-start-clean**: Update `/auth/google/start` to return correct redirect_uri and optional state.
- **oauth-callback-code-exchange**: Implement GET callback, token exchange, userinfo fetch, allowlist, account upsert, cookie set, redirect to `/`.
- **tests-frontend-routing**: Update/add frontend tests for route navigation and onboarding CTA.