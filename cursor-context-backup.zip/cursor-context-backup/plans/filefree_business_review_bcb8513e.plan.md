---
name: FileFree Business Review
overview: Comprehensive review of FileFree's documentation, business viability, execution readiness, and gaps -- covering strategy, docs, Notion, co-founder workflow, and what needs to happen before coding starts.
todos:
  - id: fix-strategy-numbers
    content: Update strategy.mdc with corrected ARPU ($8.05), LTV ($27.05), and fixed infra ($34.50/mo) to match revenue pivot D14
    status: completed
  - id: add-missing-tasks
    content: Add Task B.7 (HYSA affiliate applications) and Task B.8 (Legal drafts v1) to TASKS.md Sprint 0
    status: completed
  - id: fix-product-spec-dupe
    content: Remove duplicate 'Tax Receipt Viral Card' section from PRODUCT_SPEC.md
    status: completed
  - id: validate-ocr
    content: Create standalone Python script to test Cloud Vision + GPT-4o-mini pipeline on real W-2 images before building full app
    status: completed
  - id: connect-mcps
    content: Replace placeholder tokens in .cursor/mcp.json with real GitHub, Notion, and Context7 credentials
    status: completed
  - id: reset-timeline
    content: Adjust TASKS.md critical dates to reflect realistic 2-3 week push from current state
    status: completed
  - id: start-sprint-0
    content: "Begin Sprint 0 business ops: EFIN application (longest lead), LLC registration, social accounts, Hetzner VPS"
    status: in_progress
  - id: start-task-01
    content: Begin Task 0.1 (Docker dev environment) in parallel with Sprint 0 business ops
    status: pending
  - id: create-partnerships-persona
    content: Create .cursor/rules/partnerships.mdc -- AI assistant persona for the partnerships co-founder. Drafts outreach, tracks pipeline, preps deal summaries in 5-10 min actionable chunks.
    status: completed
  - id: create-partnerships-playbook
    content: "Create PARTNERSHIPS.md at repo root -- her standalone reference doc: tiered partnership strategy (affiliate now, direct later), 10-partner hit list with research, outreach templates, role/responsibilities, weekly cadence, and partnership lifecycle from application to revenue."
    status: completed
  - id: create-pitch-package
    content: "Create a shareable pitch package for the co-founder: 2-page executive summary, revenue model one-pager with her $367K impact highlighted, and partnership hit list -- all exportable for phone reading."
    status: completed
  - id: setup-notion-partnerships
    content: Set up Notion workspace with Partnership Pipeline database (partner, type, tier, status, revenue potential, contact, next steps) and shared docs page for co-founder review.
    status: completed
  - id: update-docs-cofounders
    content: Update STRATEGY_REPORT.md, PRD.md, TASKS.md, and KNOWLEDGE.md to reflect co-founder structure (you = product/eng, wife = partnerships/revenue). Bake tiered partnership strategy into PRD Section 7. Downgrade solo founder risk.
    status: completed
isProject: false
---

# FileFree: Full Project Review and Execution Readiness Assessment

## Current State: Documentation-Only, Zero Code

The repository contains **5 major documents** (PRD v6.0, PRODUCT_SPEC v4.0, TASKS v5.0, KNOWLEDGE.md, STRATEGY_REPORT v1.0), **10 AI persona files** + workflows playbook, and MCP configuration with placeholder tokens. There are 4 git commits, all from today (March 8). No application code, no infrastructure files, no business operations have started.

The documentation quality is genuinely exceptional -- better than most Series B startups. The problem is the aggressive timeline has already started (March 9 = tomorrow) with zero code scaffolded and zero Sprint 0 business tasks completed.

---

## Is This a Viable Business? YES -- With Caveats

### What makes it viable

- **Market timing is real.** IRS killed Direct File, TurboTax faces 3 lawsuits, 67% of Gen Z stressed about taxes, 43% would trust AI over a tax pro. This window is 12-18 months before incumbents react.
- **Cost structure is world-class.** $0.060/user, 99.3% gross margin. The tiered OCR pipeline (Cloud Vision + GPT-4o-mini at $0.002/doc vs Document AI at $0.30/doc) is a genuine 150x cost advantage.
- **Revenue model is proven at scale.** Credit Karma ($7.1B acquisition) proved the referral playbook. Marcus pays $50-100/funded HYSA account (public program). Every revenue stream has a real comp.
- **Competitive moat is structural.** 80% annual retention (PCMag data) means whoever captures a 22-year-old owns them for ~10 years. TurboTax literally cannot simplify without destroying $3B+ in revenue.
- **Infrastructure cost is negligible.** $34.50/mo fixed. You can run this for years without revenue pressure.

### What threatens viability


| Risk                                 | Severity | Notes                                                                                                                                                            |
| ------------------------------------ | -------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Solo founder capacity                | CRITICAL | Tax season is a 10-week sprint with zero margin for error. No backup.                                                                                            |
| OCR accuracy UNVALIDATED             | HIGH     | The entire product depends on Cloud Vision + GPT-4o-mini working on W-2s. Has NOT been tested. Google themselves recommend their $0.30/doc parser for tax forms. |
| Refund routing attach rate (8%)      | HIGH     | This is the #1 revenue stream and has NO direct comp data. If <2%, ARPU drops 50%.                                                                               |
| Aggressive timeline already slipping | HIGH     | March 9 start date is tomorrow. Zero Sprint 0 business tasks done. MVP by March 22 from zero code is extremely ambitious.                                        |
| Organic-dependent acquisition        | MEDIUM   | $200-500/mo in paid ads is noise. If social content doesn't resonate with Gen Z, growth stalls entirely.                                                         |
| Column Tax pricing unknown           | MEDIUM   | Interim e-file depends on a partnership that hasn't been negotiated.                                                                                             |


### Honest verdict

The unit economics and market positioning are strong enough that even Scenario A (conservative, $4.38 ARPU) works at 230K users. The question is purely **execution** -- can a solo founder ship an MVP that handles SSNs, validate OCR accuracy, acquire users organically, and survive tax season?

---

## Documentation Gaps

### Missing from existing docs

1. **strategy.mdc has stale numbers** -- Still says ARPU $10.16 and LTV $34.14, but the PRD v6.0 revenue pivot (D14) revised these to $8.05 and $27.05. Fixed monthly infra says $27/mo but it's actually $34.50/mo ($20 Vercel + $7 Render + $7.50 Hetzner).
2. **No HYSA affiliate application task** -- [STRATEGY_REPORT.md](STRATEGY_REPORT.md) Recommendation #2 says "Apply to HYSA affiliate programs immediately" but [TASKS.md](TASKS.md) Sprint 0 has no task for this. This is the #1 revenue stream.
3. **No legal drafts exist** -- Task B.3 covers privacy policy and ToS, but they haven't been created. These are needed before the landing page goes live (landing page has "trust badges" referencing privacy).
4. **No incident response runbook** -- Called out as needed in [STRATEGY_REPORT.md](STRATEGY_REPORT.md) Section 6 ("break glass runbook") but not tasked.
5. **No tax-data/2025.json** -- Referenced throughout but doesn't exist. The bracket data and standard deductions are specified in the PRD but need to be codified.
6. **README references nonexistent structure** -- Lists `filefree-web/`, `filefree-api/`, `Makefile`, `render.yaml`, `docker-compose.yml` -- none of which exist.
7. **PRODUCT_SPEC has a duplicate section** -- The "Tax Receipt Viral Card" spec appears twice (lines ~133-153 and ~194-210).

### What's well-covered

- Architecture decisions (15 decisions in KNOWLEDGE.md, all with context/alternatives/rationale)
- Tech stack with no ambiguity
- Data models, API endpoints, security requirements
- UX specification with 22 granular tasks
- Revenue model with 3 scenarios and sensitivity analysis
- Risk register with mitigations
- Assumptions register with validation plans
- Competitive analysis (honest, not hand-wavy)

---

## Notion Coverage

**The plan is thorough but nothing is set up yet.**

- Task B.4 in [TASKS.md](TASKS.md) explicitly covers creating the Notion workspace "FileFree HQ"
- [strategy.mdc](.cursor/rules/strategy.mdc) defines the workspace structure: Strategy, Product Roadmap, Decision Log, Content Calendar, Legal/Compliance, Financials, Partnerships
- Decision Log format is well-defined (date, decision, context, alternatives, rationale, reversibility)
- Weekly cadence includes Notion updates (weekend: "update Notion, log decisions, plan next week")
- [.cursor/mcp.json](.cursor/mcp.json) has the Notion MCP configured -- but with `YOUR_NOTION_API_KEY_HERE` placeholder

**Gap:** The Notion workspace doesn't exist. The MCP token is a placeholder. Decisions are currently logged in KNOWLEDGE.md (which is fine and arguably better for AI agent context), but the Content Calendar, Legal tracking, and Financial tracking have no home yet.

**Recommendation:** KNOWLEDGE.md is already doing a great job as the decision log. Don't duplicate effort into Notion until there's a real need for visual boards. Start Notion with just the Content Calendar (needed for social media coordination) and the Legal/Compliance tracker (EFIN status tracking). The rest can wait.

---

## Execution Readiness Checklist

### Ready (documentation is solid)

- PRD with market sizing, competitive analysis, revenue model
- UX spec with design system, component specs, 22 implementation tasks
- Sprint-by-sprint build plan with acceptance criteria per task
- Architecture decisions documented with rationale
- Tech stack locked (zero ambiguity)
- AI persona system for cognitive offloading
- Risk register and assumptions register
- Tiered OCR pipeline design ($0.002/doc)
- Security architecture (SSN isolation, encryption, PII scrubbing)

### NOT Ready (blockers for execution)

- **EFIN application** (45-day lead time -- Task B.1, not started)
- **LLC/Corp registration** (Task B.2, not started)
- **Social media accounts** (Task B.2, not started)
- **Hetzner VPS + Postiz** (Task B.6, not started)
- **Notion workspace** (Task B.4, not started)
- **Column Tax demo call** (Task B.5, not started)
- **MCP connections** (all placeholder tokens)
- **Any application code** (Tasks 0.1-0.4, not started)
- **Any infrastructure** (Docker, Vercel, Render, Neon, Upstash -- not provisioned)
- **HYSA affiliate applications** (not even tasked)
- **Legal drafts** (privacy policy, ToS)

---

## Recommended Adjustments Before Execution

### 1. Fix the timeline (it's already behind)

The TASKS.md dates have March 9 as "EFIN application submitted + coding starts." Given nothing from Sprint 0 is done, the timeline needs a realistic reset. Suggested adjustment:

- **Week 1 (March 9-15):** Sprint 0 business ops (EFIN, LLC, social accounts, Hetzner/Postiz) + Task 0.1 (Docker dev env)
- **Week 2 (March 15-22):** Tasks 0.2 + 0.3 (frontend + backend init) + Task 0.4 (landing page + deploy)
- **Week 3-4 (March 22 - April 5):** Tasks 1.1-1.3 (camera, OCR pipeline, try-before-signup)
- **April 5-15:** Content push for tax deadline (OCR demo should be live by now)
- **April 15 - May 31:** Sprint 3 (auth, filing flow, tax calc, PDF)

This pushes the MVP by ~2-3 weeks but is realistic.

### 2. Add missing Sprint 0 tasks

- **Task B.7 -- HYSA Affiliate Applications:** Apply to Marcus, Wealthfront, Betterment affiliate programs. Self-serve signup. This is the #1 revenue stream and requires zero negotiation.
- **Task B.8 -- Legal Drafts v1:** Generate privacy policy and ToS drafts using legal.mdc persona. Needed before landing page goes live.

### 3. Fix strategy.mdc stale numbers

Update ARPU from $10.16 to $8.05, LTV from $34.14 to $27.05, fixed infra from $27/mo to $34.50/mo to match the revenue pivot (D14).

### 4. Validate OCR before building the full app

[STRATEGY_REPORT.md](STRATEGY_REPORT.md) Recommendation #3 says this, and it's correct. Before investing in the full filing flow, run a standalone Cloud Vision + GPT-4o-mini test on 20+ real W-2 images. This can be done with a simple Python script in a few hours. If accuracy is below 95%, the entire technical architecture may need adjustment (more GPT-4o vision, different approach). Do this in Week 1.

### 5. Connect MCP servers

Replace placeholder tokens in `.cursor/mcp.json` with real credentials for GitHub (for Issues/Projects tracking), Notion (when workspace is created), and Context7 (for library docs during development).

---

## Co-Founder Structure: You Build, She Closes

### Why this changes everything

Having a FAANG partnerships person as co-founder directly de-risks the #1 revenue stream. Refund routing ($4.00/user) + financial referrals ($2.25/user) = $6.25/user = **77% of Scenario B revenue**. These are partnership-dependent streams that a solo engineer would struggle to close. A partnerships professional at FAANG knows exactly how enterprise deals work, how to negotiate rev-share terms, and how to navigate legal/compliance on both sides.

**Risk impact:**

- "Solo founder burnout" drops from CRITICAL to HIGH (two people, split responsibilities)
- "Zero refund routing partners by launch" drops from HIGH to MEDIUM (she knows how to run outreach)
- "Column Tax pricing unknown" drops from MEDIUM to LOW (she can negotiate this in one call)

### Role split


| Domain       | You (Product/Eng)                             | Her (Partnerships/Revenue)                         |
| ------------ | --------------------------------------------- | -------------------------------------------------- |
| Product      | Build the app, OCR pipeline, tax calc, deploy | Review UX for partner integration points           |
| Partnerships | Provide data/deck for partner pitches         | Outreach, negotiate, close deals                   |
| Revenue      | Build the Refund Plan screen, referral infra  | Source HYSA, lending, insurance partners           |
| Legal        | Privacy policy, ToS, EFIN application         | Partnership agreement review                       |
| Content      | Record videos, write code                     | Review/approve brand messaging in partner contexts |
| Column Tax   | Build SDK integration                         | Book demo, negotiate pricing                       |


### Her workflow (2-3 hrs/week, AI-assisted)

At 2-3 hours per week with a FAANG job and two kids, every minute must count. The AI partnerships persona handles all prep work so she only does what a human must: send emails, take calls, sign deals.

**What the AI persona does for her:**

- Drafts personalized outreach emails (she reviews in 2 min, hits send)
- Researches potential partners (pricing, terms, competitor deals, contact info)
- Prepares one-page deal summaries before calls ("Marcus HYSA: $50-100/funded account, self-serve affiliate vs. direct partnership, our projected volume = X")
- Generates weekly pipeline status summary ("3 partners in outreach, 1 meeting scheduled, 0 closed")
- Drafts partnership agreement redlines based on our terms

**What she does (the human-required stuff):**

- Sends outreach emails (AI-drafted, she personalizes)
- Takes 1-2 partnership calls per week
- Reviews and negotiates deal terms
- Leverages her FAANG network for warm intros
- Signs partnership agreements

**Weekly cadence (target: 2-3 hours):**

- Monday (30 min): Review AI-generated pipeline summary in Notion, approve/send outreach emails
- Wednesday (60 min): Partnership calls (AI preps call briefs)
- Friday (30 min): Update Notion pipeline status, review any AI-drafted materials for next week

### New AI persona: partnerships.mdc

Create `.cursor/rules/partnerships.mdc` with:

- Role: Partnership Development Assistant for the co-founder leading revenue partnerships
- Trigger: Invoke when drafting outreach, researching partners, preparing deal summaries, or updating pipeline
- Constraints: Every deliverable must be actionable in 5-10 minutes. No drafts that need heavy editing. Include full context so she never has to ask background questions.
- Key knowledge: FileFree's revenue streams (from PRD Section 7), unit economics, competitive positioning, partnership targets
- Output formats: outreach email (ready to send), deal summary (one page), call prep brief (bullet points), pipeline update (dashboard-ready)

### Getting her bought in: The Pitch Package

She needs to see this is a real business, not a side project. Create a shareable package in Notion (she can read on her phone):

**Document 1: Executive Summary (2 pages)**

- The problem (IRS killed Direct File, TurboTax lawsuits, Gen Z anxiety)
- The solution (free filing, refund-moment monetization)
- The numbers ($0.060/user cost, $8.05 ARPU, 99.3% margin, $27 LTV)
- The competitive advantage (80% retention, first-filer lock-in, 150x cost advantage)
- The ask (2-3 hrs/week on partnerships = the difference between $438K and $805K revenue at 100K users)
- Extracted from [STRATEGY_REPORT.md](STRATEGY_REPORT.md) and [PRD.md](PRD.md) Section 7

**Document 2: Revenue Model Deep-Dive (1 page)**

- All 7 revenue streams with evidence and comps
- Three scenarios at 100K users ($438K / $805K / $1.53M)
- Her specific impact: Scenario A (no partnerships person) = $438K. Scenario B (partnerships in place) = $805K. The delta is $367K and it's almost entirely her contribution.
- Extracted from [PRD.md](PRD.md) Section 7

**Document 3: Partnership Hit List (1 page)**

- Top 10 partnership targets with type, estimated revenue per deal, difficulty, and status
- Marcus by Goldman Sachs (HYSA, $50-100/funded account, self-serve affiliate)
- Wealthfront (HYSA + investment, $50-150/funded account, self-serve affiliate)
- Betterment (investment, $50-150/funded account, affiliate program)
- Fidelity (IRA, $50-100/funded account, affiliate)
- Lemonade (renters insurance, $30-50/referral)
- Column Tax (e-file SDK, negotiate pricing to $10-15/return)
- Refundo (refund advance, $3-5/advance rev share)
- Green Dot (refund advance, $3-5/advance rev share)
- NerdWallet-style credit card partners ($50-100/approval)
- One secured credit card issuer for first-time credit builders

**Document 4: Full Strategy Report**

- [STRATEGY_REPORT.md](STRATEGY_REPORT.md) as-is (she likes deep analysis)

### Notion workspace (shared collaboration layer)

The Notion workspace becomes critical now as the bridge between the two co-founders. Structure:

**Partnership Pipeline (Notion database)**

- Partner Name | Type (HYSA / Lending / Insurance / Credit / E-File) | Status (Research / Outreach / Meeting / Negotiation / Signed / Active) | Revenue Potential ($/user) | Volume Estimate | Contact | Last Touch | Next Steps | Due Date | Notes

**Shared Docs (Notion pages)**

- Executive Summary
- Revenue Model
- Partnership Hit List
- Strategy Report
- Meeting Notes (per partner)

**Content Calendar** (for social media coordination)

**Decision Log** (mirrors KNOWLEDGE.md for non-technical decisions)

### New TASKS.md additions

### New deliverable: PARTNERSHIPS.md (her standalone reference doc)

Create `PARTNERSHIPS.md` at repo root. This is her equivalent of TASKS.md -- everything she needs to operate independently, without touching the codebase or reading technical docs.

**Section 1: Why Partnerships Are THE Business**

- Filing is free = acquisition channel. Partnerships = revenue.
- Her impact quantified: Scenario A (no partnerships) = $438K. Scenario B (partnerships in place) = $805K. Delta = $367K at 100K users. That delta is her contribution.
- Credit Karma built a $7.1B business on this exact model.

**Section 2: Tiered Partnership Strategy**

Phase 1 -- Affiliate Applications (NOW, pre-product):

- Apply online to affiliate networks. No calls needed.
- Payout: $50-100/funded account (standard affiliate rates).
- Partners: Marcus (Impact network), Wealthfront (Impact), Betterment (CJ Affiliate), Fidelity (in-house).
- Timeline: Apply now, activate links when Refund Plan screen ships.
- Owner: Either co-founder (online forms).

Phase 2 -- Activate + Optimize (product live, 500+ users):

- Affiliate links go live on Refund Plan screen.
- Track conversion rates, identify top-performing partners.
- A/B test recommendation copy and placement.
- Owner: You (product integration) + Her (monitor performance).

Phase 3 -- Upgrade to Direct Partnerships (5K+ users, traction proven):

- She reaches out to existing affiliate partners for direct deals.
- Pitch: "We're driving X funded accounts/month at Y conversion. We want higher payouts, co-marketing, API integration, dedicated AM."
- Payout: $100-200+/funded account (2-3x affiliate rates).
- Owner: Her (negotiation, relationship management).

Phase 4 -- Expand Partnership Categories (10K+ users):

- Add lending partners (refund advance), insurance, credit products.
- Explore B2B API partnerships (Phase 3 of product roadmap).
- Owner: Her (sourcing, negotiation, legal review).

**Section 3: Partnership Hit List (10 targets with full research)**

For each partner include: company, offering, affiliate program details (network, URL, typical payout), direct partnership potential, revenue estimate at 100K users, status, and competitive intel.

1. Marcus by Goldman Sachs -- HYSA, $50-100/funded, Impact network
2. Wealthfront -- HYSA + investment, $50-150/funded, Impact network
3. Betterment -- Investment accounts, $50-150/funded, CJ Affiliate
4. Fidelity -- IRA/brokerage, $50-100/funded, in-house program
5. Column Tax -- E-file SDK, negotiate $10-15/return (requires demo call)
6. Refundo -- Refund advance, $3-5/advance rev share (requires outreach)
7. Green Dot / Republic Bank -- Refund advance alternative
8. Lemonade -- Renters insurance, $30-50/referral
9. Secured credit card issuer (Discover/Capital One) -- $50-100/approval
10. YNAB or budgeting app -- cross-referral partnership

**Section 4: Outreach Templates (ready to personalize and send)**

- Affiliate application cover note (for networks that ask "describe your audience")
- Cold outreach email for direct partnership (Phase 3 template)
- Column Tax demo request email
- Refund advance partner intro email
- Follow-up email (1 week after no response)

**Section 5: Her Weekly Cadence (2-3 hours total)**

- Monday (30 min): Review pipeline in Notion, approve/send AI-drafted outreach
- Wednesday (60 min): Partnership calls (AI preps call briefs the night before)
- Friday (30 min): Update Notion statuses, flag anything that needs product input

**Section 6: What She Does NOT Need to Worry About**

- Product development, code, infrastructure, deployments
- Tax calculations, OCR pipeline, security architecture
- Social media content creation (separate track)
- EFIN application, IRS certification (you own this)
- Day-to-day product decisions

**Section 7: Partnership Lifecycle (how a deal goes from idea to revenue)**

```
Research → Application/Outreach → Meeting → Negotiation → Signed → Integration → Live → Revenue
   AI          AI/Her              Her        Her          Her      You          Both    Both
```

Each stage specifies who owns it and what the AI persona prepares.

### New TASKS.md additions

**Task B.7 -- Partnership Foundation (Sprint 0, you)**

- Create `PARTNERSHIPS.md` with all sections above
- Create `.cursor/rules/partnerships.mdc` AI persona
- Create Notion workspace with Partnership Pipeline database
- AI-generate the Pitch Package (Exec Summary, Revenue Model, Hit List)
- Share Notion workspace with co-founder
- AI-draft all outreach templates in Section 4

**Task B.8 -- Affiliate Applications (Sprint 0, either co-founder)**

- Apply to Marcus affiliate program via Impact network
- Apply to Wealthfront affiliate program via Impact network
- Apply to Betterment affiliate program via CJ Affiliate
- Apply to Fidelity affiliate/advisor program
- These are online applications -- fill out forms, describe audience, submit
- No product needed. No calls needed. Activate links when Refund Plan screen ships (Sprint 4).

**Task B.9 -- Column Tax Demo Call (Sprint 0, she owns)**

- Book demo at columntax.com/contact-us
- AI preps call brief: volume projections, pricing targets ($10-15/return), SDK technical questions, white-labeling options
- She runs the call. You join for technical questions if needed.
- Goal: confirm pricing, get sandbox access by June

**Task B.10 -- Refund Advance Partner Outreach (Sprint 4, she owns)**

- Cold outreach to Refundo and Green Dot/Republic Bank
- AI drafts pitch email. She personalizes and sends.
- Requires e-file capability, so waits until Column Tax integration is close

### Specific changes to existing docs

**STRATEGY_REPORT.md:**

- Rename Section 6 to "Founding Team Structure & Risk Assessment"
- Add co-founder roles table (product/eng + partnerships/revenue)
- Downgrade Risk #1 (solo founder burnout) from CRITICAL to HIGH
- Downgrade Risk #5 (zero refund routing partners) from HIGH to MEDIUM
- Add "Tiered Partnership Strategy" subsection explaining affiliate-first, direct-later approach

**PRD.md Section 7 (Revenue Model):**

- Add "Partnership Execution Strategy" subsection after revenue stream descriptions
- Include the 4-phase tiered approach (affiliate -> activate -> direct -> expand)
- Note which streams have a dedicated co-founder owner
- Add co-founder structure to Section 1.2 (Solution)

**PRD.md Section 1:**

- Update "Solo Founder Operating Model" to "Co-Founder Operating Model"
- Add partnerships co-founder role description

**KNOWLEDGE.md:**

- D16: "Co-founder structure -- product/eng + partnerships/revenue split"
- D17: "Tiered partnership strategy -- affiliate applications first (self-serve, $50-100/funded), upgrade to direct partnerships at scale (negotiated, $100-200+/funded)"

**strategy.mdc:**

- Change "Solo Founder Operating Model" to "Co-Founder Operating Model"
- Update role list to include "Partnerships/Revenue: Co-founder with FAANG partnerships background + AI persona assistant"
- Update key business metrics to match corrected ARPU/LTV

**.cursorrules:**

- Update Project Context to mention two-founder structure
- Update references to solo founder operating model

---

## Bottom Line

**The business is viable -- and significantly more viable with two co-founders.** The market timing, cost structure, and revenue model are all sound. The documentation is among the best I've seen for a pre-revenue startup.

Adding a FAANG partnerships person as co-founder directly addresses the most fragile assumption in the revenue model (refund routing attach rate) and the most critical execution risk (solo founder burnout). The delta between Scenario A (no partnerships) and Scenario B (partnerships in place) is **$367K at 100K users** -- that's the value of her 2-3 hours per week.

The tiered partnership strategy (affiliate applications now, direct deals at scale) means she doesn't need to do cold outreach on day one. Phase 1 is online forms. Phase 3 is where her FAANG skills shine -- upgrading affiliate relationships to direct partnerships with 2-3x higher payouts once there's volume to prove the value.

**The gap is purely execution.** Zero code, zero infrastructure, zero business operations. The immediate priorities:

1. **Get her bought in** -- Create PARTNERSHIPS.md + Pitch Package this week. The "$367K delta" framing and her own standalone reference doc make it concrete and actionable.
2. **Affiliate applications** -- Submit Tier 2 affiliate applications to Marcus, Wealthfront, Betterment, Fidelity. Online forms, no calls.
3. **EFIN application** -- 45-day lead time, submit this week
4. **OCR validation** -- Test Cloud Vision + GPT-4o-mini on real W-2s before building anything else
5. **Start coding** -- Task 0.1 (Docker dev env) in parallel with business ops
6. **She books Column Tax** -- One call to confirm pricing and get sandbox access

The four things that will determine success or failure:

1. **OCR accuracy on real W-2s** -- validate this week
2. **Co-founder alignment** -- PARTNERSHIPS.md and the Pitch Package are the tools to make this happen
3. **Partnership pipeline** -- at least one HYSA affiliate approved by product launch, upgrade to direct deal by October 2026
4. **Organic content traction** -- if the first 10 TikTok/IG posts don't get engagement, rethink the growth strategy

