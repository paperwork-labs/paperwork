---
name: Project Structure Cleanup
overview: Rename service directories to api/web, add infra/ folder (compose + env files per environment), delete premature scripts/, and update all references. Monorepo confirmed as correct architecture for solo founder + AI agents.
todos:
  - id: rename-dirs
    content: git mv filefree-api -> api and filefree-web -> web
    status: completed
  - id: create-infra
    content: Create infra/ folder with compose.dev.yaml, env.dev.example, env.prod.example
    status: completed
  - id: create-docs
    content: git mv all strategy/product docs (TASKS.md, PRD.md, etc.) into docs/ folder
    status: completed
  - id: delete-scripts
    content: Delete scripts/validate_ocr.py and scripts/requirements.txt, old env files
    status: completed
  - id: update-refs
    content: Update all file references in Makefile, render.yaml, pyproject.toml, README.md, .cursorrules, engineering.mdc, TASKS.md, KNOWLEDGE.md
    status: completed
isProject: false
---

# Project Structure Cleanup

Inspired by the AXIOMFOLIO project structure. Monorepo confirmed as the right architecture -- AI agents need full codebase context, one `make dev` starts everything, atomic commits across services.

## Changes

### 1. Rename service directories

- `filefree-api/` -> `api/` (git mv)
- `filefree-web/` -> `web/` (git mv)

Shorter, standard monorepo convention. Dockerfiles stay inside each service dir (better build context isolation than root-level Dockerfiles).

### 2. Create `infra/` folder (borrowed from AXIOMFOLIO pattern)

Move Docker Compose and env files into `infra/`, with environment-specific naming:

```
infra/
  compose.dev.yaml        # Local dev (moved + renamed from root docker-compose.yml)
  env.dev.example         # Dev environment vars (consolidated from api + web .env.example files)
  env.prod.example        # Production reference (new -- documents what Render/Vercel need)
```

`**env.dev.example**` (consolidated, all vars in one file):

```
# === Database (Docker service names for dev) ===
DATABASE_URL=postgresql+asyncpg://filefree:filefree_dev@postgres:5432/filefree_dev

# === Redis ===
REDIS_URL=redis://redis:6379/0

# === Auth ===
SECRET_KEY=change-me-to-a-random-64-char-string
ACCESS_TOKEN_EXPIRE_MINUTES=30

# === OpenAI (blank = mock mode) ===
OPENAI_API_KEY=

# === Google Cloud (blank = mock mode) ===
GOOGLE_APPLICATION_CREDENTIALS=
GCS_BUCKET_NAME=filefree-uploads-dev

# === Frontend ===
NEXT_PUBLIC_API_URL=http://localhost:8000
FRONTEND_URL=http://localhost:3000

# === Environment ===
ENVIRONMENT=development
DEBUG=true
```

`**env.prod.example**` (reference for production setup):

```
# === Database (Neon serverless) ===
DATABASE_URL=postgresql+asyncpg://user:pass@host/dbname?sslmode=require

# === Redis (Upstash) ===
REDIS_URL=rediss://default:token@host:6379

# === Auth ===
SECRET_KEY=<generated-by-render>

# === External APIs ===
OPENAI_API_KEY=sk-...
GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
GCS_BUCKET_NAME=filefree-uploads-prod

# === Frontend ===
NEXT_PUBLIC_API_URL=https://api.filefree.tax
FRONTEND_URL=https://filefree.tax

# === Environment ===
ENVIRONMENT=production
DEBUG=false
```

The Makefile handles the `-f` flag: `docker compose -f infra/compose.dev.yaml up`. The `make setup` target copies `infra/env.dev.example` to `infra/env.dev`. Compose references `env_file: ../infra/env.dev` or uses Makefile's `--env-file`.

Delete: `api/.env.example`, `api/.env`, `web/.env.example`, `web/.env.local`, root `docker-compose.yml`.

### 3. Delete `scripts/` folder

Delete `scripts/validate_ocr.py` and `scripts/requirements.txt`. Premature -- the OCR pipeline will be built as proper backend services in Sprint 2 (`api/app/services/ocr/`) with tests in `api/tests/`.

### 4. Update all file references

Files that reference `filefree-api`, `filefree-web`, `docker-compose.yml`, or per-service env paths:

- [Makefile](Makefile) -- service dirs, compose file path (`-f infra/compose.dev.yaml`), setup target
- [render.yaml](render.yaml) -- buildCommand, startCommand paths
- [pyproject.toml](pyproject.toml) -- `src`, `testpaths`
- [README.md](README.md) -- project structure, setup instructions
- [.cursorrules](.cursorrules) -- dependency path references
- [.cursor/rules/engineering.mdc](.cursor/rules/engineering.mdc) -- dependency path references, infra section
- [TASKS.md](TASKS.md) -- Task 0.1 file references
- [KNOWLEDGE.md](KNOWLEDGE.md) -- D18 entry

### Final structure

```
filefree/
  api/                      # FastAPI backend
    app/
      __init__.py
      main.py
    tests/
    Dockerfile
    requirements.txt
  web/                      # Next.js frontend
    src/app/
    Dockerfile.dev
    package.json
    next.config.mjs
    tsconfig.json
  infra/                    # Compose + env files (per AXIOMFOLIO pattern)
    compose.dev.yaml
    env.dev.example
    env.prod.example
  Makefile                  # Abstracts compose -f path
  render.yaml               # Render Blueprints (must be at root)
  pyproject.toml
  .gitignore
  .python-version
  .node-version
  README.md
  TASKS.md, PRD.md, etc.   # Docs stay at root for now
```

