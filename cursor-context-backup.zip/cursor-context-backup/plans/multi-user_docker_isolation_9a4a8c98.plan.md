---
name: Multi-User Docker Isolation
overview: Docker volumes and containers are shared across Mac user accounts because Docker Desktop runs a single daemon. Use a per-user Compose project name to isolate dev databases.
todos: []
isProject: false
---

# Multi-User Docker Dev Isolation

## What's Happening

**Yes — Docker is serving the other user's database.** Here's why:

```mermaid
flowchart TB
    subgraph mac [Same Mac]
        UserA[User A / sankalpsharma]
        UserB[User B / other account]
    end
    
    subgraph docker [Docker Desktop - Single Daemon]
        Daemon[Docker Daemon]
    end
    
    subgraph volumes [Shared Volumes]
        PG[(postgres_data_v16)]
        Redis[(redis_data)]
    end
    
    subgraph containers [Shared Containers]
        Postgres[axiomfolio-postgres]
    end
    
    UserA -->|docker compose up| Daemon
    UserB -->|docker compose up| Daemon
    Daemon --> Postgres
    Postgres --> PG
```



**Root cause:**

- Docker Desktop on macOS runs **one daemon** for the entire Mac — not per user.
- Both users use the same Compose project name: `axiomfolio` (from [Makefile](Makefile) line 9: `PROJECT ?= axiomfolio`).
- Same project name → same volume prefixes (`axiomfolio_postgres_data_v16`) → **same Postgres data**.
- Same container names (`axiomfolio-postgres`) → only one set of containers; whoever runs last owns them, but the volume data persists for both.

So when you (sankalpsharma) and the other account both run `make up` or `./run.sh`, you share:

- Postgres data in `postgres_data_v16`
- Redis data in `redis_data`
- Broker accounts, positions, users — everything

---

## Fix: Per-User Project Name

Make the Compose project name include the OS username so each Mac user gets isolated containers and volumes.

### Option A: Makefile Default (Recommended)

Change [Makefile](Makefile) to derive project name from `$USER` when unset:

```makefile
PROJECT ?= axiomfolio_$(shell whoami)
```

- User sankalpsharma → `axiomfolio_sankalpsharma` → volumes `axiomfolio_sankalpsharma_postgres_data_v16`
- Other user → `axiomfolio_otheruser` → separate volumes
- Single-user machines can override: `make up PROJECT=axiomfolio`

### Option B: env.dev Override

Add to [infra/env.dev.example](infra/env.dev.example) and document:

```
# Optional: per-user isolation when multiple Mac accounts run dev
# COMPOSE_PROJECT_NAME=axiomfolio_$(whoami)
```

Then in Makefile: `PROJECT ?= $(shell grep -E '^COMPOSE_PROJECT_NAME=' $(ENV_DEV) 2>/dev/null | cut -d= -f2 || echo axiomfolio_$(shell whoami))`

This is more flexible but adds complexity. Option A is simpler.

---

## Implementation

1. **Makefile**
  - Change `PROJECT ?= axiomfolio` to `PROJECT ?= axiomfolio_$(shell whoami)`
  - Keep `PROJECT_TEST ?= axiomfolio_test` — tests should remain shared/standard.
2. **Port Conflicts**
  - Both users can't bind to 5432, 8000, 3000 at once. If both run simultaneously, the second will fail with "port already in use."
  - For true parallel dev, users would need different ports in env.dev (e.g. `DB_HOST_PORT=5433`). That's a separate step; the immediate fix stops DB data sharing.
3. **Docs**
  - Add a short note to [docs/CHAT_SUMMARY_20260219.md](docs/CHAT_SUMMARY_20260219.md) or a new `docs/DEV_SETUP.md` section:
  - "Multi-user Mac: Each OS user gets isolated Postgres/Redis via `PROJECT=axiomfolio_$(whoami)`. Override with `PROJECT=axiomfolio` for single-user."
4. **Existing Data**
  - After switching, your project will use fresh volumes. Old `axiomfolio_postgres_data_v16` stays until removed. To wipe and start clean: `docker compose -p axiomfolio down -v` (then re-run with new project).

---

## Files to Change


| File                                              | Change                                  |
| ------------------------------------------------- | --------------------------------------- |
| [Makefile](Makefile)                              | `PROJECT ?= axiomfolio_$(shell whoami)` |
| [docs/DEV_SETUP.md](docs/DEV_SETUP.md) or similar | Document multi-user isolation           |


---

## Verification

1. As sankalpsharma: `make up` → containers like `axiomfolio_sankalpsharma-postgres-1`
2. As other user: `make up` → `axiomfolio_otheruser-postgres-1`
3. `docker volume ls` shows separate `axiomfolio_*_postgres_data_v16` volumes

