---
name: admin-dashboard-v2-cutover
overview: Replace-in-place Admin Dashboard rebuild with strict composite health, consolidated API, and monolith decomposition to reduce tech debt.
todos:
  - id: backend-health-service
    content: Create backend/services/market/admin_health_service.py with strict composite health aggregation (coverage + stage + jobs + audit + task_runs). Thresholds in a constants dict. Single typed response.
    status: completed
  - id: backend-endpoint-consolidate
    content: "Add GET /admin/health endpoint in market_data.py. Include task_runs timestamps so /admin/tasks/status can be deleted. Delete old endpoints: /admin/stage-quality, /admin/jobs/summary, /admin/market-audit, /admin/tasks/status."
    status: completed
  - id: frontend-extract-components
    content: "Extract from AdminDashboard.tsx into focused subcomponents: AdminHealthBanner, AdminDomainCards, CoverageDailyHistogram, CoverageSparklineView, AdminOperatorActions (safe vs destructive grouping), AdminReleaseControls."
    status: completed
  - id: frontend-hook-and-types
    content: Create useAdminHealth hook (single fetch replaces 4 load functions), define typed interfaces for health response, remove all any-typed admin state.
    status: completed
  - id: frontend-rewrite-dashboard
    content: Rewrite AdminDashboard.tsx in-place as thin orchestration using extracted components and new hook. Add histogram/sparkline toggle.
    status: completed
  - id: tests
    content: "Backend: test strict composite health outcomes (green/yellow/red). Frontend: test health banner rendering, domain cards, histogram toggle, action grouping."
    status: completed
  - id: delete-legacy
    content: Delete old individual endpoints from backend, remove dead load functions/state from frontend, remove unused CoverageActionsList export.
    status: completed
isProject: false
---

# Admin Dashboard Rebuild -- Replace In-Place

## Problem

`AdminDashboard.tsx` is a 1145-line monolith with 25+ state variables, 4 separate API fetches on mount, and an inline 120-line histogram. The backend exposes 4+ overlapping admin health endpoints that each return partial views. "Green" status only reflects daily bar completeness, not actual system health.

## Architecture

```mermaid
flowchart TD
  subgraph frontend [Frontend]
    dashboard[AdminDashboard]
    hook[useAdminHealth]
    banner[AdminHealthBanner]
    cards[AdminDomainCards]
    histogram[CoverageDailyHistogram]
    sparkline[CoverageSparklineView]
    actions[AdminOperatorActions]
    release[AdminReleaseControls]
    dashboard --> hook
    dashboard --> banner
    dashboard --> cards
    dashboard --> histogram
    dashboard --> sparkline
    dashboard --> actions
    dashboard --> release
  end

  subgraph backend [Backend]
    endpoint["GET /admin/health"]
    svc[AdminHealthService]
    endpoint --> svc
    svc --> coverageSvc[CoverageService]
    svc --> stageQuality["stage_quality_summary()"]
    svc --> jobsSummary["jobs_summary()"]
    svc --> auditStore["Redis market_audit"]
    svc --> taskRuns["Redis task status"]
  end

  hook -->|single fetch| endpoint
```



## Backend Changes

### New file: `backend/services/market/admin_health_service.py`

Single aggregation service that composes all health dimensions into one response:

```python
# Thresholds in a constants dict -- tune here, not scattered across code
HEALTH_THRESHOLDS = {
    "coverage_daily_pct_min": 95,
    "coverage_stale_daily_max": 0,
    "stage_unknown_rate_max": 0.35,
    "stage_invalid_max": 0,
    "stage_monotonicity_max": 0,
    "jobs_error_max": 0,
    "jobs_lookback_hours": 24,
    "audit_daily_fill_pct_min": 95,
    "audit_snapshot_fill_pct_min": 90,
}

class AdminHealthService:
    def get_composite_health(self, db: Session) -> dict:
        # Returns:
        # {
        #   "composite_status": "green" | "yellow" | "red",
        #   "composite_reason": str,
        #   "dimensions": {
        #     "coverage": { "status", "daily_pct", "stale_daily", "expected_date", ... },
        #     "stage_quality": { "status", "unknown_rate", "invalid_count", ... },
        #     "jobs": { "status", "success_rate", "error_count", "latest_failed", ... },
        #     "audit": { "status", "tracked_total", "daily_fill_pct", ... },
        #   },
        #   "task_runs": { "admin_coverage_refresh": { "ts": ... }, ... },
        #   "thresholds": HEALTH_THRESHOLDS,
        #   "checked_at": str
        # }
```

**Strict composite logic:** `green` only when ALL dimensions pass their thresholds. Any single failure -> `yellow`. Multiple or critical -> `red`.

**Task runs included:** `task_runs` dict carries the same Redis task-status timestamps that `/admin/tasks/status` currently returns, so that endpoint can be deleted without losing the monitor/backfill timestamp display.

### Endpoint changes in `backend/api/routes/market_data.py`

- **Add:** `GET /admin/health` -- calls `AdminHealthService.get_composite_health(db)`.
- **Delete:**
  - `GET /admin/stage-quality` (now in `dimensions.stage_quality`)
  - `GET /admin/jobs/summary` (now in `dimensions.jobs`)
  - `GET /admin/market-audit` (now in `dimensions.audit`)
  - `GET /admin/tasks/status` (now in `task_runs`)

**Keep as-is:** All action/backfill endpoints, coverage endpoint, jobs list endpoint, sanity check, stage repair.

## Frontend Changes

### New hook: `frontend/src/hooks/useAdminHealth.ts`

- Single `GET /market-data/admin/health` fetch.
- Typed response interface (no `any`).
- Returns `{ health, loading, refresh }`.
- Replaces `loadStageQuality`, `loadJobsSummary`, `loadMarketAudit`, `loadTaskStatus` + their 4 state vars.

### New types: `frontend/src/types/adminHealth.ts`

```typescript
interface AdminHealthResponse {
  composite_status: 'green' | 'yellow' | 'red';
  composite_reason: string;
  dimensions: {
    coverage: CoverageDimension;
    stage_quality: StageQualityDimension;
    jobs: JobsDimension;
    audit: AuditDimension;
  };
  task_runs: Record<string, { ts: string | null }>;
  thresholds: Record<string, number>;
  checked_at: string;
}
```

### Extracted components (new files under `frontend/src/components/admin/`):

- `AdminHealthBanner` -- Top composite status badge + reason + per-dimension status chips (~60 lines)
- `AdminDomainCards` -- 2x2 grid of Coverage/Stage/Jobs/Audit detail cards (~120 lines)
- `CoverageDailyHistogram` -- Extracted histogram JSX shared by both AdminDashboard and MarketCoverage (replaces near-duplicate ~~85-line inline histogram in each). Accepts `variant` prop ("compact" for MarketCoverage dots, "detailed" for AdminDashboard strips) (~~140 lines)
- `CoverageSparklineView` -- Simpler alternative using Recharts AreaChart (~80 lines)
- `AdminOperatorActions` -- Collapsible actions, grouped into safe-default (backfill daily, refresh coverage) vs advanced-destructive (since-date backfills, recompute, retention) with confirm on destructive (~200 lines)
- `AdminReleaseControls` -- Market-only/portfolio/strategy toggles (~60 lines)

### Rewrite `AdminDashboard.tsx` in-place:

Goal: thin orchestration layer that composes hooks and components. No inline business logic or giant JSX blocks.

```
AdminDashboard
  AdminHealthBanner (composite status from useAdminHealth)
  CoverageSummaryCard (existing, wraps useCoverageSnapshot data)
    CoverageKpiGrid
    CoverageTrendGrid
    CoverageBucketsGrid
    AdminReleaseControls
    AdminDomainCards (stage/jobs/audit detail from useAdminHealth)
    [Toggle: Histogram | Sparkline]
      CoverageDailyHistogram / CoverageSparklineView
    Metadata badges row (uses task_runs from useAdminHealth)
    5m toggle
    AdminOperatorActions (collapsible, safe vs destructive grouping)
```

### State cleanup -- delete from dashboard:

- `stageQuality`, `jobsSummary`, `marketAudit`, `taskStatus` state vars
- `loadStageQuality()`, `loadJobsSummary()`, `loadMarketAudit()`, `loadTaskStatus()` functions
- `fmtLastRun()` helper (moves into `AdminHealthBanner` or consumes `task_runs` directly)

## Tech Debt Kills

- Remove unused `CoverageActionsList` export from `CoverageSummaryCard.tsx`
- Remove all `any` types for admin health data
- Consolidate 4 API calls into 1
- Delete 4 backend endpoints
- Inline histogram JSX moved to shared component (kills duplicate code in both AdminDashboard and MarketCoverage)
- Action grouping replaces flat sprawl
- MarketCoverage read-only page unaffected (uses useCoverageSnapshot + GET /coverage, both untouched)

## Tests

**Backend:**

- `test_admin_health_composite.py`: green/yellow/red strict outcomes, edge cases (empty DB, partial failures), task_runs included

**Frontend:**

- `AdminDashboard.test.tsx`: renders health banner, domain cards, histogram toggle, action grouping
- `useAdminHealth.test.ts`: fetch lifecycle, error handling, typed response

## Execution Order

1. Backend: create `AdminHealthService` with thresholds constants + `GET /admin/health` endpoint + tests
2. Frontend: create types, hook, extract 6 components
3. Frontend: rewrite `AdminDashboard.tsx` in-place as thin orchestration
4. Verify all tests pass (lint + typecheck + unit)
5. Delete old endpoints and dead frontend code

