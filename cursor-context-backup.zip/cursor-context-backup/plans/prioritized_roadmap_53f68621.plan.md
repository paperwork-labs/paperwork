---
name: Prioritized Roadmap
overview: Comprehensive prioritized roadmap covering agent autonomy, core product, landing page, and TASKS.md gap analysis. Organized by critical dates with the April 15 tax deadline as the forcing function.
todos:
  - id: update-tasks-md
    content: "Update TASKS.md: re-open 0.4 for content, add Task 0.5 (analytics), add Task B.11 (agent autonomy), update B.6/D21/D23"
    status: completed
  - id: landing-page
    content: "Build landing page content: hero, how-it-works, trust badges, email capture, social links, responsive dark theme"
    status: completed
  - id: agent-autonomy
    content: "Wire n8n workflows to real outputs: Notion pages, Postiz scheduling, GitHub issues (no code changes, just n8n node config)"
    status: completed
  - id: analytics-foundation
    content: PostHog setup + UTM tracking + funnel events before landing page goes live
    status: completed
  - id: sprint0-ops
    content: EFIN application (this week!), LLC/bank, privacy policy + ToS drafts
    status: completed
isProject: false
---

# Prioritized Roadmap — FileFree Next Steps

## Where We Stand

**Infrastructure (100% done):**

- Vercel (frontend), Render Starter (API), Neon (DB connected + migrated), Hetzner (n8n + Postiz), DNS configured
- Docker dev environment with test isolation
- 16 passing tests, CI-ready

**Sprint 0 Business Ops (~40% done):**

- DONE: B.4 (Notion), B.6 (Hetzner/n8n, 6 workflows imported + OpenAI key added), B.7 (Partnership Foundation)
- NOT DONE: B.1 (EFIN), B.2 (Company Setup), B.3/B.10 (Legal), B.5/B.9 (Column Tax), B.8 (Affiliates)

**Sprint 1 Foundation (100% done):**

- Tasks 0.1-0.4 all DONE (Docker, Frontend, Backend, Landing infra + deploy)

**Code shipped:** 7 SQLAlchemy models, health/waitlist endpoints, design system, 22 shadcn components, PII scrubber, encryption, rate limiter, correlation IDs

---

## TASKS.md Gap Analysis

TASKS.md is **solid** — it covers 95% of what we need. Three gaps:

1. **Agent autonomy** is not a task — TASKS.md has the n8n infra setup (B.6) but not the next step: wiring workflows to real outputs (Notion pages, Postiz posts, GitHub issues, Slack notifications). This should be a new task.
2. **Landing page content** — Task 0.4 is marked DONE but only the infrastructure shipped (Vercel, Render, DNS, waitlist endpoint). The actual landing page content (hero copy, how-it-works, trust badges, social links, email capture) hasn't been built yet. Task 0.4 needs to be split or re-opened.
3. **Attribution from day one** — Task 2.7 covers PostHog/analytics but it's in Sprint 3 (April-May). UTM capture code exists in the frontend, but we need PostHog wired up before the landing page goes live, not after. Should be pulled forward.

**Recommendation:** Add a new Task B.11 for agent autonomy. Re-open Task 0.4 for landing page content. Pull analytics setup from 2.7 into a lightweight "Task 0.5 — Analytics Foundation."

---

## Prioritized Roadmap

### Phase 1: Get Live + Start Content Engine (March 9-23)

**Priority A — Landing Page Content (re-open Task 0.4)**
The #1 thing that matters right now. Infrastructure is done, but filefree.tax has no content.

- Build the actual landing page: hero, 3-step how-it-works, trust badges, email capture, anti-TurboTax hook
- Mobile-first, dark theme, gradient accents
- Social links in footer
- Wire waitlist form to POST /api/v1/waitlist
- Target: filefree.tax is shareable by March 16

**Priority B — Agent Autonomy (new Task B.11)**
Make the 6 n8n persona workflows actually useful by connecting outputs to real systems:

- **Social Content Generator** -> drafts post -> creates Notion page in Content Calendar -> optionally schedules in Postiz
- **Growth Content Writer** -> drafts blog post -> creates Notion page for review
- **Weekly Strategy Check-in** (already on cron) -> writes summary to Notion Decision Log
- **QA Security Scan** -> creates GitHub Issue with findings
- **Partnership Outreach Drafter** -> creates Notion entry in Partnership Pipeline
- **CPA Tax Review** -> creates Notion page with review notes

This is all n8n node wiring — no code changes needed. Each workflow gets 2-3 additional nodes (Notion API, GitHub API, Postiz API).

**Priority C — Sprint 0 Business Ops (parallel, non-code)**

- B.1: EFIN application (45-day lead time — APPLY THIS WEEK)
- B.2: LLC, bank account, social media accounts
- B.10: Privacy policy + ToS drafts (needed before landing page goes live)

### Phase 2: OCR Demo for April 15 Traffic (March 23 - April 5)

This is Sprint 2 from TASKS.md — the "wow moment."

- Task 1.1: Camera component + image quality checks
- Task 1.2: Tiered OCR pipeline (Cloud Vision + GPT-4o-mini)
- Task 1.3: Try-before-signup frontend (snap a W-2 without an account)
- Task 0.5 (new): Analytics foundation — PostHog, UTM tracking, funnel events (pulled from 2.7)

### Phase 3: Content Push (April 5-15)

Ride the April 15 tax deadline traffic spike.

- Task 1.4: SEO pages, content articles, pixels, pricing page
- n8n agents generating daily social content via Postiz
- First creator outreach (10 DMs to micro-influencers)
- B.8: Affiliate applications (Marcus, Wealthfront, Betterment, Fidelity)

### Phase 4: Full MVP (April 15 - May 31)

Sprint 3 from TASKS.md — complete filing flow for extension filers.

- Tasks 2.1-2.2: Auth system (Google One-Tap, Apple Sign In, email/password)
- Tasks 2.3-2.5: Filing flow, tax calculator, PDF generation
- Tasks 2.6-2.7: Polish, error handling, monitoring
- B.5/B.9: Column Tax demo + sandbox access

### Phase 5: Growth + E-File (June - January 2027)

Sprints 4-6 from TASKS.md — unchanged, well-scoped.

---

## Summary: What Needs to Change in TASKS.md


| Change           | Description                                                         |
| ---------------- | ------------------------------------------------------------------- |
| Re-open Task 0.4 | Landing page content not yet built (only infra shipped)             |
| New Task 0.5     | Analytics foundation (PostHog + UTM) — pulled forward from Task 2.7 |
| New Task B.11    | Agent autonomy — wire n8n workflows to Notion, Postiz, GitHub       |
| Update B.6       | Mark OpenAI credential as DONE                                      |
| Update D21       | Render is now Starter plan ($7/mo), not free tier                   |
| Update D23       | Neon DB connected + migrated, alembic running on startup            |


