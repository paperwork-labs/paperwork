---
name: UI+Pagination No Tests
overview: Fix shell layout (no horizontal scroll), implement server-paged AdminJobs with modern pagination, fix coverage KPI at backend source, switch table actions to icon buttons, and document Ladle + Chakra v3 architecture. Testing deferred.
todos:
  - id: layout-shell
    content: Fix DashboardLayout + SettingsShell layout so collapsed sidebar never causes horizontal scroll; implement hybrid icon-rail/overlay behavior
    status: pending
  - id: adminjobs-pagination
    content: Implement server-paged AdminJobs with reusable Pagination component (page size dropdown + totals + ellipsis paging)
    status: pending
  - id: icon-actions
    content: Convert AdminJobs/AdminSchedules action buttons to icon buttons with tooltips (accessible aria-labels)
    status: pending
  - id: coverage-kpi-backend
    content: Fix backend coverage meta.kpis generation so stale_m5==0 becomes “All 5m covered”; remove frontend override to avoid band-aids
    status: pending
  - id: docs-ladle-chakra
    content: Write docs for Ladle usage and Chakra v3 system architecture; confirm .ladle provider matches app provider
    status: pending
---

# UI Shell + Pagination + Coverage KPI Fix (tests deferred)

## Goal

- Fix layout issues (no horizontal scroll/drift when sidebar collapses; SettingsShell background/width clean on all screens).
- Implement Admin Jobs server-side pagination with compact, modern controls.
- Fix coverage KPI messaging at the backend source (no frontend band-aids).
- Use icon actions (with tooltips) across Admin tables to save space.
- Add docs for Ladle + Chakra v3 architecture and ensure Ladle provider matches refreshed v3 system.

## Workstream A — Layout cleanup (hybrid collapse)

- Update [`frontend/src/components/layout/DashboardLayout.tsx`](frontend/src/components/layout/DashboardLayout.tsx):
- Hybrid behavior: icon-rail on desktop, overlay drawer on small screens.
- Remove width/margin math causing negative offsets.
- Enforce `minW={0}` on flex children and `overflowX="hidden"` where appropriate.
- Update [`frontend/src/pages/SettingsShell.tsx`](frontend/src/pages/SettingsShell.tsx):
- Ensure sidebar/content align cleanly and share consistent background tokens.

## Workstream B — Admin Jobs pagination (server-side)

- Add a reusable pagination component (or restore existing):
- [`frontend/src/components/ui/Pagination.tsx`](frontend/src/components/ui/Pagination.tsx)
- Page size: 10/25/50/100 (default 25)
- Numbered pages with ellipsis + prev/next
- Range label: `1–25 of 4585`
- Update [`frontend/src/pages/AdminJobs.tsx`](frontend/src/pages/AdminJobs.tsx) to use backend `limit/offset` and the new pagination UI.

## Workstream C — Admin actions as icons

- Update Admin tables to use **icon buttons with tooltips** for actions:
- Jobs: Details/Error log
- Schedules: Run now / Pause-Resume / Delete
- Keep text labels only where needed for accessibility (tooltip + aria-label).

## Workstream D — Coverage KPI correctness (backend source of truth)

- Update [`backend/api/routes/market_data.py`](backend/api/routes/market_data.py) KPI generator (`_kpi_cards()`):
- `stale_m5 == 0` → “All 5m covered”
- else → “N missing 5m”
- Remove the frontend override logic from [`frontend/src/utils/coverage.ts`](frontend/src/utils/coverage.ts) so frontend reflects backend truth.

## Workstream E — Docs (Ladle + Chakra v3)

- Confirm [`frontend/.ladle/components.tsx`](frontend/.ladle/components.tsx) uses the v3 provider stack (Chakra v3 `system` + color mode provider).
- Add [`docs/frontend-ui.md`](docs/frontend-ui.md):
- How to run/view Ladle locally
- Chakra v3 architecture used here (system/semantic tokens + primitives)
- Where UI dependency versions live and how to update

## Smoke checks

- Toggle sidebar on desktop and mobile width: no horizontal scroll.
- Settings routes render without background bleed.
- `/settings/admin/jobs` paginates properly and shows correct totals.
- Coverage KPI shows “All 5m covered” when `stale_m5 == 0`.

## Implementation Todos

- `layout-shell`