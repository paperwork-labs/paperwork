---
name: Intelligence Experimentation Retention Moat
status: archived
overview: "ARCHIVED — Content integrated into Venture Master Plan Section 4K/4L. Three strategic additions to the intelligence engine: experimentation platform, retention intelligence, and credit score strategy."
todos:
  - id: add-experimentation
    content: "Add Experimentation Platform subsection to Section 5B: PostHog feature flags (Phase 1) -> Thompson Sampling bandit (Phase 2) -> ML models (Phase 3). Include FTC compliance constraint."
    status: in_progress
  - id: add-retention
    content: "Add Retention Intelligence subsection to Section 5B: churn signals, lifecycle campaign table (7 triggers), ChurnGuard AI for MVP prediction, web push (Phase 2+)."
    status: pending
  - id: revise-credit-timeline
    content: Revise credit score timeline from Phase 2 to Phase 1.5 (Launch + 3 months). Add data moat argument. Update Phase descriptions, package structure, and mermaid diagram.
    status: pending
  - id: update-package-structure
    content: Expand packages/intelligence module list to include experimentation, retention, and campaign modules.
    status: pending
  - id: sync-and-commit
    content: Update KNOWLEDGE.md with new decisions, sync VENTURE_MASTER_PLAN.md, commit and push to existing branch.
    status: pending
isProject: false
---

# Intelligence Engine: Experimentation, Retention, and Data Moat

All three additions go into the existing **Section 5B (Recommendation Intelligence Engine)** of the master plan, expanding it from a recommendation system into a full-stack intelligence platform.

---

## 1. Experimentation Platform (Our "Darwin")

CK's Darwin runs 22,000 models/month and 60B predictions/day. We don't need that scale. We need a lightweight framework that grows.

**Research context:**

- CK's Darwin is a unified ML experimentation system powering ~80% of their operations
- Google published a 2024 paper on user simulation to minimize live A/B tests in recsys (tested on YouTube Music onboarding)
- Capital One's FinTRec (2025) uses transformer-based contextual targeting for financial products
- Meta's PEX framework optimizes treatment assignment with heterogeneous treatment effect modeling
- **FTC warning**: CK got fined in 2022 for A/B testing "pre-approved" language that was misleading. Our experimentation must NEVER test language implying guaranteed approval.

**Phased implementation:**

- **Phase 1 (Launch)** -- Feature flags + simple A/B via PostHog (already in stack, free tier: 1M events/mo). Test: recommendation card placement, partner ordering, CTA copy. Track: CTR, conversion rate, revenue per impression. No ML needed.
- **Phase 2 (10K+ users)** -- Multi-Armed Bandit (Thompson Sampling) for partner ranking. Auto-allocates traffic to higher-converting partners. Personalized ranking by user profile. Implementation: `scipy.stats.beta` in the recommendation API, ~200 lines of Python.
- **Phase 3 (50K+ users)** -- ML recommendation models. Collaborative filtering on user-partner interaction data. Input: financial profile + behavioral signals. Output: ranked partners with predicted conversion probability. Serve via FastAPI.

**FTC compliance constraint**: Baked into the framework -- experiments can NEVER test language like "pre-approved", "guaranteed", or "you qualify." Only "may qualify", "based on your profile", "personalized for you."

---

## 2. Retention Intelligence (Churn + Lifecycle Campaigns)

Tax filing is seasonal (Jan-Apr). LLC formation is one-time. Without retention, we lose users after the transaction. The intelligence engine must keep users engaged year-round. **The data compounds year-over-year -- 2nd-season users have income trajectory + credit score delta.**

**Churn prediction signals:**

- Days since last login
- Repeat vs one-time filer
- Recommendation engagement (click, convert, ignore)
- Email opt-out
- Credit score change (score drops = financial stress = re-engagement opportunity)

**Lifecycle campaigns (n8n workflows + `packages/email`):**

- Filed taxes, no refund action (3 days post-filing): "Your $X refund is coming -- here's where to put it"
- Filed taxes, 6 months no return (July): Mid-year check-in, "your tax profile is getting smarter"
- Formed LLC, no banking setup (7 days post-formation): "Your LLC needs a bank account"
- Credit score dropped 20+ pts (within 48 hours): "Your credit score changed -- here's what to know"
- Tax season approaching, returning user (January): "Your W-2 info is pre-filled from last year"
- Annual report deadline approaching (30 days before): "[State] annual report due in X days"
- No login for 90 days: Value recap email showing what we know about their financial profile

**Churn prediction model (Phase 2+):**

- MVP: ChurnGuard AI (open-source, connects PostHog + Stripe, 15-min setup)
- Features: login frequency, recommendation engagement, email open rate, conversion history
- Output: risk score (Critical/High/Medium/Low) per user
- Critical risk users get personalized re-engagement (AI-drafted, founder-approved email)

**Push notifications (Phase 2+):**

- Web push via service worker (no app store)
- Opt-in only, max 2/week, only high-value triggers (credit score change, tax season, deadlines)

**Data as moat**: Every interaction adds data points. Every campaign response adds behavioral signal. Year 2 users have 2 years of income data, credit trajectory, engagement history. This compounds and cannot be replicated by competitors who only see one-time transactions.

---

## 3. Early Credit Score = The Real Data Moat

**The user's insight is correct**: CK's moat isn't the credit score itself (Intuit, NerdWallet, every bank shows free scores now). CK's moat is **2,500 data points per user** accumulated over time. We have a unique advantage CK never had: **we see the actual tax return.** That is the most complete financial snapshot that exists.

**What FileFree knows from a single filing that CK doesn't:**

- Exact income (actual W-2 Box 1, not self-reported range)
- Filing status (single/married/HOH = household composition)
- Dependents (family size, child ages)
- Refund/owed amount (disposable income signal)
- State (cost of living context)
- Employer (stability signal)

**Add credit score and we have:**

- Income + creditworthiness = approval odds for any financial product
- Refund amount + credit score = right HYSA vs right credit card recommendation
- Business owner (LaunchFree) + personal credit score = business credit/loan eligibility

**Partners will pay a premium** for users described as "W-2 income $75K, 720+ score, $3,200 refund, single, CA, age 28." That's not a lead; that's a pre-qualified customer. CK charges $25-1,250/referral because of this.

**Revised timeline -- move credit score to Phase 1.5 (Launch + 3 months):**

- Soft pull only (never affects user's score)
- TransUnion reseller (Array or SavvyMoney): ~$0.50-2.00/pull, no direct bureau contract needed, Array provides embeddable widget
- Alternative: Plaid LendScore (cash-flow scoring, trained on ~1B transactions, 25% better for thin files)
- FCRA compliance required: disclosures, dispute process. Budget ~~$500-1K for legal review. This is the bottleneck, not the engineering (~~1 week).
- UX: "Want personalized financial recommendations? Let us check your credit score -- it won't affect your score." Subtle, opt-in, value-first framing.

**Why Phase 1.5 not Phase 2**: Every month we delay credit score integration, we lose data compounding. A user who files in January 2027 and gives us credit score permission immediately has 12 months of credit trajectory by January 2028. If we wait until Year 2, we have zero trajectory data for returning users. The moat starts building the day we turn on soft pulls.

---

## Changes to the Master Plan

All additions go into [docs/VENTURE_MASTER_PLAN.md](docs/VENTURE_MASTER_PLAN.md) and the Cursor plan file:

- **Section 5B (Intelligence Engine)**: Add three new subsections: "Experimentation Platform (Our Darwin)", "Retention Intelligence (Churn + Lifecycle)", and "Why Early Credit Score Is the Moat"
- **Phase timeline**: Add Phase 1.5 (credit score), shift current Phase 2 credit items earlier
- **Mermaid diagram**: Update to include Experimentation, Retention, and Campaigns as modules in the intelligence package
- **packages/intelligence structure**: Expand to include experimentation, retention engine, and campaign trigger modules alongside the existing profile builder and partner matcher
- **Section 6I (Org Chart)**: Add note about retention campaigns being n8n-automated
- **KNOWLEDGE.md**: Log decisions on experimentation framework choice (PostHog), credit score timing (Phase 1.5), and retention model (ChurnGuard AI)

