---
name: Brokerage Setup + Options Enrichment
overview: "Three improvements: (1) Add client_id to TastyTrade OAuth form, clean up stale DB data, and go through the proper per-user setup flow; (2) Improve wizard UX so clicking a broker auto-advances to step 2 with a clean back button; (3) Enrich the Options page with greeks (delta, gamma, theta, vega) and underlying price from TastyTrade sync data."
todos:
  - id: wizard-auto-advance
    content: "Wizard UX: Auto-advance on broker logo click, add back arrow in header, remove Next button"
    status: completed
  - id: tt-client-id
    content: Add client_id to TastyTrade form (frontend ttForm, api.ts, TTConnectRequest, _tt_connect_job, credential storage)
    status: completed
  - id: options-model-greeks
    content: Add delta/gamma/theta/vega/iv columns to Option model + Alembic migration
    status: completed
  - id: sync-persist-greeks
    content: Update _option_position_kwargs to pass greeks through during sync
    status: completed
  - id: api-return-greeks
    content: Return greeks + underlying_price from unified options portfolio API + add aggregate greeks to summary
    status: completed
  - id: options-frontend-enrich
    content: Enrich OptionPos type, redesign option rows to show greeks, add Net Delta/Theta stat cards
    status: completed
  - id: update-tests
    content: Update test_aggregator_tt_async (client_id in payload), verify sync stores greeks
    status: completed
isProject: false
---

# Brokerage Setup Flow + Options Page Enrichment

---

## Todo 1: `wizard-auto-advance` -- Wizard UX polish

**File: `frontend/src/pages/SettingsBrokerages.tsx`**

### Change 1A: Add FiArrowLeft import (line 39)

**StrReplace** old:

```
import { FiExternalLink, FiTrash2 } from 'react-icons/fi';
```

new:

```
import { FiArrowLeft, FiExternalLink, FiTrash2 } from 'react-icons/fi';
```

### Change 1B: Auto-advance on broker click (lines 501-505)

**StrReplace** old:

```
                <SimpleGrid columns={{ base: 3, md: 3 }} gap={6}>
                  <LogoTile label="Charles Schwab" srcs={[SchwabLogo]} selected={broker === 'SCHWAB'} onClick={() => setBroker('SCHWAB')} wide />
                  <LogoTile label="Tastytrade" srcs={[TastytradeLogo]} selected={broker === 'TASTYTRADE'} onClick={() => setBroker('TASTYTRADE')} wide />
                  <LogoTile label="Interactive Brokers" srcs={[IbkrLogo]} selected={broker === 'IBKR'} onClick={() => setBroker('IBKR')} wide />
                </SimpleGrid>
```

new:

```
                <SimpleGrid columns={{ base: 3, md: 3 }} gap={6}>
                  <LogoTile label="Charles Schwab" srcs={[SchwabLogo]} selected={broker === 'SCHWAB'} onClick={() => { setBroker('SCHWAB'); setStep(2); }} wide />
                  <LogoTile label="Tastytrade" srcs={[TastytradeLogo]} selected={broker === 'TASTYTRADE'} onClick={() => { setBroker('TASTYTRADE'); setStep(2); }} wide />
                  <LogoTile label="Interactive Brokers" srcs={[IbkrLogo]} selected={broker === 'IBKR'} onClick={() => { setBroker('IBKR'); setStep(2); }} wide />
                </SimpleGrid>
```

### Change 1C: Back arrow in dialog header (lines 494-496)

**StrReplace** old:

```
          <DialogHeader>
            <DialogTitle>New Brokerage Connection</DialogTitle>
          </DialogHeader>
```

new:

```
          <DialogHeader>
            <HStack gap={2}>
              {step === 2 && (
                <IconButton aria-label="Back" variant="ghost" size="sm" onClick={() => setStep(1)}>
                  <FiArrowLeft />
                </IconButton>
              )}
              <DialogTitle>New Brokerage Connection</DialogTitle>
            </HStack>
          </DialogHeader>
```

### Change 1D: Simplify footer -- remove "Next" button (lines 544-550)

**StrReplace** old:

```
          <DialogFooter>
            <HStack>
              {step > 1 && <Button variant="ghost" onClick={() => setStep(step - 1)}>Back</Button>}
              {step < 2 && <Button onClick={() => broker ? setStep(2) : null} disabled={!broker}>Next</Button>}
              {step === 2 && <Button loading={busy} onClick={submitWizard}>Connect</Button>}
            </HStack>
          </DialogFooter>
```

new:

```
          <DialogFooter>
            {step === 2 && <Button loading={busy} onClick={submitWizard}>Connect</Button>}
          </DialogFooter>
```

---

## Todo 2: `tt-client-id` -- Add client_id to TastyTrade flow

### Change 2A: ttForm state (file: `frontend/src/pages/SettingsBrokerages.tsx`, line 60)

**StrReplace** old:

```
  const [ttForm, setTtForm] = useState({ client_secret: '', refresh_token: '' });
```

new:

```
  const [ttForm, setTtForm] = useState({ client_id: '', client_secret: '', refresh_token: '' });
```

### Change 2B: TastyTrade wizard form fields (lines 520-533)

**StrReplace** old:

```
            {step === 2 && broker === 'TASTYTRADE' && (
              <VStack align="stretch" gap={3}>
                <Text fontWeight="semibold">Tastytrade OAuth</Text>
                <Text fontSize="xs" color="fg.muted">
                  Create an OAuth app at{' '}
                  <a href="https://my.tastytrade.com/app.html#/manage/api-access/oauth-applications" target="_blank" rel="noopener noreferrer" style={{ textDecoration: 'underline' }}>
                    my.tastytrade.com > API Access > OAuth
                  </a>
                  , then generate a refresh token under Manage > Create Grant.
                </Text>
                <Input placeholder="Client Secret" type="password" value={ttForm.client_secret} onChange={(e) => setTtForm({ ...ttForm, client_secret: e.target.value })} onKeyDown={(e) => { if (e.key === 'Enter') submitWizard(); }} />
                <Input placeholder="Refresh Token" type="password" value={ttForm.refresh_token} onChange={(e) => setTtForm({ ...ttForm, refresh_token: e.target.value })} onKeyDown={(e) => { if (e.key === 'Enter') submitWizard(); }} />
                <Text fontSize="xs" color="fg.muted">Refresh tokens never expire. Secrets are encrypted at rest.</Text>
              </VStack>
            )}
```

new:

```
            {step === 2 && broker === 'TASTYTRADE' && (
              <VStack align="stretch" gap={3}>
                <Text fontWeight="semibold">Tastytrade OAuth</Text>
                <Text fontSize="xs" color="fg.muted">
                  Create an OAuth app at{' '}
                  <a href="https://my.tastytrade.com/app.html#/manage/api-access/oauth-applications" target="_blank" rel="noopener noreferrer" style={{ textDecoration: 'underline' }}>
                    my.tastytrade.com > API Access > OAuth
                  </a>
                  , then generate a refresh token under Manage > Create Grant.
                </Text>
                <Input placeholder="Client ID" value={ttForm.client_id} onChange={(e) => setTtForm({ ...ttForm, client_id: e.target.value })} onKeyDown={(e) => { if (e.key === 'Enter') submitWizard(); }} />
                <Input placeholder="Client Secret" type="password" value={ttForm.client_secret} onChange={(e) => setTtForm({ ...ttForm, client_secret: e.target.value })} onKeyDown={(e) => { if (e.key === 'Enter') submitWizard(); }} />
                <Input placeholder="Refresh Token" type="password" value={ttForm.refresh_token} onChange={(e) => setTtForm({ ...ttForm, refresh_token: e.target.value })} onKeyDown={(e) => { if (e.key === 'Enter') submitWizard(); }} />
                <Text fontSize="xs" color="fg.muted">Refresh tokens never expire. Secrets are encrypted at rest.</Text>
              </VStack>
            )}
```

### Change 2C: handleTTConnect payload (line 214)

**StrReplace** old:

```
      const res: any = await aggregatorApi.tastytradeConnect({ client_secret: ttForm.client_secret.trim(), refresh_token: ttForm.refresh_token.trim() });
```

new (there are TWO occurrences of this pattern -- one in `handleTTConnect` at line 214 and one in `submitWizard` at line 289; update BOTH):

```
      const res: any = await aggregatorApi.tastytradeConnect({ client_id: ttForm.client_id.trim(), client_secret: ttForm.client_secret.trim(), refresh_token: ttForm.refresh_token.trim() });
```

### Change 2D: submitWizard validation (line 288)

**StrReplace** old:

```
        if (!ttForm.client_secret || !ttForm.refresh_token) throw new Error('Enter Tastytrade OAuth client secret and refresh token');
```

new:

```
        if (!ttForm.client_id || !ttForm.client_secret || !ttForm.refresh_token) throw new Error('Enter Tastytrade Client ID, Client Secret, and Refresh Token');
```

### Change 2E: api.ts payload type (file: `frontend/src/services/api.ts`, line 561)

**StrReplace** old:

```
  tastytradeConnect: async (payload: { client_secret: string; refresh_token: string }) =>
    makeOptimizedRequest(() => api.post('/aggregator/tastytrade/connect', payload, { timeout: 60000, _noRetry: true })),
```

new:

```
  tastytradeConnect: async (payload: { client_id: string; client_secret: string; refresh_token: string }) =>
    makeOptimizedRequest(() => api.post('/aggregator/tastytrade/connect', payload, { timeout: 60000, _noRetry: true })),
```

### Change 2F: TTConnectRequest model (file: `backend/api/routes/aggregator.py`, lines 216-218)

**StrReplace** old:

```
class TTConnectRequest(BaseModel):
    client_secret: str
    refresh_token: str
```

new:

```
class TTConnectRequest(BaseModel):
    client_id: str
    client_secret: str
    refresh_token: str
```

### Change 2G: _tt_connect_job signature (file: `backend/api/routes/aggregator.py`, line 231)

**StrReplace** old:

```
async def _tt_connect_job(job_id: str, client_secret: str, refresh_token: str, user_id: int):
```

new:

```
async def _tt_connect_job(job_id: str, client_id: str, client_secret: str, refresh_token: str, user_id: int):
```

### Change 2H: Credential payload inside _tt_connect_job (line 291)

**StrReplace** old:

```
            payload = {"client_secret": client_secret, "refresh_token": refresh_token}
```

new:

```
            payload = {"client_id": client_id, "client_secret": client_secret, "refresh_token": refresh_token}
```

### Change 2I: tastytrade_connect endpoint call (line 327)

**StrReplace** old:

```
    asyncio.create_task(_tt_connect_job(job_id, req.client_secret, req.refresh_token, user.id))
```

new:

```
    asyncio.create_task(_tt_connect_job(job_id, req.client_id, req.client_secret, req.refresh_token, user.id))
```

---

## Todo 3: `options-model-greeks` -- Add greeks columns to Option model

### Change 3A: Add columns (file: `backend/models/options.py`, after line 75)

**StrReplace** old:

```
    underlying_price = Column(Numeric(12, 4), nullable=True)  # Current underlying price

    # Exercise/Assignment Details
```

new:

```
    underlying_price = Column(Numeric(12, 4), nullable=True)  # Current underlying price

    # Greeks (snapshot at last sync)
    delta = Column(Numeric(10, 6), nullable=True)
    gamma = Column(Numeric(10, 6), nullable=True)
    theta = Column(Numeric(10, 6), nullable=True)
    vega = Column(Numeric(10, 6), nullable=True)
    implied_volatility = Column(Numeric(10, 4), nullable=True)

    # Exercise/Assignment Details
```

### Change 3B: Alembic migration

Run from project root:

```bash
cd backend && alembic revision --autogenerate -m "add_greeks_and_iv_to_options"
```

Then run:

```bash
alembic upgrade head
```

Or if running in Docker, exec into the backend container and run the same. If the app is in dev and tables are managed by `create_all`, just restart.

---

## Todo 4: `sync-persist-greeks` -- Persist greeks during sync

### Change 4A: Update return dict (file: `backend/services/portfolio/tastytrade_sync_service.py`, lines 400-414)

**StrReplace** old:

```
        return dict(
            user_id=ba.user_id,
            account_id=ba.id,
            symbol=symbol,
            underlying_symbol=underlying_symbol,
            strike_price=float(strike_price),
            expiry_date=exp_date,
            option_type=option_type,
            multiplier=mult,
            open_quantity=quantity,
            current_price=p.get("mark"),
            unrealized_pnl=unrealized,
            currency="USD",
            data_source="TASTYTRADE",
        )
```

new:

```
        return dict(
            user_id=ba.user_id,
            account_id=ba.id,
            symbol=symbol,
            underlying_symbol=underlying_symbol,
            strike_price=float(strike_price),
            expiry_date=exp_date,
            option_type=option_type,
            multiplier=mult,
            open_quantity=quantity,
            current_price=p.get("mark"),
            unrealized_pnl=unrealized,
            delta=p.get("delta"),
            gamma=p.get("gamma"),
            theta=p.get("theta"),
            vega=p.get("vega"),
            currency="USD",
            data_source="TASTYTRADE",
        )
```

---

## Todo 5: `api-return-greeks` -- Return greeks from API

### Change 5A: Add greeks to position dict (file: `backend/api/routes/portfolio_options.py`, lines 142-166)

**StrReplace** old:

```
            pos: Dict[str, Any] = {
                "id": p.id,
                "symbol": sym_value,
                "underlying_symbol": p.underlying_symbol or "",
                "strike_price": float(p.strike_price or 0),
                "expiration_date": p.expiry_date.isoformat() if p.expiry_date else None,
                "option_type": (p.option_type or "").lower(),
                "quantity": qty,
                "average_open_price": avg_cost,
                "current_price": cur_price,
                "market_value": mv,
                "unrealized_pnl": u_pnl,
                "unrealized_pnl_pct": (
                    (u_pnl / (float(p.total_cost or 0)) * 100)
                    if (p.total_cost and float(p.total_cost) != 0)
                    else 0.0
                ),
                "day_pnl": 0.0,
                "account_number": account_number,
                "days_to_expiration": _days_to_expiry(p.expiry_date),
                "multiplier": mult,
                "last_updated": (
                    p.updated_at or p.last_updated or datetime.utcnow()
                ).isoformat(),
            }
```

new:

```
            pos: Dict[str, Any] = {
                "id": p.id,
                "symbol": sym_value,
                "underlying_symbol": p.underlying_symbol or "",
                "strike_price": float(p.strike_price or 0),
                "expiration_date": p.expiry_date.isoformat() if p.expiry_date else None,
                "option_type": (p.option_type or "").lower(),
                "quantity": qty,
                "average_open_price": avg_cost,
                "current_price": cur_price,
                "market_value": mv,
                "unrealized_pnl": u_pnl,
                "unrealized_pnl_pct": (
                    (u_pnl / (float(p.total_cost or 0)) * 100)
                    if (p.total_cost and float(p.total_cost) != 0)
                    else 0.0
                ),
                "day_pnl": 0.0,
                "account_number": account_number,
                "days_to_expiration": _days_to_expiry(p.expiry_date),
                "multiplier": mult,
                "delta": float(p.delta) if p.delta is not None else None,
                "gamma": float(p.gamma) if p.gamma is not None else None,
                "theta": float(p.theta) if p.theta is not None else None,
                "vega": float(p.vega) if p.vega is not None else None,
                "implied_volatility": float(p.implied_volatility) if p.implied_volatility is not None else None,
                "underlying_price": float(p.underlying_price) if p.underlying_price is not None else None,
                "cost_basis": float(p.total_cost) if p.total_cost else None,
                "last_updated": (
                    p.updated_at or p.last_updated or datetime.utcnow()
                ).isoformat(),
            }
```

### Change 5B: Add aggregate greeks to summary (file: `backend/api/routes/portfolio_options.py`, lines 217-243)

**StrReplace** old:

```
        summary = {
            "total_positions": len(positions),
            "total_market_value": total_value,
            "total_unrealized_pnl": total_pnl,
            "total_unrealized_pnl_pct": (
                (total_pnl / total_value * 100) if total_value else 0.0
            ),
            "total_day_pnl": 0.0,
            "total_day_pnl_pct": 0.0,
            "calls_count": len(calls),
            "puts_count": len(puts),
            "expiring_this_week": sum(
                1 for p in positions if (p.get("days_to_expiration", 0) <= 7)
            ),
            "expiring_this_month": sum(
                1 for p in positions if (p.get("days_to_expiration", 0) <= 30)
            ),
            "underlyings_count": len(portfolio["data"]["underlyings"]),
            "avg_days_to_expiration": (
                (
                    sum(p.get("days_to_expiration", 0) for p in positions)
                    / len(positions)
                )
                if positions
                else 0
            ),
            "underlyings": list(portfolio["data"]["underlyings"].keys()),
        }
```

new:

```
        summary = {
            "total_positions": len(positions),
            "total_market_value": total_value,
            "total_unrealized_pnl": total_pnl,
            "total_unrealized_pnl_pct": (
                (total_pnl / total_value * 100) if total_value else 0.0
            ),
            "total_day_pnl": 0.0,
            "total_day_pnl_pct": 0.0,
            "calls_count": len(calls),
            "puts_count": len(puts),
            "expiring_this_week": sum(
                1 for p in positions if (p.get("days_to_expiration", 0) <= 7)
            ),
            "expiring_this_month": sum(
                1 for p in positions if (p.get("days_to_expiration", 0) <= 30)
            ),
            "underlyings_count": len(portfolio["data"]["underlyings"]),
            "avg_days_to_expiration": (
                (
                    sum(p.get("days_to_expiration", 0) for p in positions)
                    / len(positions)
                )
                if positions
                else 0
            ),
            "net_delta": sum(
                (p.get("delta") or 0) * p.get("quantity", 0)
                for p in positions
            ),
            "net_theta": sum(
                (p.get("theta") or 0) * p.get("quantity", 0) * p.get("multiplier", 100)
                for p in positions
            ),
            "underlyings": list(portfolio["data"]["underlyings"].keys()),
        }
```

---

## Todo 6: `options-frontend-enrich` -- Enrich frontend options display

### Change 6A: Extend OptionPos type (file: `frontend/src/pages/portfolio/PortfolioOptions.tsx`, lines 28-41)

**StrReplace** old:

```
type OptionPos = {
  id: number;
  symbol: string;
  underlying_symbol: string;
  strike_price: number;
  expiration_date: string | null;
  option_type: string;
  quantity: number;
  average_open_price?: number;
  current_price?: number;
  market_value?: number;
  unrealized_pnl?: number;
  days_to_expiration?: number;
};
```

new:

```
type OptionPos = {
  id: number;
  symbol: string;
  underlying_symbol: string;
  strike_price: number;
  expiration_date: string | null;
  option_type: string;
  quantity: number;
  average_open_price?: number;
  current_price?: number;
  market_value?: number;
  unrealized_pnl?: number;
  unrealized_pnl_pct?: number;
  days_to_expiration?: number;
  delta?: number;
  gamma?: number;
  theta?: number;
  vega?: number;
  implied_volatility?: number;
  underlying_price?: number;
  cost_basis?: number;
};
```

### Change 6B: Add summary types for greeks (file: `frontend/src/pages/portfolio/PortfolioOptions.tsx`, line 60)

**StrReplace** old:

```
  const summaryData = optionsQuery.summaryData as { summary?: { total_market_value?: number; total_unrealized_pnl?: number; total_positions?: number; calls_count?: number; puts_count?: number; expiring_this_week?: number; avg_days_to_expiration?: number } } | undefined;
```

new:

```
  const summaryData = optionsQuery.summaryData as { summary?: { total_market_value?: number; total_unrealized_pnl?: number; total_positions?: number; calls_count?: number; puts_count?: number; expiring_this_week?: number; avg_days_to_expiration?: number; net_delta?: number; net_theta?: number } } | undefined;
```

### Change 6C: Extract new summary values (after line 71, before `const openChart`)

**StrReplace** old:

```
  const avgDte = Number(summary.avg_days_to_expiration ?? 0);

  const openChart = (symbol: string) => setChartSymbol(symbol);
```

new:

```
  const avgDte = Number(summary.avg_days_to_expiration ?? 0);
  const netDelta = Number(summary.net_delta ?? 0);
  const netTheta = Number(summary.net_theta ?? 0);

  const openChart = (symbol: string) => setChartSymbol(symbol);
```

### Change 6D: Add Net Delta and Daily Theta stat cards (after the "Total P&L" StatCard, around line 133-134)

**StrReplace** old:

```
                  <StatCard
                    label="Total P&L"
                    value={formatMoney(totalPnl, currency)}
                    sub={totalPnlPct !== 0 ? `${totalPnlPct >= 0 ? '+' : ''}${totalPnlPct.toFixed(1)}%` : undefined}
                    color={totalPnl >= 0 ? 'status.success' : 'status.danger'}
                  />
                </Box>
```

new:

```
                  <StatCard
                    label="Total P&L"
                    value={formatMoney(totalPnl, currency)}
                    sub={totalPnlPct !== 0 ? `${totalPnlPct >= 0 ? '+' : ''}${totalPnlPct.toFixed(1)}%` : undefined}
                    color={totalPnl >= 0 ? 'status.success' : 'status.danger'}
                  />
                  <StatCard label="Net Delta" value={netDelta.toFixed(2)} />
                  <StatCard
                    label="Daily Theta"
                    value={formatMoney(netTheta, currency)}
                    color={netTheta < 0 ? 'status.danger' : 'status.success'}
                  />
                </Box>
```

### Change 6E: Redesign option row with greeks (lines 198-213 inside UnderlyingGroup)

**StrReplace** old:

```
            <VStack align="stretch" gap={1} mt={3} pl={6}>
              {allPositions.map((pos) => (
                <HStack key={pos.id} justify="space-between" fontSize="sm" gap={4} flexWrap="wrap">
                  <Text fontFamily="mono">
                    {pos.underlying_symbol} {pos.strike_price}{pos.option_type === 'call' ? 'C' : 'P'} {pos.expiration_date?.slice(0, 10) ?? '—'}
                  </Text>
                  <HStack gap={4}>
                    <Text color="fg.muted">{pos.quantity} contracts</Text>
                    <Text color="fg.muted">{formatMoney(Number(pos.current_price ?? 0), currency)}</Text>
                    <PnlText value={Number(pos.unrealized_pnl ?? 0)} format="currency" fontSize="sm" currency={currency} />
                    {pos.days_to_expiration != null && pos.days_to_expiration <= EXPIRING_SOON_DAYS && (
                      <Badge colorPalette="orange" size="sm">Expires soon</Badge>
                    )}
                  </HStack>
                </HStack>
              ))}
            </VStack>
```

new:

```
            <VStack align="stretch" gap={2} mt={3} pl={6}>
              {allPositions.map((pos) => (
                <Box key={pos.id} py={1} borderBottomWidth="1px" borderColor="border.subtle" _last={{ borderBottom: 'none' }}>
                  <HStack justify="space-between" fontSize="sm" gap={4} flexWrap="wrap">
                    <Text fontFamily="mono" fontWeight="medium">
                      {pos.strike_price}{pos.option_type === 'call' ? 'C' : 'P'} {pos.expiration_date?.slice(0, 10) ?? '—'}
                    </Text>
                    <HStack gap={4}>
                      <Text color="fg.muted">{pos.quantity} ct</Text>
                      <Text>{formatMoney(Number(pos.current_price ?? 0), currency)}</Text>
                      <PnlText value={Number(pos.unrealized_pnl ?? 0)} format="currency" fontSize="sm" currency={currency} />
                      {pos.days_to_expiration != null && pos.days_to_expiration <= EXPIRING_SOON_DAYS && (
                        <Badge colorPalette="orange" size="sm">{pos.days_to_expiration}d</Badge>
                      )}
                    </HStack>
                  </HStack>
                  {(pos.delta != null || pos.theta != null) && (
                    <HStack gap={3} fontSize="xs" color="fg.muted" mt={0.5}>
                      {pos.delta != null && <Text>D {pos.delta.toFixed(3)}</Text>}
                      {pos.gamma != null && <Text>G {pos.gamma.toFixed(4)}</Text>}
                      {pos.theta != null && <Text>T {pos.theta.toFixed(3)}</Text>}
                      {pos.vega != null && <Text>V {pos.vega.toFixed(3)}</Text>}
                      {pos.days_to_expiration != null && <Text>{pos.days_to_expiration} DTE</Text>}
                    </HStack>
                  )}
                </Box>
              ))}
            </VStack>
```

---

## Todo 7: `update-tests` -- Update tests

### Change 7A: test payload includes client_id (file: `backend/tests/test_aggregator_tt_async.py`, line 54)

**StrReplace** old:

```
        json={"client_secret": "test_secret", "refresh_token": "test_refresh"},
```

new:

```
        json={"client_id": "test_client_id", "client_secret": "test_secret", "refresh_token": "test_refresh"},
```

### Change 7B: Run all backend tests

```bash
make test
```

Verify all 310+ tests pass. If any fail due to the new Option columns (e.g., tests that create `Option` objects without greeks), that's fine -- greeks default to `nullable=True` so no test should break.

### Change 7C: Run frontend type checks

```bash
cd frontend && npx tsc --noEmit
```

Fix any type errors introduced by the changes.

---

## Post-implementation: Manual walkthrough

1. Delete existing TastyTrade accounts from the Settings > Brokerages UI (click the trash icon)
2. Click "+ New connection" -- the wizard opens at step 1
3. Click the Tastytrade logo -- should immediately advance to step 2
4. Enter Client ID, Client Secret, and Refresh Token
5. Click Connect -- backend authenticates, discovers accounts, stores encrypted creds
6. Trigger Sync on the newly created account
7. Navigate to Portfolio > Options -- verify greeks appear in the position rows and stat cards

