---
name: OpenAI Assignment Rewrite
overview: Completely rewrite the OpenAI Account Director written assignment — reframing it as a sales pitch (selling OpenAI's products TO Discord), with clear structure, specific OpenAI product references, business value quantification, and proper 2-page scope — then deliver as a print-ready HTML file that converts to a clean PDF.
todos:
  - id: rewrite-content
    content: Write the full 2-page proposal content with proper sales framing, OpenAI product specificity, and business value quantification
    status: completed
  - id: create-html
    content: Create a print-optimized HTML file with professional typography, proper margins, and 2-page layout that converts cleanly to PDF
    status: completed
  - id: loom-tips
    content: Add brief Loom video talking points as a separate companion document or notes
    status: completed
isProject: false
---

# OpenAI Account Director Assignment: Discord Sales Pitch

## Critical Problems with the Current Draft

1. **Wrong framing entirely**: The role is "Account Director" at OpenAI — she would be *selling OpenAI's products to companies*. The prompt says "choose one company you would like to **sell to**." The current draft reads like an internal Discord product manager wrote a PRD. It never mentions OpenAI, its APIs, or any commercial angle. This is the single biggest issue.
2. **No OpenAI product specificity**: The draft mentions generic "LLMs" and "supervised classification models." A great submission names specific OpenAI products — GPT-4o, Whisper, Embeddings API, Structured Outputs, fine-tuning — and shows how each maps to the customer's needs. This demonstrates product knowledge and technical sales fluency.
3. **Way too long and dense**: The current draft is ~800 words of wall-of-text with no headers, no whitespace, no visual hierarchy. The 2-page limit demands ruthless concision. Every sentence must earn its place.
4. **The idea is too niche**: Cross-platform community sync (Facebook Groups to Discord) is a narrow operational tool. A stronger pitch shows a bigger vision that represents a larger deal size and ties to Discord's core strategic priorities.
5. **No business value quantification**: No revenue impact, engagement metrics, deal size reasoning, or competitive positioning. An Account Director thinks in dollars.
6. **Missing the "sell" mindset**: The evaluators want to see sales acumen — understanding the customer's business, identifying where OpenAI creates value, sizing the opportunity, and anticipating objections.

## The Rewrite Strategy

### Company: Discord (keep it — strong digital-native large enterprise)

Discord is an excellent choice: 200M+ MAU, voice-first differentiation, massive moderation challenges, enterprise ambitions, and clear multi-product OpenAI use cases.

### Reframed Thesis

**"Discord should build a Community Intelligence Engine powered by OpenAI — transforming ephemeral conversation into structured, searchable knowledge."**

Instead of the niche cross-platform sync idea, the pitch centers on Discord's biggest structural problem: **knowledge dies in the scroll**. As servers scale, critical information (decisions, answers, announcements) gets buried within hours. This creates churn, moderator burnout, and blocks enterprise adoption.

### Page 1: The Problem, The Build, and The Value

**Problem** (3-4 sentences):

- Discord servers generate thousands of messages/day. Knowledge is ephemeral.
- Members ask repeated questions. Moderators burn out on manual triage.
- Voice channels (Discord's differentiator) produce zero searchable content.
- Enterprise adoption is blocked because there's no institutional knowledge layer.

**What to build — Community Intelligence Engine** (4 capabilities):

1. **Conversation Catch-Up** (GPT-4o) — AI-generated "what you missed" summaries per channel, prioritized by relevance to the member's role and interests.
2. **Voice Intelligence** (Whisper + GPT-4o) — Transcription and summarization of voice channels and Stage events. Discord's voice-first identity becomes a knowledge asset.
3. **Smart Q&A** (Embeddings + GPT-4o) — When a member asks a question, semantic search surfaces relevant past answers. Reduces repeat questions by 40-60%.
4. **Community Health Insights** (GPT-4o Structured Outputs) — Admins ask natural-language questions about their server. "What topics drove engagement this week?" gets an answer, not a dashboard.

**Why this matters to Discord's business** (the sales angle):

- Unlocks premium tier pricing (AI features as paid add-on for large servers)
- Creates switching costs (accumulated knowledge makes servers sticky)
- Differentiates from Slack/Teams (voice + community + AI = no competitor matches this)
- Accelerates enterprise adoption (the #1 growth priority for Discord)

### Page 2: Technical Architecture and Risks

**How it works** (high-level, using OpenAI products specifically):

```
Text messages --> GPT-4o API (Structured Outputs) --> Summaries, classification, extraction
Voice channels --> Whisper API --> Transcription --> GPT-4o --> Voice summaries
All content --> Embeddings API --> Vector store --> Semantic search (RAG)
Server-specific norms --> Fine-tuning API --> Custom moderation + relevance models
```

Key architecture principles:

- Models suggest, humans confirm (moderators review before posting)
- Deterministic systems handle permissions/routing/compliance
- Privacy scoped to server (no cross-server data leakage)
- Structured Outputs ensure consistent UI rendering

**Risks and Mitigations** (5-6 items, concise table or list):

- Hallucination: RAG-only, confidence scoring, human review
- Privacy: Server-scoped processing, opt-in, clear data policies
- Cost at scale: Relevance filtering, tiered processing, caching
- Adoption resistance: Start with catch-up summaries (low risk, high value)
- Over-automation: AI assists moderators, doesn't replace them
- Platform dependency: Modular architecture, graceful degradation

**Commercial framing** (closing paragraph):

- Full-stack OpenAI deal: GPT-4o + Whisper + Embeddings + Fine-tuning
- 200M MAU at even modest adoption = multi-million dollar annual contract
- Grows with Discord's user base (usage-based pricing alignment)

## Delivery Format

Create a beautifully formatted HTML file with print-optimized CSS:

- Clean typography (professional serif/sans-serif pairing)
- Proper margins, spacing, and visual hierarchy
- Exactly 2 pages when printed to PDF (A4/Letter)
- Header with name, date, and title
- File saved as `discord-openai-proposal.html` in the repo root
- Instructions: open in browser, File > Print > Save as PDF

## Loom Video Tips (Bonus)

Include brief guidance for the 5-10 minute Loom recording:

- Open with "why Discord" (30 seconds)
- Walk through each section of the PDF on screen share
- Emphasize the sales lens: "As an Account Director, I'd approach Discord by..."
- Close with the commercial opportunity sizing
- Show enthusiasm for OpenAI's product suite

