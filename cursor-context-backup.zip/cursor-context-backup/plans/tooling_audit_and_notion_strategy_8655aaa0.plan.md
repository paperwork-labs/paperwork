---
name: Tooling Audit and Notion Strategy
overview: Self-review of current state, social agent readiness, Impact.com timing, tool procurement tracking, and Notion workspace strategy.
todos:
  - id: verify-notion
    content: Verify Notion databases exist for all 6 n8n workflow outputs, create missing ones
    status: completed
  - id: tool-registry
    content: Add Tool Registry section to cfo.mdc + create Notion database for tool/vendor tracking
    status: completed
  - id: postiz-mcp
    content: Generate Postiz API key, update .cursor/mcp.json with real credentials
    status: completed
  - id: notion-structure
    content: Verify/create the full Notion workspace structure per the proposed layout
    status: completed
isProject: false
---

# Self-Review, Tool Procurement, and Notion Strategy

## 1. Where We Are (Self-Review)

**What's live and working:**

- `filefree.tax` -- landing page with hero, how-it-works, trust badges, comparison, footer, waitlist
- `api.filefree.tax` -- FastAPI backend, health/waitlist endpoints, Neon DB connected
- `n8n.filefree.tax` -- 6 persona workflows wired (Notion + GitHub outputs)
- `social.filefree.tax` -- Postiz running with Temporal stack
- PostHog analytics integrated with PII scrubbing
- Sentry wired (needs DSN to activate)
- `/demo` page with camera capture, upload zone, OCR pipeline (mock mode)
- `/pricing`, 3 SEO guide pages, privacy/terms, sitemap, robots
- Pre-push hook blocking direct pushes to main
- Social handles claimed: TikTok `@filefree.tax`, IG `filefree.tax`, X `@filefreetax`, YouTube `@FileFreeTax`

**Sprint status:**

- Sprint 0 (Business Ops): 4/11 done, B.1 (EFIN), B.2 (LLC), B.5/B.9 (Column Tax), B.8 (affiliates) still need human action
- Sprint 1 (Foundation): essentially complete (frontend, backend, landing, analytics, OCR demo)
- Sprint 2+ (Product -- auth, filing, tax calc): not started

## 2. Social Agents: Ready to Use?

**Postiz** is running at `social.filefree.tax`. You can log in and manually schedule posts right now.

**n8n persona workflows** are imported and wired:

- `social-content-generator.json` -- POST trigger, GPT drafts, outputs to Notion Content Calendar
- `growth-content-writer.json` -- POST trigger, GPT drafts, outputs to Notion Content Calendar

**What's NOT ready:**

- The **Postiz MCP** in `.cursor/mcp.json` still has placeholder values (`YOUR_POSTIZ_API_KEY_HERE`). You need to generate an API key from Postiz settings and update the config.
- The n8n workflows output drafts to **Notion**, not directly to Postiz. The intended flow is: n8n generates -> saves to Notion -> you review -> manually schedule in Postiz. This is by design (human-in-the-loop for brand voice).
- No **automated posting** to social platforms yet. That would require wiring n8n directly to Postiz's REST API (skipping the Notion review step). Not recommended at this stage -- you want to own the voice first.

**Recommendation:** Start using Postiz manually now. Create your first 3-5 posts (founder journey / "building a free tax app" angle). Get comfortable with the tool. The n8n automation layer is for Phase 2 when you have a content rhythm.

## 3. Impact.com: Not Yet

Impact.com is an affiliate network for partner referrals (Marcus HYSA, Wealthfront, etc.). Per the partnership strategy (D17), you need it for **Phase 1 affiliate applications** (Task B.8).

**But:** You have no product to refer users TO yet. Affiliate programs want to see:

- A live product with user traffic
- A clear referral integration point (the "refund moment" UI)
- Some volume to make the partnership worthwhile

**Recommendation:** Apply to affiliate programs when the filing flow MVP is live (Sprint 3, ~May). Right now, focus energy on OCR demo + content. Impact.com signup takes 24 hours -- it's not a long-lead item.

## 4. Tool Procurement Tracking

You're right that the tool count has grown organically. Here's the current inventory:

**Infrastructure (paying or will pay):**

- Render ($7/mo), Hetzner (EUR 5.49/mo), Vercel (free), Neon (free), Upstash (free)

**AI/APIs (pay-per-use):**

- OpenAI (GPT-4o, GPT-4o-mini), GCP Cloud Vision, GCP Cloud Storage

**Dev tools (free):**

- GitHub, Cursor, Docker, Caddy

**Ops/Content (self-hosted free):**

- n8n, Postiz, Temporal

**Analytics/Monitoring (free tier):**

- PostHog, Sentry (not activated)

**MCP integrations:**

- GitHub MCP, Context7, Postiz MCP (placeholder), Render MCP (referenced in KNOWLEDGE.md but not in mcp.json)

**DNS:**

- Spaceship

**Future/planned:**

- Impact.com, CJ Affiliate, Column Tax, ID.me, hCaptcha

### Proposal: Procurement Persona

Rather than a full new persona `.mdc` file, I'd recommend **extending the CFO persona** (`cfo.mdc`) which already tracks costs and vendors. Add a "Tool Registry" section that serves as the single source of truth for every tool/vendor/service. This keeps it in one place and doesn't fragment the persona system.

The CFO persona already says "Invoke when adding any new service, dependency, or vendor." It just needs the registry added.

## 5. Notion Workspace Strategy

Currently, the strategy persona references these Notion pages:

- Strategy and Vision
- Product Roadmap
- Decision Log
- Content Calendar
- Legal and Compliance
- Financials
- Partnerships

**The problem:** It's unclear what's actually been created in Notion vs. what's just documented in the `.mdc` file. The n8n workflows output to Notion databases, but we don't know if those databases exist or are structured correctly.

### Proposed Notion Structure

```
FileFree HQ (workspace root)
  |
  +-- Dashboard (landing page with links to everything)
  |
  +-- Product
  |     +-- Roadmap (kanban: Backlog / In Progress / Done)
  |     +-- Sprint Board (current sprint tasks)
  |     +-- Bug Tracker
  |
  +-- Strategy
  |     +-- Decision Log (database: date, decision, rationale, reversibility)
  |     +-- Competitive Analysis
  |     +-- Metrics Dashboard
  |
  +-- Content
  |     +-- Content Calendar (database: date, platform, status, copy, media)
  |     +-- Social Posts Archive
  |     +-- SEO Articles
  |
  +-- Legal & Compliance
  |     +-- EFIN Tracker
  |     +-- Privacy Policy (version history)
  |     +-- Terms of Service
  |
  +-- Partnerships (Founder 2 workspace)
  |     +-- Pipeline (database: partner, stage, contact, next step)
  |     +-- Outreach Templates
  |     +-- Deal Terms
  |
  +-- Financials
  |     +-- Tool Registry (database: tool, category, cost, status, purpose)
  |     +-- Monthly Burn Tracker
  |     +-- Revenue Projections
  |
  +-- Operations
        +-- Weekly Check-in Notes
        +-- n8n Workflow Status
        +-- Incident Log
```

### Should Personas Write to Notion?

**Yes, but through n8n, not directly.** The current architecture is correct:

- Cursor personas (`.mdc`) are context files for interactive coding sessions
- n8n workflows are the autonomous execution layer
- n8n outputs go to Notion databases

What's missing is making sure the Notion databases actually exist and match what n8n expects. The 6 n8n workflows target these Notion databases:

- Content Calendar (social + growth content generators)
- Decision Log (weekly strategy check-in)
- Partnership Pipeline (partnership outreach drafter)
- CPA Reviews (CPA tax review)
- GitHub Issues (QA security scan -- this one bypasses Notion)

### Notion Maintenance Strategy

- **KNOWLEDGE.md stays as the git-tracked source of truth** for decisions (AI agents read it at session start)
- **Notion is the operational layer** -- calendar views, pipeline tracking, collaboration
- **n8n syncs decisions both ways**: significant decisions logged in KNOWLEDGE.md get mirrored to Notion Decision Log via the weekly strategy check-in workflow
- **Tool Registry in Notion** gives you a visual dashboard of all vendors/costs

## Recommended Next Steps

1. **Verify Notion databases exist** for the 6 n8n workflow outputs (can be done via Notion MCP)
2. **Create the Tool Registry** database in Notion + add the registry section to `cfo.mdc`
3. **Configure Postiz MCP** (generate API key, update `.cursor/mcp.json`)
4. **Start posting manually** on socials (3-5 founder journey posts this week)
5. **Skip Impact.com** until filing flow MVP is live (~May)

