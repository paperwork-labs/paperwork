---
name: Capitalize names and tracked fundamentals
overview: (1) Display the user's name with proper capitalization in the header (title-case). (2) Clarify why some tracked symbols lack name/sector/industry and how to backfill or surface the existing fill-missing endpoint.
todos: []
isProject: false
---

# Capitalize header name and tracked symbol name/sector/industry

## 1. Capitalize person's name in the header

**Current behavior:** [DashboardLayout.tsx](frontend/src/components/layout/DashboardLayout.tsx) shows `user?.username || 'Account'` in the top-right (lines 557 and 570). The avatar uses the first character uppercased (line 555), but the full string is shown as stored (e.g. "smith", "admin").

**Change:** Apply title-case to the displayed name so "smith" → "Smith", "admin" → "Admin", "john doe" → "John Doe".

- **Display value:** Prefer `user?.full_name` when present, otherwise `user?.username`, otherwise `'Guest'` (or keep `'Account'`). Then title-case that string.
- **Implementation:** Add a small helper, e.g. `toTitleCase(s: string): string` (split on spaces, capitalize first letter of each word, rejoin). Use it for both the avatar initial (first character of title-cased string) and the visible label in the button and menu.
- **Files:** [frontend/src/components/layout/DashboardLayout.tsx](frontend/src/components/layout/DashboardLayout.tsx) — add helper (or import from a shared util if one exists), then replace `user?.username || 'Account'` with the title-cased display name in the two places it’s rendered.

---

## 2. Fill all missing snapshot data (tracked table) — run once at end of daily

**Goal:** One daily check at the end of the pipeline that finds any tracked snapshot row with **any** missing fundamental/display field (name, sector, industry, EPS, PE, ROE, revenue growth, etc.) and fills it from the provider. No need to run often; just once after the rest of the daily jobs.

**Current gap:** The task `fill_missing_snapshot_fundamentals` ([backend/tasks/market_data_tasks.py](backend/tasks/market_data_tasks.py) ~240–308) only fills **five** fields: name, sector, industry, sub_industry, market_cap (see `FUNDAMENTAL_FIELDS_CORE_WITH_NAME`). It does **not** fill pe_ttm, roe, eps_growth_yoy, revenue_growth_yoy, dividend_yield, next_earnings, etc., so those stay missing in the tracked table. The constants already define the full list: [FUNDAMENTAL_FIELDS_WITH_NAME](backend/services/market/constants.py) = name, sub_industry, sector, industry, market_cap, pe_ttm, peg_ttm, roe, eps_growth_yoy, eps_growth_qoq, revenue_growth_yoy, revenue_growth_qoq, dividend_yield, beta, analyst_rating, next_earnings, last_earnings.

**Changes:**

1. **Expand the fill task** in [backend/tasks/market_data_tasks.py](backend/tasks/market_data_tasks.py):
  - **Selection:** Select snapshot rows where **any** of the fields in `FUNDAMENTAL_FIELDS_WITH_NAME` is missing (not just sector/industry/market_cap). Use a single OR condition over those columns so we catch rows missing name, or sector, or pe_ttm, or eps_growth_yoy, etc.
  - **Fetch:** Keep using `get_fundamentals_info(sym)`; the provider already returns the full set. Merge into `snap` **all** keys from `FUNDAMENTAL_FIELDS_WITH_NAME` that exist in `funda` (replace the current loop that only uses `FUNDAMENTAL_FIELDS_CORE_WITH_NAME`).
  - **Persist:** When persisting, consider the row “updated” if **any** of the fundamental fields was missing and we now have a value for it (not just the five we currently check). So: build a dict of “new values” from snap for all keys in FUNDAMENTAL_FIELDS_WITH_NAME where the current row has None and snap has a value; if that dict is non-empty, call persist_snapshot with the merged data and count updated.
  - **Docstring:** Update to say it fills all missing fundamental/display data for the tracked table (name, sector, industry, PE, EPS growth, revenue growth, etc.), not only sector/industry/market_cap.
2. **Add to job catalog** in [backend/tasks/job_catalog.py](backend/tasks/job_catalog.py):
  - Add a new `JobTemplate` for `fill_missing_snapshot_fundamentals` with a descriptive name (e.g. “Fill Missing Snapshot Data” or “Snapshot Fundamentals Backfill”), group `market_data`, and a **single daily run at the end** of the pipeline — e.g. cron `15 4 * * `* or `20 4 * * *` (after “Data Retention Cleanup” at 30 4) so the order is: … → Retention 30 4 → Fill Missing 15 4 or 45 4. That way it runs once per day and fills whatever is still missing without running often.
  - Optional: use the same task_run name so the existing button/API still targets the same task.

**Result:** At the end of each day, any snapshot row (for the tracked universe) that is missing name, sector, industry, PE, EPS growth, revenue growth, or other fundamentals will get those fields filled from the provider. The button/API for on-demand run stays as-is.