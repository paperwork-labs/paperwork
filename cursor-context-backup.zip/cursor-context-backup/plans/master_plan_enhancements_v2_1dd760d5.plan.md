---
name: Master Plan Enhancements v2
overview: "Address 10 items: add Trinkets palette, define port map for parallel dev, add EA/Doc-keeper agents, define agent interaction model, save plan to git, add venture-wide TASKS.md sections, fix LaunchFree \"free\" framing with competitive data, resolve the Wyoming vs California LLC question, and update the LaunchFree state-selection feature spec."
todos:
  - id: wyoming-vs-california
    content: "DECIDED: California LLC. Update master plan Section 0, Section 0B, and Section 10 to reflect California formation. Include Wyoming vs CA comparison as rationale."
    status: completed
  - id: trinkets-palette
    content: Add Trinkets amber-orange palette to Section 2 Brand Palettes. Update P1.2 to reference 4 themes instead of 3.
    status: completed
  - id: port-map
    content: Add port map subsection to Section 2 Architecture. Define ports for all 4 frontends (3001-3004) and 3 backends (8001-8003), skipping x000. Add dev command specs.
    status: completed
  - id: ea-agent
    content: Add Executive Assistant agent (#32) to Section 6. Create ea.mdc persona + n8n workflow spec with daily briefing, weekly planning, decision tracking, financial tracking, doc maintenance responsibilities.
    status: completed
  - id: docs-keeper-agent
    content: Merge docs-keeper responsibilities into EA agent (single agent). EA is both Cursor persona + n8n workflow -- maintains docs, checks state data freshness, keeps financials current.
    status: completed
  - id: agent-interaction-model
    content: "Add Section 6J: Agent Interaction Model -- how founder communicates with Cursor personas, autonomous n8n workflows, and on-demand triggers."
    status: completed
  - id: save-plan-to-git
    content: Copy master plan to docs/VENTURE_MASTER_PLAN.md in the repo. Add source-of-truth note. Commit.
    status: completed
  - id: update-tasks-md
    content: Add venture-wide Phase 0-8 tasks to docs/TASKS.md after existing Sprint 4. Keep Sprint 0-3 as historical record.
    status: completed
  - id: fix-free-framing
    content: "Update LaunchFree product description and Section 1 with honest free framing: service is $0, state fees disclosed upfront, state comparison AI guide as differentiator."
    status: completed
  - id: create-financials-md
    content: Create docs/FINANCIALS.md with one-time expenses, monthly recurring, and runway tracking. Include known purchases (domains, planned LLC).
    status: completed
  - id: llc-journey-content
    content: "Add Section 5J to master plan: Founder LLC Journey Content Series -- 12 steps mapped to viral hooks, content formats per step, revenue flywheel. Update 30-day calendar."
    status: completed
isProject: false
---

# Master Plan Enhancements v2

## Critical Finding: Wyoming LLC May Be the Wrong Move

**You live in California.** The current plan says "form Wyoming LLC." This needs careful review:

**If you form in Wyoming AND operate from California:**

- You MUST register as a **foreign LLC in California** (~$70 filing fee)
- You MUST pay California's **$800/yr franchise tax** regardless (first year may be exempt for new LLCs)
- You need **two registered agents** (one in each state)
- You do **double compliance** (annual reports in both states)
- California taxes ALL your income anyway -- Wyoming's $0 income tax doesn't help you

**Wyoming year 1 (as a California resident)**: $100 WY filing + $70 CA foreign registration + $800 CA franchise tax + 2x RA ($25 WY + $99 CA) = **~$1,094**

vs

**California year 1**: $70 CA filing + $0 franchise tax (first year exempt for new LLCs) + $49 CA RA = **~$119**

Wyoming's only real advantages: **privacy** (no owner disclosure) and **charging order protection** for single-member LLCs. These matter for asset protection if you're handling financial data, but they cost ~$975/yr extra.

**Recommendation**: Form in California unless asset protection is a top priority. Revisit Wyoming if/when revenue exceeds $250K and asset protection justifies the dual-state cost. Update Section 0 and F7 of the master plan.

This should be presented as a decision point in the plan with both options.

---

## 1. Add Trinkets Color Palette (4th frontend)

Current plan has 3 palettes (FileFree: violet-indigo, LaunchFree: teal-cyan, Studio: zinc-neutral). Trinkets needs one.

Add to Section 2 "Brand Palettes" in [venture_master_plan_v1_61fe6d89.plan.md](/Users/sankalpsharma/.cursor/plans/venture_master_plan_v1_61fe6d89.plan.md), after the Studio palette:

```
**Trinkets / Tools** (Utility / Approachable / Helpful): Amber-Orange family
- Primary: #F59E0B (Amber 500)
- Gradient: #F59E0B -> #EA580C (Amber 500 -> Orange 600)
- Background: #0C0A09 (Stone 950)
- Typography: Inter + JetBrains Mono
```

Amber/orange conveys utility, energy, and approachability -- distinct from the other 3 palettes while staying in the same dark-mode family. Also update P1.2 to reference 4 themes.

## 2. Port Map for Parallel Development

Define a clear port assignment in the master plan (new subsection in Section 2: Architecture) and update [infra/compose.dev.yaml](infra/compose.dev.yaml) references:

```
PORT MAP (local development):
  Frontends:
    apps/filefree     -> 3000 (default Next.js)
    apps/launchfree   -> 3001
    apps/trinkets     -> 3002
    apps/studio       -> 3003

  Backends:
    apis/filefree     -> 8000 (default FastAPI)
    apis/launchfree   -> 8001
    apis/studio       -> 8002

  Infrastructure:
    PostgreSQL        -> 5432
    Redis             -> 6379

  Dev commands:
    pnpm dev:filefree     -> starts 3000 + 8000
    pnpm dev:launchfree   -> starts 3001 + 8001
    pnpm dev:trinkets     -> starts 3002 (no backend, client-side only)
    pnpm dev:studio       -> starts 3003 + 8002
    pnpm dev:all          -> starts everything (for testing cross-product)
```

Each Next.js app uses `--port` flag. Each FastAPI uses `--port` in uvicorn. Environment variable `NEXT_PUBLIC_API_URL` differs per app.

## 3. Add Executive Assistant (EA) Agent

New persona: `ea.mdc` (Executive Assistant). This is the founder's daily operating partner.

**Responsibilities:**

- Daily morning briefing (n8n cron, 7am): What's due today, which agents ran overnight, what needs attention, any alerts
- Weekly planning (n8n cron, Sunday evening): Summarize week's progress, propose next week's priorities based on phase milestones
- Track decisions: When founder says "I bought X" or "We decided Y", log to `docs/KNOWLEDGE.md`
- Maintain `docs/TASKS.md`: When phase tasks complete, update status. Add new tasks from conversations.
- Financial tracking: Maintain `docs/FINANCIALS.md` with expenses (domains, subscriptions, one-time purchases), projected costs, and runway

**Implementation**: n8n workflow (`venture-ea-daily`) + Cursor persona `.cursor/rules/ea.mdc`

Add to Section 6 as agent #32 and add to Phase 6 task list.

## 4. Add Documentation Agent

New persona: `docs-keeper.mdc` (Documentation Manager).

**Responsibilities:**

- Keep `docs/KNOWLEDGE.md` current (decisions, rationale, alternatives considered)
- Keep `docs/TASKS.md` synced with master plan phases
- Create/maintain `docs/FINANCIALS.md` (expense tracking, subscription costs, domain purchases)
- Generate monthly expense reports
- Ensure all significant decisions from conversations get logged

**Implementation**: Cursor persona `.cursor/rules/docs-keeper.mdc`. Not an n8n workflow -- invoked during conversations when decisions are made.

Add to Section 6 as agent #33.

## 5. Agent Interaction Model (How to Talk to Your Agents)

Add a new subsection to Section 6: "6J. Agent Interaction Model"

Currently agents are invoked implicitly via Cursor persona glob patterns or n8n cron triggers. The founder needs a clear mental model:

```
INTERACTION PATTERNS:

1. CURSOR PERSONAS (interactive -- they join your conversation)
   How: Open a file matching a persona's glob pattern, or explicitly invoke
   Examples:
     - Open apps/filefree/... -> engineering + filefree personas activate
     - Ask "review this for legal compliance" -> legal.mdc activates
     - Ask "what should I work on today?" -> ea.mdc activates
   When: During coding/strategy sessions in Cursor IDE

2. N8N AUTONOMOUS WORKFLOWS (they work while you sleep)
   How: Run on cron schedules or webhook triggers
   Output: Results appear in Google Drive folders or Discord #ops-alerts
   Review: Founder checks output daily (~5-10 min)
   Examples:
     - 7am: EA daily briefing lands in GDrive + Discord
     - 8am: Social content drafts appear in Postiz queue
     - Hourly: Infra health checks, alert only on issues

3. ON-DEMAND N8N WORKFLOWS (you trigger them)
   How: n8n webhook URL or Discord slash command
   Examples:
     - /trinket-discover [keyword] -> Market Discovery Agent runs
     - /support [user question] -> L1 DocBot responds
     - /competitive-check -> Competitive Intel runs immediately
```

## 6. Save Master Plan to Git

The master plan lives in `~/.cursor/plans/` which is NOT in the git repo. It should be copied to a version-controlled location.

- Copy `venture_master_plan_v1_61fe6d89.plan.md` to `docs/VENTURE_MASTER_PLAN.md` in the repo
- Add a note at the top: "Source of truth: this file. The .cursor/plans/ copy may be stale."
- Commit with a meaningful message
- Going forward, edits happen to the repo copy

## 7. Update docs/TASKS.md with Venture-Wide Phases

Current [docs/TASKS.md](docs/TASKS.md) covers FileFree Sprints 0-4. It needs venture-wide phases from the master plan.

Add a new section after the existing Sprint 4:

```markdown
## Venture Phases (from Master Plan v1)

### Phase 0: Infrastructure (This Week)
... (mirror the phase tasks from master plan Section 7)

### Phase 1: Monorepo Restructure (Week 2-3)
...
```

Keep existing Sprint 0-3 as historical record. Sprint 4 becomes part of Phase 7 (FileFree Season Prep).

## 8. Fix LaunchFree "Free" Framing

The current plan says "Free LLC formation" but this needs honest, defensible framing. No state has $0 filing fees.

Add a new subsection to Section 1 (Revenue Model) or update LaunchFree's product description:

**What's actually free (our service):**

- LLC formation filing (prep + submit): $0
- Operating agreement (AI-generated, state-specific): $0
- EIN filing walkthrough: $0
- Compliance calendar + reminders: $0
- State selection AI guide (compares all 50 states): $0

**What's NOT free (government fees, clearly disclosed):**

- State filing fee: $35-$500 (depends on state -- we show this upfront)
- We help users find the cheapest legitimate option for their situation

**Framing language:**

> "LaunchFree handles the paperwork for $0. You only pay what your state charges -- and we'll help you pick the most affordable one."

**State comparison feature**: LaunchFree's AI guide compares all 50 states on filing fee, annual costs, franchise tax, privacy, speed, and recommends based on user's situation (home state, business type, budget). This IS the differentiator -- competitors don't help you choose.

**Cheapest states highlight** (marketing content):

- Montana: $35 filing
- Kentucky: $40
- Arkansas: $45
- Colorado/Arizona/Michigan: $50

## 9. Wyoming vs California LLC Decision

Add to Section 0B and Section 10 (Key Decisions) as a critical decision point:

**For the founder's own holding company** (not LaunchFree users):


| Factor                     | Wyoming                                              | California                              |
| -------------------------- | ---------------------------------------------------- | --------------------------------------- |
| Filing fee                 | $100                                                 | $70                                     |
| Annual report              | $60/yr                                               | $0 (no annual report)                   |
| Franchise tax              | $0 (but CA charges you anyway)                       | $800/yr (first year exempt)             |
| RA cost                    | $25-29/yr                                            | $49-125/yr                              |
| Privacy                    | Excellent (no owner disclosure)                      | Poor (public disclosure required)       |
| Foreign registration in CA | Required (~$70)                                      | Not needed                              |
| Asset protection           | Strong (charging order protection for single-member) | Weak                                    |
| **Year 1 total**           | **~$1,094** (with CA foreign reg)                    | **~$119** (first year franchise exempt) |
| **Year 2+ total**          | **~$985/yr**                                         | **~$849/yr**                            |


**Recommendation**: Start with California LLC (cheapest, simplest). If asset protection becomes critical (handling >$1M in user financial data), consider converting to Wyoming holding company with California subsidiary later.

Update Section 0 to reflect this and mark it as a decision in Section 10.

## 10. Create docs/FINANCIALS.md

New file tracking all venture expenses. Structure:

```markdown
# Venture Financial Tracker

## One-Time Expenses
| Date | Item | Amount | Category | Notes |
|---|---|---|---|---|
| Mar 2026 | filefree.ai domain (2yr) | ~$220 | Domain | Purchased |
| Mar 2026 | launchfree.ai domain (2yr) | ~$220 | Domain | Purchased |
| TBD | LLC filing fee | $70-100 | Legal | State dependent |

## Monthly Recurring
| Service | Cost | Category | Notes |
|---|---|---|---|
| Hetzner VPS | $6/mo | Infrastructure | n8n + Postiz |
| Render (FileFree API) | $7/mo | Infrastructure | Starter plan |
| Google Workspace | $6/mo | Operations | |
| Domain renewals | ~$20/mo avg | Domain | Spread across year |

## Runway
Total monthly burn: ~$46/mo
Cash invested to date: ~$X
Months of runway at $0 revenue: X months
```

Maintained by the EA agent.

## 11. Founder LLC Journey Content Series (NORTH STAR: Go Viral -> Traffic -> Partner $$$)

The founder is forming a California LLC for the venture RIGHT NOW. This is the exact journey LaunchFree users will go through. Document every step as social content -- authentic, educational, and positions LaunchFree as the solution.

**The meta-narrative**: "I'm building a free LLC formation app while forming my own LLC. Here's every step, every cost, every frustration -- and why I'm building something better."

### LLC Formation Steps -> Content Hooks


| Step                     | What Happens                                                             | Content Hook (TikTok/IG/X)                                                                            | Emotion                     |
| ------------------------ | ------------------------------------------------------------------------ | ----------------------------------------------------------------------------------------------------- | --------------------------- |
| 1. Choose a name         | Search CA SOS business database, discover your name is taken, try 5 more | "I tried to name my company and California said no. 5 times."                                         | Frustration -> relatability |
| 2. File Articles of Org  | Fill out Form LLC-1 on CA SOS website, pay $70                           | "Starting an LLC costs $70 in California. Here's the 3-minute form nobody shows you."                 | Demystification             |
| 3. Wait for approval     | CA SOS processing time (can be weeks)                                    | "Day 1 vs Day 14 of waiting for California to approve my LLC..."                                      | Anticipation                |
| 4. Get an EIN            | IRS.gov, free, takes 5 minutes online                                    | "The IRS gave me a tax ID in 5 minutes. For free. Why does anyone pay $70 for this?"                  | Outrage at upsellers        |
| 5. Operating Agreement   | Write one (or use a template, or AI generates it)                        | "LegalZoom charges $99 for this document. I had AI write mine in 30 seconds."                         | Product demo moment         |
| 6. Registered Agent      | Set up RA service                                                        | "Your LLC needs a 'registered agent.' Here's what that actually means (and why it costs $49-249/yr)." | Education                   |
| 7. Statement of Info     | File LLC-12 within 90 days of formation                                  | "90 days after forming your LLC, California wants MORE paperwork. Here's what to do."                 | Compliance awareness        |
| 8. Business bank account | Apply at Mercury/Relay/local bank                                        | "I opened a business bank account in 10 minutes. From my phone."                                      | Partner demo moment         |
| 9. Franchise tax reality | Discover the $800/yr CA franchise tax                                    | "Nobody told me California charges $800/yr just to EXIST as an LLC. Here's the workaround."           | Shock -> education          |
| 10. First year exempt    | Discover first-year exemption                                            | "Plot twist: your first year is actually FREE. Here's the fine print."                                | Relief                      |
| 11. Compliance calendar  | Set up annual reminders                                                  | "The 5 dates every LLC owner needs to know. Miss one and your LLC gets dissolved."                    | Urgency                     |
| 12. DBA filing           | File "Doing Business As" for brand names                                 | "My LLC name isn't my brand name. Here's why you need a DBA (and what it costs)."                     | Practical                   |


### Content Format per Step

Each step produces 3-5 pieces of content:

1. **TikTok/Reel (primary)**: 30-60s screen recording of the actual process + voiceover explaining what's happening. Show real screens, real forms, real costs. Raw and authentic.
2. **X thread**: 5-7 tweet breakdown of the step with screenshots. Educational, save-worthy.
3. **IG carousel**: Step-by-step visual guide (5-7 slides). Highly saveable, shareable.
4. **Blog/guide page** (SEO): Full written guide on launchfree.ai (e.g., "How to File Articles of Organization in California"). Each guide page is an SEO asset targeting "[state] LLC formation" keywords.
5. **Behind-the-scenes TikTok**: "Day X of building a free LLC formation app while forming my own LLC" (build-in-public narrative)

### Why This Goes Viral

- **Pain is universal**: Everyone forming an LLC hits the same confusion. This content validates their frustration.
- **Real receipts**: Showing actual forms, actual costs, actual timelines. Not hypothetical.
- **Outrage hooks**: "LegalZoom charges $249 for something that takes 3 minutes" triggers shares.
- **Build-in-public**: "I'm building the solution to the problem I'm showing you" is a compelling narrative arc.
- **Each step is searchable**: People Google "how to get an EIN" (110K monthly searches), "California LLC cost" (12K), "do I need a registered agent" (8K). This content ranks.

### Revenue Flywheel

```
Viral LLC content (TikTok/IG/X)
    |
    v
Traffic to launchfree.ai (SEO guides + social CTAs)
    |
    v
Users form LLCs via LaunchFree ($0 service fee)
    |
    v
Cross-sell: RA ($99/yr), banking (Mercury/Relay affiliate $50-100),
            payroll (Gusto $50-200), insurance (Next $30-75)
    |
    v
Partner revenue ($$$) -- this is the 77% revenue driver
    |
    v
Reinvest in more content + product
```

### Add to Master Plan

- Add this as Section 5J (LLC Journey Content Series) in the Social Pipeline section
- Reference from Phase 0.6 (Form LLC) -- every phase 0 step becomes content
- Update the 30-day content calendar to incorporate LLC journey steps alongside tax content
- Cross-reference with the LaunchFree social hooks in Section 5E

