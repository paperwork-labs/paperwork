---
name: RunnerBuilder_Doorvest_MVP
overview: Build a Gmail-inspired Runner Builder that lets users search, facet-filter, preview, then create runners. Seed emails are ingested into Postgres; ongoing polling keeps runners up to date. Add Doorvest-specific classification, extraction, queue, and LLM reply drafts (approval-only).
todos:
  - id: runner-data-model
    content: Add Runner models/migrations for runners, runner_filters, runner_items, runner_runs.
    status: completed
  - id: runner-preview-api
    content: Implement preview endpoint that compiles facets into Gmail query and returns paged preview results.
    status: completed
    dependencies:
      - runner-data-model
  - id: runner-create-seed
    content: "Implement runner creation: store filter + enqueue seed ingest job for previewed emails (cap=1000)."
    status: completed
    dependencies:
      - runner-preview-api
  - id: runner-polling-jobs
    content: Implement polling scheduler/jobs to ingest new matching emails and update runner state.
    status: completed
    dependencies:
      - runner-create-seed
  - id: promo_actionable_classify
    content: Implement rules-first classification with LLM fallback; store results on runner_items and EmailMessage metadata.
    status: completed
    dependencies:
      - runner-polling-jobs
  - id: structured_extraction
    content: Implement structured extraction for Doorvest ops emails and persist fields for UI display.
    status: completed
    dependencies:
      - promo_actionable_classify
  - id: draft_generation
    content: Implement OpenAI-compatible draft generation (approval-only) stored as LLMArtifact and linked to runner_items.
    status: completed
    dependencies:
      - promo_actionable_classify
  - id: frontend_runners_ui
    content: Add /runners list, /runners/new builder with facet chips+icons, preview table, create runner flow, runner detail queue UI.
    status: completed
    dependencies:
      - runner-preview-api
      - runner-create-seed
  - id: docs_runners
    content: Document runner journeys, filter facets, safety model, and diagrams in docs/UX_FRONTEND.md and docs/RUNNERS.md.
    status: cancelled
    dependencies:
      - frontend_runners_ui
---

# Runner Builder MVP (Doorvest-first, multi-runner)

## Product intent

Create a **Gmail-inspired Runner Builder**: user types a search (e.g. “doorvest”), refines with facets (From/Subject/Body/Labels/Date/Unread/Has attachment), previews matching emails, then clicks **Create Runner**. The system:

- Saves the **rule** (facet config + compiled Gmail query)
- Ingests **seed emails** (the preview results) into Postgres
- Continues to ingest **new matching emails** via polling (read-only Gmail)
- Produces a **Runner Queue** of actionable items, separates promos, and supports **LLM reply drafts** (never auto-send)

## Key UX journeys

### Journey_01_CreateRunner

1) Go to **Runners** → “New Runner”2) Type search term (`doorvest`)3) Add facets with icon chips:

- From include/exclude
- Subject contains/doesn’t
- Body contains/doesn’t
- Labels include/exclude
- Date range (newer_than/older_than)
- Unread only
- Has attachment

4) See **live preview** list (paged, capped by default)5) Click **Create Runner**:

- name runner (default suggested from query)
- confirm scope: “Ingest first N=1000 matches”

6) Runner created → shows status (seed ingest job running) → then queue populates

### Journey_02_RunnerQueueOps

- Runner page shows tabs: **Queue (Actionable)**, **Promos**, **All matched**, **Drafts**
- Each actionable item supports:
- Mark done
- Assign owner + due date
- Add tags
- Open in Gmail
- Generate draft (edit + copy)
- Create internal task record

### Journey_03_PromoFiltering

- Rules-first, LLM-when-uncertain:
- hard rules: category/label heuristics + subject/body keywords + sender patterns
- LLM classification for ambiguous messages

### Journey_04_OngoingIngest

- Runner polls Gmail every X minutes (config) for new matches
- Maintains idempotency by Gmail message IDs

## Architecture decisions

- Gmail access: **read-only** (current OAuth scope) with a clear future upgrade path to `gmail.modify`.
- Seed semantics: **store (ingest) all previewed emails into DB** at creation time (seed), then continuous polling for new matches.
- Preview/backfill guardrail: default **cap=1000 matches** (paged); user can expand intentionally.
- Draft generation: **OpenAI-compatible** client, default OpenAI; drafts always require approval and are stored as artifacts.

## Backend work

### Data model additions

Add new tables (or extend existing):

- `runners` (id, user_id, name, description, status, created_at)
- `runner_filters` (runner_id, compiled_query, facets_json, label_includes/excludes, sender includes/excludes, date range, etc.)
- `runner_items` (runner_id, email_message_id, classification, status, owner, due_date, tags, created_at)
- Optionally `runner_runs` (runner_id, started_at, finished_at, counts, error)

Leverage existing:

- `EmailThread`, `EmailMessage`, `Attachment` for ingested content
- `Job` for background processing
- `LLMArtifact` for draft payloads/classification outputs

### API endpoints

- `POST /assistant/api/runners` create runner (name + facets + compiled query + seed selection)
- `GET /assistant/api/runners` list
- `GET /assistant/api/runners/{id}` detail
- `POST /assistant/api/runners/preview` return preview results for a given facet set (paged)
- `GET /assistant/api/runners/{id}/items` list queue/promos/all
- `POST /assistant/api/runners/{id}/items/{item_id}/actions` (mark done, assign, tag)
- `POST /assistant/api/runners/{id}/drafts` generate draft for an item (approval-only)

### Background jobs

- `runner_seed_ingest_job`: ingest previewed message IDs (or query pages) into DB
- `runner_poll_job`: periodic polling per runner; enqueue classification/extraction jobs
- `runner_classify_job`: promo vs actionable (rules + LLM)
- `runner_extract_job`: extract structured fields (property, ticket#, due date, amount, address, etc.)
- `runner_draft_job`: generate reply drafts (LLM)

### Gmail service enhancements

- Add Gmail search: execute compiled query and return message IDs + minimal metadata for preview.
- Ensure rate limiting/retry/backoff and attachment limits stay enforced.

### LLM service

- Add OpenAI-compatible client with env config:
- `LLM_API_KEY`, `LLM_BASE_URL` (default OpenAI), `LLM_MODEL`
- Prompts:
- Classification prompt: promo vs actionable + reason + confidence
- Extraction prompt: return strict JSON schema
- Draft prompt: context + tone + required approval, output draft + bullets

## Frontend work

### IA

- Add a new section: **Runners**
- `/runners` list
- `/runners/new` builder
- `/runners/[id]` runner detail (Queue/Promos/All/Drafts/Settings)

### Runner Builder UI (Gmail-inspired)

- Search bar + facet chips with icons (mail, user, tag, calendar, paperclip, unread badge)
- Facet editor popovers (include/exclude sender, subject/body contains, labels, date range)
- Preview table (paged, capped default 1000) + counts + “why included” badges
- Create Runner CTA with final confirmation

### Organization / naming

- Keep Next route entry files as `page.tsx` (Next convention), but move real components into:
- `frontend/src/features/runners/*` (e.g. `RunnerBuilder.tsx`, `FacetBar.tsx`, `PreviewTable.tsx`)
- `frontend/src/app/components/ui/*` for shared primitives

## Docs updates

- Update `docs/UX_FRONTEND.md` with Runner journeys + UI wire notes.
- Add `docs/RUNNERS.md` covering:
- runner concepts, filter facets, query compilation
- job cadence/caps
- promo/actionable logic
- draft generation safety (approval-only)

## Diagram

```mermaid
flowchart TD
  ui[RunnerBuilderUI] --> api[RunnerAPI]
  api --> gmail[GmailSearch]
  api --> db[Postgres]
  api --> queue[RQ]
  queue --> worker[RunnerJobs]
  worker --> llm[LLMProvider]
  worker --> db


```