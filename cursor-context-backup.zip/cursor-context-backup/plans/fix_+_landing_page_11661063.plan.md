---
name: Fix + Landing Page
overview: Fix 7 doc inconsistencies identified in the persona review, add D23 knowledge entry for the Sprint 1 check-in, then build and ship the Task 0.4 landing page with waitlist email capture.
todos:
  - id: fix-inconsistencies
    content: "Fix 7 doc inconsistencies: TASKS.md (B.6 refs, Gen Z FAQ), .cursorrules + engineering.mdc (Vercel tier), env.prod.example (missing vars), KNOWLEDGE.md D21 (Hetzner status)"
    status: completed
  - id: d23-knowledge
    content: Add D23 entry to KNOWLEDGE.md documenting Sprint 1 completion, Gen Z branding removal, and current status
    status: completed
  - id: alembic-migration
    content: Generate initial Alembic migration via Docker and verify schema is correct
    status: completed
  - id: landing-components
    content: "Build landing page components: hero (email CTA), how-it-works (3 steps), trust-badges, comparison hook, footer"
    status: completed
  - id: landing-page
    content: Assemble landing page in page.tsx with waitlist form (react-hook-form + zod), confetti success, sonner errors
    status: completed
  - id: landing-merge
    content: Commit, push, merge feat/0.4-landing-deploy to main, verify Vercel deploy
    status: completed
isProject: false
---

# Fix Inconsistencies + Ship Landing Page

## Part 1: Fix 7 Inconsistencies

Quick edits across docs and config files:

1. **[docs/TASKS.md](docs/TASKS.md) Task B.6 (lines 73-76)**: Replace `docker-compose.yml` with `infra/compose.dev.yaml`, remove Temporal reference, change "separate databases `postiz_db` and `n8n_db`" to "single shared `filefree_ops` database"
2. **[docs/TASKS.md](docs/TASKS.md) Task 3.1 (line 623)**: Change "Gen Z-focused questions" to "first-time filer questions"
3. **Vercel tier alignment**: Update `Vercel (Pro plan, $20/mo)` to `Vercel (Hobby tier, free — upgrade to Pro when needed)` in:
  - [.cursorrules](.cursorrules) (line 76)
  - [.cursor/rules/engineering.mdc](.cursor/rules/engineering.mdc) (Infrastructure section)
4. **[infra/env.prod.example](infra/env.prod.example)**: Add `ENCRYPTION_KEY`, `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `APPLE_CLIENT_ID`, `APPLE_TEAM_ID`, `APPLE_KEY_ID`, `APPLE_PRIVATE_KEY_PATH`
5. **[docs/KNOWLEDGE.md](docs/KNOWLEDGE.md) D21**: Update "Not yet bootstrapped (Docker/Caddy install pending)" to reflect that Hetzner IS bootstrapped with all 4 services running (PostgreSQL, Redis, n8n, Postiz)

## Part 2: D23 Knowledge Entry

Add to [docs/KNOWLEDGE.md](docs/KNOWLEDGE.md):

**D23 — Sprint 1 Complete + Gen Z Branding Removed (2026-03-09)**

- Sprint 1 foundation shipped: frontend design system (Tailwind v4, 22 shadcn components, attribution), backend foundation (7 models, 16 tests, response envelope, Alembic, encryption, PII scrubbing)
- Hetzner ops stack bootstrapped: Docker, Caddy, n8n (200), Postiz (307), all services healthy
- Removed "Gen Z" from all user-facing copy — product leads with benefits, not demographic labels. Internal strategy docs retain demographic insight where analytically relevant
- Monthly burn: $5.49/mo (Hetzner only). All other services on free tiers.
- Next: landing page, EFIN application, affiliate applications, social accounts

## Part 3: Landing Page (Task 0.4)

**Branch**: `feat/0.4-landing-deploy`

Build the landing page per the spec in [docs/TASKS.md](docs/TASKS.md) lines 239-286. The waitlist POST endpoint already exists at `/api/v1/waitlist`. Infrastructure is already live. This is purely frontend work.

### Page Structure

```mermaid
flowchart TD
    Hero["Hero Section\nHeadline + subhead + email CTA"]
    HowItWorks["How It Works\n3 steps with icons"]
    TrustBadges["Trust Badges\nEncryption, privacy, deletion"]
    AntiTT["Anti-TurboTax\nHonest comparison hook"]
    Footer["Footer\nSocial links + legal links"]

    Hero --> HowItWorks --> TrustBadges --> AntiTT --> Footer
```



### Components to Create

- `src/components/landing/hero.tsx` — Headline: "Taxes shouldn't make you cry.", subheadline, email input + "Get Early Access" button. Animated gradient background. Posts to `/api/v1/waitlist` with attribution data from `getAttribution()`.
- `src/components/landing/how-it-works.tsx` — Three steps: (1) Snap icon + "Snap your W-2", (2) Scan icon + "AI reads every field", (3) Download icon + "Download your return". Framer Motion stagger animation on scroll (using `slideInUp` from `motion.ts`).
- `src/components/landing/trust-badges.tsx` — Three badges: "256-bit Encrypted", "We never sell your data", "Deleted when you ask". Lucide icons (Shield, Lock, Trash2).
- `src/components/landing/comparison.tsx` — Anti-TurboTax hook: "Unlike TurboTax, we don't ask 60 questions or charge hidden fees." Simple side-by-side or statement block, not a full comparison table (that's Task 3.1).
- `src/components/landing/footer.tsx` — Social links (TikTok, Instagram, X), legal links (Privacy, Terms — placeholder hrefs for now), copyright.

### Page Assembly

- Update `src/app/page.tsx` to compose all landing components
- Waitlist form uses `react-hook-form` + `zod` for email validation
- Success state: "You're on the list!" with confetti (`canvas-confetti`)
- Error state: toast via `sonner` ("Already on the waitlist" for 409, generic for others)
- All API calls through `src/lib/api.ts` axios instance

### Acceptance Criteria (from spec)

- filefree.tax is live (already deployed, just needs the page content)
- Email capture works (POST to existing `/api/v1/waitlist`)
- Page loads in less than 2s
- Responsive 375px-1440px
- Dark theme with gradient accents

### Alembic Migration (prerequisite)

Before the waitlist can actually store data, the Neon database needs tables. Generate and run the initial Alembic migration via Docker Compose so the waitlist endpoint works end-to-end. This means:

- `docker compose run --rm api alembic revision --autogenerate -m "initial schema"` (generates migration file)
- Review the generated migration
- Push to main so Render auto-deploys
- Run migration against Neon: set `DATABASE_URL` on Render, then trigger migration (either via Render shell or a deploy hook)

### Merge and Ship

- Commit on `feat/0.4-landing-deploy`, push, merge to main
- Vercel auto-deploys the frontend
- Render auto-deploys the backend (migration needs manual trigger or deploy hook)

