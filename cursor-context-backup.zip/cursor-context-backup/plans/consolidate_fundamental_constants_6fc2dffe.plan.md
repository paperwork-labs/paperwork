---
name: Consolidate fundamental constants
overview: "Reduce the five fundamental-field constants to one: a single tuple of all snapshot fundamental keys (name, sub_industry, sector, industry, market_cap, …). Every use site uses this same list; 'core' is derived via slice where needed."
todos: []
isProject: false
---

# Consolidate fundamental constants to one

## Current state

Five constants in [backend/services/market/constants.py](backend/services/market/constants.py):

- `FUNDAMENTAL_FIELDS_CORE` – sector, industry, market_cap  
- `FUNDAMENTAL_FIELDS` – core + 12 more (pe_ttm, roe, …)  
- `FUNDAMENTAL_FIELDS_WITH_SUB_INDUSTRY` – sub_industry + `FUNDAMENTAL_FIELDS`  
- `FUNDAMENTAL_FIELDS_WITH_NAME` – name + `FUNDAMENTAL_FIELDS_WITH_SUB_INDUSTRY`  
- `FUNDAMENTAL_FIELDS_CORE_WITH_NAME` – name, sub_industry, sector, industry, market_cap

Usage is scattered across service and tasks. The only place that used the "15 without name/sub_industry" set was `_needs_fundamentals` ("is any fundamental missing?"). Using the full set there is correct: if name or sub_industry is missing we still want to fill. So one list suffices.

## Target: one constant

`**FUNDAMENTAL_FIELDS**` – Single tuple: `("name", "sub_industry", "sector", "industry", "market_cap", "pe_ttm", …)`. Used everywhere: _needs_fundamentals, merge from provider, select missing, copy from prev, persist. Where code needs "core" (sector, industry, market_cap) or "core with name" (first five), use slices: `FUNDAMENTAL_FIELDS[2:5]` and `FUNDAMENTAL_FIELDS[:5]`.

## Changes

### 1. [backend/services/market/constants.py](backend/services/market/constants.py)

- Replace all five constants with one: `FUNDAMENTAL_FIELDS = ("name", "sub_industry", "sector", "industry", "market_cap", "pe_ttm", "peg_ttm", "roe", "eps_growth_yoy", "eps_growth_qoq", "revenue_growth_yoy", "revenue_growth_qoq", "dividend_yield", "beta", "analyst_rating", "next_earnings", "last_earnings")`.
- Short comment: first two are name/sub_industry; remainder are fundamental data; use `[:5]` for core-with-name, `[2:5]` for core-only where needed.

### 2. [backend/services/market/market_data_service.py](backend/services/market/market_data_service.py)

- Imports: only `FUNDAMENTAL_FIELDS`.
- Line ~452 (_needs_fundamentals): keep `any(snapshot.get(f) is None for f in FUNDAMENTAL_FIELDS)` — now includes name/sub_industry, which is desired.
- Line ~755 (needs_core): use `FUNDAMENTAL_FIELDS[:5]` (name, sub_industry, sector, industry, market_cap).
- Line ~1339 (copy from prev): use `FUNDAMENTAL_FIELDS`.
- Lines ~1349 and ~1402: use `FUNDAMENTAL_FIELDS`.

### 3. [backend/tasks/market_data_tasks.py](backend/tasks/market_data_tasks.py)

- Imports: only `FUNDAMENTAL_FIELDS`.
- Line ~205 (indices enrich, copy core from provider): use `FUNDAMENTAL_FIELDS[2:5]` (sector, industry, market_cap).
- Lines ~258, ~281, ~287, ~295: use `FUNDAMENTAL_FIELDS` instead of `FUNDAMENTAL_FIELDS_WITH_NAME`.

## Result

- One constant. One source of truth. No "with name" / "with sub industry" / "core" variants.
- Slices at two call sites: `[:5]` for "core with name", `[2:5]` for "core only".

