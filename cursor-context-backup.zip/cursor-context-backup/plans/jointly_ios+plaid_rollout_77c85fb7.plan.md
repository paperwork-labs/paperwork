---
name: Jointly iOS+Plaid rollout
overview: Turn iOS into a first-class, runnable Xcode project in-repo (Simulator-ready) and harden Plaid for real institutions with stronger attribution + re-sync behaviors, while keeping backend as single source of truth.
todos:
  - id: ios-xcodeproj
    content: Create and commit `ios/Jointly/Jointly.xcodeproj` with bundle id `com.sankalpsharma.jointly`, wire existing SwiftUI sources into target, and make API base URL configurable via Info.plist.
    status: pending
  - id: ios-simulator-smoke
    content: Document and verify the iOS Simulator smoke-test path (login → dashboard → inbox → transaction detail) against local backend.
    status: pending
    dependencies:
      - ios-xcodeproj
  - id: plaid-harden-sync
    content: "Harden Plaid sync jobs: relink-required handling, idempotency locks, cursor robustness, and item status surfaced to clients."
    status: pending
  - id: attribution-using-accounts
    content: "Strengthen attribution: account owner mapping + merchant history heuristic, improve confidence/rationale stored for suggestions."
    status: pending
    dependencies:
      - plaid-harden-sync
  - id: web-connect-relink-ui
    content: Update `/connect` to show Plaid item status and a relink call-to-action when the backend marks an item as relink-required.
    status: pending
    dependencies:
      - plaid-harden-sync
---

# Jointly: iOS-first-class + Plaid hardening

## Goals
- **A (iOS)**: Commit a real Xcode project so `git clone` → open Xcode → Run in Simulator works. Bundle id: **`com.sankalpsharma.jointly`**.
- **B (Plaid)**: Move from “sandbox-only happy path” to real-institution readiness: better Link UX, robust sync/relink handling, and stronger attribution defaults.
- Ensure **web + iOS remain fully interchangeable clients** of the same backend.

## A) Make iOS first-class (commit Xcode project)
- **Create an actual Xcode project under** `ios/Jointly/`:
  - Add `ios/Jointly/Jointly.xcodeproj` (or `.xcworkspace` if we adopt SwiftPM deps later).
  - Configure:
    - **Bundle Identifier**: `com.sankalpsharma.jointly`
    - **Display Name**: Jointly
    - **App icon**: placeholder asset set in `Assets.xcassets`
    - **Debug build config** uses local API base URL (e.g. `http://localhost:1814`).
- **Move/attach existing SwiftUI sources** (currently in `ios/Jointly/`) into the Xcode target.
- **Add a single source of truth for API base URL** (e.g. Info.plist key like `JOINTLY_API_BASE_URL` read by `APIConfig.swift`) so you can switch between local/docker/prod without code edits.
- **Smoke-test in Simulator**:
  - Magic-link login
  - Dashboard fetch
  - Inbox list + transaction detail
  - Connect screen stays web-first for now (Plaid Link is already in web).

Files involved (current sources):
- `ios/Jointly/APIConfig.swift`
- `ios/Jointly/APIClient.swift`
- `ios/Jointly/SessionStore.swift`
- `ios/Jointly/JointlyApp.swift`

## B) Plaid real-institution hardening (backend-first)
- **Config + environment gating**:
  - Keep sandbox working, but allow real Plaid environments via `PLAID_ENV` (already present).
  - Ensure Link token creation includes correct options (web + iOS compatible in future) and stable `client_user_id`.
  - Current `client_name` is already set to Jointly in `[backend/app/plaid/service.py](backend/app/plaid/service.py)`.
- **Sync reliability**:
  - Audit the transaction sync job path in `[backend/app/plaid/jobs.py](backend/app/plaid/jobs.py)`:
    - Handle `ITEM_LOGIN_REQUIRED` / `ITEM_LOCKED` by marking the item status and surfacing “relink required” state.
    - Add idempotency for sync runs per item (Redis lock) to prevent overlapping syncs.
    - Store/advance cursor robustly and handle removed transactions.
- **Account ownership → attribution**:
  - Use `accounts.owner_user_id` (already patchable via `/accounts`) as a strong default signal in `_propose_owner`.
  - Add “merchant history” heuristic: if household historically assigns merchant X to user Y, propose Y with higher confidence.
- **Web UX improvements (support B)**:
  - On `/connect`, show Plaid item status (active vs relink required) and add a “Relink” CTA (web Link flow) when needed.

Key files:
- `[backend/app/plaid/service.py](backend/app/plaid/service.py)`
- `[backend/app/plaid/jobs.py](backend/app/plaid/jobs.py)`
- `[backend/app/plaid/models.py](backend/app/plaid/models.py)`
- `[web/app/connect/ConnectClient.js](web/app/connect/ConnectClient.js)`

## Test plan (practical walkthrough)
- **Web**:
  - Login → `/connect` → Link a real institution (when keys added) → exchange → accounts show.
  - Assign owners → new transactions show suggested owner.
  - If item needs relink → verify UI surfaces it.
- **iOS (Simulator)**:
  - Login with invited user → verify shared household data.
  - Browse dashboard/inbox/detail and confirm actions work.

## Notes / constraints
- You haven’t bought a domain yet → we keep domain references out of code/docs for now.
- We keep Plaid Link **web-first** initially; iOS Link can be added next using Plaid’s iOS SDK once the Xcode project is committed.

```mermaid
sequenceDiagram
  participant Web
  participant iOS
  participant API as FastAPI
  participant Plaid
  participant DB as Postgres

  Web->>API: POST /auth/magic-link
  Web->>API: POST /auth/magic-link/verify
  iOS->>API: GET /me (same user/session)

  Web->>API: POST /plaid/link-token
  API->>Plaid: link_token_create
  Web->>Plaid: PlaidLink(onSuccess public_token)
  Web->>API: POST /plaid/exchange
  API->>Plaid: item_public_token_exchange + accounts_get
  API->>DB: upsert plaid_items + accounts

  API->>Plaid: transactions_sync (worker)
  API->>DB: upsert transactions
  iOS->>API: GET /transactions?status=new
  Web->>API: GET /transactions?status=new
```
