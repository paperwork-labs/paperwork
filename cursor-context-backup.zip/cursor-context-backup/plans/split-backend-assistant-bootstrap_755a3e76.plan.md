---
name: Split-backend-assistant-bootstrap
overview: Stand up a new backend-first repo (Python/FastAPI) for assistant ingestion/search while keeping the current Next.js site as the shell, with a clear path to add guarded LLM drafts soon.
todos:
  - id: bootstrap-backend
    content: Bootstrap new Python/FastAPI backend repo
    status: pending
  - id: define-schemas
    content: Model Postgres schemas + migrations incl. pgvector
    status: pending
  - id: gmail-ingest
    content: Implement Gmail OAuth + search-based sync + quotas
    status: pending
  - id: docs-ingest
    content: Add upload, parse, chunk, embed pipeline
    status: pending
  - id: read-apis
    content: Expose read/search APIs for email/docs
    status: pending
  - id: frontend-proxy
    content: Proxy /assistant from Next.js to new backend
    status: pending
  - id: llm-guarded
    content: Add gated LLM draft stubs + budget guard
    status: pending
  - id: ci-tests
    content: CI with lint/tests and health E2E
    status: pending
---

# Plan: ReplyRunner Stack (Phase 0–1 now, LLM-ready soon)

## Scope & stance

- New repo `replyrunner` with `backend/` (Python/FastAPI + worker) and `frontend/` (fresh Next.js shell). Can add shared contracts/types later if useful.
- Near term: ingest + search/browse only (`llm_enabled=false`). Clear path to guarded LLM drafts later.

## Steps

1) **Repo/bootstrap**: Initialize `replyrunner` with `backend/`, `frontend/`, root `docker-compose.yml`, and `Makefile`/task runner (`make dev`, `make test`, `make lint`, `make format`). Include `.env.example` at root and service-specific env samples.
2) **Backend scaffold**: FastAPI app + worker (RQ/Celery/Arq); Postgres + Alembic; pgvector-ready. Config loader for envs; port current env keys into new `.env.example`.
3) **Data model & storage**: Schemas for `User`, `Account`, `Agent`, `EmailThread/EmailMessage`, `Attachment`, `Document/DocumentChunk`, `Embedding`, `Job`, `AuditEvent`, `LLMArtifact` (gated). Storage abstraction (local now, S3/R2 later); size caps and retention knobs; PDF extraction hook.
4) **Auth & tenancy**: Google OAuth allowlist; session/JWT for assistant API; tenant scoping on every query. Cron secret for jobs.
5) **Gmail ingest (search-based)**: OAuth token handling; search-based incremental sync; historyId upgrade criteria captured. Quota guard, structured logs, attachment size limits, audit of reads/writes.
6) **Docs/PDF ingest**: Upload endpoint → background parse/chunk/embed; provenance metadata; retention hooks. Pluggable embedding backend.
7) **Read/search APIs (Phase 0–1)**: Read-only endpoints for threads/messages, attachments, docs, and retrieval over email+docs. No generation yet.
8) **Frontend (fresh)**: New Next.js app in `frontend/` pointing to backend `/assistant/api` via env base URL. Pages: Dashboard, Agents, Data, Activity wired to new contracts. SSO via shared cookie/domain.
9) **LLM-ready toggles**: Config flags + budget guard; stub draft/create/send endpoints gated off; feedback schema in place for Phase 2.
10) **Security/observability**: Request/job/user/agent IDs in logs; metrics/traces; PII-safe logging; audit trails; rate limits. Cron/auth secrets documented.
11) **Testing (TDD) & CI/CD**: TDD-first unit + contract tests; budget/quota guard tests; Playwright health smoke hitting compose stack. GitHub Actions: lint/test on PR; build/publish Docker images; deploy on main to chosen host (Fly/Render/Railway to be decided) with migrations and secrets. Env promotion notes.
12) **Dev & ops**: Docker Compose for Postgres + backend + worker + frontend (optional MinIO). `make dev` for hot reload; `make migrate` for Alembic; seed demo agent.

## Key references

- Existing docs: `/Users/sankalpsharma/development/sankalpsharma/docs/assistant.md`, `architecture.md`, `security.md`, `testing.md`, `roadmap.md`.