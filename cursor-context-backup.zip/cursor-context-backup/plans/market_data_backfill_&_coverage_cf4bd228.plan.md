---
name: Market data backfill & coverage
overview: Trace the UI↔backend market-data/coverage flow, fix correctness gaps (freshness buckets + 5m-ignore behavior), add clear admin controls/observability for coverage refresh, and execute a daily OHLCV backfill plan (≈1y) to restore coverage dashboards to 100% green.
todos:
  - id: fix-coverage-buckets
    content: Fix backend `/market-data/coverage` response so `daily.freshness`/`m5.freshness` are always populated and `>48h` counts match the status/stale lists.
    status: completed
  - id: ignore-5m-status
    content: Implement “ignore 5m” coverage-status behavior when 5m backfill is disabled (toggle/config), including clear SLA/meta messaging.
    status: completed
  - id: coverage-refresh-endpoint
    content: Add admin endpoint to trigger `monitor_coverage_health` and expose last-run time/status (extend admin task status API).
    status: completed
    dependencies:
      - fix-coverage-buckets
  - id: admin-dashboard-refresh-ui
    content: "Frontend: add “Refresh coverage now”, show cache vs DB + last updated time, and auto-trigger refresh if stale (admin only)."
    status: completed
    dependencies:
      - coverage-refresh-endpoint
  - id: runbook-monitor-wireup
    content: Wire `monitor_coverage_health` into `taskActions.ts` and ensure Admin Runbook can run the full chain.
    status: completed
    dependencies:
      - coverage-refresh-endpoint
  - id: docs-coverage-updates
    content: Update `docs/MARKET_DATA.md` to clearly document coverage update mechanics, caching, refresh triggers, and 5m-ignore mode.
    status: completed
  - id: tests-coverage
    content: Add backend + frontend tests covering bucket correctness, ignore-5m behavior, refresh endpoint, and Admin Dashboard refresh UX.
    status: completed
    dependencies:
      - fix-coverage-buckets
      - ignore-5m-status
      - coverage-refresh-endpoint
      - admin-dashboard-refresh-ui
---

# Market Data Backfill + Coverage Green Plan

## End-to-end flow (today)

### UI entry points

- **Settings → Market Data → Coverage**: [`/Users/sankalpsharma/development/quantmatrix/frontend/src/pages/MarketCoverage.tsx`](/Users/sankalpsharma/development/quantmatrix/frontend/src/pages/MarketCoverage.tsx)
- On mount it calls `GET /market-data/coverage` via [`useCoverageSnapshot`](/Users/sankalpsharma/development/quantmatrix/frontend/src/hooks/useCoverageSnapshot.ts).
- It is **read-only**.
- **Settings → Admin → Dashboard**: [`/Users/sankalpsharma/development/quantmatrix/frontend/src/pages/AdminDashboard.tsx`](/Users/sankalpsharma/development/quantmatrix/frontend/src/pages/AdminDashboard.tsx)
- Shows the same coverage snapshot and exposes quick actions from server-provided `meta.actions`.
- Has a **5m backfill toggle** calling `POST /market-data/admin/coverage/backfill-5m-toggle`.
- **Settings → Admin → Runbook**: [`/Users/sankalpsharma/development/quantmatrix/frontend/src/pages/AdminRunbook.tsx`](/Users/sankalpsharma/development/quantmatrix/frontend/src/pages/AdminRunbook.tsx)
- Triggers task endpoints defined in [`taskActions.ts`](/Users/sankalpsharma/development/quantmatrix/frontend/src/utils/taskActions.ts).

### Backend coverage computation & caching

- **Read path**: `GET /api/v1/market-data/coverage` in [`backend/api/routes/market_data.py`](/Users/sankalpsharma/development/quantmatrix/backend/api/routes/market_data.py)
- If Redis has `coverage:health:last`, returns it (**`meta.source="cache"`**, `meta.updated_at` = last monitor time).
- Else computes `MarketDataService.coverage_snapshot(db)` (**`meta.source="db"`**).
- Then it recomputes daily freshness/counts directly from DB again (to avoid stale cache artifacts).
- **Write/refresh path**: Celery task `monitor_coverage_health` in [`backend/tasks/market_data_tasks.py`](/Users/sankalpsharma/development/quantmatrix/backend/tasks/market_data_tasks.py)
- Writes Redis keys:
    - `coverage:health:last` (snapshot + updated_at)
    - `coverage:health:history` (sparkline series)
- Task execution is already tracked via `JobRun` and `taskstatus:{name}:last` through [`backend/tasks/task_utils.py`](/Users/sankalpsharma/development/quantmatrix/backend/tasks/task_utils.py).

### Provider selection (why FMP)

- Provider routing is centralized in [`backend/services/market/market_data_service.py`](/Users/sankalpsharma/development/quantmatrix/backend/services/market/market_data_service.py)
- Controlled by **`MARKET_PROVIDER_POLICY`** (default `paid`) and presence of API keys.
- In **paid mode with `FMP_API_KEY` set**, historical/quotes use **FMP first** (via `fmpsdk`) and fall back (e.g., yfinance; TwelveData if configured).
- Index constituents also use **FMP-first** with Wikipedia fallback.
- Backfill tasks return `provider_usage` counters, so we can verify FMP is being used during backfill runs.
```mermaid
sequenceDiagram
  participant UI as UI
  participant API as FastAPI
  participant Celery as CeleryWorker
  participant Redis as Redis
  participant DB as Postgres
  participant Providers as Providers(FMP_first)

  UI->>API: GET /market-data/coverage
  alt cache_present
    API->>Redis: GET coverage:health:last
    Redis-->>API: snapshot+updated_at
  else cache_missing
    API->>DB: Query PriceData (latest per symbol)
    DB-->>API: coverage snapshot
  end
  API-->>UI: coverage snapshot (meta.source, meta.updated_at, buckets)

  UI->>API: POST /market-data/admin/coverage/refresh (new)
  API->>Celery: enqueue monitor_coverage_health
  Celery->>DB: query PriceData
  Celery->>Redis: SET coverage:health:last, LPUSH history
  Celery-->>API: task_id
  API-->>UI: task_id
```




## Gaps we’ll fix (based on your screenshot)

- **Freshness buckets show zeros** even when status says “520 symbols have daily bars older than 48h.”
- Root cause: the route recomputes daily counts/staleness from DB but does **not** repopulate `daily.freshness` / `m5.freshness`, so the UI renders 0s.
- **5m should not affect green** when we’re explicitly ignoring 5m.
- You selected: **ignore 5m via code** (not by doing minimal 5m backfill).
- **Coverage refresh behavior is unclear**.
- Today: UI loads `GET /coverage` on first render, but **does not** automatically run `monitor_coverage_health`.
- You selected: **auto-trigger monitor when cache is missing/stale** (default N=15m), plus a manual refresh button.

## Implementation plan

### Backend (correctness + admin refresh)

- **Fix coverage freshness bucket data** in [`backend/api/routes/market_data.py`](/Users/sankalpsharma/development/quantmatrix/backend/api/routes/market_data.py)
- Ensure `snapshot.daily.freshness` is always present and consistent with the recomputed DB freshness.
- Ensure `>48h` bucket count is correct and matches `stale_daily` semantics.
- **Ignore 5m in status when 5m backfill is disabled**
- Use the existing Redis toggle `coverage:backfill_5m_enabled`.
- When disabled, `compute_coverage_status` should not set `degraded`/`warning` from 5m absence.
- Update SLA metadata to clearly communicate that 5m is intentionally ignored.
- **Add an admin endpoint to refresh coverage now**
- Add `POST /api/v1/market-data/admin/coverage/refresh` to enqueue `monitor_coverage_health`.
- Extend `GET /api/v1/market-data/admin/tasks/status` to include `taskstatus:monitor_coverage_health:last` (so UI can show last-run time without scraping Jobs).

### Frontend (neat, clean UX)

- **Admin Dashboard: “Refresh coverage now” + last run/source**
- In [`frontend/src/pages/AdminDashboard.tsx`](/Users/sankalpsharma/development/quantmatrix/frontend/src/pages/AdminDashboard.tsx):
    - Add a button that calls the new refresh endpoint.
    - Display: `meta.source` (cache vs db), `meta.updated_at`, and `meta.snapshot_age_seconds` in a compact, consistent way.
- **Auto-refresh when cache is missing/stale (admin only)**
- If `meta.source != "cache"` or `meta.snapshot_age_seconds > 15*60`, trigger refresh endpoint once on load.
- **Fix Admin Runbook wiring**
- Add `monitor_coverage_health` to [`frontend/src/utils/taskActions.ts`](/Users/sankalpsharma/development/quantmatrix/frontend/src/utils/taskActions.ts) (currently referenced in `AdminRunbook` but not implemented).
- Point it to the new `/market-data/admin/coverage/refresh` endpoint.

### Docs (how coverage updates)

- Update [`docs/MARKET_DATA.md`](/Users/sankalpsharma/development/quantmatrix/docs/MARKET_DATA.md) with a **Coverage & Freshness** section that explains:
- What “coverage” means (daily freshness buckets, stale cutoff >48h)
- When coverage refreshes automatically (hourly schedule) vs on-demand (admin button)
- Cache vs DB behavior (`meta.source`, `meta.updated_at`, staleness threshold)
- How to interpret the UI (why “Updated … ago” can be recent even if data is stale)
- 5m ignore mode (when enabled, 5m is informational only)

## Backfill plan (restore daily coverage to 100% green)

### Goal

- **Daily coverage**: 100% of tracked symbols have a daily bar within the last 48h; freshness buckets reflect reality.
- **5m**: explicitly ignored for coverage status (no need to backfill 5m).

### Execution chain (operators)

- Preferred: **Admin Runbook** “Coverage Reset Chain” (after we wire monitor step correctly), but with 5m ignored.
- Backend tasks in order:
- `refresh_index_constituents`
- `update_tracked_symbol_cache`
- `backfill_last_200_bars` (≈1y/270 bars; FMP-first)
- `recompute_indicators_universe`
- `record_daily_history`
- `monitor_coverage_health` (hourly schedule + on-demand refresh)

### Verification

- `GET /api/v1/market-data/coverage`:
- `status.label == "ok"`
- `status.stale_daily == 0`
- `daily.freshness[">48h"] == 0` and `daily.freshness["none"] == 0` (or “none” only for truly missing symbols)
- `meta.source == "cache"` after monitor runs
- `Admin Jobs` shows successful JobRuns for the backfill tasks.
- Backfill responses include `provider_usage` confirming FMP usage.

## Testing plan (keep it clean + well-tested)