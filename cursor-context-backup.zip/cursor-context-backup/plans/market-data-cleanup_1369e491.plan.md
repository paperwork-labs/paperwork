---
name: market-data-cleanup
overview: Implement the six remaining DRY/architecture cleanups in market data (fundamentals constants, tracked-symbol helper, column order helper, move route logic to services, shared DataFrame conversion, and split heavy service responsibilities), with tests updated as needed.
todos:
  - id: constants-and-helpers
    content: Create shared constants/helpers for fundamentals, columns, tracked symbols
    status: completed
  - id: service-split
    content: Extract provider/snapshot/coverage services and update usage
    status: completed
  - id: tests-and-verify
    content: Update tests and run make test
    status: completed
isProject: false
---

# Market Data DRY + Architecture Cleanup

## Scope

Implement all six requested improvements:

1. fundamentals constants, 2) tracked symbols helper, 3) preferred column helper, 4) move route logic into services, 5) shared DataFrame conversion helper, 6) split `MarketDataService` responsibilities.

## Implementation Plan

- **Centralize constants**
  - Add a shared constants module (e.g. `[backend/services/market/constants.py](/Users/sankalpsharma/development/axiomfolio/backend/services/market/constants.py)`) with `FUNDAMENTAL_FIELDS` and snapshot preferred column lists.
  - Replace hardcoded lists across `[backend/services/market/market_data_service.py](/Users/sankalpsharma/development/axiomfolio/backend/services/market/market_data_service.py)` and `[backend/tasks/market_data_tasks.py](/Users/sankalpsharma/development/axiomfolio/backend/tasks/market_data_tasks.py)`.
- **Tracked symbols helper**
  - Add `_get_tracked_symbols_safe()` in `[backend/tasks/market_data_tasks.py](/Users/sankalpsharma/development/axiomfolio/backend/tasks/market_data_tasks.py)` (or move to a shared helper in `services/market/universe.py` if reused outside tasks).
  - Replace all inline Redis/DB fallback patterns in tasks with the helper.
- **Preferred column helper**
  - Introduce `_snapshot_preferred_columns()` helper in `[backend/api/routes/market_data.py](/Users/sankalpsharma/development/axiomfolio/backend/api/routes/market_data.py)` backed by constants.
  - Update `get_snapshot`, `get_snapshots`, and `get_snapshot_history` to use the helper.
- **Move route logic to services**
  - Extract `_load_tracked_details()` into `MarketDataService.get_tracked_details()` (or a new `TrackedUniverseService`) and call it from the route.
  - Move any complex coverage assembly logic that still lives in routes into a service method to keep routes thin.
- **Shared DataFrame conversion**
  - Add a helper (e.g. `_price_rows_to_dataframe`) in a shared market utilities module (e.g. `[backend/services/market/dataframe_utils.py](/Users/sankalpsharma/development/axiomfolio/backend/services/market/dataframe_utils.py)`), and replace duplicated conversions in service/tasks.
- **Split `MarketDataService**`
  - Extract into focused services:
    - `MarketDataProviderService` (provider fetch + fallback)
    - `MarketSnapshotService` (snapshot computation/persistence)
    - `CoverageService` (coverage computation + cache)
  - Keep `MarketDataService` as a facade that wires these services together for backward compatibility.
  - Update imports/usage in routes and tasks to the new service boundaries.
- **Tests + validation**
  - Run `make test` and adjust any failing tests related to moved logic or refactored imports.
  - Add/adjust unit tests for new helpers if necessary (especially for tracked-symbol fallback and preferred columns).

## Files to Change

- `[backend/services/market/market_data_service.py](/Users/sankalpsharma/development/axiomfolio/backend/services/market/market_data_service.py)`
- `[backend/tasks/market_data_tasks.py](/Users/sankalpsharma/development/axiomfolio/backend/tasks/market_data_tasks.py)`
- `[backend/api/routes/market_data.py](/Users/sankalpsharma/development/axiomfolio/backend/api/routes/market_data.py)`
- New helper modules under `[backend/services/market/](/Users/sankalpsharma/development/axiomfolio/backend/services/market/)`
- Tests under `[backend/tests/](/Users/sankalpsharma/development/axiomfolio/backend/tests/)`

## Notes

- Keep backward-compatible method names where possible to avoid broad churn; use facade methods on `MarketDataService` to minimize changes in call sites.

