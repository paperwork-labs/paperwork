---
name: Infra+Safety Rails
overview: Standardize infra/env + Makefile entrypoint, spin up full stack predictably, and harden DB test isolation with dedicated test Postgres + multiple independent guards (including a canary) so real tables like price_data can never be dropped by tests.
todos:
  - id: infra-layout
    content: Create infra/ structure (compose.dev.yaml, compose.test.yaml, env.dev.example, env.test.example) and migrate day-to-day usage off root docker-compose.yml.
    status: pending
  - id: makefile-entrypoint
    content: Add Makefile with canonical targets (up/down/down-reset/logs/ps/test-up/test) using fixed --project-name and explicit --env-file.
    status: pending
  - id: env-git-hygiene
    content: Update .gitignore to ignore infra/env.dev and infra/env.test (real secrets) while keeping infra/*.example committed.
    status: pending
  - id: test-postgres-service
    content: Add dedicated postgres_test service with separate volume + distinct credentials; wire TEST_DATABASE_URL accordingly.
    status: pending
  - id: pytest-paranoia-guards
    content: Harden backend/tests/conftest.py to require postgres_test host + *_test dbname + expected user; also verify current_database() and add a sentinel canary table/row.
    status: pending
  - id: runtime-guard
    content: Optionally strengthen backend/database.py SessionLocal test-mode guard to require postgres_test host for TEST_DATABASE_URL.
    status: pending
  - id: spinup-snapshot
    content: Use Makefile entrypoint to bring up stack and produce a current-state snapshot (green/yellow/red + immediate priorities).
    status: pending
  - id: improvement-backlog
    content: Produce prioritized improvement recommendations based on observed runtime signal and codebase audit, with effort/risk estimates.
    status: pending
---

# QuantMatrix Infra Cleanup + DB-Test Safety Rails Plan

## Goals
- **One canonical local entrypoint** (`make up`, `make down`, `make logs`, `make test`)
- **Clean, production-ready infra/env pattern** (safe templates in git; real secrets out of git)
- **Predictable Docker project naming** (no random compose project names)
- **No port-collision surprises** (explicit host port vars)
- **Hard guarantee**: pytest can **never** drop or mutate your real DB/tables (e.g., `price_data`) again

## Guiding principles (what we do + why)
- **Separate host-level substitution vs container runtime env**
  - Host substitution: `docker compose --env-file infra/env.dev ...` enables `${VAR}` interpolation inside compose.
  - Container runtime env: `env_file: infra/env.dev` ensures backend/worker/frontend receive the same env.
- **Separate internal Docker URLs vs browser URLs**
  - Internal: `API_BASE_URL=http://backend:8000` (container-to-container)
  - Browser: `VITE_API_URL=http://localhost:${BACKEND_HOST_PORT}` (browser-to-api)
- **Safe defaults + intentional resets**
  - `make down` preserves volumes
  - `make down-reset` explicitly removes volumes

## Phase 0 — Infra layout & env hygiene (foundation)
### Add `infra/` structure
Create:
- [`infra/compose.dev.yaml`](infra/compose.dev.yaml): dev stack (postgres, redis, backend, celery, flower, frontend, optional cloudflared)
- [`infra/compose.test.yaml`](infra/compose.test.yaml): **test-only Postgres** (and optional test runner service)
- [`infra/env.dev.example`](infra/env.dev.example): safe placeholders + port vars
- [`infra/env.test.example`](infra/env.test.example): safe placeholders for test DB only

Keep existing root files for backward compatibility initially:
- Keep [`docker-compose.yml`](/Users/sankalpsharma/development/quantmatrix/docker-compose.yml) working, but move day-to-day usage to `Makefile` + `infra/*`.

### Secrets out of git
- Commit only `infra/*.example`
- Add `.gitignore` entries for:
  - `infra/env.dev`
  - `infra/env.test`
  - (optionally) `.env` if we fully migrate away from root `.env`

## Phase 1 — Canonical entrypoint: Makefile
Add a root [`Makefile`](Makefile) with targets (non-destructive by default):
- `make up`: bring up dev stack using fixed project name
- `make down`: stop stack (no volume deletion)
- `make down-reset`: stop + remove volumes (explicit wipe)
- `make ps`: show status
- `make logs`: tail logs (backend/worker)
- `make test-up`: bring up `postgres_test`
- `make test`: run pytest in a controlled env against `postgres_test`

Implementation details:
- Use a fixed project name, e.g. `quantmatrix`:
  - `docker compose --project-name quantmatrix --env-file infra/env.dev -f infra/compose.dev.yaml ...`
- Compose uses port vars from env:
  - `DB_HOST_PORT`, `REDIS_HOST_PORT`, `BACKEND_HOST_PORT`, `WEB_HOST_PORT`, `FLOWER_HOST_PORT`

## Phase 2 — Dedicated test Postgres + “extra paranoia” guards
### Safety layer A (physical isolation): `postgres_test` service
In [`infra/compose.test.yaml`](infra/compose.test.yaml):
- Add `postgres_test` with a **separate named volume** (e.g. `postgres_test_data`)
- Use **different credentials** from dev (e.g. `quantmatrix_test` user/password)
- Expose optional host port var `TEST_DB_HOST_PORT` for local inspection

### Safety layer B (fail-fast URL validation): hard requirements in pytest
Harden [`backend/tests/conftest.py`](/Users/sankalpsharma/development/quantmatrix/backend/tests/conftest.py):
- Parse `TEST_DATABASE_URL` and assert **all**:
  - host == `postgres_test`
  - dbname endswith `_test` (e.g. `quantmatrix_test`)
  - user == `quantmatrix_test` (or whatever we standardize)
- Also keep/strengthen existing protection:
  - refuse if `TEST_DATABASE_URL` missing
  - refuse if `TEST_DATABASE_URL == app DATABASE_URL`

### Safety layer C (server-side verification): validate what DB we actually connected to
After connecting to `test_engine` (and only after URL checks):
- Run read-only checks:
  - `SELECT current_database()` must endwith `_test`
  - `SELECT inet_server_addr(), inet_server_port()` (or equivalent) must match expectations

### Safety layer D (canary sentinel): “prove this is a test DB”
Add a canary that makes it nearly impossible to accidentally point at real DB:
- After the above checks succeed, create a tiny sentinel table/row if missing (first run):
  - e.g. table `quantmatrix_test_sentinel` with a row containing:
    - `created_by='pytest'`
    - `created_at`
    - optional `project_name`
- On every test session start, require that sentinel to exist and match expectations.

Rationale:
- Even if someone somehow routes `TEST_DATABASE_URL` to the wrong Postgres service, the combination of:
  - host/dbname/user checks
  - `current_database()` checks
  - sentinel requirement
  makes an accidental “real DB” hit extremely unlikely.

### Safety layer E (runtime safety): keep guarded session factory
We keep and (optionally) strengthen the runtime guard in [`backend/database.py`](/Users/sankalpsharma/development/quantmatrix/backend/database.py):
- Under pytest (`PYTEST_CURRENT_TEST` or `QUANTMATRIX_TESTING`), `SessionLocal()` refuses to operate unless `TEST_DATABASE_URL` is set and is not equal to app DB.
- Optional enhancement: also require `TEST_DATABASE_URL` host == `postgres_test`.

## Phase 3 — Spin up & verify “where we are” (operational snapshot)
Once infra is standardized:
- `make up`
- Verify:
  - Backend: `GET /health`, `GET /docs`
  - Frontend: loads, API calls succeed via proxy
  - Flower: worker online
  - Auth/RBAC: `GET /api/v1/auth/me`, admin routes gated
  - Broker async jobs: at least one connect/sync path exercised (safe failure if creds missing)

## Phase 4 — Codebase improvement recommendations (after we have runtime signal)
Deliver a prioritized backlog (risk/effort/impact), with **DB-safety** as item #1 already addressed.
Initial likely candidates (to confirm during Phase 3):
- **Config consolidation**: converge fully on `settings` in [`backend/config.py`](/Users/sankalpsharma/development/quantmatrix/backend/config.py)
- **Startup/migrations policy**: decide whether startup should fail-fast if Alembic upgrade fails (currently warns and continues)
- **Compose hygiene**: clarify optional services (cloudflared/nginx) as profiles, and ensure missing configs (e.g., nginx.conf) are either added or removed from dev defaults

```mermaid
flowchart LR
  browser[Browser] --> web[Frontend_3000]
  web -->|"/api proxy"| api[Backend_8000]
  api --> pgDev[Postgres_dev_volume]
  api --> r[Redis]

  pytest[Pytest] --> pgTest[Postgres_test_volume]
```
