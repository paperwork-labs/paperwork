---
name: ChakraV3Menu+LatestSweep
overview: Fix the current Chakra v3 runtime export errors (MenuButton, useColorModeValue/useColorMode) by migrating to Chakra v3 APIs, then update all dependency surfaces (frontend npm, backend pip, GitHub Actions, Docker base images) to latest stable majors with a safety net of tests/builds.
todos:
  - id: fix-chakra-v3-menu
    content: Replace Chakra v2 MenuButton/MenuList patterns with Chakra v3 MenuRoot/MenuTrigger/MenuContent in affected files
    status: completed
  - id: fix-chakra-v3-color-mode
    content: Remove useColorModeValue/useColorMode usage and migrate styling to Chakra v3 token/system-compatible patterns
    status: completed
    dependencies:
      - fix-chakra-v3-menu
  - id: upgrade-frontend-deps
    content: Update frontend npm dependencies to latest stable majors (LTS policy) and regenerate lockfile
    status: completed
    dependencies:
      - fix-chakra-v3-color-mode
  - id: upgrade-backend-deps
    content: Update backend Python dependencies to latest stable majors and rebuild
    status: completed
    dependencies:
      - upgrade-frontend-deps
  - id: upgrade-actions
    content: Update GitHub Actions to latest majors
    status: completed
    dependencies:
      - upgrade-backend-deps
  - id: upgrade-docker-images
    content: Update Docker base images (Node 22, Python 3.12, Postgres 16) with pinned tags
    status: completed
    dependencies:
      - upgrade-actions
  - id: verify-stack
    content: Rebuild/recreate stack and verify frontend loads + /api proxy works; run backend tests
    status: completed
    dependencies:
      - upgrade-docker-images
---

# Plan: Fix Chakra v3 runtime errors + Update to latest (all)

## 0) Success criteria

- Frontend boots without browser console module export errors.
- `http://localhost:3000/` loads and `/api/v1/auth/health` via Vite proxy returns 200.
- Dependency surfaces updated to **latest stable majors (LTS policy)** across frontend, backend, GitHub Actions, and Docker images.

## 1) Fix Chakra v3 export errors (starting with `MenuButton`)

**Problem:** Chakra v3 does not export multiple Chakra v2-era components/hooks that the code still imports:

- `MenuButton` (and often `MenuList`) are not exported
- `useColorModeValue` / `useColorMode` are not exported

### 1.1 Menu migration (Chakra v2 → v3)

- Replace v2 menu usage patterns in:
- `frontend/src/components/layout/DashboardLayout.tsx`
- `frontend/src/pages/OptionsPortfolio.tsx`
- `frontend/src/pages/Notifications.tsx`
- `frontend/src/pages/MultiPortfolio.tsx`
- `frontend/src/pages/PortfolioCategories.tsx`
- `frontend/src/pages/Strategies.tsx`

Using Chakra v3 exports verified in the container:

- Use `MenuRoot`/`MenuTrigger`/`MenuContent`/`MenuItem` (instead of `MenuButton`/`MenuList`).

### 1.2 Remove v2-only color mode hooks

- Replace `useColorModeValue` / `useColorMode` usage with v3-compatible alternatives:
- Prefer token-driven styling and explicit color tokens
- Where conditional styling is needed, use CSS variables or theme tokens (via system) rather than hook APIs.

### 1.3 Theme/provider correctness (Chakra v3)

- Ensure `frontend/src/App.tsx` uses Chakra v3 `createSystem(defaultConfig, ...)` and `<ChakraProvider value={system}>` (no `extendTheme`).

## 2) Update to latest everywhere (include majors) under LTS policy

### 2.1 Frontend npm deps

- Update `frontend/package.json` to latest stable majors.
- Regenerate `frontend/package-lock.json`.
- Ensure we do **not** add `@chakra-ui/icons` (it is not compatible with Chakra v3 in this setup).

### 2.2 Backend Python deps

- Update `requirements.txt` pins to latest stable majors where available.
- Rebuild backend container and run backend test suite.

### 2.3 GitHub Actions

- Update action versions in `.github/workflows/*.yml` to latest major releases.

### 2.4 Docker base images

- Update Dockerfiles:
- `Dockerfile.frontend`: Node 22 (LTS) alpine
- `Dockerfile.backend`: Python 3.12 slim
- Update compose images where appropriate:
- Postgres 16 alpine
- Redis 7.x (pinned)

## 3) Verification

- Rebuild/recreate dev stack (frontend at minimum) and validate:
- `curl http://localhost:3000/` → 200
- `curl http://localhost:3000/api/v1/auth/health` → 200
- Run backend tests (isolated test DB) to ensure the upgrade didn’t break DB safety.

## 4) Deliverables

- Chakra v3 compatibility fixes (menus + styling)
- Full dependency “latest stable majors” sweep across:
- `frontend/package.json` + lockfile