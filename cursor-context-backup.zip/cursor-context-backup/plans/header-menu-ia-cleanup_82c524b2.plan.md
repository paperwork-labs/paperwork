---
name: header-menu-ia-cleanup
overview: "Refine header account/notification information architecture for cleaner quick access: remove duplicated app-nav links from the avatar menu and replace with focused account/session actions."
todos:
  - id: update-avatar-menu-items
    content: Replace avatar menu entries with account/session actions and remove duplicated sidebar links.
    status: completed
  - id: preserve-notification-menu-scope
    content: Keep bell menu focused on notifications with notification-center CTA and no app-nav duplication.
    status: completed
  - id: run-targeted-ui-tests
    content: Run relevant frontend tests and adjust assertions only if impacted by menu label changes.
    status: completed
isProject: false
---

# Header Menu IA Cleanup Plan

## Scope

Update the header menus in [frontend/src/components/layout/DashboardLayout.tsx](/Users/sankalpsharma/development/axiomfolio/frontend/src/components/layout/DashboardLayout.tsx) to align with clear ownership:

- Sidebar = primary app navigation.
- Avatar menu = account/session actions.
- Bell menu = recent notifications + jump to notification center.

## Changes

- Refactor avatar menu items to account-focused links only:
  - `Profile` -> `/settings/profile`
  - `Preferences` -> `/settings/preferences`
  - `Brokerages` -> `/settings/brokerages`
  - `Notification Center` -> `/settings/notifications`
  - `Security` -> `/settings/security`
  - Admin-only: `Admin Dashboard` -> `/settings/admin/dashboard`
  - Keep `Logout` as the terminal action.
- Remove duplicated app-nav shortcuts from avatar menu (`Portfolio`, `Workspace`) since those already live in the sidebar.
- Keep notification bell menu as event feed surface with `Open Notification Center` CTA (already implemented), and ensure no overlap with app-nav links.

## Validation

- Run targeted layout/settings tests:
  - `frontend/src/components/layout/__tests__/DashboardLayoutPersistence.test.tsx`
  - `frontend/src/pages/__tests__/SettingsShell.test.tsx`
- Add/adjust assertions in layout tests only if menu text/structure is currently covered.

## Notes

- No routing changes required because all target routes already exist in [frontend/src/App.tsx](/Users/sankalpsharma/development/axiomfolio/frontend/src/App.tsx).
- Keep changes low-risk and UI-only (no backend impact).

