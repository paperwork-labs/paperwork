---
name: Naming RA Trinkets Updates
status: archived
overview: "ARCHIVED — Content integrated into Venture Master Plan Section 0B/0F. Naming, RA pricing, Trinkets strategy, and domain decisions all folded in."
todos:
  - id: naming-research
    content: "LLC name TBD -- user brainstorming separately. Master plan Section 0B updated with Toast Inc risk analysis + 'butters' slang finding. Name left as placeholder."
    status: pending
  - id: ra-strategy
    content: "Correct F7 RA pricing: $25-29/yr Wyoming (our LLC), $49-149/yr wholesale tiers for LaunchFree users (CorpNet volume pricing). Add GoDaddy competitive analysis. Clarify moat: transparent pricing + no bait-and-switch + AI guidance + cross-sell trust."
    status: pending
  - id: trinkets-plan
    content: "Finalize docs/UTILITY_SITES_STRATEGY.md. Add Trinkets as Phase 1.5 in master plan. Add Trinket Factory agent pipeline (3-stage: Discovery Agent -> PRD Agent -> Eng Agent). First trinket = financial calculators (pre-decided idea, agent validates). Add templates: docs/templates/trinket-one-pager.md + trinket-prd.md."
    status: pending
  - id: master-plan-sync
    content: "Update master plan: overview, todos, phase table, Section 10 decisions, domains purchased (launchfree.ai + filefree.ai), Trinket Factory pipeline spec, corrected RA economics."
    status: pending
isProject: false
---

# Naming, RA Strategy, and Trinkets Revenue Stream

## 1. Holding Company Name: "Toast" Market Study

### How the Name Works

Yes, sankalpsharma.com remains the command center / HQ. The LLC name is a **legal facade only** -- it appears on:

- State filings, tax returns, bank accounts
- Privacy policies and Terms of Service ("FileFree and LaunchFree are products of [LLC Name]")
- Invoices and contracts
- Press mentions / media quotes ("Toast Ventures, the company behind FileFree...")

It does NOT appear in product UI, app stores, or direct marketing. FileFree and LaunchFree are the customer-facing brands.

### The Problem with "Toast"

**Toast Inc (NYSE: TOST)** is a $25B+ restaurant POS company. They:

- Own 28 USPTO trademark registrations including "TOAST" (Registration #6185319) in Class 009
- **Actively enforce**: They sued **Toast Labs, Inc.** in January 2016 (SDNY, Case 1:16-cv-00168). The case was "voluntarily dismissed" in March 2016 -- likely a settlement where Toast Labs changed their name.
- Their marks are in restaurant/POS classes, NOT financial services. But they clearly don't tolerate "Toast [X]" branding.

**Risk assessment**:

- **"Toast Ventures LLC"** or **"Toast Labs LLC"**: HIGH RISK. Toast Inc has already sued "Toast Labs." Even in a different industry, receiving a cease & desist from a company with $25B market cap and aggressive IP counsel is expensive to fight, even if you'd win.
- **"Toasted Ventures LLC"** or similar derivatives: MEDIUM RISK. Clearly different but still in the "toast" family.
- **Toast as holding company only (never public-facing)**: LOWER risk but still not zero. Privacy policies, press mentions, SEC filings (if you ever raise) would all reference it.

### Recommended Approach

Given Toast Inc's enforcement history, **avoid the word "Toast" in the primary LLC name position**. Instead, consider these options:

**Option A: Toast-inspired but legally differentiated**


| Name                     | Story                                                              | Domain Available?         | Risk       |
| ------------------------ | ------------------------------------------------------------------ | ------------------------- | ---------- |
| **Toasted Ventures LLC** | Past tense clearly differentiates. "We make things that are done." | toasted.ventures (check)  | Medium     |
| **Marmalade Labs LLC**   | Toast topping. Fun, unique, zero trademark conflict.               | marmalade.labs (check)    | Very Low   |
| **Golden Toast LLC**     | Adjective differentiates. Warm, aspirational.                      | goldentoast.com (check)   | Medium-Low |
| **Crumb Ventures LLC**   | Toast-adjacent. "From crumbs to empires."                          | crumbventures.com (check) | Very Low   |
| **Buttered Labs LLC**    | Playful, toast-adjacent, memorable.                                | butteredlabs.com (check)  | Very Low   |


**Option B: Previously recommended (no toast connection)**


| Name                      | Story                                             | Risk     |
| ------------------------- | ------------------------------------------------- | -------- |
| **Kindling Ventures LLC** | "Starting fires" -- connects to LaunchFree energy | Very Low |
| **Meridian Ventures LLC** | Neutral, professional, abstract                   | Very Low |


**Option C: Embrace "Toast" with full awareness of risk**

Use **"Toast [X] LLC"** knowing that:

- It's a holding company, never customer-facing
- Different trademark class (financial services vs restaurant POS)
- If Toast Inc sends a C&D, changing an LLC name costs ~$50-100 in state fees + new bank accounts

From the domain list provided, the most interesting for a ventures/labs entity:

- `toast.fund` ($19.99 first yr) -- if you ever wanted a public-facing URL
- `toast.exchange` ($17.99 first yr) -- interesting for a platform concept
- `toast.productions` ($14.99 first yr) -- creative studio energy

**My recommendation**: **Go with a toast-INSPIRED name that avoids the exact word "Toast" in primary position.** Best options: **Marmalade Labs LLC** (unique, zero risk, fun origin story: "my daughter's favorite word is toast") or **Kindling Ventures LLC** (previously recommended, strong metaphor). If you insist on "Toast", use **Toasted Ventures LLC** as the safest variant.

---

## 2. Registered Agent Strategy: Corrected

### Is RA Required?

**Yes, mandatory in all 50 states.** Every LLC and corporation must designate a registered agent before the state will approve formation documents. Operating without one can result in administrative dissolution, inability to defend lawsuits, fines, and personal liability.

**Exceptions**: New York and West Virginia -- the Secretary of State serves as RA by default.

### RA Pricing Reality (It's WAY Cheaper Than $125)

The previous plan cited Northwest RA at ~$125/yr. That was for a **wholesale resale partnership** (we resell to our users). For **our own LLC** and for **user-facing pricing**, much cheaper options exist:


| Provider                          | Price/Year       | Coverage      | Notes                                           |
| --------------------------------- | ---------------- | ------------- | ----------------------------------------------- |
| Wyoming Registered Agent Services | **$25/yr**       | Wyoming only  | Cheapest in market. Real office, mail scanning. |
| Rocky Mountain Registered Agent   | **$29/yr**       | Wyoming only  | Similar budget tier                             |
| Buffalo Registered Agents         | **$49/yr**       | Wyoming only  | Free basic scanning                             |
| MyCompanyWorks                    | **$99/yr**       | All 50 states | Cheapest nationwide                             |
| Northwest Registered Agent        | **$125/yr**      | All 50 states | Most recommended, transparent pricing           |
| ZenBusiness                       | **$99 first yr** | All 50 states | Jumps to $199/yr on renewal                     |


**For our OWN Wyoming LLC**: Use the $25/yr or $29/yr provider. Done.

**For LaunchFree USERS**: This is where the strategy matters. We need a wholesale partner for volume pricing.

### GoDaddy "Free LLC" -- What's Actually Happening

GoDaddy (via LegalZoom partnership) offers **$0 service fee** for LLC formation. The user still pays:

- **State filing fee**: $100 (Wyoming), $90 (Delaware), $50-$800 (varies by state)
- **Registered Agent**: Not included. GoDaddy upsells their own RA at ~$150/yr
- **Operating Agreement**: Not included. Upsell.
- **EIN Filing**: Not included. Upsell (even though IRS provides this free)

Same model for ZenBusiness ($0 formation, $199/yr RA renewal), Bizee ($0 formation, $119/yr RA), LegalZoom ($0 formation, $249/yr RA).

### LaunchFree's REAL Competitive Advantage (It's NOT Just "Free Filing")

Everyone offers $0 LLC formation now. That's table stakes. Here's where LaunchFree differentiates:

1. **No bait-and-switch**: ZenBusiness charges $199/yr on RA renewal (vs $99 first year). LegalZoom charges $249/yr. We charge $49/yr flat. No surprise renewals. No hidden upsells.
2. **AI-powered guidance**: GPT-powered wizard that explains what you need in plain English, not legal jargon. Generates operating agreement. Walks through EIN application.
3. **RA credit system**: Earn credits through referrals and activity to reduce or eliminate the $49/yr RA cost. Can genuinely reach $0/yr.
4. **Cross-sell from FileFree trust**: "You already trust us with your taxes. Now launch your business." This is a conversion funnel competitors don't have.
5. **All 50 state data, AI-maintained**: Formation requirements, fees, processing times, pros/cons -- for every state. Updated by AI agents, not stale blog posts.
6. **Compliance calendar**: Automated reminders for annual reports, franchise taxes, RA renewals. Competitors charge $100+/yr for "compliance packages."

The moat is the **cross-product trust flywheel** (FileFree -> LaunchFree -> advisory), not the filing itself.

### Updated RA Strategy for Master Plan

- **Our own LLC**: $25-29/yr Wyoming RA (budget provider)
- **LaunchFree users**: Partner with a wholesale RA provider at ~$25-35/yr per user. Resell at $49/yr (margin: $14-24/user). Offer credit mechanism to reduce to $0.
- **Phase 3+ (DIY RA)**: Only when volume justifies ($2,500-5,000/yr for 50-state virtual offices). Deferred.

---

## 3. Utility Sites ("Trinkets") -- McKinsey-Style Analysis

### Market Data


| Leader   | Monthly Visits | Est. Revenue             | RPM           | Founded | Authority Score |
| -------- | -------------- | ------------------------ | ------------- | ------- | --------------- |
| iLovePDF | 216M           | ~$4M/yr ads + premium    | ~$0.005/visit | 2010    | DA 91           |
| SmallPDF | 61M            | ~$11M/yr (freemium SaaS) | ~$0.015/visit | 2013    | DA 83           |
| PDF2Go   | 5-12M          | ~$670K/yr                | ~$0.005/visit | 2009    | ~DA 50          |
| TinyPNG  | ~20M           | ~$500K-1M/yr             | ~$0.004/visit | 2014    | ~DA 60          |


### SEO Timeline Reality (Data-Backed)

From multiple 2026 SEO studies (BackendSpark, PeakLora, AustinCodeMonkey):

- **Months 1-2**: Indexed, zero meaningful traffic
- **Months 3-6**: First long-tail keyword rankings (KD < 30)
- **Months 6-12**: Stable rankings, traffic compounds (1K-10K/mo)
- **Month 12+**: Meaningful traffic if SEO compounds
- **To compete with iLovePDF/SmallPDF**: 3-5+ years and massive backlink building

**Critical reality**: A new domain will NOT rank for "pdf to word" (KD 80+) within Year 1. BUT it CAN rank for long-tail variants like "convert scanned pdf to editable word free" (KD 20-30) within 3-6 months.

### Revenue Projections (Conservative, No Hype)


| Period       | Monthly Visits (all tools) | AdSense RPM | Monthly Revenue  |
| ------------ | -------------------------- | ----------- | ---------------- |
| Months 1-3   | < 100                      | $0          | **$0**           |
| Months 4-6   | 500-2,000                  | $3          | **$1.50-6**      |
| Months 7-9   | 2,000-10,000               | $4          | **$8-40**        |
| Months 10-12 | 10,000-50,000              | $4          | **$40-200**      |
| Months 13-18 | 50,000-200,000             | $5          | **$250-1,000**   |
| Months 19-24 | 200,000-500,000            | $5          | **$1,000-2,500** |


**Year 1 total**: ~$50-300 (barely covers the domain)
**Year 2 total**: ~$5,000-20,000 (meaningful side income)
**Year 3+ (if compound SEO works)**: $20,000-100,000/yr

### Tool Selection (Ranked by Opportunity)

**Build these 8-10 tools** (prioritize Tier 2 low-KD keywords for faster ranking):


| Tool                    | Search Vol (est.) | KD          | Build Time | Legal Risk |
| ----------------------- | ----------------- | ----------- | ---------- | ---------- |
| HEIC to JPG             | 200K+             | LOW (30)    | 0.5 day    | None       |
| WebP to PNG             | 100K+             | LOW (25)    | 0.5 day    | None       |
| Image Compressor        | 300K+             | MEDIUM (45) | 0.5 day    | None       |
| QR Code Generator       | 1M+               | HIGH (70)   | 0.5 day    | None       |
| JSON Formatter          | 200K+             | LOW (25)    | 0.5 day    | None       |
| SVG to PNG              | 50K+              | LOW (15)    | 0.5 day    | None       |
| Image to PDF            | 500K+             | MEDIUM (50) | 0.5 day    | None       |
| PDF Merge               | 300K+             | MEDIUM (55) | 0.5 day    | None       |
| Color Palette Generator | 100K+             | LOW (20)    | 1 day      | None       |
| Markdown to HTML        | 50K+              | LOW (15)    | 0.5 day    | None       |


**AVOID** (legal risk): Instagram/TikTok/YouTube downloaders (DMCA violations).

### Technical Fit with Our Infra

```
venture/
  apps/
    trinkets/                  (Next.js SSG, Vercel free tier)
      src/app/
        heic-to-jpg/page.tsx
        webp-to-png/page.tsx
        image-compressor/page.tsx
        qr-generator/page.tsx
        ...
      src/components/
        tool-layout.tsx        (shared: header, ad slots, footer)
        ad-unit.tsx            (Google AdSense)
        seo-head.tsx           (per-tool JSON-LD)
  packages/
    ui/                        (shared shadcn components)
```

- **Zero server cost**: All processing happens client-side (pdf-lib, heic2any, browser-image-compression, qrcode.js)
- **Zero backend needed**: Pure SSG pages on Vercel free tier
- **Fits monorepo**: Just another `apps/` entry, same CI, same deploy
- **Build time**: 3-5 days total for all 10 tools using repeatable template pattern

### Domain Strategy

**Recommended: Dedicated domain** (separate from FileFree/LaunchFree brand). A generic utility domain is more sellable and doesn't dilute the financial services brand. Example: `freeconvert.tools`, `toolbox.dev`, or something brandable.

### Honest Verdict

**YES, build it -- but with eyes open:**

- Build in 3-5 days as Phase 1.5 (after monorepo, before LaunchFree MVP)
- Then FORGET about it for 6 months while you build the real products
- Check back at Month 6 -- if any tool is getting traction, optimize. If not, it cost you 3-5 days.
- Do NOT let this distract from FileFree/LaunchFree, which are 10-100x higher revenue potential

**The math**: 3-5 days of work for a potential $5K-20K/yr passive income stream by Year 2. That's a good bet. But only if you don't let it steal focus from the main venture.

---

## 4. Changes to Master Plan

### Section 0B Update

- Replace "Kindling Ventures LLC" recommendation with updated research including Toast-inspired options
- Add Toast Inc trademark conflict analysis
- Present final recommendation with options for user to choose

### F7 / RA Strategy Update

- Correct RA pricing from "$125/yr" to "$25-49/yr" for Wyoming, "$99-125/yr" for nationwide
- Add GoDaddy/ZenBusiness competitive analysis
- Clarify LaunchFree's REAL moat (trust flywheel, no bait-and-switch, AI guidance)
- Update Section 10 decisions

### New Section / Phase: Trinkets

- Add "Trinkets" as a 4th product line in Venture Overview
- Add Phase 1.5 to the phase timeline (between monorepo and state data pipeline)
- Add new todo for Trinkets build (3-5 days)
- Reference the separate strategy doc (`docs/UTILITY_SITES_STRATEGY.md`) for full analysis

### docs/UTILITY_SITES_STRATEGY.md

- Already created (need to finalize content based on plan approval)
- Will serve as the detailed reference, with master plan containing a summary

