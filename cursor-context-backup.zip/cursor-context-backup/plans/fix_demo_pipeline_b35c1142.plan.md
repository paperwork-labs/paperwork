---
name: Fix Demo Pipeline
overview: "Fix three demo-breaking issues: production OCR crashes (likely missing/invalid credentials on Render), 3/day rate limit too tight for conversion, and blur detection false positives on clean PDF scans."
todos:
  - id: fix-rate-limit
    content: Make demo rate limit conditional — 3/day in production, effectively unlimited in development
    status: pending
  - id: fix-blur
    content: Add high-res bypass and lower threshold in image-quality.ts to stop false positives on clean scans
    status: pending
  - id: fix-ocr-errors
    content: Add specific exception handling in ocr_service.py -- graceful fallback to mock instead of crashing
    status: pending
  - id: check-render-creds
    content: Verify OPENAI_API_KEY and GOOGLE_APPLICATION_CREDENTIALS are set and valid on Render
    status: pending
  - id: rate-limit-cta
    content: Show conversion CTA ("sign up to scan more") when user hits 429 rate limit in demo
    status: pending
  - id: test-and-verify
    content: "Test blur bypass, OCR fallback, and rate limit -- commit to PR #14"
    status: pending
isProject: false
---

# Fix Demo Pipeline

## Problem Diagnosis

Three issues are breaking the demo experience:

### 1. Production OCR crashes ("Couldn't read that W-2")

The error comes from `api/app/routers/documents.py` line 49-53 -- the backend's `process_w2()` throws an exception, caught by a generic `except Exception`. This is NOT a blur issue -- blur detection is client-side only and just shows a toast.

**Root cause**: `OPENAI_API_KEY` and/or `GOOGLE_APPLICATION_CREDENTIALS` on Render are either missing, invalid, or expired. When both are empty, mock mode returns fine. When they're set but broken, the Cloud Vision or OpenAI calls throw, hitting the catch-all.

**Fix**:

- Check Render dashboard for `OPENAI_API_KEY` and `GOOGLE_APPLICATION_CREDENTIALS` status
- Improve error handling in [api/app/services/ocr_service.py](api/app/services/ocr_service.py) to catch specific API errors (auth errors, rate limits, timeouts) and return actionable messages instead of generic "Couldn't read"
- Add a fallback: if the real pipeline throws, fall back to mock mode with a warning rather than showing an error

### 2. Rate limit: keep 3/day in prod, unlimited in dev, convert on limit

Line 28 of [api/app/routers/documents.py](api/app/routers/documents.py):

```python
@limiter.limit("3/day")
```

3/day in production is fine -- it prevents abuse. But in dev it blocks testing. And when a user hits the limit in production, the error message should nudge them to sign up rather than just saying "rate limit exceeded."

**Fixes**:

- Dev bypass: `1000/day` when `ENVIRONMENT != production`
- Better rate limit error: Backend returns a structured message so the frontend can show: "You've used your 3 free scans today. Create a free account to scan more W-2s and file your return."
- Frontend: catch 429 status in the demo page and show a conversion CTA instead of the generic error screen

### 3. Blur detection false positives on clean scans

[web/src/lib/image-quality.ts](web/src/lib/image-quality.ts) uses a Laplacian edge detector with `BLUR_THRESHOLD = 15`. Clean PDF scans from the internet have smooth gradients and uniform backgrounds that score LOW on edge variance. The detector was designed for camera photos (which have noise = high edge scores even when slightly blurry), not for digital scans (which are sharp but have low edge variance).

**Fix**: Two changes:

1. Make blur check **advisory only** -- show the toast but NEVER block the upload. Currently it doesn't block the upload (the demo proceeds regardless), but the toast saying "blurry" for a crystal-clear PDF erodes trust.
2. Lower threshold further to `5` OR add a secondary check: if the image has high resolution (>1500px on longest side), skip blur detection entirely (high-res implies a deliberate upload, not an accidental camera shake).

## Implementation

### Step 1: Fix rate limit (dev bypass)

In [api/app/routers/documents.py](api/app/routers/documents.py), keep `"3/day"` for production but disable the limit in development. Use a dynamic limit string based on `settings.ENVIRONMENT`:

```python
from app.config import settings

DEMO_RATE_LIMIT = "3/day" if settings.ENVIRONMENT == "production" else "1000/day"
```

Then use `@limiter.limit(DEMO_RATE_LIMIT)`. Production stays protected at 3/day, dev is effectively unlimited.

**Rate limit conversion CTA**: In the frontend demo page ([web/src/app/demo/page.tsx](web/src/app/demo/page.tsx)), detect 429 responses and show a dedicated "sign up to continue" screen instead of the generic error:

```tsx
if (err.response?.status === 429) {
  // Show signup CTA instead of error
}
```

The CTA: "You've used your 3 free scans today. Sign up (free) to scan unlimited W-2s and file your return." with a button to `/auth/register`.

### Step 2: Fix blur detection

In [web/src/lib/image-quality.ts](web/src/lib/image-quality.ts):

- Add high-resolution bypass: if `max(width, height) >= 1500`, skip blur check (mark as passed)
- Lower `BLUR_THRESHOLD` from `15` to `5` for remaining cases
- This ensures clean digital scans never trigger the "blurry" toast

### Step 3: Improve OCR error handling

In [api/app/services/ocr_service.py](api/app/services/ocr_service.py), wrap the API calls with specific exception handling:

- Catch `google.api_core.exceptions.PermissionDenied` / `google.auth.exceptions.DefaultCredentialsError` -- log and fall back to mock
- Catch `openai.AuthenticationError` -- log and fall back to mock
- Catch `openai.RateLimitError` -- return "Try again in a moment"
- Catch network timeouts -- return "Service temporarily unavailable"
- Always return data (mock if necessary) rather than showing the error screen

### Step 4: Check Render credentials

Verify via Render dashboard or CLI that `OPENAI_API_KEY` and `GOOGLE_APPLICATION_CREDENTIALS` are actually set and valid. If not, the demo works in mock mode (returns Acme Corporation data for everyone -- functional but not impressive).

### Step 5: Add test coverage

Add tests for:

- Blur bypass for high-resolution images
- OCR graceful fallback to mock on API errors
- Rate limit at 10/day

