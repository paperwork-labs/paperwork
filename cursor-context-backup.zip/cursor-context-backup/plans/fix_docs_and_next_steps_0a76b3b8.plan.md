---
name: Fix Docs and Next Steps
overview: "n8n is fixed (separate database created, migrations ran cleanly, site returns 200). Now: clean up stale docs, commit all infrastructure changes, and prep for Sprint 2 development work (the OCR demo targeting the April 15 traffic spike)."
todos:
  - id: fix-docs
    content: "Fix stale docs: brand.mdc (remove deleted image refs), KNOWLEDGE.md (add D28-D31), PITCH_PACKAGE.md (fix costs $12.49), .cursorrules (Tailwind ref)"
    status: completed
  - id: commit-infra
    content: Create chore/infra-cleanup branch, commit compose.yaml + doc fixes, open PR
    status: completed
  - id: task-04b
    content: "Task 0.4b: Build landing page content (hero, waitlist CTA, how-it-works, trust badges)"
    status: completed
  - id: task-11
    content: "Task 1.1: Camera component + image quality validation (document-camera.tsx, image-quality.ts, file-upload-zone.tsx)"
    status: completed
  - id: task-05
    content: "Task 0.5: Complete analytics (Sentry integration, PostHog funnel verification)"
    status: completed
isProject: false
---

# Fix Docs, Commit Infra, and Sprint 2 Prep

## Done: n8n Fixed

- Created separate `n8n` database on the existing PostgreSQL instance
- Updated `[infra/hetzner/compose.yaml](infra/hetzner/compose.yaml)` line 38: `DB_POSTGRESDB_DATABASE: n8n` (was `${POSTGRES_DB:-ops}`)
- Deployed, n8n ran all migrations on the fresh database, returns HTTP 200
- **You need to**: Re-register your owner account at [https://n8n.filefree.tax/setup](https://n8n.filefree.tax/setup) (same credentials), then re-import the 6 workflow JSON files from `infra/hetzner/workflows/` and re-add credentials (OpenAI, Notion, GitHub)

## Task 1: Fix Stale Docs

Several docs reference outdated values. Changes needed:

### `[brand.mdc](.cursor/rules/brand.mdc)` (lines 16-24)

- Logo Assets table references 4 deleted files (`filefree-wordmark-dark.png`, `filefree-monogram.png`, `filefree-avatar.png`, `filefree-og.png`)
- Replace with a placeholder note: "Logo assets pending — generate wordmark via Ideogram v3, monogram via Figma/Canva. See brand voice and color sections below for design direction."
- Keep `favicon.svg` reference (it still exists)

### `[KNOWLEDGE.md](docs/KNOWLEDGE.md)` (after D27)

- Add **D28**: Temporal visibility switched from PostgreSQL to Elasticsearch 7.17.27 (fixes Postiz 502)
- Add **D29**: Brand assets removed (AI-generated logos rejected, pending professional generation)
- Add **D30**: Postiz MCP activated with API key
- Add **D31**: n8n database isolated from Postiz (separate `n8n` database on shared PostgreSQL instance to prevent Prisma migration conflicts)

### `[PITCH_PACKAGE.md](docs/PITCH_PACKAGE.md)` (lines 51, 165)

- Line 51: `$34.50` -> `$12.49` (Vercel is Hobby/free, Hetzner is EUR 5.49)
- Line 165: Update breakdown: `$12.49/month. Render ($7) + Hetzner (EUR 5.49). Vercel Hobby (free), Neon (free tier), Upstash (free tier).`

### `[.cursorrules](.cursorrules)` (line 135)

- Change `tailwind.config.ts` to `globals.css` (Tailwind v4 uses CSS-based config, no `tailwind.config.ts` exists)

## Task 2: Commit Infrastructure Changes

Create a branch `chore/infra-cleanup` and commit:

- `infra/hetzner/compose.yaml` (n8n DB separation + prior ES/MAIN_URL additions)
- All doc fixes from Task 1
- Open a PR per `git-workflow.mdc` guardrails

**Note**: `.cursor/mcp.json` contains the Postiz API key -- this file should NOT be committed (it's gitignored).

## Task 3: Sprint 2 Prep

Sprint 2 (Tasks 1.1-1.4) targets the **April 15 traffic spike** with a working OCR demo. Here's the critical path:

### What already exists (from prior commits)

Per `git log`, Tasks 1.2, 1.3, and 1.4 were already committed:

- `4a422e3` Task 1.2: Tiered OCR pipeline with Cloud Vision + GPT + demo endpoint
- `7c324ad` Task 1.3: Try-before-signup demo page with cascade field reveal
- `a6f2d11` Task 1.4: Content foundation -- SEO guides, pricing, JSON-LD

### What's missing

- **Task 1.1**: Camera component + image quality validation (`document-camera.tsx`, `image-quality.ts`, `file-upload-zone.tsx`)
- **Task 0.4b**: Landing page content (the actual hero section, waitlist CTA, how-it-works, trust badges)
- **Task 0.5**: Analytics completion (Sentry integration, PostHog funnel verification)
- **Task B.6 remaining**: Connect social accounts in Postiz, test scheduling

### Recommended execution order

1. **Task 0.4b** (Landing page content) -- most impactful, makes filefree.tax shareable
2. **Task 1.1** (Camera component) -- completes the demo flow pipeline
3. **Task 0.5** (Sentry + PostHog verification) -- monitoring before traffic
4. **Task B.6** (Postiz social accounts) -- manual setup, requires platform logins

### Human-action items (no code, you need to do these)

- Re-register n8n owner account + re-import workflows + credentials
- EFIN application (B.1) -- 45-day lead time, apply ASAP
- LLC registration (B.2) -- needed for EFIN
- Connect social accounts in Postiz (B.6) -- TikTok, IG, X, YouTube
- Column Tax demo call (B.5/B.9) -- schedule for June sandbox access

