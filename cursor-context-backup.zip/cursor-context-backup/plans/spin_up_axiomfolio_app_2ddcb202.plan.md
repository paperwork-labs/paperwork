---
name: Spin up AxiomFolio app
overview: Start the AxiomFolio dev stack (Postgres, Redis, backend, frontend, Celery, Flower, Ladle) via Docker Compose using the existing Makefile and env setup.
todos: []
isProject: false
---

# Spin up the AxiomFolio app

## Prerequisites

- **Docker** (and Docker Compose) installed and running.
- **Env file**: Ensure [infra/env.dev](infra/env.dev) exists. If this is your first time, copy from the example:

```bash
  cp infra/env.dev.example infra/env.dev
  

```

  Edit `infra/env.dev` if you need to change ports, DB credentials, or API keys (e.g. FMP, Finnhub, New Relic). Defaults in the example are usually fine for local dev.

## Steps to run the app

1. **Start the stack** (from repo root):

```bash
   make up
   

```

   This runs `docker compose` with [infra/compose.dev.yaml](infra/compose.dev.yaml) and the **ui** profile. It brings up:

- Postgres, Redis  
- Backend (FastAPI)  
- Frontend (React/Vite)  
- Celery worker + Celery Beat  
- Flower (task monitoring)  
- Ladle (component stories)  
 Then it runs [scripts/health_check.sh](scripts/health_check.sh) to wait for backend, frontend, ladle, and flower to respond (up to ~90s).

1. **Check services** (optional):

```bash
   make ps
   

```

1. **Open the app**
  - **Frontend**: [http://localhost:3000](http://localhost:3000)  
  - **Backend API docs**: [http://localhost:8000/docs](http://localhost:8000/docs)  
  - **Flower** (Celery): [http://localhost:5555](http://localhost:5555)

## Optional

- **Full stack** (add IBKR + tunnel profiles): `make up-all`
- **Logs**: `make logs`
- **Stop**: `make down`

## If something fails

- **Health check fails**: Ensure ports 3000, 8000, 5555, 61000 are free. Adjust in `infra/env.dev` (e.g. `BACKEND_HOST_PORT`, `WEB_HOST_PORT`) if needed.
- **Backend/Frontend won’t start**: Run `make logs` and fix any errors (e.g. missing env vars, DB connection). For a clean DB reset (destructive): `make down-reset` then `make up`, and re-run migrations if required.

