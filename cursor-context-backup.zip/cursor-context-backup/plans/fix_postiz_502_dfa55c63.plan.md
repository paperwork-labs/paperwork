---
name: Fix Postiz 502
overview: Fix the Postiz backend crash caused by Temporal rejecting search attribute registration due to a per-type limit of 3 Text search attributes.
todos:
  - id: fix-temporal-config
    content: Update Temporal dynamic config to raise search attribute limit and restart Postiz
    status: completed
  - id: verify-postiz
    content: Verify Postiz backend starts and registration works at social.filefree.tax
    status: completed
isProject: false
---

# Fix Postiz 502 -- Temporal Search Attributes Limit

## Root Cause

The Postiz backend (NestJS on port 3000) crashes on startup with:

```
Error: 3 INVALID_ARGUMENT: Unable to create search attributes:
cannot have more than 3 search attribute of type Text.
Backend failed to start on port 3000
```

Temporal's default dynamic config limits custom search attributes to 3 per type. Postiz needs more Text-type attributes.

## Fix

Update the Temporal dynamic config file on Hetzner at `/opt/filefree-ops/dynamicconfig/development-sql.yaml` to raise the search attribute limit, then restart the Temporal and Postiz containers.

Add this to the dynamic config:

```yaml
limit.numOfCustomSearchAttributes:
  - value: 10
    constraints: {}
```

Then restart:

```bash
cd /opt/filefree-ops
docker compose restart temporal
# Wait ~10s for Temporal to come up
docker compose restart postiz
```
