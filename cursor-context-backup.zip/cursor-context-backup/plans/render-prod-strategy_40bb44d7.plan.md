---
name: render-prod-strategy
overview: Productionize QuantMatrix with a provider-agnostic (Render + Fly) strategy, GitHub Actions image-based CI/CD, and non-functional hardening mapped to the current codebase.
todos:
  - id: prod-config
    content: Define production config + secrets contract
    status: completed
  - id: frontend-prod
    content: Add frontend prod build + API base URL config
    status: completed
  - id: render-services
    content: Map services to Render + env wiring
    status: completed
  - id: cicd
    content: Replace CD placeholders with Render deploys
    status: completed
  - id: ops
    content: Observability, backups, and runbooks
    status: completed
isProject: false
---

# Production Hosting Strategy (Provider-Agnostic: Render + Fly)

## Context from repo

- Backend config currently ships a default `SECRET_KEY` and local `DATABASE_URL` (`[/Users/sankalpsharma/development/quantmatrix/backend/config.py](/Users/sankalpsharma/development/quantmatrix/backend/config.py)`).
- Dev compose runs Postgres/Redis, FastAPI, Celery worker/beat, and a Vite dev server (`[/Users/sankalpsharma/development/quantmatrix/infra/compose.dev.yaml](/Users/sankalpsharma/development/quantmatrix/infra/compose.dev.yaml)`).
- Frontend API client hardcodes relative `/api/v1`, and Vite dev proxy only exists for dev (`[/Users/sankalpsharma/development/quantmatrix/frontend/src/services/api.ts](/Users/sankalpsharma/development/quantmatrix/frontend/src/services/api.ts)`, `[/Users/sankalpsharma/development/quantmatrix/frontend/vite.config.ts](/Users/sankalpsharma/development/quantmatrix/frontend/vite.config.ts)`).
- CD pipeline builds images but deployment steps are placeholders (`[/Users/sankalpsharma/development/quantmatrix/.github/workflows/cd.yml](/Users/sankalpsharma/development/quantmatrix/.github/workflows/cd.yml)`).

## Hosting recommendation

- **Dual-target (Render + Fly).** Keep workflows agnostic by shipping the same Docker images to both and using thin provider configs (`render.yaml`, `fly.toml`).
- **Primary ergonomics: Render.** Simplest ops and managed services for the current topology.
- **Cost-optimized alternative: Fly.io.** More control and potentially lower compute costs with auto-stop.

## Target architecture (provider-agnostic)

- **Services:**
  - **Web service** for backend (FastAPI)
  - **Background worker** for Celery worker
  - **Cron job** for scheduled tasks (replace always-on beat)
  - **Static site** for frontend (Vite build)
  - **Managed Postgres** database
  - **Managed Redis** broker/cache
- **Networking:**
  - Frontend served over HTTPS from Render; backend on separate service with allowed origins and a stable API base URL
- **Data & secrets:**
  - Use Render environment variables and/or Render secret files; no repo `.env` in production

## Plan

1. **Non-functional hardening (codebase-mapped)**
  - Gate/remove auto-migrations on startup in `[/Users/sankalpsharma/development/quantmatrix/backend/api/main.py](/Users/sankalpsharma/development/quantmatrix/backend/api/main.py)` and move to CI/CD release step.
  - Require production secrets (`SECRET_KEY`, `DATABASE_URL`, `REDIS_URL`) in `[/Users/sankalpsharma/development/quantmatrix/backend/config.py](/Users/sankalpsharma/development/quantmatrix/backend/config.py)`.
  - Tighten CORS + add rate limiting in `[/Users/sankalpsharma/development/quantmatrix/backend/api/main.py](/Users/sankalpsharma/development/quantmatrix/backend/api/main.py)`.
  - Replace always-on beat with provider cron; keep RedBeat for dev/admin only in `[/Users/sankalpsharma/development/quantmatrix/backend/tasks/celery_app.py](/Users/sankalpsharma/development/quantmatrix/backend/tasks/celery_app.py)`.
  - Schedule data-retention job via cron using `enforce_price_data_retention` in `[/Users/sankalpsharma/development/quantmatrix/backend/tasks/market_data_tasks.py](/Users/sankalpsharma/development/quantmatrix/backend/tasks/market_data_tasks.py)`.
  - Add structured logging + request IDs using `LOGGING_CONFIG` in `[/Users/sankalpsharma/development/quantmatrix/backend/config.py](/Users/sankalpsharma/development/quantmatrix/backend/config.py)`.
2. **Production frontend build & hosting strategy**
  - Add a production frontend build flow (static build with `vite build`) and serve via Render Static Site.
  - Make API base URL configurable (e.g., `VITE_API_BASE_URL`) in `[/Users/sankalpsharma/development/quantmatrix/frontend/src/services/api.ts](/Users/sankalpsharma/development/quantmatrix/frontend/src/services/api.ts)` so frontend can point to Render backend service or a shared domain.
  - Decide if backend will serve `/api` only or also static assets (if we want a single origin).
3. **Provider configs (Render + Fly)**
  - Add `render.yaml` for Render services (web, worker, cron, Postgres, Redis).
  - Add `fly.toml` per service (API, worker, cron) with auto-stop settings where appropriate.
4. **CI/CD (provider-agnostic)**
  - GitHub Actions builds & pushes versioned images to GHCR for backend/frontend.
  - Render/Fly deploy hooks pull those images.
  - Add release step for DB migrations and smoke tests (`/health`).
5. **Security and compliance hardening**
  - Tighten CORS to explicit origins.
  - Add rate limiting at the API layer or via a proxy.
  - Ensure encryption keys are managed via Render secrets; document rotation.
6. **Observability and reliability**
  - Ensure structured logs and request IDs; align with New Relic config under `[/Users/sankalpsharma/development/quantmatrix/infra/observability/newrelic.ini](/Users/sankalpsharma/development/quantmatrix/infra/observability/newrelic.ini)`.
  - Add alerts for error rates, latency, task queue backlog, and DB connections.
  - Define backup/restore for Postgres and Redis.
7. **Operational runbooks & cost/scaling**
  - Document scaling policy for backend and workers based on queue depth and latency.
  - Add a minimal incident runbook: deploy rollback, DB restore, task backlog handling.
  - Provide cost guardrails (limits, idle scaling, burst caps).
8. **Step-by-step hosting setup (Render + Fly)**
  - Render: provision Postgres/Redis, create web + worker + cron services, wire env vars.
  - Fly: provision managed Postgres + Upstash Redis, create API + worker + cron apps.
  - Frontend: static site (Render) or Fly static hosting if preferred; set `VITE_API_BASE_URL`.
  - Configure domains, DNS, TLS; verify `/health`.

## Key code references

- Production secrets and settings: `[/Users/sankalpsharma/development/quantmatrix/backend/config.py](/Users/sankalpsharma/development/quantmatrix/backend/config.py)`
- Dev topology for service mapping: `[/Users/sankalpsharma/development/quantmatrix/infra/compose.dev.yaml](/Users/sankalpsharma/development/quantmatrix/infra/compose.dev.yaml)`
- Frontend API base path: `[/Users/sankalpsharma/development/quantmatrix/frontend/src/services/api.ts](/Users/sankalpsharma/development/quantmatrix/frontend/src/services/api.ts)`
- Vite build/dev proxy: `[/Users/sankalpsharma/development/quantmatrix/frontend/vite.config.ts](/Users/sankalpsharma/development/quantmatrix/frontend/vite.config.ts)`
- CD placeholders: `[/Users/sankalpsharma/development/quantmatrix/.github/workflows/cd.yml](/Users/sankalpsharma/development/quantmatrix/.github/workflows/cd.yml)`

