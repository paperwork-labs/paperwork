---
name: Portfolio Section Rebuild
overview: A ground-up rebuild of the Portfolio frontend section, integrating market data (stages, RS, technicals) into portfolio views, extracting shared components from MarketDashboard, and shipping a complete viewer experience across Overview, Holdings, Options, Transactions, and Categories pages -- all backed by existing backend APIs.
todos:
  - id: extract-shared-components
    content: Extract StatCard, StageBar, StageBadge, PnlText from MarketDashboard into components/shared/; unify with KPIStatCard; update MarketDashboard imports
    status: completed
  - id: portfolio-types
    content: Create types/portfolio.ts consolidating all scattered interfaces (Position, EnrichedPosition, OptionPosition, TaxLot, Transaction, Dividend, PortfolioSummary, PortfolioAnalytics)
    status: completed
  - id: extract-chart-colors
    content: Extract useChartColors hook and SECTOR_PALETTE from MarketDashboard into shared hooks/useChartColors.ts and shared constants; update MarketDashboard imports
    status: completed
  - id: enrich-stocks-api
    content: "Backend: LEFT JOIN MarketSnapshot onto /portfolio/stocks response for stage_label, rs_mansfield_pct, perf_1d/5d/20d, rsi, atr_14"
    status: completed
  - id: restructure-routes
    content: Move all portfolio routes under /portfolio/* namespace in App.tsx and update DashboardLayout portfolioItems
    status: completed
  - id: split-hooks
    content: "Refactor usePortfolio.ts into focused hooks: usePortfolioOverview, usePositions, useOptions, useActivity, useDividends"
    status: completed
  - id: overview-page
    content: "Build PortfolioOverview: KPI cards, allocation chart, performance chart, stage distribution, top movers, account cards"
    status: completed
  - id: portfolio-history-api
    content: "Backend: Add GET /portfolio/performance/history returning portfolio_snapshots time series for performance chart"
    status: completed
  - id: fill-dashboard-placeholders
    content: "Backend: Populate sector_allocation, top_performers, top_losers, accounts_summary in /dashboard endpoint"
    status: completed
  - id: holdings-page
    content: "Build PortfolioHoldings: enriched SortableTable with market data columns, stage/sector filters, heatmap toggle, SymbolLink integration"
    status: completed
  - id: options-page
    content: "Build PortfolioOptions: summary KPIs, positions grouped by underlying, account filter"
    status: completed
  - id: transactions-page
    content: "Build PortfolioTransactions: activity feed with date range, category, side, symbol filters using SortableTable"
    status: completed
  - id: categories-page
    content: "Build PortfolioCategories: category cards, CRUD dialogs, position assignment, rebalance suggestions; add backend CRUD endpoints if missing"
    status: completed
  - id: tests-shared-components
    content: "Frontend tests: StatCard, StageBar, StageBadge, PnlText render tests with props and edge cases (vitest + @testing-library/react)"
    status: completed
  - id: tests-backend-enrichment
    content: "Backend tests: enriched /portfolio/stocks endpoint with MarketSnapshot join, portfolio history endpoint, categories CRUD"
    status: cancelled
  - id: tests-portfolio-pages
    content: "Frontend page tests: PortfolioOverview, PortfolioHoldings, PortfolioOptions, PortfolioTransactions render with mocked API data"
    status: cancelled
  - id: tests-hooks
    content: "Frontend hook tests: usePositions, usePortfolioOverview, useOptions, useActivity with React Query test utils"
    status: cancelled
  - id: sync-verify-ibkr
    content: "Sync verification: trigger IBKR FlexQuery sync, verify positions/trades/tax-lots/transactions populate in Holdings + Transactions pages"
    status: cancelled
  - id: sync-verify-tastytrade
    content: "Sync verification: trigger Tastytrade sync, verify positions/options/trades/dividends populate in Holdings + Options + Transactions pages"
    status: cancelled
  - id: ladle-stories
    content: "Add Portfolio.stories.tsx to Ladle: StatCard variants, StageBadge, StageBar, PnlText, AllocationDonut, PerformanceChart, mock Overview/Holdings/Options/Transactions/Categories"
    status: cancelled
  - id: update-docs
    content: "Update docs: ARCHITECTURE.md with portfolio data flow mermaid diagram, README.md API map, ROADMAP.md milestone status, TODO.md cleanup; generate architecture overview image"
    status: completed
  - id: sync-e2e-smoke
    content: "E2E smoke: connect brokerage via Settings > Brokerages, sync, navigate to Portfolio Overview and verify KPIs and holdings render with real data"
    status: cancelled
  - id: cleanup-old-pages
    content: Delete old Portfolio.tsx, Transactions.tsx, PortfolioCategories.tsx stubs; remove KPIStatCard.tsx (replaced by unified StatCard); update all imports
    status: completed
isProject: false
---

# Portfolio Section: Architect-Level Rebuild Plan

## Context

The portfolio backend is production-grade: 12+ tables, IBKR/Tastytrade sync services, analytics (Sharpe/beta/volatility), tax optimization, activity aggregation with materialized views, and rich API surface (~25 endpoints). The frontend is lagging: 2 functional pages, 2 stubs, no options UI, no analytics UI, and zero market data integration.

This plan ships a brand-new Portfolio section. No backward compatibility -- we're replacing the current pages wholesale.

---

## Key Design Decisions

### 1. Market Data Integration (the big unlock)

Portfolio symbols are already part of the tracked universe (`universe.py` unions `Position.symbol` with index constituents). `MarketSnapshot` already contains stage, RS, ATR, RSI, SMAs, performance windows, and TD Sequential for every tracked symbol.

**Backend change**: Enrich `/api/v1/portfolio/stocks` to LEFT JOIN `MarketSnapshot` on `symbol`, returning `stage_label`, `rs_mansfield_pct`, `perf_1d`, `perf_5d`, `perf_20d`, `rsi`, `atr_14`, `sma_50`, `sma_200` alongside position data. One query param `include_market_data=true` (default true). This is the bridge -- no new tables, no new sync, just a JOIN.

**Frontend**: Stage badges, RS bars, and technical columns in the Holdings table. Filter by stage. Sort by RS. The portfolio becomes a market-aware portfolio.

### 2. Component Extraction (DRY)

`MarketDashboard.tsx` is 1141 lines with inline sub-components (`StatCard`, `StageBar`, `SetupCard`, `TransitionList`, `RankMatrix`, `SymbolLink`). These should be extracted into `components/shared/` so both Market and Portfolio sections share them:

- `StatCard` --> `components/shared/StatCard.tsx` (replaces the inline one AND unifies with `KPIStatCard.tsx`)
- `StageBar` --> `components/shared/StageBar.tsx`
- `StageBadge` --> `components/shared/StageBadge.tsx` (new: single stage label badge)
- `SymbolLink` / `ChartSlidePanel` / `ChartContext` --> already extracted in `components/market/SymbolChartUI.tsx` -- just import it in portfolio pages too

This also means the `SymbolLink` hover-sparkline + click-to-chart pattern works everywhere: clicking AAPL in your holdings table opens the same TradingView slide panel.

### 3. Page Architecture

Replace the current 4 nav items with 6, organized under `/portfolio/`*:

```
PORTFOLIO (sidebar)
  Overview      /portfolio              <-- NEW: dashboard with KPIs, allocation, performance
  Holdings      /portfolio/holdings     <-- REPLACE: enriched stocks table with market data
  Options       /portfolio/options      <-- NEW: options positions grouped by underlying
  Transactions  /portfolio/transactions <-- REBUILD: activity feed with filters
  Categories    /portfolio/categories   <-- REBUILD: CRUD with target allocations
  Workspace     /portfolio/workspace    <-- KEEP: per-symbol deep dive (rename route)
```

All routes under `/portfolio/*` for clean URL structure. `Workspace` stays but moves to `/portfolio/workspace?symbol=AAPL` (no more top-level `/workspace`).

### 4. Shared Types

Create `frontend/src/types/portfolio.ts` consolidating all scattered interfaces. Single source of truth:

```typescript
export interface Position { ... }
export interface EnrichedPosition extends Position { stage_label?: string; rs_mansfield_pct?: number; ... }
export interface OptionPosition { ... }
export interface TaxLot { ... }
export interface Transaction { ... }
export interface Dividend { ... }
export interface PortfolioSummary { ... }
export interface PortfolioAnalytics { ... }
export interface AccountData { ... }
```

### 5. Hook Consolidation

Current `usePortfolio.ts` has ~12 exports doing different things. Split into focused hooks:

- `usePortfolioOverview()` -- summary + performance + analytics (for Overview page)
- `usePositions(accountId?)` -- enriched stock positions with market data
- `useOptions(accountId?)` -- options positions
- `useActivity(params)` -- unified activity feed
- `useDividends(params)` -- dividend history
- `usePortfolioSync()` -- sync mutation (keep)
- `usePortfolioAccounts()` -- account list (keep)

All backed by React Query with appropriate stale times.

---

## UI Design Specification

### Design Language

Follow the established AxiomFolio design system exactly. "Snowball-ish + Apple-ish: subtle radii, crisp focus, quiet surfaces."

**Brand palette**: Blue-dominant (`brand.500: #3B82F6`), with `status.success` (green) / `status.danger` (red) for P&L. Typography: Space Grotesk for headings, Inter for body. Radii: `lg` (12px) for cards/inputs, `xl` (16px) for outer containers.

**Surfaces**: `bg.canvas` (page background) -> `bg.card` (card surfaces) -> `bg.panel` (elevated panels). Cards always use `borderWidth="1px" borderColor="border.subtle" borderRadius="xl" bg="bg.card"`. Text hierarchy: `fg.default` -> `fg.muted` -> `fg.subtle`.

**Chart colors**: `chart.success` for bullish/positive, `chart.danger` for bearish/negative, `chart.neutral` for neutral data, `chart.area1`/`chart.area2` for layered area fills. Always use `useChartColors()` hook for theme-aware chart rendering (extract from MarketDashboard into shared).

### Page Layout Pattern

Every portfolio page follows the same structure (matching MarketDashboard):

```tsx
<ChartContext.Provider value={openChart}>
  <Box p={4}>
    <Stack gap={4}>
      <PageHeader title="..." subtitle="..." actions={...} />
      <AccountFilterWrapper ...>
        {(filtered) => (
          <>
            {/* KPI row */}
            <Box display="flex" gap={3} flexWrap="wrap">
              <StatCard ... />
            </Box>
            {/* Content sections */}
            ...
          </>
        )}
      </AccountFilterWrapper>
    </Stack>
  </Box>
  <ChartSlidePanel symbol={chartSymbol} onClose={() => setChartSymbol(null)} />
</ChartContext.Provider>
```

Every page wraps content in `ChartContext.Provider` so `SymbolLink` works everywhere. Every page uses `AccountFilterWrapper` for consistent account filtering.

### Portfolio Overview Page Layout

```
+------------------------------------------------------+
| Portfolio Overview               [Account Filter] [Sync]
+------------------------------------------------------+
| [Total Value]  [Day P&L]  [Unrealized P&L]  [Cash]  |  <-- StatCard row (4 cards)
+------------------------------------------------------+
| Allocation (donut)       | Value Over Time (area)    |  <-- 2-col grid
| - By sector              | - portfolio_snapshots     |
| - Toggle: by account     | - 30d/90d/1Y/All range   |
+------------------------------------------------------+
| Stage Distribution       | Top Movers                |  <-- 2-col grid
| [StageBar component]     | +5 contributors (green)   |
| portfolio positions only | -5 detractors (red)       |
+------------------------------------------------------+
| Account Cards (1 per brokerage)                       |  <-- responsive grid
| [IBKR: $xxx | 12 pos | synced 2h ago] [TT: ...]     |
+------------------------------------------------------+
```

StatCard specs:

- Border box style (matching MarketDashboard `StatCard`): `borderWidth="1px" borderColor="border.subtle" borderRadius="lg" p={3} bg="bg.card" flex="1" minW="120px"`
- Day P&L card: value colored `status.success`/`status.danger`, sub shows percentage with arrow
- Total Value: large `fontSize="lg" fontWeight="bold"`, sub shows cost basis

Allocation donut:

- Recharts `PieChart` with `SECTOR_PALETTE` colors (same palette from MarketDashboard line 527)
- Inner label: total value formatted
- Legend below with sector name + percentage
- Toggle between "By Sector" / "By Account" via small pill buttons

Performance area chart:

- Recharts `AreaChart` with gradient fill (`chart.area1` with 25% -> 2% opacity gradient, same pattern as BreadthChart)
- X-axis: dates, Y-axis: portfolio value
- Range selector: `[30d] [90d] [1Y] [All]` as small outline buttons
- Reference line at cost basis (dashed, `chart.refLine`)

### Holdings Page Layout

```
+------------------------------------------------------+
| Holdings                   [Account Filter] [Heatmap Toggle]
+------------------------------------------------------+
| [SortableTable with filter bar]                       |
| Filters: [Stage ▾] [Sector ▾] [P&L ▾]              |
| Presets: [Stage 2 Only] [Winners] [Losers]           |
+------------------------------------------------------+
| Symbol | Shares | Avg Cost | Price | Value | Day P&L |
|  AAPL  |   100  |  145.20  | 182.5 | 18.2K | +1.2%  |
|  [SymbolLink]     ...      ...     [PnlText]  [StageBadge]
+------------------------------------------------------+
```

- Symbol column: `SymbolLink` component (hover sparkline, click opens TradingView panel)
- Stage column: `StageBadge` with color (green for 2A/2B, blue for 1, red for 3/4)
- RS% column: numeric with `fg.muted` for negative, `status.success` for positive
- P&L columns: `PnlText` component (green/red with sign)
- Row click: navigates to `/portfolio/workspace?symbol=AAPL`
- Heatmap toggle: switches entire view to `FinvizHeatMap` (already built)

SortableTable filter presets (matching existing `filterPresets` API from `SortableTable.tsx`):

```typescript
{ label: 'Stage 2 (Uptrend)', filters: { conjunction: 'OR', rules: [
  { columnKey: 'stage', operator: 'equals', value: '2A' },
  { columnKey: 'stage', operator: 'equals', value: '2B' },
  { columnKey: 'stage', operator: 'equals', value: '2C' },
] } }
{ label: 'Winners', filters: { conjunction: 'AND', rules: [{ columnKey: 'pnl', operator: 'greater_than', value: 0 }] } }
{ label: 'Losers', filters: { conjunction: 'AND', rules: [{ columnKey: 'pnl', operator: 'less_than', value: 0 }] } }
{ label: 'Declining (3+4)', filters: { conjunction: 'OR', rules: [
  { columnKey: 'stage', operator: 'equals', value: '3' },
  { columnKey: 'stage', operator: 'equals', value: '4' },
] } }
```

### Options Page Layout

```
+------------------------------------------------------+
| Options                            [Account Filter]   |
+------------------------------------------------------+
| [Total Value] [Calls] [Puts] [Expiring Soon] [Avg DTE]
+------------------------------------------------------+
| AAPL (underlying)                     Total: +$1,200  |
|   AAPL 180C 03/21  | 5 contracts | $3.20 | +$420    |
|   AAPL 170P 03/21  | -2 contracts | $1.80 | -$180   |
| MSFT (underlying)                     Total: -$340    |
|   ...                                                 |
+------------------------------------------------------+
```

- Grouped by underlying symbol (collapsible sections using Chakra `Box` with toggle, not Accordion to keep it lightweight)
- Underlying header: `SymbolLink` + aggregate P&L
- Each option row: strike/expiry/type, quantity (negative for short), price, P&L as `PnlText`
- Expiring soon count: highlight options expiring within 7 days with `status.warning` badge

### Transactions Page Layout

```
+------------------------------------------------------+
| Transactions                       [Account Filter]   |
+------------------------------------------------------+
| [7d] [30d] [90d] [YTD] [1Y] [All]   [Category ▾]   |
| [Symbol search]   [Side: Buy/Sell ▾]                 |
+------------------------------------------------------+
| Date     | Symbol | Type     | Side | Qty | Price | $ |
| 02/18/26 | AAPL   | TRADE    | BUY  | 10  | 182   | -1,820
| 02/15/26 | MSFT   | DIVIDEND |      |     |       | +42.50
+------------------------------------------------------+
| Daily Summary toggle → grouped by day                |
+------------------------------------------------------+
```

- Toolbar: date range as pill button group, category/side as native selects (not Chakra MenuButton -- keep it simple and accessible)
- `SortableTable` with all columns from `/portfolio/activity` response
- Type column: `Badge` with `colorPalette` (green for DIVIDEND, blue for TRADE, gray for COMMISSION/FEE)
- Daily summary: toggle switches to a different view using `/activity/daily_summary`, showing per-day aggregated cards

### Categories Page Layout

```
+------------------------------------------------------+
| Categories                        [+ New Category]    |
+------------------------------------------------------+
| [Category Card]        [Category Card]                |
| Growth Stocks          Dividend Income                |
| Target: 40% | Actual: 35% | 8 positions             |
| [▓▓▓▓▓▓░░░░] -5% underweight                        |
| [Edit] [Manage Positions]                             |
+------------------------------------------------------+
```

- Category cards: `bg.card` with target/actual allocation bar
- Allocation bar: filled portion uses `brand.500`, gap shows over/underweight
- CRUD: Dialog for create/edit (name + target %), Dialog for position assignment (checkbox list of positions with search)
- Rebalance indicator: "underweight"/"overweight" with `status.warning`/`status.danger`

### Shared Component Specs

**StatCard** (unified):

```tsx
interface StatCardProps {
  label: string;
  value: string | number;
  sub?: string;
  trend?: 'up' | 'down';
  color?: string;  // semantic token like 'status.success'
}
```

Renders as border box: `borderWidth="1px" borderColor="border.subtle" borderRadius="lg" p={3} bg="bg.card" flex="1" minW="120px"`. Label: `fontSize="xs" color="fg.muted"`. Value: `fontSize="lg" fontWeight="bold"`. Sub: `fontSize="xs" color="fg.muted"`.

**StageBadge**:

```tsx
interface StageBadgeProps { stage: string; size?: 'sm' | 'md'; }
```

Color mapping: `1` -> blue, `2A`/`2B` -> green, `2C` -> yellow, `3` -> orange, `4` -> red. Renders as `<Badge colorPalette={...} fontSize="xs">{stage}</Badge>`.

**PnlText**:

```tsx
interface PnlTextProps { value: number; format?: 'currency' | 'percent'; fontSize?: string; }
```

Color: `value >= 0 ? 'status.success' : 'status.danger'`. Prepends `+`/`-` sign. Uses `formatMoney()` or `toFixed()` based on format.

**StageBar** (extracted from MarketDashboard line 179):
Same component, just moved to `components/shared/StageBar.tsx`. Shows 6 stages as proportional horizontal segments with stage colors.

**useChartColors** (extracted from MarketDashboard line 380):
Move to `hooks/useChartColors.ts`. Returns resolved chart semantic token values for Recharts/D3 usage.

### Shared Constants to Extract

The `SECTOR_PALETTE` (MarketDashboard line 527) has 14 harmonized CSS variable colors. Extract to `frontend/src/constants/chart.ts`:

```typescript
export const SECTOR_PALETTE = [
  'var(--chakra-colors-brand-600)',
  'var(--chakra-colors-red-500)',
  'var(--chakra-colors-green-500)',
  // ... 14 entries total
];

export const STAGE_COLORS: Record<string, string> = {
  '1': 'blue', '2A': 'green', '2B': 'green', '2C': 'yellow', '3': 'orange', '4': 'red',
};
```

No new semantic tokens needed -- the existing palette + status tokens cover all use cases. The allocation donut, stage colors, and P&L coloring all derive from what already exists in `system.ts`.

### Ladle Stories to Add

Create `frontend/src/stories/Portfolio.stories.tsx` with:

1. **StatCard_Variants**: compact card with label/value/sub, card with trend arrow, card with colored value (P&L)
2. **StageBadge_AllStages**: render all 6 stages side by side (1, 2A, 2B, 2C, 3, 4)
3. **StageBar_Distribution**: bar with sample stage counts, bar with skewed data (mostly Stage 2)
4. **PnlText_Variants**: positive/negative/zero in both currency and percent formats
5. **AllocationDonut**: donut chart with sample sector data, with and without inner label
6. **PerformanceChart**: area chart with sample time series, gradient fill, reference line
7. **PortfolioOverview_Mock**: full Overview page with mocked data (demonstrates the complete layout)
8. **HoldingsTable_Mock**: SortableTable with sample enriched positions (shows stage badges, RS%, SymbolLink)
9. **OptionsGrouped_Mock**: options grouped by underlying with sample data
10. **TransactionsTable_Mock**: activity feed table with mixed types (trades, dividends, fees)
11. **CategoryCard_Mock**: category card with allocation bar, over/underweight indicator

Each story includes light/dark mode toggle (same pattern as existing stories). Stories use sample data fixtures, not API calls.

---

## Implementation Plan

### Phase 1: Foundation (extract, type, restructure)

**1a. Extract shared components from MarketDashboard**

Extract from [MarketDashboard.tsx](frontend/src/pages/MarketDashboard.tsx) into `frontend/src/components/shared/`:

- `StatCard.tsx` -- unify the inline `StatCard` (line 171) with `KPIStatCard.tsx` into one versatile component supporting both compact (border box) and full (Chakra StatRoot) variants
- `StageBar.tsx` -- horizontal stage distribution bar (line 179)
- `StageBadge.tsx` -- single stage label with color (new, derived from stage color logic at line 155)
- `PnlText.tsx` -- formatted P&L text with green/red coloring (used everywhere, currently duplicated)

Update `MarketDashboard.tsx` to import from shared instead of inline.

**1b. Create portfolio types**

Create [frontend/src/types/portfolio.ts](frontend/src/types/portfolio.ts) with all interfaces, sourced from:

- `Portfolio.tsx` line 12 (`AnyPos` -- replace with proper types)
- `PortfolioWorkspace.tsx` lines 32-61 (`StockRow`, `TxRow`, `LotRow`)
- `AccountSelector.tsx` (`AccountData`)
- `useAccountFilter.ts` (`FilterableItem`, `AccountFilterConfig`)
- `api.ts` line 413 (`PortfolioSummary`)
- Backend API response shapes (documented above)

**1c. Enrich portfolio stocks API**

In [backend/api/routes/portfolio_stocks.py](backend/api/routes/portfolio_stocks.py), LEFT JOIN `MarketSnapshot` (latest per symbol) onto the stocks response. Add fields: `stage_label`, `rs_mansfield_pct`, `perf_1d`, `perf_5d`, `perf_20d`, `rsi`, `atr_14`. Query param: `include_market_data=true` (default).

**1d. Restructure routes**

In [frontend/src/App.tsx](frontend/src/App.tsx), change portfolio routes to nested `/portfolio/*` structure. Update [DashboardLayout.tsx](frontend/src/components/layout/DashboardLayout.tsx) `portfolioItems` array.

**1e. Split hooks**

Refactor [frontend/src/hooks/usePortfolio.ts](frontend/src/hooks/usePortfolio.ts) into focused hooks. Keep backward compat exports temporarily if MarketDashboard uses any.

### Phase 2: Overview Dashboard (the new landing page)

Build [frontend/src/pages/portfolio/PortfolioOverview.tsx](frontend/src/pages/portfolio/PortfolioOverview.tsx):

**Top row -- KPI cards** (from `/dashboard` + `/analytics/{account_id}`):

- Total Portfolio Value
- Day P&L (with % and arrow)
- Unrealized P&L (with %)
- Cash Balance

**Second row -- Allocation + Performance** (side by side):

- Left: Asset allocation donut chart (by sector from positions data, by account from accounts)
- Right: Portfolio value over time (from `portfolio_snapshots` -- needs a new lightweight endpoint or use existing performance endpoint)

**Third row -- Stage Distribution + Top Movers**:

- `StageBar` showing stage distribution of portfolio positions (from enriched stocks data)
- Top 5 contributors / detractors (from `/analytics/{account_id}` `performance_attribution`)

**Fourth row -- Account Cards**:

- One card per linked brokerage account showing value, positions count, last sync time
- Quick sync button per account

All cards use `StatCard`, `AccountFilterWrapper` for filtering, `SymbolLink` for clickable symbols, existing loading skeletons.

### Phase 3: Holdings Page (enriched with market data)

Build [frontend/src/pages/portfolio/PortfolioHoldings.tsx](frontend/src/pages/portfolio/PortfolioHoldings.tsx):

**Full-featured `SortableTable`** with columns:

- Symbol (with `SymbolLink` for hover sparkline + click to chart)
- Shares
- Avg Cost
- Current Price
- Market Value
- Day P&L / Day P&L %
- Unrealized P&L / P&L %
- Weight % (of total portfolio)
- Stage (badge, from market data)
- RS % (from market data)
- Sector

**Built-in filters** (using `SortableTable` filter presets):

- Stage filter: "Stage 2 Only", "Accumulation (1)", "Declining (4)"
- Account filter via `AccountFilterWrapper`
- Sector filter
- P&L filter: "Winners", "Losers"

**Heatmap toggle**: existing `FinvizHeatMap` as alternate view (already works in current `Portfolio.tsx`).

Rows clickable to navigate to `/portfolio/workspace?symbol=AAPL`.

### Phase 4: Options Page

Build [frontend/src/pages/portfolio/PortfolioOptions.tsx](frontend/src/pages/portfolio/PortfolioOptions.tsx):

Consume `/portfolio/options/unified/portfolio` and `/portfolio/options/unified/summary`.

**Summary row**: Total options value, Calls count, Puts count, Expiring this week, Avg DTE.

**Positions grouped by underlying** (accordion or collapsible sections):

- Each underlying shows: calls and puts, strike, expiry, quantity, current price, P&L
- `SymbolLink` on underlying symbol for chart access

**Account filter** via `AccountFilterWrapper`.

### Phase 5: Transactions Page

Build [frontend/src/pages/portfolio/PortfolioTransactions.tsx](frontend/src/pages/portfolio/PortfolioTransactions.tsx):

Consume `/portfolio/activity` endpoint (unified trades + transactions + dividends).

**Toolbar filters**:

- Date range picker (presets: 7d, 30d, 90d, YTD, 1Y, All)
- Category filter: Trade, Dividend, Commission, Fee, Transfer
- Side filter: Buy, Sell
- Symbol search
- Account filter

`**SortableTable`** with columns: Date, Symbol, Type, Side, Quantity, Price, Amount, Commission, Account.

**Daily summary toggle**: switch to daily aggregated view using `/activity/daily_summary`.

### Phase 6: Categories Page

Build [frontend/src/pages/portfolio/PortfolioCategories.tsx](frontend/src/pages/portfolio/PortfolioCategories.tsx):

Consume existing `Category` and `PositionCategory` models. Needs backend CRUD endpoints if not already present (check `/api/v1/portfolio` routes -- may need to add `POST /categories`, `PUT /categories/{id}`, `DELETE /categories/{id}`, `POST /categories/{id}/positions`).

**Category cards**: Each category shows name, target allocation %, current allocation %, position count, total value.

**CRUD dialogs**: Create/edit category (name, target %), assign/remove positions (multi-select from positions list).

**Rebalance suggestions**: Compare target vs actual allocation, show over/underweight.

---

## Backend Work Required

Most frontend pages consume existing endpoints. Backend changes needed:

1. **Enrich `/portfolio/stocks`** with `MarketSnapshot` join (Phase 1c) -- in [portfolio_stocks.py](backend/api/routes/portfolio_stocks.py)
2. **Portfolio value history endpoint** -- `GET /portfolio/performance/history?account_id=&period=1y` returning time series of `portfolio_snapshots` for the performance chart (Phase 2)
3. **Categories CRUD endpoints** -- if not already in routes, add to [portfolio.py](backend/api/routes/portfolio.py): create, update, delete categories; assign positions (Phase 6)
4. **Fill dashboard placeholders** -- the `/dashboard` endpoint returns placeholder `[]` for `sector_allocation`, `top_performers`, `top_losers`, `accounts_summary` (lines visible in the route). Populate these from real data.

---

## DRY Opportunities


| Current Duplication | Resolution |
| ------------------- | ---------- |


- `StatCard` inline in MarketDashboard + `KPIStatCard.tsx` as separate component --> Unify into `components/shared/StatCard.tsx`
- P&L coloring logic (green/red) duplicated in Portfolio.tsx, PortfolioWorkspace.tsx, MarketDashboard.tsx --> `PnlText` component + `pnlColor()` utility
- `AnyPos` type alias in Portfolio.tsx --> Replace with typed `EnrichedPosition` from shared types
- Account filtering repeated across pages --> Already solved with `AccountFilterWrapper` (keep using it)
- `SymbolLink` pattern only in Market section --> Import `ChartContext` + `SymbolLink` + `ChartSlidePanel` into portfolio pages too
- Stage color mapping duplicated wherever stages shown --> `stageColor()` utility in shared

---

## What NOT to Build (scope boundaries)

- **Trade execution** -- that's Strategy section
- **Alerts/notifications** -- separate concern
- **Schwab API completion** -- separate task, backend only
- **Historical store for indices** -- market data milestone, not portfolio
- **Primo strategy** -- future milestone

---

## Phase 7: Sync Verification (prove data flows end-to-end)

After building the UI, we verify real data flows through the system. This is the "light it up" phase.

### Pre-requisites

Ensure env vars are configured in `infra/env.dev`:

- **IBKR**: `IBKR_FLEX_TOKEN`, `IBKR_FLEX_QUERY_ID`, `IBKR_ACCOUNTS` (format: `ACCT1:TAXABLE,ACCT2:IRA`)
- **Tastytrade**: `TASTYTRADE_USERNAME`, `TASTYTRADE_PASSWORD`
- **Seed**: `SEED_ACCOUNTS_ON_STARTUP=true`

### Sync Flow

```
1. Start stack           ./run.sh start
2. Accounts auto-seed    (SEED_ACCOUNTS_ON_STARTUP populates broker_accounts table)
3. Navigate to Settings > Brokerages
   - Verify accounts appear in table
   - For IBKR: click Sync, monitor sync status (11-step FlexQuery sync)
   - For Tastytrade: click Sync, monitor sync status
4. Navigate to Portfolio > Overview
   - Verify KPI cards show real values (Total Value, Day P&L, Unrealized P&L)
   - Verify account cards show per-account stats
5. Navigate to Portfolio > Holdings
   - Verify positions table populated with real symbols
   - Verify market data columns (Stage, RS%) populated (requires market data tasks to have run)
   - Click a symbol -> verify Workspace loads with chart + tax lots
6. Navigate to Portfolio > Options
   - Verify options positions grouped by underlying (if account has options)
7. Navigate to Portfolio > Transactions
   - Verify activity feed shows trades, dividends, transactions
   - Test date range and category filters
```

### Data Dependency Chain

```mermaid
flowchart LR
  Seed["Account Seed"] --> BrokerAccounts["broker_accounts"]
  BrokerAccounts --> SyncIBKR["IBKR FlexQuery Sync"]
  BrokerAccounts --> SyncTT["Tastytrade Sync"]
  SyncIBKR --> Positions["positions"]
  SyncIBKR --> Trades["trades"]
  SyncIBKR --> TaxLots["tax_lots"]
  SyncIBKR --> Transactions["transactions"]
  SyncIBKR --> Options["options"]
  SyncIBKR --> AccountBalances["account_balances"]
  SyncTT --> Positions
  SyncTT --> Trades
  SyncTT --> Dividends["dividends"]
  SyncTT --> Options
  Positions --> Overview["Portfolio Overview"]
  Positions --> Holdings["Portfolio Holdings"]
  Options --> OptionsPage["Portfolio Options"]
  Trades --> TransactionsPage["Portfolio Transactions"]
  Transactions --> TransactionsPage
  Dividends --> TransactionsPage
  MarketTasks["Market Data Tasks"] --> MarketSnapshot["market_snapshots"]
  MarketSnapshot --> Holdings
  MarketSnapshot --> Overview
```



### Troubleshooting Checklist

If data doesn't appear:

1. Check `broker_accounts` table has entries: `SELECT * FROM broker_accounts;`
2. Check sync status: `SELECT account_id, sync_status, last_successful_sync FROM broker_accounts;`
3. Check positions populated: `SELECT COUNT(*) FROM positions;`
4. Check Celery worker is running: `./run.sh logs worker`
5. If market data columns empty: run `POST /api/v1/market-data/universe/tracked/refresh` then trigger snapshot/indicator tasks
6. Check API directly: `curl localhost:8000/api/v1/portfolio/stocks`

---

## Test Strategy

Per existing patterns in `docs/TEST_PLAN.md` and `backend/tests/README.md`. Tests use vitest + @testing-library/react on frontend, pytest on backend.

### Backend Tests

**Enriched stocks endpoint** (`backend/tests/test_portfolio_stocks_enriched.py`):

- Mock `Position` rows + `MarketSnapshot` rows in test DB
- Call `GET /portfolio/stocks?include_market_data=true`
- Assert response includes `stage_label`, `rs_mansfield_pct`, `perf_1d` fields
- Assert `include_market_data=false` omits those fields
- Assert symbols with no snapshot still return position data (LEFT JOIN correctness)

**Portfolio history endpoint** (`backend/tests/test_portfolio_history.py`):

- Seed `portfolio_snapshots` with 30 days of data
- Call `GET /portfolio/performance/history?period=1m`
- Assert time series returned with correct date range
- Assert filtering by `account_id` works

**Categories CRUD** (`backend/tests/test_portfolio_categories.py`):

- Create category, verify 201
- Update category name/target, verify 200
- Assign positions to category, verify join table populated
- Delete category, verify cascade cleans up position_categories
- Verify rebalance suggestions endpoint returns correct over/underweight

**Dashboard populated** (`backend/tests/test_portfolio_dashboard.py`):

- Seed positions with sectors
- Call `GET /portfolio/dashboard`
- Assert `sector_allocation` is non-empty
- Assert `top_performers` / `top_losers` populated from real position data
- Assert `accounts_summary` includes all broker_accounts

### Frontend Tests

**Shared component tests** (`frontend/src/components/shared/__tests__/`):

Using existing `renderWithProviders` from `frontend/src/test/render.tsx`:

- `StatCard.test.tsx`: renders label/value/sub, handles missing sub, compact vs full variant
- `StageBar.test.tsx`: renders all 6 stages proportionally, handles empty data, zero total
- `StageBadge.test.tsx`: renders correct color per stage, handles unknown stage
- `PnlText.test.tsx`: green for positive, red for negative, zero shows neutral, formats currency

**Hook tests** (`frontend/src/hooks/__tests__/`):

- `usePositions.test.ts`: returns enriched positions, handles loading/error states
- `usePortfolioOverview.test.ts`: combines dashboard + analytics data
- `useOptions.test.ts`: returns options grouped by underlying
- `useActivity.test.ts`: returns filtered activity with pagination

**Page tests** (`frontend/src/pages/__tests__/`):

Following the pattern established in `SettingsBrokerages.test.tsx` (mock `api.ts`, mock `AuthContext`):

- `PortfolioOverview.test.tsx`: renders KPI cards with mocked dashboard data, shows loading skeleton first, shows account cards
- `PortfolioHoldings.test.tsx`: renders SortableTable with positions, stage badges appear, SymbolLink renders for each symbol, heatmap toggle works
- `PortfolioOptions.test.tsx`: renders options grouped by underlying, summary row shows counts
- `PortfolioTransactions.test.tsx`: renders activity feed, date filter changes data, category filter works

### E2E Smoke Test

After full build, using the browser-use subagent:

1. Navigate to `/settings/brokerages`, verify accounts table renders
2. Click Sync on an account, wait for completion
3. Navigate to `/portfolio`, verify KPI cards show non-zero values
4. Navigate to `/portfolio/holdings`, verify table has rows
5. Click a symbol, verify workspace loads
6. Navigate to `/portfolio/transactions`, verify activity rows appear

---

## Execution Recommendation

**Model**: The default model in auto mode is well-suited for this task. The patterns are established (MarketDashboard sets the template), backend APIs exist, and the work is "broad but consistent" -- many files following the same patterns rather than deep algorithmic complexity. The risky parts (backend JOIN, component extraction from MarketDashboard without breaking it) are well-scoped and can be verified with tests.

**Execution order**: Follow the phases sequentially. Phase 1 (foundation) must complete before any page work. Phases 2-6 can be done in order. Phase 7 (sync verification) happens after all pages are built. Tests should be written alongside each phase, not deferred to the end.

---

## Phase 8: Documentation and Cleanup

### Files to Delete (replaced wholesale)

- `frontend/src/pages/Portfolio.tsx` -- replaced by `PortfolioOverview.tsx` + `PortfolioHoldings.tsx`
- `frontend/src/pages/Transactions.tsx` -- replaced by `PortfolioTransactions.tsx`
- `frontend/src/pages/PortfolioCategories.tsx` -- replaced by new `PortfolioCategories.tsx`
- `frontend/src/components/ui/KPIStatCard.tsx` -- replaced by unified `StatCard.tsx`

### Documentation Updates

**[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)**:

Add a "Portfolio Data Architecture" section with this mermaid diagram (rendered as an image saved to `docs/assets/portfolio_architecture.png`):

```mermaid
flowchart TB
  subgraph brokers ["Brokerage Integrations"]
    IBKR["IBKR FlexQuery + TWS"]
    TT["Tastytrade SDK"]
    Schwab["Schwab OAuth"]
  end

  subgraph backend ["Backend Services"]
    SyncSvc["BrokerSyncService"]
    AnalyticsSvc["PortfolioAnalyticsService"]
    TaxSvc["TaxLotService"]
    ActivityAgg["ActivityAggregator"]
    MarketSvc["MarketDashboardService"]
  end

  subgraph db ["PostgreSQL"]
    Positions["positions"]
    Options["options"]
    Trades["trades"]
    Transactions["transactions"]
    TaxLots["tax_lots"]
    Dividends["dividends"]
    Balances["account_balances"]
    Snapshots["portfolio_snapshots"]
    MarketSnap["market_snapshots"]
    Categories["categories"]
  end

  subgraph frontend ["Portfolio Frontend"]
    Overview["Overview Dashboard"]
    Holdings["Holdings Table"]
    OptionsUI["Options View"]
    TransUI["Transactions Feed"]
    CatUI["Categories CRUD"]
    Workspace["Symbol Workspace"]
  end

  IBKR --> SyncSvc
  TT --> SyncSvc
  Schwab --> SyncSvc
  SyncSvc --> Positions
  SyncSvc --> Options
  SyncSvc --> Trades
  SyncSvc --> Transactions
  SyncSvc --> TaxLots
  SyncSvc --> Dividends
  SyncSvc --> Balances
  SyncSvc --> Snapshots
  MarketSvc --> MarketSnap

  Positions --> Holdings
  MarketSnap -->|"LEFT JOIN on symbol"| Holdings
  Positions --> Overview
  Snapshots --> Overview
  AnalyticsSvc --> Overview
  Options --> OptionsUI
  ActivityAgg --> TransUI
  TaxSvc --> Workspace
  Categories --> CatUI
```



Add a "Market-Portfolio Integration" section explaining the LEFT JOIN bridge between `MarketSnapshot` and `Position` via symbol.

**[README.md](README.md)**:

Update the API Map section to include the new endpoints:

- `GET /api/v1/portfolio/stocks?include_market_data=true` -- enriched with stage/RS
- `GET /api/v1/portfolio/performance/history` -- snapshot time series
- `CRUD /api/v1/portfolio/categories` -- category management

Update the Portfolio section of the docs listing:

- Add: `docs/PORTFOLIO.md` -- Portfolio section architecture and data flow

**[docs/ROADMAP.md](docs/ROADMAP.md)**:

Update milestone status:

- `2) Portfolio UI (Snowball Analytics+)` -- mark as **completed** after this build
- Add milestone: `2b) Market-Portfolio Integration` -- completed

**[docs/TODO.md](docs/TODO.md)**:

Remove completed items:

- "Stocks: add Stage/RS badges" -- done
- "Dashboard: add Stage distribution" -- done
- "Naming cleanup: avoid the word holdings" -- done

Add new items if any remain after build.

**[backend/models/README.md](backend/models/README.md)**:

Update the data flow diagram to include the market data integration path. Replace text-art diagrams with mermaid rendered images for clarity.

**New file: [docs/PORTFOLIO.md](docs/PORTFOLIO.md)**:

Create a dedicated portfolio architecture doc covering:

- Page inventory (Overview, Holdings, Options, Transactions, Categories, Workspace) with routes
- Data flow: brokerage sync -> DB tables -> API endpoints -> frontend pages
- Market data integration (how portfolio symbols get stage/RS enrichment)
- Component architecture (shared components, hooks, types)
- Brokerage connection guide (IBKR FlexQuery setup, Tastytrade credentials, Schwab OAuth)

### Architecture Diagram Images

Generate architecture images using mermaid-to-image for:

1. `docs/assets/portfolio_architecture.png` -- portfolio data flow (diagram above)
2. `docs/assets/portfolio_frontend.png` -- frontend component hierarchy
3. `docs/assets/sync_data_flow.png` -- brokerage sync data dependency chain (from Phase 7)

The `docs/ARCHITECTURE.md` already references `assets/architecture_overview.png` which doesn't exist -- generate that too with a system-wide architecture diagram showing Market, Portfolio, and Strategy sections.

---

## Final Architect Review Notes

### Risks and Mitigations

1. **MarketDashboard breakage during extraction**: Extract components one at a time. After each extraction, verify MarketDashboard still renders correctly (run the existing `MarketDashboard.test.tsx` test). The inline components are self-contained -- extraction is mechanical.
2. **LEFT JOIN performance on /portfolio/stocks**: The `MarketSnapshot` table could be large. Mitigate with a subquery selecting only `DISTINCT ON (symbol) ... ORDER BY created_at DESC` for the latest snapshot per symbol. Index on `(symbol, created_at DESC)` already exists.
3. **Hook refactor breaking existing pages**: `usePortfolio.ts` is imported by the current `Portfolio.tsx` and `PortfolioWorkspace.tsx`. Since we're replacing `Portfolio.tsx` wholesale and `PortfolioWorkspace.tsx` stays, keep `usePortfolio()` export as a thin wrapper around the new `usePositions()` hook during migration. Remove after workspace is updated.
4. **Categories CRUD is new backend work**: The `Category` and `PositionCategory` models exist with all fields (`target_allocation_pct`, `rebalance_threshold_pct`, `auto_rebalance`, `color`, `parent_category_id`). Only the API routes are missing. Add standard CRUD endpoints in `backend/api/routes/portfolio_categories.py` -- straightforward SQLAlchemy operations.
5. **Portfolio snapshots may be sparse**: If no scheduled snapshot task has run, the performance chart will be empty. Add a graceful empty state: "No performance history yet -- snapshots are recorded daily after sync." Optionally trigger a snapshot as part of the sync flow.

### What Changed From V1 Plan

- Added concrete UI wireframes for every page
- Added component TypeScript interfaces with exact styling specs
- Added Ladle story inventory (11 stories)
- Added `useChartColors` and `SECTOR_PALETTE` extraction
- Fixed Stage 2 filter to include all sub-stages (2A/2B/2C)
- Confirmed categories CRUD needs new backend endpoints (zero exist today)
- Added documentation phase with mermaid architecture diagrams
- Added file deletion/cleanup phase
- Added risk mitigations for MarketDashboard extraction and LEFT JOIN performance
- Total todos: 23 (was 13 in v1)

