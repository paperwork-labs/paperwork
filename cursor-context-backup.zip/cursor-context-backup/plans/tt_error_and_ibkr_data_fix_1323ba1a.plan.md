---
name: TT Error and IBKR Data Fix
overview: Fix TastyTrade error visibility and IBKR data sync, add sync job history in Settings, Edit connections, and clean account display.
todos: []
isProject: false
---

# TT Error, IBKR Data, Sync Jobs, Edit Connections, and Clean Display

## Summary of Changes


| Area                 | What                                                                                                                                                     |
| -------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Sync Jobs**        | Create `AccountSync` rows on each sync; add `GET /accounts/sync-history`; show "Recent syncs" or "Sync Jobs" in Brokerages with status, timestamp, error |
| **Edit Connections** | Add Edit button per account; TT/IBKR re-open credential form; new update-credentials endpoints                                                           |
| **Clean Display**    | Account column: `account_name` primary, `account_number` muted; add PATCH to edit display name                                                           |
| **TT Error**         | Surface `sync_error_message`, `job_error`, `last_error` in UI                                                                                            |
| **IBKR Data**        | Use per-user stored credentials; support real account ID; fix credential flow                                                                            |


### TastyTrade "showing an error"

- The `tt` state stores `last_error` and `job_error` from the backend but **nothing in the UI renders them**
- When connect fails, the toast shows the error but there is no persistent error display
- The backend `tastytrade_status` returns `job_error` when polling with `job_id` for a failed connect job
- `BrokerAccount.sync_error_message` (from sync failures) is **not** returned in the accounts list API, so users see "ERROR" badge but not the actual message

### IBKR "no data"

- **Critical bug**: [IBKRFlexQueryClient](backend/services/clients/ibkr_flexquery_client.py) reads credentials from **env vars only** (`settings.IBKR_FLEX_TOKEN`, `settings.IBKR_FLEX_QUERY_ID`), but the wizard stores per-user credentials in `AccountCredentials` via [aggregator._ibkr_connect_job](backend/api/routes/aggregator.py)
- The stored credentials are **never used** by the sync service
- **Account ID mismatch**: The wizard creates an account with `account_number="IBKR_FLEX"`. The FlexQuery API either needs:
  - No `acct` param (global report for all accounts under the token), or
  - The real IBKR account ID (e.g. `U1234567`)
- When `get_full_report("IBKR_FLEX")` is called, the client sends `acct=IBKR_FLEX` to IBKR, which rejects it. The fallback retries without `acct`, but XML parsing then filters by `account_id == "IBKR_FLEX"`, so all rows are skipped (real IDs in XML are like `U12345`)

---

## Implementation Plan

### Part 0: Connect Job Persistence (Production Fix)

- Replace in-memory `JOBS` dict with Redis: `connect_job:{job_id}` key, JSON value `{state, error, started_at, ...}`, TTL 600s.
- Create `ConnectJobStore` (or use Redis directly in aggregator): `set(job_id, data)`, `get(job_id)`.
- `_tt_connect_job` and `_ibkr_connect_job` write to Redis; `tastytrade_status` and `ibkr_flex_status` (when job_id provided) read from Redis.
- Add `job_id` query param to `ibkr_flex_status` so frontend can poll for IBKR connect job errors.

---

### Part 1: Surface Errors in SettingsBrokerages UI

**1.1 Add sync_error_message to accounts list API and display it**

- [account_management.py](backend/api/routes/account_management.py): Add `sync_error_message: Optional[str]` to `BrokerAccountResponse`; include it in the list serializer
- [SettingsBrokerages.tsx](frontend/src/pages/SettingsBrokerages.tsx): In the accounts table Status cell, when `a.sync_status === 'ERROR'` (or similar) and `a.sync_error_message`, show a tooltip or inline text with the error

**1.2 Display TT connection status and errors**

- Add a small status card/section for TastyTrade (similar pattern to Schwab "Connect" if needed): show connected vs disconnected, and when `tt.last_error` or `tt.job_error` exists, display it
- Option: add an `Alert` above the table or inside the TT connect area when `tt` has an error

---

### Part 2: IBKR Per-User Credentials + Real Account ID

**2.1 IBKR sync must use stored credentials**

- Create `get_ibkr_credentials_for_account(account_id, db)` helper (e.g. in `credential_vault` or a new `account_credentials_service`) that:
  - Loads `AccountCredentials` for the given `BrokerAccount`
  - Decrypts and returns `{ flex_token, query_id }`
- [IBKRFlexQueryClient](backend/services/clients/ibkr_flexquery_client.py): Support injecting credentials via constructor or a `with_credentials(flex_token, query_id)` style API instead of always reading from settings
- [IBKRSyncService](backend/services/portfolio/ibkr_sync_service.py): Before calling FlexQuery, load credentials for the `BrokerAccount` from DB; pass them to the client (or construct client with them). Fall back to env only if no stored creds (for backward compatibility)

**2.2 Support real IBKR account number**

- [aggregator.py](backend/api/routes/aggregator.py) `IBKRFlexConnectRequest`: Add optional `account_number: Optional[str]` (user's real IBKR account ID, e.g. `U1234567`)
- When creating/updating the `BrokerAccount`, store the user-provided `account_number` if given; otherwise keep `"IBKR_FLEX"`
- [SettingsBrokerages.tsx](frontend/src/pages/SettingsBrokerages.tsx): Add an optional "IBKR Account Number" field in the IBKR step (placeholder: "e.g. U1234567 - optional, improves FlexQuery filtering")
- [IBKRSyncService](backend/services/portfolio/ibkr_sync_service.py): When account_number is `"IBKR_FLEX"`, attempt report without `acct` filter; parse the first `accountId` from the Flex XML and use it for downstream filtering. Document that for best results users should enter their real account number.

**2.3 IBKR FlexQuery client credential injection**

- Refactor `IBKRFlexQueryClient` to accept optional `token` and `query_id` in `__init`__ or via a factory `create_with_credentials(token, query_id)`; use those over settings when provided

---

### Part 3: Sync Jobs in Settings (User request)

**3.1 Persist sync runs and expose them in the Brokerages UI**

- `AccountSync` model already exists ([broker_account.py](backend/models/broker_account.py) lines 263-301) with: `account_id`, `status`, `error_message`, `started_at`, `completed_at`, `sync_type`, etc.
- **Backend**: `sync_account_task` / `broker_sync_service` does NOT currently create `AccountSync` rows. Add logic to create an `AccountSync` record at start (status=running), update on completion (status=success/error, error_message, completed_at, duration_seconds).
- **API**: Add `GET /accounts/{account_id}/sync-history` (or `GET /accounts/sync-history?account_id=`) returning recent `AccountSync` rows for the user's accounts, ordered by `started_at DESC`, limit 20.
- **Frontend**: In [SettingsBrokerages.tsx](frontend/src/pages/SettingsBrokerages.tsx):
  - Add an expandable "Recent syncs" section per account row, or a collapsible "Sync history" panel.
  - Alternative: A single "Sync Jobs" card below the table listing recent syncs across all accounts (account name + status + error + timestamp). Click to expand error details.
  - Show status badge (success/error/running), timestamp, and error message when failed.

**3.2 Admin Jobs vs user-facing syncs**

- Admin Jobs (`/settings/admin/jobs`) shows `JobRun` — used by market-data tasks. It is admin-only.
- Brokerage syncs should be visible to the owning user in Settings > Brokerages, not only in Admin Jobs.
- Option A: Wire `sync_account_task` to also write a `JobRun` with `task_name="account_sync"`, `params={"account_id": X}`. Admin Jobs would then show them; but regular users can't access Admin Jobs.
- **Recommended**: Use `AccountSync` for user-scoped history. Add "Sync history" / "Recent syncs" in Brokerages page. No need to put them in Admin Jobs unless we want admins to see all users' syncs (could add a filter later).

---

### Part 4: Edit Connections (User request)

**4.1 Add Edit flow for each broker**

- **TT**: Add "Edit credentials" button. Opens the same OAuth form (Client ID, Client Secret, Refresh Token). On submit, call a new `PUT /aggregator/tastytrade/credentials` or reuse connect with an `account_id` to update existing AccountCredentials for that account.
- **IBKR**: Add "Edit credentials" — re-open Flex Token + Query ID form. New `PUT /aggregator/ibkr/credentials` or extend connect to accept `account_id` for update.
- **Schwab**: Edit = re-link OAuth (same as Connect) — no new endpoint needed.
- **UI**: Add an "Edit" (or "Update credentials") action next to Sync/Disable/Delete. Opens a modal/dialog with broker-specific fields, pre-filled if possible (we store encrypted — can't pre-fill secrets; show placeholders "••••••" and let user replace).
- **Backend**: Add update credential endpoints that decrypt existing, merge new values, re-encrypt, and save. Or: accept new credentials and overwrite; for TT/IBKR, require all three fields (or optional — only update provided fields, but security-wise simpler to require full replace).

---

### Part 5: Clean Account Display (User request)

**5.1 Improve Account column**

- Current: `a.account_name || a.account_number` — can show "IBKR (FlexQuery)", "Tastytrade (5ABC123)", or raw numbers.
- **Options**:
  1. **Display name + account number**: Show `account_name` as primary, with `account_number` in smaller/muted text, e.g. "My IRA" with "5ABC123" below.
  2. **Editable display name**: Add `display_name` or use `account_name` as user-editable. Add PATCH endpoint to update `account_name`. "Edit" could open inline or a small modal to change the display name.
  3. **Format per broker**: TT — "Nickname (5ABC123)"; IBKR — "IBKR (FlexQuery)" or "U1234567"; Schwab — "Account name or number".
- **Recommended**: Use `account_name` as the editable display. Add quick "Edit name" (pencil icon) that opens an inline input or small modal. Fallback: `account_name || brokerDisplayName(broker) + " (" + account_number + ")"`.
- **Backend**: `PATCH /accounts/{id}` to update `account_name` (and possibly `account_type`). Validate user owns the account.

---

### Part 6: Other Improvements

- **TT**: Include `last_error` in tastytrade_status when applicable; improve job_error display.
- **Error recovery**: For sync_status=ERROR, show sync_error_message in a tooltip or expandable; make "Sync" (retry) prominent.
- **IBKR setup docs**: Helper text in wizard linking to FlexQuery setup.

---

## Key Files


| File                                                                                                                   | Changes                                                                                            |
| ---------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------- |
| [backend/api/routes/account_management.py](backend/api/routes/account_management.py)                                   | sync_error_message; GET sync-history; PATCH account + credentials; sync dedup 409                  |
| [backend/api/routes/aggregator.py](backend/api/routes/aggregator.py)                                                   | Replace JOBS with Redis; `job_id` in ibkr_flex_status; IBKR account_number; credential update      |
| [backend/services/portfolio/broker_sync_service.py](backend/services/portfolio/broker_sync_service.py)                 | Create AccountSync rows; use AccountCredentialsService                                             |
| [backend/services/portfolio/account_credentials_service.py](backend/services/portfolio/account_credentials_service.py) | **New**: `get_decrypted(account_id)` - DRY credential loading                                      |
| [backend/services/clients/ibkr_flexquery_client.py](backend/services/clients/ibkr_flexquery_client.py)                 | Support injected credentials                                                                       |
| [backend/services/portfolio/ibkr_sync_service.py](backend/services/portfolio/ibkr_sync_service.py)                     | Load creds from AccountCredentials; IBKR_FLEX fallback                                             |
| [frontend/src/pages/SettingsBrokerages.tsx](frontend/src/pages/SettingsBrokerages.tsx)                                 | Sync history; Edit; sync_error tooltip; useConnectJobPoll; extract ConnectWizard, BrokerAccountRow |


---

## Principal Engineer Review: Gaps, DRY, and Long-Term

### Critical Production Bugs

**1. JOBS in-memory will fail in production**

- [aggregator.py](backend/api/routes/aggregator.py) line 36: `JOBS: Dict[str, Dict[str, Any]] = {}` is in-memory.
- With multiple uvicorn workers or load balancer, connect request hits worker A, status poll hits worker B → `job_id` not found.
- **Fix**: Persist connect job status in Redis (e.g. `connect_job:{job_id}` with JSON + TTL 600s) or add `connect_jobs` DB table. Both TT and IBKR connect flows must read/write the same store.

**2. IBKR connect job status never exposed**

- `tastytrade_status(job_id)` reads from JOBS and returns `job_state`, `job_error`.
- `ibkr_flex_status()` does NOT accept `job_id` and does NOT read JOBS. When IBKR connect fails, frontend polls for 30s and times out with no error message.
- **Fix**: Add `job_id` query param to `ibkr_flex_status` (or new `GET /aggregator/connect-job/{job_id}`) that reads from the shared job store. Frontend passes jobId when polling.

**3. Sync deduplication missing**

- `sync_broker_account` does not check `account.can_sync()`. User can spam Sync → multiple Celery tasks for same account.
- **Fix**: If `sync_status in (QUEUED, RUNNING)`, return `409 Conflict` or `400` with message "Sync already in progress".

---

### DRY Violations

**4. Connect job polling duplicated (TT + IBKR)**

- Both use the same pattern: `for (i=0; i<30; i++) { status = api(); if success break; if error throw; await sleep(1000); }`
- **Fix**: Extract `useConnectJobPoll(jobId, statusFn, successCheck, getError)` hook. TT and IBKR pass their status API and check functions.

**5. Credential loading scattered**

- `tastytrade_sync_service` loads and decrypts credentials inline. IBKR sync will need similar logic.
- **Fix**: Create `AccountCredentialsService.get_decrypted(account_id: int, db)` → returns `{provider: str, payload: dict}`. Both TT and IBKR sync services call it. Single place for "load AccountCredentials, decrypt, validate shape".

**6. Edit credentials – multiple endpoints**

- Plan suggests `PUT /aggregator/tastytrade/credentials` and `PUT /aggregator/ibkr/credentials` separately.
- **Fix**: Single `PATCH /accounts/{id}/credentials` with body `{ broker: "tastytrade"|"ibkr", credentials: {...} }`. Backend routes by broker, validates ownership. DRY and consistent with REST.

---

### Architecture / Long-Term

**7. Frontend decomposition**

- [SettingsBrokerages.tsx](frontend/src/pages/SettingsBrokerages.tsx) is 560+ lines with wizard, table, modals, and polling logic in one file.
- **Fix**: Extract `ConnectWizard` (steps, broker forms), `BrokerAccountRow` (row + Edit/Sync/sync history expand), `useConnectJobPoll` hook. Keeps page file focused on layout and orchestration.

**8. credential_type and provider – type safety**

- `AccountCredentials.credential_type` is `String(32)` with ad-hoc values: "oauth", "ibkr_flex".
- **Fix**: Use Python `Literal` or SQLEnum for known types. Prevents typos and enables better validation.

**9. Encryption key rotation**

- [credential_vault.py](backend/services/security/credential_vault.py) uses Fernet (symmetric). Rotating `ENCRYPTION_KEY` would invalidate all stored credentials.
- **Fix**: Document this in ops runbook. Future: consider `key_id` in stored ciphertext for multi-key support if rotation is required.

**10. AccountCredentials.last_error**

- Model has `last_error` column; not used. Connect jobs write to JOBS (or Redis) but not to `AccountCredentials.last_error`.
- **Fix**: When connect fails, persist `last_error` on the related `AccountCredentials` (or `BrokerAccount`). UI can show "Last connect failed: X" without needing job_id.

---

### Consistency and Polish

**11. SyncStatus enum normalization**

- `SyncStatus` has both `SUCCESS` and `COMPLETED`. Account sync uses `SUCCESS`; `AccountSync` may use different values.
- **Fix**: Standardize: `SUCCESS` for success, `FAILED`/`ERROR` for failure. Ensure `AccountSync.status` and `BrokerAccount.sync_status` use the same enum.

**12. TastyTrade SDK – client_id**

- We store `client_id` but `connect_with_credentials(client_secret, refresh_token)` does not pass it. TT SDK v12 `Session(client_secret, refresh_token)` – verify OAuth spec: some flows need `client_id` in token requests.
- **Fix**: Confirm tastytrade SDK docs; if `client_id` is required, pass it into `Session` or equivalent.

**13. Rate limiting (429)**

- IBKR FlexQuery has backoff in `_request_report`. TastyTrade – check if we handle 429/rate limits.
- **Fix**: Ensure TT client has retry-with-backoff for 429. Document broker API limits in runbook.

---

### Testing

**14. Test coverage for new flows**

- Sync history API, edit credentials, sync dedup, Redis-backed JOBS.
- **Fix**: Add pytest for `GET /accounts/sync-history`, `PATCH /accounts/{id}/credentials`, sync returning 409 when already running. Mock credential_vault in tests.

---

## Mermaid: Credential Flow (After Fix)

```mermaid
flowchart TD
    subgraph Connect [Wizard Connect]
        UI[SettingsBrokerages]
        UI -->|flex_token, query_id| Agg[aggregator /ibkr/connect]
        Agg -->|encrypt| Vault[CredentialVault]
        Vault -->|store| AC[AccountCredentials]
    end
    subgraph Sync [Sync Flow]
        SyncBtn[Sync Button]
        SyncBtn -->|account_id| Task[sync_account_task]
        Task --> BSS[BrokerSyncService]
        BSS --> IBKR[IBKRSyncService]
        IBKR -->|load| AC
        AC -->|decrypt| Vault
        Vault -->|flex_token, query_id| Client[IBKRFlexQueryClient]
        Client -->|credentials| API[IBKR Flex API]
    end
```



