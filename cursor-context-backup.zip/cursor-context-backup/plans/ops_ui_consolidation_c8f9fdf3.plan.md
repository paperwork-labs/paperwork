---
name: Ops UI consolidation
overview: Remove AdminRunbook and consolidate guided ops into Admin Dashboard Advanced with responsive, clean controls, including period-based snapshot history backfill and a detailed MarketTracked snapshot table.
todos:
  - id: admin-advanced-guidance
    content: Replace 200d snapshot history control with period/since controls and add clean inline guidance in AdminDashboard Advanced; ensure responsive wrapping
    status: completed
  - id: remove-admin-runbook-route
    content: Remove AdminRunbook page/route and any links; ensure no dead navigation remains
    status: completed
    dependencies:
      - admin-advanced-guidance
  - id: marketcoverage-remove-table
    content: Remove snapshot indicators table from MarketCoverage; keep summary + histogram
    status: completed
    dependencies:
      - admin-advanced-guidance
  - id: markettracked-level1-4-table
    content: Refactor MarketTracked to be the detailed Level 1–4 snapshot indicators table using SortableTable and /technical/snapshots; ensure small-screen behavior
    status: completed
    dependencies:
      - marketcoverage-remove-table
  - id: tests-refresh
    content: Update/add tests for AdminDashboard controls, MarketCoverage, and MarketTracked; add backend test for /technical/snapshots if needed
    status: completed
    dependencies:
      - markettracked-level1-4-table
      - remove-admin-runbook-route
---

# Consolidate Ops UI (Responsive) + Remove Runbook

## Requirements to honor
- Keep **responsive behavior on small screens** (mobile + narrow widths) for all new controls and tables.
- Remove **AdminRunbook** and move any needed context/guidance into **Admin Dashboard** while staying **clean, elegant, and helpful**.

## 1) Admin Dashboard: Guided Advanced controls
**File:** [frontend/src/pages/AdminDashboard.tsx](frontend/src/pages/AdminDashboard.tsx)

### Snapshot History backfill (replace 200d)
- Remove **Backfill Snapshot History (200d)**.
- Keep **Backfill Snapshot History (since)**.
- Add **Backfill Snapshot History (period)**:
  - Period dropdown: `6mo / 1y / 2y / 5y / max`
  - Map period → trading-day count (approx): `6mo→126`, `1y→252`, `2y→504`, `5y→1260`, `max→3000` (bounded by backend).
  - POST to: `POST /api/v1/market-data/admin/snapshots/history/backfill-last-n-days?days=<mapped>`.

### Replace Runbook UX with inline guidance
- Add a small, unobtrusive “Operator guidance” block inside Advanced:
  - 2–3 bullet lines: “Use Restore Daily Coverage when you missed days”, “Use Snapshot History backfill for analytics/backtesting”, “Use Sanity Check to validate DB counts.”
- Keep buttons grouped by intent with light labeling (no big panels):
  - **Universe**: Refresh constituents, Update tracked
  - **Daily data**: Backfill daily since-date, Recompute indicators, Record history
  - **History**: Backfill snapshot history since-date, Backfill snapshot history period
  - **Diagnostics**: Sanity Check (DB)

### Responsive layout rules
- Use `Stack/HStack` with `flexWrap="wrap"` and ensure dropdown + button pairs wrap cleanly.
- On base screens, controls should stack; on md+ they can appear in rows.

## 2) Remove AdminRunbook
**Files:**
- [frontend/src/pages/AdminRunbook.tsx](frontend/src/pages/AdminRunbook.tsx)
- [frontend/src/App.tsx](frontend/src/App.tsx)
- Any navigation links to the runbook route

Actions:
- Delete the page and remove route/import.
- Ensure no dead links remain.

## 3) MarketCoverage becomes coverage-only
**File:** [frontend/src/pages/MarketCoverage.tsx](frontend/src/pages/MarketCoverage.tsx)
- Remove the snapshot indicators table.
- Keep coverage summary + daily fill histogram.

## 4) MarketTracked becomes the Level 1–4 snapshot table
**File:** [frontend/src/pages/MarketTracked.tsx](frontend/src/pages/MarketTracked.tsx)

### Data source
- Use latest snapshots endpoint: `GET /api/v1/market-data/technical/snapshots` (MarketSnapshot).

### Table
- Switch to `SortableTable` and include Level 1–4 fields:
  - Level 1: `sma_5/14/21/50/100/150/200`, `ema_8/21`, `atr_14/30`, `range_pos_20d/50d/52w`
  - Level 2: `atrp_14/30`, `atrx_sma_21/50/100/150`
  - Level 3: `rs_mansfield_pct`
  - Level 4: `stage_label`, `stage_label_5d_ago`

### Responsive behavior
- Default visible columns should be compact and useful.
- On small screens:
  - Use horizontal scroll (already supported by `SortableTable` via `TableScrollArea`).
  - Keep `maxHeight` and avoid huge fixed widths.

## 5) Backend support
**File:** [backend/api/routes/market_data.py](backend/api/routes/market_data.py)
- Ensure `GET /technical/snapshots` includes needed fields (already largely present); add any missing Level 1–4 fields if necessary.

## 6) Tests
### Frontend
- Update AdminDashboard tests to reflect:
  - removal of 200d
  - presence of period control
- Update MarketCoverage test to no longer expect the snapshot table.
- Add MarketTracked test:
  - loads snapshot rows
  - verifies key columns render

### Backend
- Add/adjust a small test for `/technical/snapshots` if not already covered.

## Validation
- Run `make test`
- Run `make test-frontend`