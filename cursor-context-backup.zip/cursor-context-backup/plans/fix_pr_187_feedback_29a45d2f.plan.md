---
name: Fix PR 187 feedback
overview: "Address the 7 Copilot review comments on PR #187 and re-trigger CI. All tests pass locally (313 backend, 113 frontend, typecheck clean); the CI failures were GitHub Actions runner issues (0 steps ran), not code failures."
todos:
  - id: fix-stage-unknown
    content: Add '?' bucket for unknown stages in stageCountsFromPositions (utils/portfolio.ts:75)
    status: completed
  - id: fix-timeago-nan
    content: Add isNaN guard in timeAgo() (utils/portfolio.ts:139)
    status: completed
  - id: fix-overview-dashboard
    content: Fix dashboard data unwrapping in PortfolioOverview.tsx:74
    status: completed
  - id: fix-categories-market-data
    content: Pass includeMarketData=false in PortfolioCategories.tsx:64
    status: completed
  - id: fix-aria-tr-role
    content: Remove role='button' from TableRow in SortableTable.tsx:688
    status: completed
  - id: fix-categories-user-scope
    content: Add Position.user_id filter to assigned_value query in portfolio_categories.py:60
    status: completed
  - id: fix-assign-ownership
    content: Validate position ownership before creating PositionCategory in portfolio_categories.py:193
    status: completed
  - id: push-fixes
    content: Commit and push fixes to PR branch, verify CI re-triggers
    status: completed
isProject: false
---

# Fix PR #187 Review Comments and Re-trigger CI

## CI Status

Backend (313 passed) and frontend (113 passed, typecheck clean) all pass locally. The GitHub Actions CI run shows 0 steps on both jobs, indicating the runners never started -- this is a GitHub infrastructure issue, not a code problem. After pushing the fixes below, CI will be re-triggered automatically.

## Review Comments to Address (7 items)

### 1. Unknown stage mapped to "1" in `stageCountsFromPositions`

**File:** [frontend/src/utils/portfolio.ts](frontend/src/utils/portfolio.ts) line 75

Currently unknown stages silently increment the `'1'` bucket. Fix: add a `'?'` bucket to the counts record and route unknowns there instead.

```typescript
// Before
else counts['1']++;
// After
else counts['?'] = (counts['?'] ?? 0) + 1;
```

Initialize `counts` with `'?': 0` alongside the others.

### 2. `timeAgo()` doesn't guard against invalid dates

**File:** [frontend/src/utils/portfolio.ts](frontend/src/utils/portfolio.ts) line 139-144

Add `isNaN` guard after creating the Date:

```typescript
const d = new Date(iso);
if (isNaN(d.getTime())) return '—';
```

### 3. PortfolioOverview reads dashboard fields at wrong level

**File:** [frontend/src/pages/portfolio/PortfolioOverview.tsx](frontend/src/pages/portfolio/PortfolioOverview.tsx) lines 74-80

The dashboard API returns `{ status, data: { summary: {...} } }`. The code already does `dashboard?.summary ?? dashboard` on line 74, but should use `dashboard?.data?.summary ?? dashboard?.summary ?? dashboard` to correctly unwrap the nested response.

### 4. Categories fetches stocks with market data unnecessarily

**File:** [frontend/src/pages/portfolio/PortfolioCategories.tsx](frontend/src/pages/portfolio/PortfolioCategories.tsx) line 64

Pass `includeMarketData=false` to `portfolioApi.getStocks()` since category assignment only needs symbol + id + market_value.

### 5. `role="button"` on `<tr>` is invalid ARIA

**File:** [frontend/src/components/SortableTable.tsx](frontend/src/components/SortableTable.tsx) lines 688-689

Remove `role="button"` from `<TableRow>`. Keep `tabIndex`, `onClick`, `onKeyDown` but use `aria-label` instead to indicate the row is interactive. This preserves keyboard navigation without breaking table semantics.

### 6. Categories not user-scoped -- `assigned_value` query missing user filter

**File:** [backend/api/routes/portfolio_categories.py](backend/api/routes/portfolio_categories.py) line 60-65

The `assigned_value` subquery joins `Position` via `PositionCategory` but never filters by `Position.user_id == user.id`. Add the filter so one user's positions don't leak into another user's category allocations.

### 7. `assign_positions` doesn't verify position ownership

**File:** [backend/api/routes/portfolio_categories.py](backend/api/routes/portfolio_categories.py) lines 193-200

Before creating `PositionCategory` rows, validate each `position_id` belongs to the requesting user by querying `Position` filtered on `user_id`. Skip or reject IDs that don't match.

## After Fixes

Push the commit to the existing branch. GitHub Actions will auto-trigger a new CI run. The "Open PR" workflow failure is expected (PR already exists). The "Update branch" workflow will succeed once the branch is up to date.
