---
name: release-flag-alignment
overview: "Align backend/frontend gating to the release model: admins always see everything, non-admins get Market now, Portfolio/Strategy remain blocked by default until enabled."
todos:
  - id: unify-market-gating
    content: Refactor backend market visibility checks to follow release-flag policy for authenticated non-admin users.
    status: completed
  - id: preserve-nonmarket-guards
    content: Keep Portfolio/Strategy API guards as feature-gated (not admin-only) and confirm router wiring.
    status: completed
  - id: update-config-surface
    content: Reduce env-flag ambiguity by removing/deprecating market visibility env branching in API metadata/guards.
    status: completed
  - id: expand-tests
    content: Add/adjust backend and frontend tests for admin full access + non-admin market-only default behavior.
    status: completed
  - id: verify-end-to-end
    content: Run targeted suites and role-based smoke validation before finalizing.
    status: completed
isProject: false
---

# Release Flag Alignment Plan

## Goal

Implement a single, predictable release policy:

- Admin: full access to all sections.
- Non-admin: Market section available now (authenticated users).
- Non-admin Portfolio/Strategy: blocked by default until flags are enabled.

## Current Gap

The backend market guard still depends on `MARKET_DATA_SECTION_PUBLIC` in [backend/config.py](/Users/sankalpsharma/development/axiomfolio/backend/config.py) and [backend/api/dependencies.py](/Users/sankalpsharma/development/axiomfolio/backend/api/dependencies.py), which can conflict with app-level release flags.

## Implementation Steps

- Make app settings the source of truth for release behavior in [backend/api/dependencies.py](/Users/sankalpsharma/development/axiomfolio/backend/api/dependencies.py):
  - Keep admin bypass.
  - For market data viewer, allow all authenticated users (as requested rollout state).
  - Keep non-market guard for Portfolio/Strategy using existing section flags.
- Keep Portfolio routes guarded with `require_non_market_access` in [backend/api/main.py](/Users/sankalpsharma/development/axiomfolio/backend/api/main.py) (not admin-only), because these are feature-gated user surfaces, not admin surfaces.
- Remove or de-emphasize env-based market visibility behavior (`MARKET_DATA_SECTION_PUBLIC`) in [backend/config.py](/Users/sankalpsharma/development/axiomfolio/backend/config.py) and related references in [backend/api/routes/market_data.py](/Users/sankalpsharma/development/axiomfolio/backend/api/routes/market_data.py), so behavior is not split between env and DB flags.
- Validate frontend gating remains consistent in [frontend/src/components/auth/RequireNonMarketAccess.tsx](/Users/sankalpsharma/development/axiomfolio/frontend/src/components/auth/RequireNonMarketAccess.tsx) and nav visibility in [frontend/src/components/layout/DashboardLayout.tsx](/Users/sankalpsharma/development/axiomfolio/frontend/src/components/layout/DashboardLayout.tsx).
- Update/add tests:
  - Backend dependency tests for market access and non-market section blocking.
  - Existing app settings/market endpoint tests to assert non-admin market access and default portfolio/strategy lock.

## Verification

- Backend: run targeted auth/release tests and market endpoint tests.
- Frontend: run route/nav tests to verify Market visible and Portfolio/Strategy hidden for non-admin defaults.
- Manual smoke check with admin vs non-admin accounts in local dev.

