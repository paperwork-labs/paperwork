---
name: market-dashboard-rollout
overview: Create a scalable Market Dashboard MVP, rename current dashboard to Market Coverage, remove Market Data from Settings, and keep feature flags in Admin (top release controls) while preserving backend-enforced section gating.
todos:
  - id: ia-routes-cleanup
    content: "Restructure market routes/nav: new dashboard route, rename coverage route, remove settings market links"
    status: completed
  - id: admin-release-controls-placement
    content: Keep feature flags in Admin Dashboard and ensure top-level release-controls UX
    status: completed
  - id: backend-dashboard-api
    content: Add scalable backend market dashboard service and endpoint with typed response
    status: completed
  - id: frontend-dashboard-mvp
    content: Build Market Dashboard MVP UI from backend summaries and wire API client
    status: completed
  - id: coverage-admin-boundary
    content: Keep Market Coverage reader-friendly and maintain admin-only operational controls
    status: completed
  - id: tests-update
    content: Update frontend route/nav tests and add backend dashboard endpoint tests
    status: completed
isProject: false
---

# Market Dashboard Rollout Plan

## Scope Confirmed

- Market gets a dedicated Dashboard page (MVP, not hardcoded-only placeholder).
- Current Market Dashboard view becomes `Market Coverage`.
- `Settings > Market Data` section is removed.
- Feature flags stay in Admin, moved/kept at top as `Release Controls`.
- Dashboard design is research-driven for momentum workflows and built to scale.

## Product Direction (Research-Driven MVP)

For a momentum-focused dashboard, surface high-signal summaries first, then drill into `Tracked`:

- **Market Regime Snapshot**: breadth/risk-on proxy (up/down counts, trend regime, volatility state).
- **Momentum Leaderboard**: top symbols by composite momentum score.
- **Setup Watchlists**: breakout candidates, pullback-in-trend, and relative-strength leaders.
- **Sector/Industry Momentum**: strongest/weakest groups.
- **Action Queue**: symbols whose signal state changed since last refresh.

These should be API-derived summaries (server computes), with UI mostly read-only and compositional.

## Architecture Changes

- Use image-based architectural diagrams (PNG/SVG) for design reviews and docs updates.
- Diagram content to include:
  - Backend flow: `market_snapshot` + tracked universe -> `market_dashboard_service` -> `/api/v1/market-data/dashboard`.
  - Frontend flow: `MarketDashboard` consumes dashboard endpoint and links to `MarketTracked`.
  - Admin boundary: Release controls in Admin dashboard, coverage ops in Admin, reader-friendly coverage in Market area.



## Implementation Plan

1. **Routing + IA cleanup (Market-first navigation)**
  - Add a new Market Dashboard page route at `/` (and optionally `/market/dashboard`).
  - Keep `Market Coverage` at `/market/coverage`.
  - Keep `Tracked` at `/market/tracked`.
  - Remove `Settings` market routes and links.
  - Files:
    - [frontend/src/App.tsx](frontend/src/App.tsx)
    - [frontend/src/components/layout/DashboardLayout.tsx](frontend/src/components/layout/DashboardLayout.tsx)
    - [frontend/src/pages/SettingsShell.tsx](frontend/src/pages/SettingsShell.tsx)
2. **Feature-flag UX cleanup (Admin top card)**
  - Keep release toggles in Admin Dashboard but ensure they are a clear, top-level card.
  - Preserve current backend flag model and admin write path.
  - Files:
    - [frontend/src/pages/AdminDashboard.tsx](frontend/src/pages/AdminDashboard.tsx)
    - [frontend/src/services/api.ts](frontend/src/services/api.ts)
3. **Backend scalable dashboard API (heavy lifting on server)**
  - Add a dedicated service that computes dashboard sections from existing market snapshot data.
  - Introduce a typed response contract for cards/sections (regime, leaders, setups, sectors, changed signals).
  - Expose a read endpoint (`GET /api/v1/market-data/dashboard`) for authenticated users.
  - Files:
    - [backend/services/market_dashboard_service.py](backend/services/market_dashboard_service.py) (new)
    - [backend/api/routes/market_data.py](backend/api/routes/market_data.py)
    - [backend/api/dependencies.py](backend/api/dependencies.py) (only if access control updates are needed)
4. **Frontend Market Dashboard MVP page**
  - Create `MarketDashboard` page consuming the new API.
  - Render concise cards and tables with links into `Tracked` pre-filtered views where applicable.
  - Keep page modular so adding cards does not change route/layout logic.
  - Files:
    - [frontend/src/pages/MarketDashboard.tsx](frontend/src/pages/MarketDashboard.tsx) (new)
    - [frontend/src/services/api.ts](frontend/src/services/api.ts)
5. **Market Coverage positioning cleanup**
  - Keep `MarketCoverage` as reader-friendly coverage analytics page.
  - Ensure operational controls remain in Admin only.
  - Files:
    - [frontend/src/pages/MarketCoverage.tsx](frontend/src/pages/MarketCoverage.tsx)
    - [frontend/src/pages/AdminDashboard.tsx](frontend/src/pages/AdminDashboard.tsx)
6. **Tests + safety checks**
  - Update route/nav tests for new Dashboard vs Coverage naming and visibility.
  - Add backend tests for new dashboard endpoint contract and auth behavior.
  - Keep/extend release-control tests.
  - Files:
    - [frontend/src/components/layout/**tests**/DashboardLayoutPersistence.test.tsx](frontend/src/components/layout/__tests__/DashboardLayoutPersistence.test.tsx)
    - [frontend/src/pages/**tests**/SettingsShell.test.tsx](frontend/src/pages/__tests__/SettingsShell.test.tsx)
    - [backend/tests/test_market_data_dashboard_endpoint.py](backend/tests/test_market_data_dashboard_endpoint.py) (new)
    - [backend/tests/test_app_settings_endpoints.py](backend/tests/test_app_settings_endpoints.py)

## Why flags were in Admin Dashboard

They were placed there as release controls near operational market controls for fast internal rollout. With this plan, they remain in Admin (as you requested) but are clearly separated at the top so they don’t feel mixed into coverage analytics.