---
name: admin-endpoint-hardening
overview: Audit all API endpoints for admin-only task triggers and data exposure, enforce RBAC consistently, and update tests/docs to match the new security posture.
todos:
  - id: audit-routes
    content: Scan routes for admin-only enforcement gaps
    status: completed
  - id: apply-rbac
    content: Update endpoints to require admin where needed
    status: completed
  - id: tests-docs
    content: Adjust tests/docs and verify with make test
    status: completed
isProject: false
---

# Admin Endpoint Hardening

## Scope

- Apply admin-only enforcement across the full backend API, with extra focus on task-triggering endpoints and data-exposure endpoints that should not be public.

## Implementation Plan

- **Inventory and classify endpoints**
  - Scan route modules under `backend/api/routes/` for any `@router.post`/`@router.get` that mutate state or expose operational data but use `get_optional_user` or no auth.
  - Classify into: admin-only, viewer-level, authenticated-only, or public.
  - Pay special attention to market data task triggers in `[backend/api/routes/market_data.py](/Users/sankalpsharma/development/axiomfolio/backend/api/routes/market_data.py)` (e.g., `POST /indices/constituents/refresh`, `POST /symbols/{symbol}/refresh`, `GET /admin/tasks/status`) and any non-admin `/admin/*` routes.
- **Apply RBAC fixes**
  - Switch task-triggering endpoints to `get_admin_user` and update any route parameters accordingly.
  - Ensure data-exposure endpoints under `/admin/*` use `get_admin_user` unless explicitly intended for broader access.
  - Keep read-only public endpoints (e.g., prices/snapshots) on `get_optional_user` or `get_market_data_viewer` based on current product policy.
- **Update tests**
  - Add/adjust tests to assert 401/403 for non-admin access and success when `get_admin_user` is overridden.
  - Update any existing smoke tests that currently assume anonymous access (e.g., `test_market_data_refresh` in `[backend/tests/test_api_endpoints.py](/Users/sankalpsharma/development/axiomfolio/backend/tests/test_api_endpoints.py)`).
  - Extend recent admin-only tests created for `/admin/tasks` and `/admin/db/history` as needed.
- **Update docs**
  - Note admin-only requirements in `[docs/MARKET_DATA.md](/Users/sankalpsharma/development/axiomfolio/docs/MARKET_DATA.md)` and `[docs/PRODUCTION.md](/Users/sankalpsharma/development/axiomfolio/docs/PRODUCTION.md)` for relevant endpoints.
- **Verification**
  - Run `make test` and confirm no regression in RBAC-related test cases.

## Files to Review/Change

- Core routes: `[backend/api/routes/market_data.py](/Users/sankalpsharma/development/axiomfolio/backend/api/routes/market_data.py)` and other route modules under `backend/api/routes/`.
- Tests: `[backend/tests/test_api_endpoints.py](/Users/sankalpsharma/development/axiomfolio/backend/tests/test_api_endpoints.py)`, plus any admin-auth test modules.
- Docs: `[docs/MARKET_DATA.md](/Users/sankalpsharma/development/axiomfolio/docs/MARKET_DATA.md)`, `[docs/PRODUCTION.md](/Users/sankalpsharma/development/axiomfolio/docs/PRODUCTION.md)`

## Notes

- Existing Copilot comments already identify specific fixes in market data routes (e.g., `POST /indices/constituents/refresh` and `POST /symbols/{symbol}/refresh`). These will be addressed as part of the first two steps above.

