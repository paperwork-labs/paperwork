---
name: use-market-data-endpoints
overview: Plan to adopt canonical market-data endpoints across frontend, backend clients, and docs and remove deprecated aliases by the end of this PR.
todos:
  - id: map-routes
    content: Map deprecated → canonical routes for removal
    status: completed
  - id: frontend-update
    content: Update frontend services/hooks to use canonical routes
    status: completed
  - id: docs-update
    content: Refresh docs/examples to canonical routes + deprecation note
    status: completed
  - id: tests-update
    content: Align tests to new endpoints and remove alias checks
    status: completed
isProject: false
---

# Use New Market Data Endpoints

## Context and Targets

- Canonical routes already added in `[/Users/sankalpsharma/development/axiomfolio/backend/api/routes/market_data.py](/Users/sankalpsharma/development/axiomfolio/backend/api/routes/market_data.py)` with deprecated legacy aliases scheduled for removal in this PR.
- Existing API surface references live in docs (notably `[/Users/sankalpsharma/development/axiomfolio/docs/MARKET_DATA.md](/Users/sankalpsharma/development/axiomfolio/docs/MARKET_DATA.md)`) and potentially in frontend service helpers.

## Approach

1. Inventory and map old → new paths
  - Enumerate all deprecated paths (e.g., `/technical/snapshot/*`, `/tracked/update`, `/index/constituents`) from the router file and create a canonical mapping list for replacement.
  - Identify any references in frontend service utilities and backend/docs that still point to deprecated paths and plan replacements.
2. Update frontend usage (primary)
  - Introduce or update centralized API helpers in the frontend (likely under `[/Users/sankalpsharma/development/axiomfolio/frontend/src/services](/Users/sankalpsharma/development/axiomfolio/frontend/src/services)`) to call the canonical endpoints:
    - Prices: `/prices/{symbol}`, `/prices/{symbol}/history`
    - Snapshots: `/snapshots`, `/snapshots/{symbol}`, `/snapshots/{symbol}/history`
    - Coverage: `/coverage`, `/coverage/{symbol}`
    - Universe/indices: `/universe/tracked`, `/indices/constituents`
    - Admin ops: `/admin/coverage/restore`, `/admin/coverage/backfill-stale`, `/admin/backfill/5m`, `/admin/retention/enforce`, `/admin/db/history`, `/admin/snapshots/history/record`
  - Replace any inline fetches to old endpoints with the new canonical helper calls.
  - Remove deprecated routes from the backend router after all callers are updated.
3. Backend/internal clients
  - If any backend scripts or internal callers use HTTP calls to the API, update to canonical paths (search the repo for `/api/v1/market-data` usage outside tests/docs).
4. Documentation and examples
  - Update endpoint examples and runbooks in `[/Users/sankalpsharma/development/axiomfolio/docs/MARKET_DATA.md](/Users/sankalpsharma/development/axiomfolio/docs/MARKET_DATA.md)` and any other docs mentioning old routes.
  - Add a short “Canonical routes” section with a table-style bullet list; remove any “deprecated alias” mentions once aliases are deleted.
5. Tests and validation
  - Add/adjust frontend tests (if any) to align with the new helpers.
  - Update backend smoke tests to only assert canonical routes (remove alias expectations) in `[/Users/sankalpsharma/development/axiomfolio/backend/tests/test_api_endpoints.py](/Users/sankalpsharma/development/axiomfolio/backend/tests/test_api_endpoints.py)`.

## Notes

- Deprecated aliases will be removed in this PR after callers are migrated.
- Prioritize consistency: all code should use canonical routes only.

