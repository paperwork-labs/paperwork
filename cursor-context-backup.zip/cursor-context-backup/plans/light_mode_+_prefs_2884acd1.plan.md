---
name: Light mode + prefs
overview: "Fix light mode visuals by removing dark-only hardcoded colors and completing missing semantic tokens. Then wire user preferences (theme, currency, table density, timezone) end-to-end: persisted in backend (already) and applied consistently across the UI with shared formatters and table sizing."
todos:
  - id: theme-tokens
    content: Add missing semantic tokens (bg.muted/bg.subtle and optionally bg.header/bg.sidebar) and remove dark-only styling sources.
    status: completed
  - id: layout-lightmode
    content: Refactor DashboardLayout + account select styling to use semantic tokens/CSS variables so light mode renders correctly and menus are readable.
    status: completed
    dependencies:
      - theme-tokens
  - id: toast-theme
    content: Update App.tsx toast styling to use CSS variables so toast matches current theme.
    status: completed
    dependencies:
      - theme-tokens
  - id: prefs-formatters
    content: Add shared formatters (currency + timezone) and a small preferences accessor so pages can render user-specific formats.
    status: completed
  - id: apply-currency-timezone
    content: Replace hardcoded USD and local toLocaleString usage across key pages with shared formatters + user preferences.
    status: completed
    dependencies:
      - prefs-formatters
  - id: table-density
    content: Default SortableTable size from user table_density when not explicitly set, and add a focused test.
    status: completed
    dependencies:
      - prefs-formatters
  - id: tests-format
    content: Add unit tests for formatters (currency/timezone) and validate persistence behavior remains intact.
    status: completed
    dependencies:
      - prefs-formatters
      - apply-currency-timezone
      - table-density
---

# Fix light mode + persist preferences end-to-end

## Why it’s broken

- `DashboardLayout` hardcodes dark grays (`gray.900/950`) and a dark-styled native `<select>`, so when you switch to **light mode** the app shell stays dark while semantic tokens (`fg.*`, `bg.*`) flip to light mode values. This makes Settings/menu text appear “hidden” (dark text on dark background) and icons/buttons look wrong.
- Settings/menu hover/active uses `bg.muted`/`bg.subtle` (e.g. in `SettingsShell`), but these aren’t defined in our custom semantic tokens in [`frontend/src/theme/system.ts`](frontend/src/theme/system.ts), so rendering depends on defaults and can be inconsistent.
- Preference persistence exists in the backend (`users.ui_preferences` + `/auth/me` PUT merges/validates in [`backend/api/routes/auth.py`](backend/api/routes/auth.py)), but the frontend only applies:
- theme on load; and
- writes table density/timezone/currency without using them broadly in UI.

## Implementation plan

### 1) Make light/dark theming consistent (no hardcoded dark shell)

- Update [`frontend/src/theme/system.ts`](frontend/src/theme/system.ts)
- Add missing semantic tokens used across the app: `bg.muted`, `bg.subtle` (light + dark values).
- (Optional, if needed for clarity) Add `bg.header` and `bg.sidebar` tokens so layout intent is explicit.
- Update [`frontend/src/components/layout/DashboardLayout.tsx`](frontend/src/components/layout/DashboardLayout.tsx)
- Replace `gray.900/950` hardcoding with semantic tokens (`bg.canvas` / `bg.panel` / `border.subtle`).
- Update `NavItem` active/hover backgrounds to use `bg.muted`/`bg.subtle` and text to use `fg.default`/`fg.muted`.
- Replace the inline-styled account `<select>` to use CSS variables (`--chakra-colors-bg-input`, `--chakra-colors-border-subtle`, `--chakra-colors-fg-default`) so it looks correct in both modes.
- Update [`frontend/src/App.tsx`](frontend/src/App.tsx)
- Replace hardcoded dark toast styling with CSS variables so `react-hot-toast` matches the current theme (no hook needed).

### 2) Wire preferences end-to-end (theme + currency + table density + timezone)

- Add a small formatting layer in a new [`frontend/src/utils/format.ts`](frontend/src/utils/format.ts)
- `formatMoney(amount, currency, { maximumFractionDigits })`
- `formatDateTime(isoOrEpoch, timezone)` and `formatTime(isoOrEpoch, timezone)` (using `Intl.DateTimeFormat` with `timeZone`).
- Add a small preference accessor (either)
- a `useUserPreferences()` hook (new file) that reads from `useAuth().user` and returns `{ currency, timezone, tableDensity }` with safe defaults; **or**
- lightweight helpers colocated in `format.ts`.
- Apply **currency preference** to pages/components currently hardcoding USD:
- [`frontend/src/components/ui/AccountSelector.tsx`](frontend/src/components/ui/AccountSelector.tsx)
- [`frontend/src/pages/Portfolio.tsx`](frontend/src/pages/Portfolio.tsx)
- [`frontend/src/pages/OptionsPortfolio.tsx`](frontend/src/pages/OptionsPortfolio.tsx)
- [`frontend/src/pages/DividendsCalendar.tsx`](frontend/src/pages/DividendsCalendar.tsx)
- [`frontend/src/pages/TaxLots.tsx`](frontend/src/pages/TaxLots.tsx)
- (plus any other obvious `currency: 'USD'` occurrences from a quick grep)
- Apply **timezone preference** to pages currently using `toLocaleString()` / `toLocaleTimeString()`:
- [`frontend/src/pages/AdminDashboard.tsx`](frontend/src/pages/AdminDashboard.tsx)
- [`frontend/src/pages/AdminJobs.tsx`](frontend/src/pages/AdminJobs.tsx)
- [`frontend/src/pages/MarketTracked.tsx`](frontend/src/pages/MarketTracked.tsx)
- [`frontend/src/pages/Dashboard.tsx`](frontend/src/pages/Dashboard.tsx)
- Apply **table density preference** globally via `SortableTable`:
- Update [`frontend/src/components/SortableTable.tsx`](frontend/src/components/SortableTable.tsx) so when `size` prop is not explicitly provided it defaults based on `user.ui_preferences.table_density`:
    - `compact` → `size="sm"`
    - `comfortable` → `size="md"`

### 3) Ensure preferences truly “persist”

- Keep server-side persistence as source of truth (already supported by `/auth/me` PUT).
- On initial load, continue applying `ui_preferences.color_mode_preference` in [`frontend/src/context/AuthContext.tsx`](frontend/src/context/AuthContext.tsx).
- Ensure any newly-used preferences (currency/timezone/table density) read from `useAuth().user` so they’re consistent across reloads and across devices.

## Tests (minimal but meaningful)

- Add unit tests for [`frontend/src/utils/format.ts`](frontend/src/utils/format.ts) (currency formatting + timezone formatting).
- Add a component-level test for `SortableTable` default sizing based on mocked `useAuth().user.ui_preferences.table_density`.
- Keep existing `SettingsPreferences` save test as-is; optionally extend it to verify it writes all three fields (it already does).