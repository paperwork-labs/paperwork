---
name: Fix Master Plan Doc
overview: Comprehensive self-review of VENTURE_MASTER_PLAN.md identified 19 findings (4 HIGH, 7 MEDIUM, 8 LOW) across formatting, stale data, contradictions, and missing content. Fix all in a single commit.
todos:
  - id: high-fixes
    content: "Fix 4 HIGH findings: H1 (FCRA cost in FINANCIALS.md), H2 (deletion cascade + credit provider), H3 (4H unsubscribe contradiction), H4 (email alias domains)"
    status: completed
  - id: medium-fixes
    content: "Fix 7 MEDIUM findings: M1 (strikethrough formatting), M2 (0G LLC name stale), M3 (Phase 4 agent count), M4 (Cross-Sell header), M5 (4N missing from Phase 4), M6 (6K quality gates), M7 (ChurnGuard fallback)"
    status: completed
  - id: low-fixes
    content: "Fix 8 LOW findings: L1 (P0.6 status), L2 (cross-sell wording), L3 (6D header), L4 (KNOWLEDGE D42), L5 (section numbering), L6 (credit score events), L7 (credit score data model), L8 (risk assessment timing)"
    status: completed
  - id: commit-push
    content: Commit all fixes to the existing docs/master-plan-enhancements-v2 branch and push
    status: completed
isProject: false
---

# Fix and Self-Review: Venture Master Plan

Full multi-persona review of [docs/VENTURE_MASTER_PLAN.md](docs/VENTURE_MASTER_PLAN.md) (3,155 lines) + [docs/FINANCIALS.md](docs/FINANCIALS.md) + [docs/KNOWLEDGE.md](docs/KNOWLEDGE.md).

**Verdict: 0 CRITICAL, 4 HIGH, 7 MEDIUM, 8 LOW = 19 findings**

---

## HIGH (4) -- Must Fix

**H1: FCRA compliance cost missing from FINANCIALS.md** (CFO + Legal)

- Section 4M (line 1782) references "$500-1,000 for FCRA compliance review"
- [docs/FINANCIALS.md](docs/FINANCIALS.md) line 63 `Planned one-time expenses` does not include it
- **Fix**: Add `FCRA compliance review | $500-1,000 | Legal` to one-time expenses table and update the total range

**H2: Deletion cascade missing credit provider** (Engineering + Legal)

- Section 0I deletion cascade (lines 664-672) lists 7 steps but omits credit score provider API deletion
- When a user requests deletion, we must notify the credit score reseller (Array/SavvyMoney) per FCRA
- **Fix**: Add step between #4 and #5: "Credit score provider: request data deletion via reseller API (Array/SavvyMoney)"

**H3: Consent unsubscribe contradiction** (Legal)

- Section 4H (line 1622): "Single unsubscribe covers all brands (same legal entity)"
- Section 0I (line 679): "Per-product unsubscribe in email footer"
- Section 0C (line 189): "I can unsubscribe from any product at any time"
- Sections 0C and 0I agree (per-product); Section 4H contradicts
- **Fix**: Update Section 4H line 1622 to: "Per-product unsubscribe in email footer: users can unsubscribe from FileFree emails without affecting LaunchFree (and vice versa)"

**H4: Email alias domain inconsistency** (Engineering + Legal)

- Section 14 email table (lines 3127-3132) mixes domains: `hello@filefree.tax` / `support@filefree.tax` alongside `legal@filefree.ai` / `partnerships@filefree.ai`
- P0.2 migrates to filefree.ai as primary domain; filefree.tax becomes a redirect
- **Fix**: Standardize all aliases to filefree.ai domain. Add note: "(filefree.tax aliases retained as redirects post-migration)"

---

## MEDIUM (7) -- Should Fix

**M1: Broken markdown strikethrough on line 29** (Engineering)

- `~~$284/mo` and `~~$0.005` create unintended markdown strikethrough -- everything between these two `~~` markers renders as struck-through text in GitHub/viewers
- **Fix**: Replace double tildes with single `~` for "approximately"

**M2: Section 0G #4 stale -- LLC name action still open** (Strategy)

- Line 616: "Decide LLC name | $0 | Hard deadline: 2 weeks from today" with no DONE status
- LLC name is DECIDED as Paperwork Labs LLC (Section 0B)
- **Fix**: Mark row as DONE or add strikethrough + "DECIDED -- see Section 0B"

**M3: Phase 4 agent count wrong** (Strategy)

- Line 2700: "one human + **37 agents** model"
- Section 6I (line 2389): "24 Cursor personas + 20 n8n workflows = **44 agents**"
- **Fix**: Update line 2700 to "44 agents"

**M4: "Cross-Sell & Marketing" table header stale** (Engineering)

- Section 0E line 409: table heading still says "Cross-Sell & Marketing"
- Package renamed from `cross-sell` to `intelligence` (D61, Section 2 architecture)
- **Fix**: Rename to "Intelligence & Marketing"

**M5: Partner Dashboard (4N) missing from Phase 4 tiers** (CFO)

- Section 4N describes a partner dashboard at `paperworklabs.com/admin/partners`
- Phase 4 tiers (lines 2702-2735) don't include it; P4.11 (`/admin/revenue`) is the closest but different
- **Fix**: Add cross-reference note to Section 4N: "Implemented as a tab within P4.11 Revenue & Spend Intelligence, or as P4.15 in Tier 3"

**M6: Autonomous engineering (6K) missing quality gates** (QA)

- Section 6K lists tasks suitable for background agents but doesn't mention enhanced review requirements
- .cursorrules requires "100% test coverage" for tax calculations + validation against IRS Pub 17
- **Fix**: Add quality gate note to Section 6K: "Tax calculation and formation data PRs require 100% test coverage and validation against IRS Publication 17 worked examples before merge"

**M7: ChurnGuard AI validation needed** (Engineering)

- Section 4L (line 1724) references "ChurnGuard AI (open-source, connects PostHog + Stripe, 15-min setup)"
- Project maintenance status unverified
- **Fix**: Add fallback note: "If ChurnGuard is unmaintained at implementation time, PostHog's built-in retention analysis + custom churn scoring via Python is the fallback (~1 day of engineering)"

---

## LOW (8) -- Fix While We're Here

**L1: P0.6 status says "BLOCKED (name TBD)"** -- Name is decided. Update to "NOT STARTED" (line 2621)

**L2: Section 0 line 17** -- "cross-sell campaigns" wording for paperworklabs.com HQ. Update to "intelligence campaigns"

**L3: Section 6D header count stale** -- "18" doesn't include EA + AI Ops Lead (both Active). Update header to "20+" or list them explicitly

**L4: KNOWLEDGE.md D42 agent count** -- Says "43 agents (24 Cursor + 19 n8n)" but master plan says 44 (20 n8n after Partnership Intelligence #34 added). Update D42

**L5: Section numbering gap** -- Jumps 11 -> 14 (Sections 12-13 don't exist). Add note: "Sections 12-13 reserved for future use" or renumber

**L6: Event taxonomy (4C) missing credit score events** -- Add placeholder: `credit_score_requested`, `credit_score_received`, `credit_score_opt_in`, `credit_score_changed`

**L7: Data model (4B) missing credit score fields** -- Add to `user_financial_profile`: `credit_score, credit_score_date, credit_score_provider, credit_score_band`

**L8: Risk assessment timing implicit** -- Section 0I line 693: add "before processing begins" to make timing explicit

---

## Files to Edit

- [docs/VENTURE_MASTER_PLAN.md](docs/VENTURE_MASTER_PLAN.md) -- 17 edits (H2, H3, H4, M1-M7, L1-L3, L5-L8)
- [docs/FINANCIALS.md](docs/FINANCIALS.md) -- 1 edit (H1)
- [docs/KNOWLEDGE.md](docs/KNOWLEDGE.md) -- 1 edit (L4)

