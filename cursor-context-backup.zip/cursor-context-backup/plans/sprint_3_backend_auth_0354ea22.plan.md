---
name: Sprint 3 Backend Auth
overview: Implement Task 2.1 (Backend Auth System) -- Redis sessions, register/login/logout/me/delete-account endpoints with CSRF protection, rate limiting, and full test coverage. This is the foundation for all remaining Sprint 3 work.
todos:
  - id: redis-client
    content: Create api/app/redis.py with async Redis pool and get_redis() dependency
    status: completed
  - id: user-repo
    content: Create api/app/repositories/user.py extending BaseRepository with get_by_email and delete_cascade
    status: completed
  - id: auth-schemas
    content: Create api/app/schemas/auth.py with RegisterRequest, LoginRequest, CSRFTokenResponse
    status: completed
  - id: auth-service
    content: Create api/app/services/auth_service.py with register, login, logout, get_current_user, delete_account, CSRF
    status: completed
  - id: auth-deps
    content: Create api/app/dependencies.py with get_current_user and require_csrf FastAPI dependencies
    status: completed
  - id: auth-router
    content: Implement api/app/routers/auth.py with all 5 endpoints, cookies, rate limiting
    status: completed
  - id: auth-tests
    content: Write api/tests/test_auth.py with full coverage (register, login, me, logout, delete, CSRF, rate limiting)
    status: completed
  - id: auth-integration
    content: Update main.py lifespan for Redis, verify all tests pass, update TASKS.md
    status: completed
isProject: false
---

# Sprint 3: Backend Auth System (Task 2.1)

## What Already Exists

- **User model** (`[api/app/models/user.py](api/app/models/user.py)`): `email`, `password_hash`, `full_name_encrypted`, `referral_code`, `auth_provider`, `email_verified`, cascade deletes
- **Security utils** (`[api/app/utils/security.py](api/app/utils/security.py)`): `hash_password`, `verify_password`, `generate_session_token`
- **Encryption** (`[api/app/utils/encryption.py](api/app/utils/encryption.py)`): AES-256 `encrypt`/`decrypt` for PII fields
- **Base repository** (`[api/app/repositories/base.py](api/app/repositories/base.py)`): CRUD base class
- **User schema** (`[api/app/schemas/user.py](api/app/schemas/user.py)`): `UserResponse` Pydantic model
- **Auth router stub** (`[api/app/routers/auth.py](api/app/routers/auth.py)`): empty `APIRouter(prefix="/auth")`
- **Config** (`[api/app/config.py](api/app/config.py)`): `REDIS_URL`, `SECRET_KEY` configured but unused
- **Redis** in `requirements.txt` (`redis>=5.2.0`) but no client initialized

## Architecture

```mermaid
sequenceDiagram
    participant Client
    participant FastAPI
    participant Redis
    participant PostgreSQL

    Client->>FastAPI: POST /auth/register
    FastAPI->>PostgreSQL: Create user
    FastAPI->>Redis: SET session:token user_id TTL 7d
    FastAPI->>Client: Set-Cookie (httponly, secure, samesite=lax)

    Client->>FastAPI: GET /auth/me (cookie)
    FastAPI->>Redis: GET session:token
    Redis-->>FastAPI: user_id
    FastAPI->>PostgreSQL: Get user by ID
    FastAPI-->>Client: UserResponse

    Client->>FastAPI: POST /auth/logout
    FastAPI->>Redis: DEL session:token
    FastAPI->>Client: Clear cookie
```



## Implementation

### 1. Redis client (`api/app/redis.py`)

- `get_redis()` async dependency yielding an `aioredis` connection from `settings.REDIS_URL`
- Lifespan hook to close pool on shutdown

### 2. User repository (`api/app/repositories/user.py`)

Extends `BaseRepository[User]`:

- `get_by_email(email: str) -> User | None`
- `get_by_id(id: UUID) -> User | None`
- `delete_cascade(user: User)` -- deletes filings, documents, tax profiles, etc.

### 3. Auth schemas (`api/app/schemas/auth.py`)

```python
class RegisterRequest(BaseModel):
    email: EmailStr
    password: str  # min 8, at least 1 number + 1 uppercase
    full_name: str

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class CSRFTokenResponse(BaseModel):
    csrf_token: str
```

### 4. Auth service (`api/app/services/auth_service.py`)

- `register(db, redis, data) -> User` -- hash password, encrypt full_name, generate referral_code, create user, create session
- `login(db, redis, email, password) -> User` -- verify credentials, create session
- `logout(redis, token)` -- delete session from Redis
- `get_current_user(db, redis, token) -> User` -- lookup session, get user
- `delete_account(db, redis, user) -> None` -- cascade delete all user data (CCPA), delete session
- `generate_csrf_token(redis, session_token) -> str` -- create and store CSRF token
- `validate_csrf_token(redis, session_token, token) -> bool`

Session key format: `session:{token}` -> `user_id`, TTL 7 days.
CSRF key format: `csrf:{session_token}` -> `csrf_token`, TTL 7 days.

### 5. Auth dependency (`api/app/dependencies.py`)

- `get_current_user` -- FastAPI dependency that reads cookie, validates session via Redis, returns `User` or raises 401
- `require_csrf` -- FastAPI dependency that validates CSRF header on state-changing requests

### 6. Auth router (`api/app/routers/auth.py`)


| Method | Path             | Auth | CSRF | Rate Limit | Description                |
| ------ | ---------------- | ---- | ---- | ---------- | -------------------------- |
| POST   | `/auth/register` | No   | No   | 5/min      | Create account, set cookie |
| POST   | `/auth/login`    | No   | No   | 5/min      | Verify creds, set cookie   |
| POST   | `/auth/logout`   | Yes  | Yes  | --         | Clear session + cookie     |
| GET    | `/auth/me`       | Yes  | No   | --         | Return current user        |
| DELETE | `/auth/account`  | Yes  | Yes  | --         | Delete all data (CCPA)     |


Cookie settings: `httponly=True, secure=True (prod), samesite="lax", max_age=604800, path="/"`.
Response includes CSRF token on register/login for the frontend to store and send on mutations.

### 7. Tests (`api/tests/test_auth.py`)

- Register: success, duplicate email (409), invalid email, weak password
- Login: success, wrong password (401), nonexistent email (401)
- Get /me: success, no cookie (401), expired session (401)
- Logout: success, clears session from Redis
- Delete account: cascades all data, session cleared
- CSRF: valid token passes, missing/wrong token returns 403
- Rate limiting: 6th request in 1 minute returns 429

### 8. Integration updates

- `[api/app/main.py](api/app/main.py)`: Add Redis pool to lifespan, import updated auth router
- Alembic migration if User model needs any field additions (likely none -- model is complete)

