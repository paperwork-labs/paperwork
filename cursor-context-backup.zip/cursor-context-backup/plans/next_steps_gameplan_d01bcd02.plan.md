---
name: Next Steps Gameplan
overview: Ship the config/credential PR, fix the ops dashboard n8n key, update KNOWLEDGE.md with the config system decision, and lay out the engineering roadmap from Sprint 4 (State Tax + PDF) through the North Star (MeF transmitter, January 2027).
todos:
  - id: fix-env-local
    content: Copy n8n API key from .cursor/mcp.json into web/.env.local so ops dashboard shows live workflow data
    status: completed
  - id: commit-pr
    content: Create branch feat/config-credential-safety, commit all changes, push, create PR, request Copilot review
    status: completed
  - id: update-knowledge
    content: Add D34 to KNOWLEDGE.md documenting the config system, credential registry, and gitleaks
    status: completed
  - id: update-tasks
    content: "Update TASKS.md: expand Task 3.4 to all 50 states via JSON engine, add config system task as done, update dates"
    status: completed
isProject: false
---

# Next Steps Gameplan

## Immediate (Today)

### 1. Fix the ops dashboard "Setup needed" issue

The `N8N_API_KEY` in [web/.env.local](web/.env.local) is empty. Copy the actual key (the one from [.cursor/mcp.json](.cursor/mcp.json)) into it:

```
N8N_API_KEY=eyJhbG...the-jwt-token...
```

Restart the dev server. The ops dashboard will then hit n8n's API, get back the 6 workflows, and match them against the agent roster -- showing "Inactive" instead of "Setup needed."

### 2. Commit, push, create PR

All config/credential safety changes are ready:

- 7 new files, 9 modified files
- TypeScript type check clean, 38/38 tests pass
- No secrets in tracked files

Branch: `feat/config-credential-safety`, PR against `main`. Request Copilot review per standard workflow.

### 3. Update KNOWLEDGE.md

Add decision D34 documenting the config system, credential registry, and gitleaks addition.

---

## Sprint 4: State Tax + PDF + Polish (Next Sprint)

This is where TASKS.md picks up. Sprint 3 is complete (7/7). The next engineering work is:

### Task 3.1 -- Production Polish (landing page redesign, trust section)

Already scoped in [TASKS.md](docs/TASKS.md) line 785.

### Task 3.4 -- State Tax Calculation (the "all 50 states" question)

Currently scoped for top 5 states (CA, NY, IL, PA, OH). Here's the path to all 50:

**The 50-state breakdown:**

- **9 states have NO income tax**: AK, FL, NV, NH (dividends/interest only), SD, TN (dividends/interest only through 2020, now fully none), TX, WA, WY -- auto-detect and skip
- **9 states have FLAT tax**: CO, IL, IN, KY, MA, MI, NC, PA, UT -- single bracket, trivial to implement
- **~32 states have GRADUATED brackets**: similar to federal, just different rates/thresholds

**Strategy: data-driven, not code-driven.**

Instead of hardcoding 50 separate modules, build a single state tax engine that reads from `tax-data/states/{state}.json`. Each JSON file contains:

- brackets (or flat rate)
- standard deduction (or none)
- personal exemption amounts
- special rules (SALT cap interaction, reciprocity agreements)

This means adding a state is adding a JSON file, not writing code. AI can generate and validate these JSON files against state DOR publications.

**Implementation order:**

1. No-income-tax states (9) -- just detection, zero code
2. Flat-tax states (9) -- one engine, 9 JSON files
3. Top 10 graduated states by population (CA, NY, NJ, VA, GA, OH, NC already covered by flat, MA already covered, so: CA, NY, NJ, VA, GA, OH, MN, WI, MD, OR)
4. Remaining ~14 graduated states

**Timeline:** Task 3.4 can realistically cover all 50 states in one sprint if we use the JSON-driven approach. The engine is the same -- only the data files differ.

### Task 2.5 -- Tax Return Summary + PDF (already done for display, needs PDF generation)

The `@react-pdf/renderer` generates the downloadable 1040 PDF.

### Task 3.3 -- Column Tax SDK Integration (interim e-file)

Depends on Founder 2 securing sandbox access (Task B.9).

---

## Engineering Roadmap to North Star

```mermaid
gantt
    title FileFree Roadmap to Free E-File
    dateFormat YYYY-MM
    axisFormat %b %Y

    section Sprint_4
    State tax engine + 50 states    :s4a, 2026-03, 2026-04
    PDF generation (1040)           :s4b, 2026-03, 2026-04
    Production polish               :s4c, 2026-03, 2026-04

    section Sprint_5
    Column Tax SDK integration      :s5a, 2026-06, 2026-08
    E-file go-live (extensions)     :s5b, 2026-10, 2026-10

    section Sprint_6
    MeF XML generator               :s6a, 2026-08, 2026-10
    IRS ATS testing (12 scenarios)  :s6b, 2026-10, 2026-11
    Communication test              :s6c, 2026-11, 2026-12
    Own transmitter LIVE            :milestone, m1, 2027-01, 0d

    section Business
    EFIN application                :b1, 2026-03, 2026-04
    Column Tax demo call            :b2, 2026-04, 2026-06
    Affiliate applications          :b3, 2026-03, 2026-04
    Direct partnerships (5K users)  :b4, 2026-10, 2027-01
```



## How n8n Agents Will Work (End State)

Once credentials are configured in the n8n UI (OpenAI, Notion, GitHub, Postiz):

1. **Social Content Generator** (daily) -- OpenAI generates platform-specific posts (TikTok script, IG caption, X tweet) using the growth persona, saves drafts to Notion Content Calendar, optionally pushes to Postiz for scheduling
2. **Growth Content Writer** (3x/week) -- generates SEO blog drafts, tax guides, newsletter content to Notion
3. **Weekly Strategy Check-in** (Monday 9am) -- analyzes PostHog metrics, reviews week's progress, writes strategy summary to Notion Decision Log
4. **QA Security Scan** (daily 2am) -- scans for PII leaks, checks endpoint security, creates GitHub Issues for findings
5. **Partnership Outreach Drafter** (Tuesday) -- drafts partner outreach emails based on pipeline status in Notion
6. **CPA Tax Review** (Thursday) -- reviews tax calculation edge cases, writes accuracy notes to Notion

**To activate:**

1. Go to n8n.filefree.tax
2. Create credentials: OpenAI API Key, Notion API Key, GitHub PAT, Postiz API Key
3. Open each workflow, assign credentials to the relevant nodes
4. Activate each workflow (toggle to "Active")
5. Workflows will fire on their cron schedules automatically

---

## What Should Be Updated in TASKS.md

- Task 3.4 (State Tax) should be expanded from "top 5 states" to "all 50 states via JSON-driven engine"
- Add a new task for the credential/config system (what we just built) -- mark as DONE
- Update critical dates to reflect current progress (Sprint 3 done ahead of schedule)
- Add EFIN application to critical path with actual deadline tracking

