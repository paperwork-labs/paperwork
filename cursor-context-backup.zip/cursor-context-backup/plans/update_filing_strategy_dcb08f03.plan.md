---
name: Update Filing Strategy
overview: Update PRD.md and VENTURE_MASTER_PLAN.md to replace the factually incorrect "Submit LLC Reality Check" section with an accurate competitive analysis and a production-grade "State Filing Engine" architecture that enables LaunchFree to actually file for users across all 50 states.
todos:
  - id: update-prd-filing
    content: Replace PRD Section 3.4 'Submit LLC Reality Check' with 'State Filing Engine' section. Correct state counts. Add competitive filing analysis. Update honest UX language.
    status: pending
  - id: update-vmp-filing
    content: Replace VMP 'LaunchFree Submit LLC Reality Check' (lines 3675-3687) and update 'LaunchFree Free Framing' section. Add State Filing Engine architecture.
    status: pending
  - id: update-tasks-filing
    content: Add State Filing Engine build tasks to Phase 3 in TASKS.md with full specs (acceptance criteria, branches, files, dependencies).
    status: pending
isProject: false
---

# Update LaunchFree Filing Strategy in PRD and VMP

## What's Wrong Now

Both [docs/PRD.md](docs/PRD.md) (Section 3.4, lines 315-325) and [docs/VENTURE_MASTER_PLAN.md](docs/VENTURE_MASTER_PLAN.md) (lines 3675-3687) contain the same factually incorrect "Submit LLC Reality Check":

- Claims ~15-20 states have online filing portals -- **reality: ~48/50 states have online filing**
- Claims ~20-25 states are mail-only -- **reality: only ~2 states (Maine + possibly 1 other)**
- Claims "a submit button doesn't exist for 35+ states" -- **false, almost every state has one**
- Says LaunchFree "does NOT file for you" -- **but every competitor (LegalZoom, ZenBusiness, Northwest) DOES file for you at $0 service fee**

## What Changes

### 1. Replace "Submit LLC Reality Check" with "State Filing Engine" Architecture

The new section describes a tiered, production-grade submission system:

```
Tier 1: State APIs (where formal APIs exist)
  - Delaware ICIS PublicXMLService (confirmed -- requires DCIS ID, RA number, IP registration)
  - Any other states with third-party filing APIs (research ongoing)
  - Proper REST/SOAP integrations, not scraping

Tier 2: Structured Portal Automation (majority of states)
  - Playwright-based browser automation for ~45 state SOS portals
  - Per-state configuration: portal URL, form field mappings, fee handling, confirmation capture
  - RA/agent filing paths where available (more structured, more automatable)
  - Screenshot audit trail at every step
  - Health monitoring + alerting when portal changes break automation
  - State-specific rate limiting to avoid anti-bot detection

Tier 3: Print-and-Mail (2-3 mail-only states)
  - Generate completed PDF + cover letter
  - Automated mailing via Lob API or similar print-and-mail service
  - Tracking number provided to user
```

### 2. Update Competitive Analysis

Add how LegalZoom/ZenBusiness actually submit:
- Manual staff entry into state portals (primary method)
- State API integrations where available
- Mail for paper-only states
- They absorb filing infrastructure cost; revenue from RA ($199-249/yr), compliance upsells, and referral commissions

### 3. Update "Honest UX" Language

**Old:** LaunchFree "prepares your LLC filing" -- it does NOT "file for you"
**New:** LaunchFree files your LLC with the state on your behalf. You provide information, we handle submission. State filing fees paid upfront via Stripe, we remit to the state during portal submission.

### 4. Add State Filing Engine Architecture Section

New subsection in PRD under LaunchFree describing:

```
User provides info -> LaunchFree validates ->
  State Filing Engine routes to:
    Tier 1 (API) | Tier 2 (Portal Automation) | Tier 3 (Mail)
  -> Submission confirmation + filing number returned to user
  -> Status tracking: pending -> submitting -> submitted -> approved/rejected
```

**Key architectural components:**
- `apis/launchfree/services/filing_engine/` -- orchestrator
- `apis/launchfree/services/filing_engine/states/` -- per-state configs (JSON: portal URL, field mappings, fee schedule, filing method tier)
- `apis/launchfree/services/filing_engine/automation/` -- Playwright scripts
- `apis/launchfree/services/filing_engine/api_integrations/` -- state API clients (Delaware ICIS, etc.)
- Celery task queue for async submission processing
- State portal health monitor (daily automated checks)

**RA Filing Authority:** Being the Registered Agent in each state gives LaunchFree legitimate filing authority and access to RA-specific portal paths. This is how formation companies operate legally and at scale.

### 5. Update Cost Model

- State API integrations: $0/filing (just dev time upfront)
- Portal automation: $0/filing (compute cost only -- Playwright headless browser)
- Print-and-mail: ~$2-3/filing (Lob pricing)
- Blended cost: ~$0.05/filing average (heavily weighted toward portal automation)

Compare to formation API wholesale: $50-80/filing -- our approach is 1000x cheaper at scale.

### 6. Rollout Strategy (Add to Phase 3 in TASKS.md)

- **MVP (Phase 3):** Top 10 states by formation volume (CA, TX, FL, DE, WY, NY, NV, IL, GA, WA) via portal automation + Delaware API. Manual fallback for remaining 40 states.
- **Scale (Phase 3.5):** Expand to 30 states. Apply for state API access where available.
- **Full Coverage (Phase 5):** All 50 states automated. Print-and-mail for 2-3 holdouts.

## Files to Edit

1. **[docs/PRD.md](docs/PRD.md)** -- Replace Section 3.4 "Submit LLC Reality Check" (lines 315-325) with "State Filing Engine" section. Update Section 3.2 line 285 ("LLC formation filing (prep + submit)" -> "LLC formation filing (prep + state submission)"). Add competitive filing analysis.

2. **[docs/VENTURE_MASTER_PLAN.md](docs/VENTURE_MASTER_PLAN.md)** -- Replace "LaunchFree Submit LLC Reality Check" (lines 3675-3687). Update "LaunchFree Free Framing" section (line 874). Add State Filing Engine architecture details.

3. **[docs/TASKS.md](docs/TASKS.md)** -- Add State Filing Engine tasks to Phase 3 (LaunchFree MVP) with acceptance criteria, branch names, and file specs.
