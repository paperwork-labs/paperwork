---
name: Fix market-data 500 errors
overview: Diagnose and fix 500 Internal Server Error on `/api/v1/market-data/dashboard` and `/api/v1/market-data/snapshots` by capturing the real exception, then addressing the most likely causes (Redis, DB schema, or query logic).
todos: []
isProject: false
---

# Fix market-data dashboard and snapshots 500 errors

## Context

- **Failing endpoints**: `GET /api/v1/market-data/dashboard` and `GET /api/v1/market-data/snapshots?limit=5000`.
- **Working**: `/portfolio/live` (200), `/market-data/volatility-dashboard` (200).
- Both failing endpoints use: [tracked_symbols](backend/services/market/universe.py) (which uses Redis then DB), [MarketDataService](backend/services/market/market_data_service.py) (which requires `REDIS_URL` for `redis_client`), and queries against `MarketSnapshot` / `MarketSnapshotHistory`.

## Step 1: Capture the actual exception

The 500 response body and backend logs contain the real error; the frontend only shows "Response Error: Object".

- **Option A**: From repo root run `make logs` (or `docker logs axiomfolio-backend --tail 100`) and reproduce the 500 by loading the page that calls dashboard + snapshots. Look for `market dashboard error:` or a traceback right after a GET to `/api/v1/market-data/dashboard` or `/api/v1/market-data/snapshots`.
- **Option B**: In dev, ensure the 500 response body is returned to the client. The dashboard handler already does `raise HTTPException(status_code=500, detail=str(e))` in [market_data.py](backend/api/routes/market_data.py) (lines 1100–1101); the snapshots endpoint has **no try/except**, so any exception there becomes a 500 with no `detail`. Add a try/except around the snapshots handler and `raise HTTPException(status_code=500, detail=str(e))` (and `logger.exception(...)`) so both endpoints return and log the same way.

Recommendation: do **Option B** (add try/except + logging to snapshots and use `logger.exception` in both handlers so logs include tracebacks), then reproduce and read either the response body or logs.

## Step 2: Likely root causes and fixes

### 2a. Redis required for tracked_symbols

- [tracked_symbols(db, redis_client=svc.redis_client)](backend/api/routes/market_data.py) is called by both dashboard and snapshots. [MarketDataService.redis_client](backend/services/market/market_data_service.py) (lines 113–119) raises `RuntimeError("REDIS_URL is not configured")` if `REDIS_URL` is missing. So if Redis is not set or connection fails, both endpoints can 500.
- [tracked_symbols_with_source](backend/services/market/universe.py) (lines 46–61) calls `redis_client.get("tracked:all")` without checking for `redis_client is None`. If callers ever passed `None` (they don’t today because the property raises), or if we want to tolerate Redis being down, we’d need to handle `None` and fall back to DB.
- **Fix**: Prefer making the dashboard and snapshots paths resilient to Redis being unavailable:
  - In [MarketDataService](backend/services/market/market_data_service.py), make `redis_client` return `None` when `REDIS_URL` is missing (or on connection failure) instead of raising, **or**
  - In [universe.py](backend/services/market/universe.py), have `tracked_symbols_with_source` accept `redis_client=None` and skip the Redis branch when `redis_client is None`, falling back to `tracked_symbols_from_db(db)`.
- Only one of the two approaches is needed; the second (universe tolerating `None`) is localized and avoids changing every `MarketDataService` caller.

### 2b. Database schema / migrations

- If tables `market_snapshot` or `market_snapshot_history` are missing or out of date, the queries in [market_dashboard_service._fetch_rows](backend/services/market/market_dashboard_service.py) and in [get_snapshots](backend/api/routes/market_data.py) will raise (e.g. relation does not exist or column missing).
- **Check**: Run migrations: `docker compose exec backend alembic upgrade head` (from repo root with dev stack up). Confirm no failed migrations.
- **Fix**: Resolve any migration conflicts or missing steps; ensure schema matches [MarketSnapshot](backend/models/market_data.py) and [MarketSnapshotHistory](backend/models/market_data.py).

### 2c. DISTINCT ON usage (PostgreSQL)

- Dashboard: [market_dashboard_service._fetch_rows](backend/services/market/market_dashboard_service.py) uses `.distinct(MarketSnapshotHistory.symbol)` with `.order_by(MarketSnapshotHistory.symbol.asc(), MarketSnapshotHistory.as_of_date.desc())`.
- Snapshots: [get_snapshots](backend/api/routes/market_data.py) uses `base_query.distinct(MarketSnapshot.symbol).limit(limit).all()` when dialect is PostgreSQL.
- In SQLAlchemy 2.x, legacy `Query.distinct(column)` for PostgreSQL DISTINCT ON can behave differently. If the captured exception points to invalid SQL or "DISTINCT ON expression must match initial ORDER BY", then either:
  - Adjust `order_by` so the leading columns match the distinct expression, or
  - Remove `.distinct(...)` and use Python-side dedupe only (like the non-Postgres branch in get_snapshots and the existing loop in _fetch_rows for MarketSnapshot) so both code paths are consistent and avoid dialect-specific SQL.

## Step 3: Implement fixes (after Step 1 confirms cause)

- **If Redis**: Implement `tracked_symbols_with_source` accepting `redis_client=None` and falling back to `tracked_symbols_from_db(db)`. Ensure callers (dashboard service, market_data routes) pass `svc.redis_client` only when available (e.g. wrap Redis access in try/except and pass None on failure, or use the property that returns None when REDIS_URL is unset if you change it).
- **If DB**: Fix migrations and re-run; no code change in handlers beyond ensuring they don’t assume tables exist without migrations.
- **If DISTINCT ON**: Switch dashboard history query and/or snapshots query to Python-side “latest per symbol” dedupe and drop `.distinct(...)` for these two endpoints so behavior is consistent across environments.

## Summary

1. Add try/except and `logger.exception` (and 500 detail) to the **snapshots** handler; use `logger.exception` for the **dashboard** handler so logs have full tracebacks.
2. Reproduce the 500 and read the exception message (and traceback) from logs or response body.
3. Apply the fix that matches the exception: Redis resilience in universe (and optionally MarketDataService), migrations, or DISTINCT ON removal with Python dedupe.
4. Re-run the frontend flow and confirm both `/api/v1/market-data/dashboard` and `/api/v1/market-data/snapshots` return 200.
