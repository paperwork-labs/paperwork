---
name: Jointly iOS+Plaid+Git
overview: Initialize git at repo root and prep GitHub private repo workflow, rename Docker Compose project to 'jointly' to avoid collisions, commit a real iOS Xcode project in-repo (Simulator-ready), and harden Plaid for real institutions with stronger attribution + resync behaviors.
todos:
  - id: git-init-root
    content: Initialize git at /Users/sankalpsharma/development/jointly, verify .gitignore protects secrets, create first commit, and prepare GitHub private remote (origin) setup.
    status: completed
  - id: compose-project-name
    content: Set docker compose project name to 'jointly' (compose.yaml + Makefile) to avoid naming collisions with other stacks.
    status: completed
    dependencies:
      - git-init-root
  - id: ios-xcodeproj
    content: Create and commit `ios/Jointly/Jointly.xcodeproj` with bundle id `com.sankalpsharma.jointly`, add Assets.xcassets, and wire existing SwiftUI sources into the target.
    status: completed
    dependencies:
      - git-init-root
  - id: ios-api-config
    content: Make iOS API base URL configurable via Info.plist key (e.g. JOINTLY_API_BASE_URL) and use it from `ios/Jointly/APIConfig.swift`.
    status: completed
    dependencies:
      - ios-xcodeproj
  - id: ios-simulator-smoke
    content: "Document and verify Simulator smoke path: login → dashboard → inbox → transaction detail against local backend (1814)."
    status: completed
    dependencies:
      - ios-api-config
  - id: plaid-harden-sync
    content: "Harden Plaid sync jobs: relink-required handling, idempotency locks, cursor robustness, and item status surfaced to clients."
    status: completed
    dependencies:
      - git-init-root
  - id: attribution-improvements
    content: Strengthen attribution with account-owner signal + merchant history heuristic; improve confidence/rationale.
    status: completed
    dependencies:
      - plaid-harden-sync
  - id: web-connect-relink-ui
    content: Update /connect UI to display item status and provide relink CTA when backend marks relink-required.
    status: completed
    dependencies:
      - plaid-harden-sync
---

# Jointly: GitHub+DockerNaming + iOS-first-class + Plaid hardening

## Goals

- Make **`/Users/sankalpsharma/development/jointly/`** the **single git repo root** and prep it for a **private GitHub repo**.
- Rename Docker compose project naming to **`jointly`** so containers/networks/volumes don’t collide with other stacks.
- **A (iOS)**: Commit a real Xcode project (not a nested repo) so `git clone` → open Xcode → Run in Simulator works. Bundle id: **`com.sankalpsharma.jointly`**.
- **B (Plaid)**: Real-institution readiness: better Link UX, robust sync/relink handling, and stronger attribution defaults.

## Constraints / safety

- Use terminal freely but cautiously: **never commit secrets**.
- Keep domain references out of repo for now (you haven’t bought a domain).

## Step 0) Git initialization at repo root + GitHub private

- Initialize git **in repo root**: `/Users/sankalpsharma/development/jointly/`.
- Verify `.gitignore` covers local secrets:
- `infra/env.dev`
- `backend/.env`
- `web/.env.local`
- Create **first commit** with everything else.
- GitHub workflow (private):
- **Assumptions** (confirmed): repo name `jointly`, branch `main`, prefer SSH remote.
- Practical approach:
    - Prepare repo locally.
    - You create the private repo in GitHub UI (or we use `gh` if already authenticated).
    - Then set `origin` and push.

## Step 1) Docker Compose naming: project = `jointly`

- Update [`infra/compose.yaml`](infra/compose.yaml) to include **`name: jointly`** (Compose v2) so names become `jointly-web-1`, etc.
- Update [`Makefile`](Makefile) targets (`up`, `down`, `ps`) to ensure the project name is always `jointly` (either via `--project-name jointly` or `COMPOSE_PROJECT_NAME=jointly`).

## A) Make iOS first-class (commit Xcode project)

- Create an actual Xcode project under `ios/Jointly/`:
- Add `ios/Jointly/Jointly.xcodeproj` (or `.xcworkspace` if we later adopt SwiftPM deps).
- Configure:
    - **Bundle Identifier**: `com.sankalpsharma.jointly`
    - **Display Name**: Jointly
    - Assets: minimal `Assets.xcassets` with placeholder AppIcon.
- Attach existing SwiftUI sources into the Xcode target:
- `ios/Jointly/APIConfig.swift`, `APIClient.swift`, `SessionStore.swift`, `JointlyApp.swift`, views, models.
- Make API base URL configurable without code edits:
- Add Info.plist key like `JOINTLY_API_BASE_URL`, read it in `APIConfig.swift`.
- Simulator smoke:
- Login → Dashboard → Inbox → Transaction detail

## B) Plaid real-institution hardening (backend-first)

- Harden sync path in [`backend/app/plaid/jobs.py`](backend/app/plaid/jobs.py):
- Handle `ITEM_LOGIN_REQUIRED`/`ITEM_LOCKED` → mark item status and surface “relink required”.
- Add idempotency lock per item sync (Redis) to prevent overlapping runs.
- Cursor robustness + removed transaction handling stays correct.
- Attribution improvements:
- Use `accounts.owner_user_id` (already patchable via `/accounts`) as a strong signal.
- Add merchant history heuristic (per household) to boost confidence.
- Web `/connect` improvements:
- Show item status and display a **Relink** CTA when needed.

## Test plan (user journey)

- Web:
- Login → Invite partner → Connect institution → Assign account owners → confirm owner suggestions.
- iOS:
- Login with invited user → see shared household data → inbox review loop.
```mermaid
sequenceDiagram
  participant Web
  participant iOS
  participant API as FastAPI
  participant Plaid
  participant DB as Postgres

  Web->>API: POST /household/invites
  iOS->>API: POST /auth/magic-link/verify
  API->>DB: attachMembership_viaInvite

  Web->>API: POST /plaid/link-token
  API->>Plaid: link_token_create
  Web->>Plaid: PlaidLink(onSuccess public_token)
  Web->>API: POST /plaid/exchange
  API->>DB: upsertItems_andAccounts

  API->>Plaid: transactions_sync(worker)
  API->>DB: upsertTransactions
  iOS->>API: GET /transactions?status=new
  Web->>API: GET /transactions?status=new



```