---
name: Name Auth Trinkets Deep Dive
overview: "Deep analysis of three decisions: parent company naming (paperwork.llc evaluation), authentication architecture (admin SSO + user auth strategy), and trinkets domain strategy (subdomain vs individual SEO domains)."
todos:
  - id: verify-paperwork-ca
    content: Verify 'Paperwork Labs LLC' availability on CA Secretary of State (bizfileonline.sos.ca.gov), update Section 0B of master plan with decision, add paperworklabs.com domain + static site spec
    status: completed
  - id: update-auth-architecture
    content: Add admin auth spec (email allowlist for Sankalp + Olga, Google/Apple OAuth, packages/auth shared lib) to master plan Section 2 and Phase 4.2
    status: completed
  - id: update-trinkets-domain
    content: Update Section 0F/7C to add subdirectory-style paths on tools.filefree.ai and the graduation-to-standalone-domain criteria
    status: completed
  - id: sync-and-commit
    content: Sync VENTURE_MASTER_PLAN.md from plan file, update KNOWLEDGE.md with new decisions, commit and push
    status: completed
isProject: false
---

# Parent Company Name, Auth Architecture, and Trinkets Domain Strategy

---

## 1. Parent Company Name: paperwork.llc Evaluation

### The Good

- **"Paperwork"** is thematically perfect -- both FileFree and LaunchFree literally eliminate paperwork (tax forms, LLC filings). The name is a wink at the problem you solve.
- $10.35 is negligible cost.
- Short, memorable, easy to spell on contracts and bank forms.
- Abstract enough to hold future products beyond tax/formation.
- No confusion with product names (not "FileLaunch" or "FreeSoft").

### The Concerns

**Trademark landscape:**

- "PAPERWORKS" has an active USPTO application (Serial #98659864, filed July 2024) for paper stationery/printing goods (Class 016). Different class from ours (Class 036/042), so no direct conflict.
- **paperwork.to** is an active Document AI startup in Dubai (bank statement processing, KYC/KYB). Different market (UAE B2B fintech), different product, but there IS a company called "Paperwork" in the adjacent fintech/document-processing space. Low risk for a holding company that's never customer-facing, but worth noting.
- No "Paperwork LLC" or "Paperwork Labs" found in US tech/fintech.

**The .llc TLD itself:**

- Less than 0.1% of websites use .llc (w3techs.com data). Extremely niche TLD.
- Low consumer trust -- most people don't recognize .llc as a real domain extension.
- **BUT**: this doesn't matter for a holding company. The domain `paperwork.llc` would only appear on legal docs, privacy policies, and Terms of Service. Customers see `filefree.ai`, `launchfree.ai`, `sankalpsharma.com`. The parent domain is never customer-facing (confirmed in Section 0B of the master plan: "The LLC name appears only on legal docs, privacy policies, bank accounts, and tax returns. Never customer-facing.").

### Verdict: Paperwork Labs LLC + paperworklabs.com -- RECOMMENDED

**Why "Paperwork Labs" over plain "Paperwork":**

- A Canadian company called "Paperwork" (Paperwork Forms) exists making form management software for municipalities. Different market and country, but "Labs" adds clear differentiation.
- "Labs" is the standard convention in tech holding companies (Crisp Labs, Lantern Labs, etc.) -- signals "we build things."
- `paperworklabs.com` is available -- a .com is far more credible than `.llc` (<0.1% of sites use .llc TLD), especially since the founder wants a clean static site on the holding company domain.

The name passes all six naming criteria from the master plan:

1. Abstract/brandable -- yes, thematically relevant without being confusing
2. Not confusable with product names -- correct, "Paperwork Labs" is distinct from "FileFree" and "LaunchFree"
3. Short -- two words, easy to spell on contracts and bank forms
4. Available in California -- needs verification on bizfileonline.sos.ca.gov (todo)
5. Domain available -- `paperworklabs.com` available, clean static site to showcase portfolio
6. Neutral enough for future products -- yes, any product that eliminates paperwork fits

**No Toast Inc. risk** (unlike the toast-themed names). No billion-dollar company with 28 trademarks to worry about. "Paperwork Labs" has zero existing US companies in tech/fintech.

**Compared to the other candidates:**

- Toastworks LLC -- Toast Inc. litigation risk (they sued Toast Labs, Inc.)
- Halftoast LLC -- Still in the Toast blast radius
- Crisp Labs LLC -- Clean, but "Crisp" is less thematically connected than "Paperwork"
- Paperwork LLC (plain) -- Good, but Canadian "Paperwork Forms" exists; "Labs" differentiates
- **Paperwork Labs LLC** -- Strongest thematic fit, zero trademark risk, .com available, professional static site

### Static Site: paperworklabs.com

Clean, minimal holding company page. Not a product site -- a portfolio page.

- **Content**: Company name, one-liner ("We build tools that eliminate paperwork"), portfolio cards for FileFree / LaunchFree / Trinkets, legal footer
- **Tech**: Static HTML/CSS on Vercel free tier (or a single Next.js SSG page in `apps/studio/` with a custom domain)
- **Design**: Match the Studio/Command Center zinc palette (neutral, professional)
- **Legal footer**: "Paperwork Labs LLC | California | FileFree, LaunchFree, and Trinkets are products of Paperwork Labs LLC"
- **Cost**: $0/yr hosting (Vercel free), ~$12/yr domain renewal

### Action Items

- Verify "Paperwork Labs LLC" availability on CA Secretary of State (bizfileonline.sos.ca.gov)
- Register `paperworklabs.com` domain
- File as "Paperwork Labs LLC" in California
- DBA filings: "FileFree", "LaunchFree", "Trinkets"

---

## 2. Authentication Architecture

The master plan already defines the federated identity pattern (Section 2, lines 894-921 of the plan file). Here's the concrete implementation with admin accounts baked in.

### Architecture

```mermaid
graph TD
    subgraph products [Product Apps]
        FF["FileFree (filefree.ai)"]
        LF["LaunchFree (launchfree.ai)"]
        TR["Trinkets (tools.filefree.ai)"]
        SC["Studio/HQ (sankalpsharma.com)"]
    end

    subgraph authLayer [packages/auth]
        AuthLib["Shared Auth Library"]
        AuthLib -->|"Google/Apple OAuth"| UserAuth["User SSO"]
        AuthLib -->|"Email allowlist check"| AdminAuth["Admin Gate"]
    end

    FF --> AuthLib
    LF --> AuthLib
    SC --> AuthLib
    TR -.->|"No auth required"| noAuth["Public (no login)"]

    subgraph ventureDB [Studio Database]
        VI["venture_identities"]
        AP["admin_principals"]
    end

    UserAuth --> VI
    AdminAuth --> AP
```



### User Auth (FileFree, LaunchFree)

- **Providers**: Google OAuth + Apple Sign-In (cover 95%+ of users). Optional email/password as fallback.
- **Implementation**: `packages/auth/` using NextAuth.js (Auth.js v5) shared across all Next.js apps.
- **SSO mechanism**: Shared cookie domain. Set `NEXTAUTH_URL` and cookie domain to `.filefree.ai` for FileFree and Trinkets (same parent domain). LaunchFree on `launchfree.ai` uses the venture identity link (event-based, as already specified in the plan).
- **Each product keeps its own user table** (the separable-by-design pattern already in the plan). The `venture_identity_id` nullable FK links them in Studio DB.

### Admin Auth (Studio/HQ + Admin panels on all products)

- **Simple, secure, no over-engineering**: Admin access is gated by an email allowlist in `packages/auth/`. Two emails: Sankalp's and Olga's.
- **How it works**: Same Google OAuth flow as users. After OAuth, middleware checks if the authenticated email is in the admin allowlist. If yes, admin routes are accessible. If no, 403.
- **No separate admin login page needed**. Same SSO, just an authorization check on top.
- **Admin routes**: `/admin/`* on Studio (sankalpsharma.com), `/admin/`* on FileFree, `/admin/`* on LaunchFree. All protected by the same `packages/auth/` middleware.
- **Olga gets access everywhere** -- she's in the allowlist, so she can log into any product's admin panel with her Google account.

### Trinkets Auth

- **No auth**. Trinkets are public utility tools. No login required.
- **Cross-sell CTAs** (e.g., "File your taxes for free with FileFree") link to FileFree where users sign up. Trinkets funnel traffic; they don't gate it.
- **If we ever want to save user preferences** (e.g., saved calculations), use localStorage or optionally add "Sign in with Google" later. Not for launch.

### Key Implementation Details

- `packages/auth/` exports: `AuthProvider`, `useSession`, `useAdmin`, `withAdminAuth` middleware
- Admin allowlist stored in environment variable: `ADMIN_EMAILS=sankalp@filefree.ai,olga@filefree.ai` (Google Workspace aliases, already configured)
- Cookie domain for SSO across subdomains: `.filefree.ai` (covers `filefree.ai` and `tools.filefree.ai`)
- LaunchFree on `launchfree.ai` cannot share cookies with `filefree.ai` (different domain). Cross-product linking happens via the venture identity system (email match in Studio DB).

---

## 3. Trinkets Domain Strategy: Subdomain vs. Individual Domains

### The SEO Data

Research confirms the hierarchy for SEO authority inheritance:

1. **Subdirectories** (`filefree.ai/tools/mortgage-calculator`) -- strongest authority inheritance, fastest indexing
2. **Subdomains** (`tools.filefree.ai/mortgage-calculator`) -- treated as semi-separate by Google, builds authority slower
3. **Separate domains** (`mortgagecalculator.com`) -- starts from zero, no authority transfer

### Analysis for Our Case

**Option A: `tools.filefree.ai` subdomain (current plan)**

- Pros: No domain costs, inherits some filefree.ai authority, single Vercel project, easy cross-sell, brand family cohesion
- Cons: Subdomains build authority slower than subdirectories. Google treats them as semi-independent sites.

**Option B: Individual SEO domains per trinket**

- Pros: Exact-match domains (e.g., `freemortgagecalculator.com`) used to be SEO gold
- Cons: Google has devalued exact-match domains significantly since 2012 (EMD update). A new domain starts at DA 0. Each domain needs separate hosting config, SSL, analytics. At $10-15/domain/year, costs add up. Managing 20+ domains is operational overhead. And the big one: **a brand-new domain with zero backlinks will NOT outrank established tools (NerdWallet, Bankrate, Calculator.net) for years, regardless of the domain name**.

**Option C: Subdirectories on filefree.ai (recommended upgrade)**

- Pros: Maximum authority inheritance from filefree.ai. Every trinket page strengthens the parent domain. Fastest indexing. Zero additional infra.
- Cons: Requires trinkets to be part of the FileFree Next.js app (or use Next.js rewrites). Slightly more coupled architecture.

### Recommendation: Hybrid -- Start with subdomain, graduate high-performers

Keep `tools.filefree.ai` as the home for ALL trinkets (the current plan). This is correct for Phase 1.5. Here's why individual domains are a trap:

- **Year 1 trinkets revenue is $50-300** (the plan's own conservative estimate). Spending $200+/year on 15+ domains for tools generating $50 total is negative ROI.
- **SEO takes 6-12 months** for a new domain to rank. By then, the trinkets on `tools.filefree.ai` will have had 6-12 months of filefree.ai's growing authority behind them.
- **The agent's job isn't to pick domains** -- it's to pick the RIGHT trinket ideas with low-competition keywords (KD < 30). A well-targeted trinket on a subdomain beats a generic trinket on an exact-match domain.

**Future graduation path**: If a specific trinket generates significant traffic (say 10K+ monthly visits), THEN consider buying a standalone domain and 301-redirecting from the subdomain. This is a growth optimization, not a launch decision.

**One tactical improvement**: Use subdirectory-style paths on the subdomain for maximum topical clustering:

- `tools.filefree.ai/calculators/mortgage`
- `tools.filefree.ai/calculators/compound-interest`
- `tools.filefree.ai/converters/pdf-to-word`

This groups related tools together, helping Google understand topical authority within the subdomain.

---

## Summary of Decisions

- **Parent company**: Register as "Paperwork Labs LLC" in California. Buy `paperworklabs.com`. Clean static portfolio site. DBA filings for FileFree, LaunchFree, Trinkets.
- **Auth**: Shared `packages/auth/` with Google + Apple OAuth. Admin access via email allowlist (`sankalp@filefree.ai`, `olga@filefree.ai`). No auth on Trinkets. Cookie-based SSO across `.filefree.ai` subdomains.
- **Trinkets domain**: Keep `tools.filefree.ai` subdomain (current plan). Do NOT buy individual domains per trinket. Agent optimizes for keyword selection, not domain names. Graduate high-performers to standalone domains only if traffic justifies it.

