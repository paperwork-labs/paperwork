---
name: Infra+CI+Tests+PRs
overview: Clean up infra layout, harden test isolation (never touch dev DB), standardize frontend/backend test architecture, and add beautiful GitHub CI + PR automation (Dependabot auto-merge, agent changes via PRs).
todos:
  - id: infra-cleanup
    content: "Audit and clean infra/root: consolidate Compose/env usage under `infra/`, remove or quarantine dangerous root scripts (e.g. `alembic_migration_options.py`), and document the canonical dev/test commands."
    status: completed
  - id: backend-test-safety
    content: "Harden backend test isolation: add additional fail-closed guards, ensure pytest cannot run against non-test DB, and standardize markers/suites."
    status: completed
    dependencies:
      - infra-cleanup
  - id: frontend-test-architecture
    content: Standardize frontend test structure (Vitest), add shared test utilities/setup, and ensure lint/typecheck/test commands are CI-ready.
    status: completed
  - id: github-actions-ci
    content: Add `.github/workflows/` for backend (compose) and frontend (node) checks, with caching and clear job naming; make it green-by-default.
    status: completed
    dependencies:
      - backend-test-safety
      - frontend-test-architecture
  - id: dependabot-automerge
    content: Add `.github/dependabot.yml` and a safe auto-merge workflow gated on required checks/labels for Dependabot PRs only.
    status: completed
    dependencies:
      - github-actions-ci
  - id: agent-pr-automation
    content: Add scripts + docs so agent changes always create a branch + PR automatically (using `gh`/GitHub API), never direct pushes to main.
    status: completed
    dependencies:
      - github-actions-ci
  - id: docs-onboarding
    content: Write `docs/ONBOARDING.md` and update root README + testing docs to reflect the new workflow and safety guarantees.
    status: completed
    dependencies:
      - github-actions-ci
      - agent-pr-automation
---

# QuantMatrix Infra/Test/CI

/PR Hardening Plan

## Goals

- **Infra cleanup**: make `infra/` the canonical place for Compose + env templates; eliminate confusing root-level leftovers.
- **Test architecture that cannot hit dev DB**: enforce isolation in Docker + add additional “fail closed” guards so the accidental table deletion you hit can’t recur.
- **Beautiful, reliable GitHub CI**: green-by-default PR checks, clear job naming, useful summaries.
- **PR automation**: Dependabot auto-merge stays; **agent changes always land via PR** (branch + PR created automatically).
- **Docs + onboarding**: update READMEs and add a single onboarding doc you can hand to any new agent.

## Current state (what we found)

- **Docker separation exists**:
- Dev stack: [`infra/compose.dev.yaml`](/Users/sankalpsharma/development/quantmatrix/infra/compose.dev.yaml)
- Test stack: [`infra/compose.test.yaml`](/Users/sankalpsharma/development/quantmatrix/infra/compose.test.yaml) (isolated `postgres_test`/`redis_test` + dedicated volume)
- Entrypoints: [`Makefile`](/Users/sankalpsharma/development/quantmatrix/Makefile) and [`run.sh`](/Users/sankalpsharma/development/quantmatrix/run.sh)
- **Backend DB-safety is strong already**:
- Pytest fixtures enforce **`TEST_DATABASE_URL` host == `postgres_test` and db name suffix `_test`** and require **`DATABASE_URL == TEST_DATABASE_URL`** inside tests.
- Runtime guard in [`backend/database.py`](/Users/sankalpsharma/development/quantmatrix/backend/database.py) refuses to create a session during pytest if it’s not pointed at the test DB.
- Shared validator: [`backend/utils/db_safety.py`](/Users/sankalpsharma/development/quantmatrix/backend/utils/db_safety.py)
- **GitHub CI config appears missing in-repo** (no `.github/` directory currently), so tests won’t run consistently on PRs.
- **There is a dangerous root script**: [`alembic_migration_options.py`](/Users/sankalpsharma/development/quantmatrix/alembic_migration_options.py) contains `drop_all_tables()` (`Base.metadata.drop_all(engine)`), which is the kind of thing that can wipe a real DB if misused.
- **Frontend tests exist (Vitest)** under `frontend/src/**/__tests__/*` and are configured in [`frontend/vite.config.ts`](/Users/sankalpsharma/development/quantmatrix/frontend/vite.config.ts).

## Decisions / defaults (based on your answers)

- **CI strategy**: default to **Docker Compose** for parity and DB isolation.
- **PR automation**:
- Keep **Dependabot auto-merge** after required checks.
- **Agent changes**: agent will commit to a branch, push, and open a PR on GitHub automatically (you selected this).

## Workstreams

### 1) Infra cleanup + “one true way” to run stacks

- Normalize around `infra/` as canonical:
- Ensure `infra/env.dev.example` and `infra/env.test.example` are the only committed templates.
- Ensure real `infra/env.dev` and `infra/env.test` remain untracked (keep current approach).
- Remove/relocate confusing root artifacts:
- **Quarantine or remove** [`alembic_migration_options.py`](/Users/sankalpsharma/development/quantmatrix/alembic_migration_options.py) (replace with safe, non-destructive tooling if needed).
- Investigate the stray root file [`=0.2.28`](/Users/sankalpsharma/development/quantmatrix/=0.2.28) (looks like pip output) and remove it from the repo.
- Make `Makefile` and `run.sh` the canonical UX:
- Add explicit targets for `lint`, `typecheck`, `frontend-test`, `backend-test`, and `ci`.

### 2) Backend test hardening (never touch dev DB)

Even though strong guards exist, we’ll make it effectively impossible to regress:

- Add a **hard fail-fast check** early in test collection to reject any DB URL whose host is not `postgres_test`.
- Ensure any helper scripts / services that create engines/sessions use the same guard when `QUANTMATRIX_TESTING=1`.
- Introduce a **two-tier test strategy**:
- **Unit tests**: no DB, no network; default run.
- **Integration tests**: DB, Docker dependencies; run in CI using compose.
- **Networked tests**: explicitly marked `integration` and gated behind env flags.

Key files leveraged/adjusted:

- [`backend/tests/conftest.py`](/Users/sankalpsharma/development/quantmatrix/backend/tests/conftest.py)
- [`backend/database.py`](/Users/sankalpsharma/development/quantmatrix/backend/database.py)
- [`backend/pytest.ini`](/Users/sankalpsharma/development/quantmatrix/backend/pytest.ini)

### 3) Frontend test architecture (clean + scalable)

- Standardize test layout:
- Keep colocated tests under `frontend/src/**/__tests__/` for components/pages.
- Keep “pure logic” tests under `frontend/src/utils/__tests__/`.
- Add/confirm `frontend/src/test/setup.ts` patterns for Chakra provider wrappers, router wrappers, MSW (if we add API mocking later).
- Add consistent scripts:
- `npm run test` (already)
- `npm run type-check` (already)
- `npm run lint` (already)

### 4) GitHub Actions CI (beautiful, reliable, green PRs)

Add `.github/` with:

- **Workflows**
- `ci.yml`:
    - Backend (compose-based): build images, run `make test` (or an explicit CI target).
    - Frontend: run `npm ci`, `npm run lint`, `npm run type-check`, `npm run test`.
    - Use caching for pip/uv and npm to keep CI fast.
- Optional `pr-title.yml`: enforce Conventional Commits (`feat:`, `fix:`, `chore:`, `docs:`).
- **PR hygiene**
- `.github/pull_request_template.md` with checklists (tests, docs, migrations, risk).
- `.github/ISSUE_TEMPLATE/*` for bugs/features.

### 5) Dependabot + auto-merge

- Add `.github/dependabot.yml` for `pip` + `npm` ecosystems.
- Add a workflow that auto-merges **Dependabot PRs** only when:
- author is `dependabot[bot]`
- all required checks pass
- label matches `dependencies`

### 6) Agent PR automation (your requested behavior)

Since you want “after fix/feature/cleanup, create PR automatically”, we’ll implement:

- A repo script like `scripts/open_pr.sh` (or `scripts/open_pr.py`) that:
- creates a branch `agent/<type>/<short-desc>-<date>`
- commits with a conventional message
- pushes
- opens a PR via `gh pr create` (or GitHub API)
- Document required secrets for the agent environment:
- A fine-grained PAT or GitHub App token with permissions: `contents:write`, `pull_requests:write`.

### 7) Documentation + onboarding

- Add **`docs/ONBOARDING.md`**:
- how to start dev stack, run tests safely, and where configs live
- “never touch dev DB from tests” policy + how it’s enforced
- how to create migrations
- how CI/PR automation works (Dependabot + agent PR)
- Update:
- root [`README.md`](/Users/sankalpsharma/development/quantmatrix/README.md) to point to onboarding as the entry point
- `docs/TESTS.md` / `docs/TEST_PLAN.md` to reflect CI reality and commands (`make test`, `make frontend-test`)

## Rollout order

- Infra cleanup + remove dangerous scripts first (reduces footguns).
- Add GitHub workflows and branch protection guidance.