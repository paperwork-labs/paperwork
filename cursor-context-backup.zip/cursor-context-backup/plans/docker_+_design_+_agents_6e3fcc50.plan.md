---
name: Docker + Design + Agents
overview: Get Docker dev environment running locally (migration included), create a design system preview route, set up n8n persona agent workflows via CLI import, and update TASKS.md with completed statuses.
todos:
  - id: test-isolation
    content: Add transactional test fixtures + separate test database to conftest.py so tests never touch dev data
    status: completed
  - id: docker-dev
    content: Run make dev, verify all 4 services healthy, run make migrate + make test
    status: completed
  - id: neon-migration
    content: Run Alembic migration on Neon via Render shell, verify health + waitlist e2e
    status: completed
  - id: design-page
    content: Create /design route with color palette, typography, all 22 shadcn components, animation demos
    status: completed
  - id: n8n-workflows
    content: Create 6 persona workflow JSONs in infra/hetzner/workflows/, import via SSH, add OpenAI credential
    status: completed
  - id: update-tasks
    content: Mark Tasks 0.2, 0.3, 0.4 as DONE in docs/TASKS.md
    status: completed
isProject: false
---

# Docker Dev, Design System Preview, and n8n Persona Agents

## 0. Test Isolation (before anything else)

The current `[api/tests/conftest.py](api/tests/conftest.py)` creates a `TestClient` pointing at the real app, which inherits the real `DATABASE_URL`. There is no transaction rollback and no separate test database. The existing 4 tests are pure unit tests (no DB writes), but any future test that touches the DB would mutate dev data.

Fix with two layers of protection:

**Layer 1 -- Separate test database**: Add a `filefree_test` database to Docker Compose (a second `initdb` script or `POSTGRES_MULTIPLE_DATABASES` pattern). The `conftest.py` overrides `DATABASE_URL` to point at `filefree_test` so tests never see dev data.

**Layer 2 -- Transactional rollback per test**: Each test that uses a DB session gets a fixture that:

1. Begins a transaction
2. Yields the session to the test
3. Rolls back after the test completes (no commit ever persists)

This is the SQLAlchemy async testing pattern:

```python
@pytest_asyncio.fixture
async def db_session():
    async with test_engine.connect() as conn:
        trans = await conn.begin()
        session = AsyncSession(bind=conn, expire_on_commit=False)
        yield session
        await trans.rollback()
```

**Layer 3 -- Auto-create/drop schema**: `conftest.py` runs `Base.metadata.create_all()` at session start and `drop_all()` at session end against the test DB, so migrations aren't even needed for tests.

Changes:

- `[infra/compose.dev.yaml](infra/compose.dev.yaml)`: Add `POSTGRES_MULTIPLE_DATABASES=filefree_dev,filefree_test` or an init script
- `[api/tests/conftest.py](api/tests/conftest.py)`: Override engine to test DB, add transactional session fixture, add `override_get_db` dependency injection, auto-create schema
- `[infra/env.dev.example](infra/env.dev.example)`: Add `TEST_DATABASE_URL`

---

## 1. Docker Dev Environment (make dev)

The Docker Compose setup already exists at `[infra/compose.dev.yaml](infra/compose.dev.yaml)` with Dockerfiles at `[api/Dockerfile](api/Dockerfile)` and `[web/Dockerfile.dev](web/Dockerfile.dev)`. The `env.dev.example` is at `[infra/env.dev.example](infra/env.dev.example)`.

Steps:

- Run `make setup` to copy `env.dev.example` to `env.dev` (if not already done)
- Generate a valid Fernet key and set it in `env.dev` for `ENCRYPTION_KEY`
- Run `make dev` to spin up postgres, redis, api, web
- Verify all 4 services are healthy
- Run `make migrate` to apply Alembic migration (creates all 7 tables locally)
- Run `make test` to verify all tests pass inside Docker
- Hit `http://localhost:8000/health` and `http://localhost:3000` to confirm

**Best practice going forward**: Always develop with Docker running. `make dev-d` for background, `make logs-api` to tail. Tests/lint/format all run through Docker (`make test`, `make lint`). Local-only variants (`test-local`, `lint-local`) exist for speed when needed.

## 2. Alembic Migration on Production (Neon)

The migration file exists at `[api/alembic/versions/001_initial_schema.py](api/alembic/versions/001_initial_schema.py)` but has never run against Neon.

Steps:

- Use Render MCP to open a shell on the `filefree-api` service
- Run `alembic upgrade head` to create all tables in Neon
- Verify via the `/health` endpoint (deep check includes DB connectivity)
- Verify waitlist endpoint works end-to-end: `curl -X POST https://api.filefree.tax/api/v1/waitlist`

## 3. Design System Preview Page (`/design` route)

Create a dev-only route at `web/src/app/design/page.tsx` that showcases the full design system. This is the cleanest approach: zero additional dependencies, works with Next.js App Router natively, and can be excluded from production builds.

The page will render:

- **Color palette**: All HSL tokens from `[globals.css](web/src/app/globals.css)` (primary, secondary, muted, accent, destructive, chart-1..5) rendered as swatches with labels, in both light and dark variants
- **Typography**: Inter (sans) at all weights (400/500/600/700), JetBrains Mono (mono) at all weights, with heading/body/caption examples
- **Spacing scale**: Visual spacing reference using Tailwind's standard scale
- **All 22 shadcn components**: Rendered with common variants (e.g., Button: default, secondary, destructive, outline, ghost, link; Badge: default, secondary, destructive, outline; Input with label; Card with content; etc.)
- **Animation presets**: Live demos of fadeIn, slideInUp, slideInRight, scaleIn, staggerContainer from `[motion.ts](web/src/lib/motion.ts)`

Protection: The page will check `process.env.NODE_ENV !== 'production'` and return `notFound()` in production. No middleware needed.

Accessible at: `http://localhost:3000/design`

## 4. n8n Persona Agent Workflows

The n8n instance at `https://n8n.filefree.tax` is live. The CLI supports `import:workflow` which means I can create workflow JSON files and import them via SSH -- no manual API key generation needed.

### Workflow architecture

Each persona agent workflow follows this pattern:

```
Trigger (Cron or Webhook)
  -> Set persona system prompt (from .mdc content)
  -> OpenAI Chat node (GPT-4o-mini for drafts, GPT-4o for quality)
  -> Output (Webhook response / Notion / Email)
```

### Workflows to create

Create workflow JSON files in `infra/hetzner/workflows/` and import via SSH:


| Workflow                     | Persona          | Trigger             | Output                                     |
| ---------------------------- | ---------------- | ------------------- | ------------------------------------------ |
| Social Content Generator     | social.mdc       | Webhook (on-demand) | Returns drafted posts for all 4 platforms  |
| Growth Content Writer        | growth.mdc       | Webhook (on-demand) | Returns SEO blog post drafts, landing copy |
| Weekly Strategy Check-in     | strategy.mdc     | Cron (Monday 9am)   | Sends summary to Notion                    |
| QA Security Scan Trigger     | qa.mdc           | Webhook (on-demand) | Returns security audit findings            |
| Partnership Outreach Drafter | partnerships.mdc | Webhook (on-demand) | Returns customized outreach emails         |
| CPA Tax Review               | cpa.mdc          | Webhook (on-demand) | Returns accuracy review of tax content     |


Each workflow:

- Has a meaningful name and description
- Includes the full persona system prompt as context
- Uses a webhook trigger so it can be called from Cursor or programmatically
- Returns structured JSON output
- Is importable via `n8n import:workflow --input=/path/to/workflow.json`

**One manual step required**: You need to add your OpenAI API key to n8n. I can SSH in and set it as an environment variable or credential, but I'll confirm the approach.

## 5. Update TASKS.md

Mark the following as DONE in `[docs/TASKS.md](docs/TASKS.md)`:

- Task 0.2 (Frontend Design System) -> DONE
- Task 0.3 (Backend Init + Database) -> DONE
- Task 0.4 (Landing Page + Waitlist + Deploy) -> DONE (once migration runs and waitlist works e2e)
- Task B.6 Hetzner portion -> already marked PARTIAL, update to reflect all services running

Also add a note that Docker is the standard dev workflow going forward.

## Decision: Why a `/design` route instead of Storybook

- **Zero dependencies**: No Storybook/Ladle/Histoire install needed
- **Native**: Works inside the actual Next.js app with the real theme, fonts, and providers
- **Fast**: No separate build process, no extra dev server
- **Sufficient**: For a solo founder + AI agents, a single page showing all components is enough
- **Upgrade path**: If component count grows to 50+, migrate to Storybook with `@storybook/nextjs-vite` (Vite-based, fast)

