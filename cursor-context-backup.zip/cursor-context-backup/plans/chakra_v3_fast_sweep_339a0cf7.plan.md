---
name: Chakra v3 Fast Sweep
overview: Eliminate all remaining Chakra v2-only imports/usages across the frontend quickly by doing a repo-wide migration sweep (rewriting/stubbing pages as needed), then add a guardrail to prevent regressions.
todos:
  - id: fix-admin-dashboard-toast
    content: Remove Chakra v2 `useToast` from AdminDashboard and use the v3-safe toast approach
    status: pending
    dependencies:
      - remove-v2-shims
  - id: repo-wide-v2-sweep
    content: Repo-wide sweep to remove remaining v2-only imports/props across frontend components/pages; rewrite/stub pages when needed
    status: pending
  - id: add-v2-regression-guard
    content: Add ESLint/CI guardrail to forbid importing known v2-only exports from `@chakra-ui/react`
    status: pending
    dependencies:
      - repo-wide-v2-sweep
  - id: smoke-verify-routes
    content: Smoke verify key routes + ensure no console missing-export errors remain; ensure Ladle build passes
    status: pending
    dependencies:
      - add-v2-regression-guard
---

# Chakra v3 Fast Migration Sweep

## Goal
- Get the frontend **booting and navigable without runtime crashes** by removing **all Chakra v2-only imports/props/usages**.
- Move from “whack-a-mole via console errors” to a **repeatable sweep** with a **regression guard**.

## Approach (fast + safe)
- Do a **repo-wide inventory** of `@chakra-ui/react` imports and identify v2-only exports (`useToast`, `Menu*`, `TableContainer`, `Thead/Tbody/Tr/Th/Td`, `Modal*`, `AlertDialog*`, `FormControl/FormLabel`, `Tabs*`, `Tooltip`, `Select`, `Tag`, etc.).
- For each hit, apply one of two fixes:
  - **Real migration** to Chakra v3 primitives (preferred for shared components and simple pages).
  - **Temporary page rewrite/stub** for complex admin pages to unblock the app fast, while keeping routes live.
- Add a **hard regression guard** so future code can’t import banned v2 APIs.

## Execution Steps
1. **Inventory + classify**
   - Use a small set of grep patterns to find remaining v2 imports/usages under `[frontend/src](frontend/src)`.
   - Group fixes into: Toast, Menu, Dialog/Modal, Table, Tabs, Form, Tooltip/Popover, Select.

2. **Unblock the current crash (`AdminDashboard.tsx`)**
   - Update `[frontend/src/pages/AdminDashboard.tsx](frontend/src/pages/AdminDashboard.tsx)` to remove v2 `useToast` and use the existing toast approach (the same pattern already used in other migrated pages).

3. **Bulk sweep: shared components first**
   - Migrate any remaining shared UI components under `[frontend/src/components](frontend/src/components)` that still import v2-only exports (highest leverage).

4. **Bulk sweep: pages (rewrite allowed)**
   - For each page under `[frontend/src/pages](frontend/src/pages)` with v2-only imports:
     - If migration is straightforward, convert to v3 primitives.
     - If it’s complex or blocked by missing v3 equivalents, replace with a **minimal v3-safe read-only page** that preserves the route and basic structure.

5. **Add regression guard**
   - Add an ESLint rule or lightweight check (script run in CI) that **fails** if any banned imports from `@chakra-ui/react` appear.
   - This prevents reintroducing `useToast`, v2 table pieces, `Modal`, etc.

6. **Smoke verification**
   - Verify key routes load without console “missing export” errors.
   - Verify Ladle still builds.

## Primary files we’ll likely touch
- `[frontend/src/pages/AdminDashboard.tsx](frontend/src/pages/AdminDashboard.tsx)` (current crash)
- Other remaining offenders under `[frontend/src/pages](frontend/src/pages)` and `[frontend/src/components](frontend/src/components)` discovered by the inventory sweep
- ESLint/CI config in `[frontend](frontend)` (for the regression guard)

## Success criteria
- No runtime errors of the form: “does not provide an export named … from `@chakra-ui/react`”.
- App shell + major routes render.
- A guardrail exists so v2 APIs can’t be reintroduced.