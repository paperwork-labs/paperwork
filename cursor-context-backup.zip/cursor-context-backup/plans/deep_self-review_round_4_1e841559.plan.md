---
name: Deep Self-Review Round 4
status: archived
overview: "ARCHIVED — All findings merged into distill_brand_+_round_4_08b9ed82.plan.md and executed. Multi-persona deep self-review covering architectural consolidation, maintenance simplification, and moat strengthening."
todos:
  - id: fix-h1-package-split
    content: Split packages/data/ into packages/data/, packages/tax-engine/, and packages/document-processing/ in Section 2 monorepo structure. Update Phase task references.
    status: pending
  - id: fix-h2-multi-tenant
    content: Add multi-tenant data isolation spec (RLS, firm-scoped middleware) to Section 1C and add P9.9 security audit task
    status: pending
  - id: fix-h3-dpa
    content: Add DPA requirement to Section 1C legal requirements. Add P9.10 task for DPA template.
    status: pending
  - id: fix-m1-phase9-timing
    content: Adjust Phase 9 timeline from 'Dec 2026 - Jan 2027' to 'Jan - Mar 2027' in Phase 9 section and Phase Timeline table
    status: pending
  - id: fix-m2-api-clarification
    content: Add note to Section 1C clarifying that Pro (CPA SaaS) and Tax-as-a-Service API (Section 5L) are distinct products sharing packages/tax-engine/
    status: pending
  - id: fix-m3-vercel-cost
    content: Add Vercel Pro ($20/mo) to FINANCIALS.md at-scale variable costs
    status: pending
  - id: fix-m5-user-split
    content: Split Section 5L acquisition model into 'Direct Users' vs 'API Filing Volume' with note on valuation multiple differences
    status: pending
  - id: fix-m6-partnerships-b2b
    content: Add Section 3.5 to PARTNERSHIPS.md for FileFree Pro CPA sales motion with ownership clarification
    status: pending
  - id: fix-low-findings
    content: Fix L1 (B2B SLA note), L2 (competitive moat point 6), L3 (P1.9c scaffold), L4 (annual billing discount note)
    status: pending
  - id: update-self-review-table
    content: Add Review Round 4 findings table to Section 9 of VENTURE_MASTER_PLAN.md
    status: pending
  - id: close-archived-plans
    content: Mark 9 superseded plan files as archived in their frontmatter
    status: pending
  - id: add-knowledge-decisions
    content: Add D70 (Package Split Architecture) to KNOWLEDGE.md
    status: pending
isProject: false
---

# Deep Self-Review Round 4: Post-Integration Architecture Optimization

The plan has grown from 3 products to 5 (+ B2B API), from 8 phases to 10, and from 3 revenue streams to 5. This review identifies findings that simplify maintenance, strengthen the moat, and resolve inconsistencies introduced by the recent B2B CPA / business tax / growth playbook integrations.

## Part 1: Plan File Cleanup

**8 plans to CLOSE** (all content integrated into master plan):

- `support_automation_strategy_3ed0ae08` -- no open todos, Chatwoot deferred
- `company_structure_deep_dive_f2e01bce` -- BizFree naming superseded
- `intelligence_experimentation_retention_moat_d406807d` -- Section 4K/4L integrated
- `pii_partners_intelligence_eng_b2fac409` -- Section 0I/4/6K integrated
- `scale_architecture_+_growth_28be31ae` -- B2B plan implemented these
- `naming_ra_trinkets_updates_ef9d6883` -- Section 0B/0F integrated
- `deep_research_tightening_cc2f702c` -- explicitly marked superseded
- `support_automation_strategy_590011fb` -- duplicate
- `b2b_cpa_integration_plan_52f21019` -- all 10 todos completed

**4 plans to KEEP** (still have actionable execution todos):

- `definitive_execution_plan` -- monorepo, 50-state data, ops infrastructure todos
- `consolidated_strategic_review` -- LLC, Google Workspace, subdomain migration todos
- `venture_master_strategy` -- domain migration, agent workstream todos
- `revenue_social_agents_review` -- persona restructure, n8n migration todos

Action: Add a note to each CLOSED plan's frontmatter marking it as archived. No content changes needed.

## Part 2: Self-Review Findings (All Personas)

### HIGH Severity (Fix Inline)

**H1 [Engineering]: `packages/data/` is overloaded -- needs split for maintainability**

`packages/data/` currently holds: 50-state formation data, 50-state tax data, tax calculation engine, state engine API, MeF XML schemas (Phase 7), and will hold business tax engine (Phase 10). These have different ownership cycles (tax data = annual IRS update, formation data = per-state SOS changes, tax engine = code changes with every form addition).

Fix: Split into 3 packages in [docs/VENTURE_MASTER_PLAN.md](docs/VENTURE_MASTER_PLAN.md) Section 2 monorepo structure:

- `packages/data/` -- 50-state formation + tax JSON configs, Zod schemas, state engine API (data layer)
- `packages/tax-engine/` -- tax calculation engine, form generators, MeF XML schemas, dual-path reconciliation (computation layer)
- `packages/document-processing/` -- OCR pipeline client, field extraction schemas, document storage lifecycle, bulk upload queue (ingestion layer)

This separation is the architectural moat: `packages/tax-engine/` becomes the independently testable, versioned core that powers consumer FileFree, FileFree Pro, business filing, AND the B2B Tax-as-a-Service API. Each package has a clean interface and can be developed/tested independently.

```mermaid
flowchart LR
    subgraph apps [Apps]
        FF[FileFree]
        FFP[FileFree Pro]
        LF[LaunchFree]
        TR[Trinkets]
    end

    subgraph packages [Packages]
        DP["document-processing\n(OCR, extraction, storage)"]
        TE["tax-engine\n(calc, forms, MeF, reconciliation)"]
        DATA["data\n(50-state JSON, Zod, state engine)"]
        UI[ui]
        AUTH[auth]
        INTEL[intelligence]
    end

    FF --> DP
    FF --> TE
    FFP --> DP
    FFP --> TE
    LF --> DATA
    TR --> TE
    TE --> DATA
    DP --> DATA
```



**H2 [Engineering]: Multi-tenant data isolation for FileFree Pro is unspec'd (CRITICAL security)**

CPA firm A's client data must never leak to CPA firm B. Section 1C says "firm-scoped middleware" but doesn't specify the isolation mechanism. This is a CRITICAL security requirement for B2B SaaS handling tax documents.

Fix: Add to Section 1C and Phase 9: "All Pro API routes use firm-scoped middleware that injects `firm_id` from auth token into every database query. Row-level security (RLS) on PostgreSQL enforced via `SET app.current_firm_id` + RLS policies. No query can return data from a different firm. Security audit required before Pro launch (add P9.9)."

**H3 [Legal]: FileFree Pro creates B2B data processing relationship requiring DPA**

Consumer FileFree users consent directly. FileFree Pro is different: the CPA firm is our customer, but the individuals whose W-2s are uploaded are NOT our direct users. We process their PII on behalf of the CPA firm.

Fix: Add to Section 1C legal requirements: "CPA firms must sign a Data Processing Agreement (DPA) covering: what data we process, how long we retain it (24hr for images per existing policy), that we don't use client data for consumer product matching, and CCPA/state privacy law compliance. DPA template needed before Pro launch (attorney consult scope item). Add P9.10: DPA template + automated firm onboarding agreement."

### MEDIUM Severity

**M1 [Engineering]: Phase 9 timing is unrealistic**

Phase 9 says "December 2026 - January 2027" but Phase 8 launches January 2027. Building multi-tenant auth, Stripe B2B billing, export formats, a landing page, and CPA outreach in 1 month WHILE launching the consumer product is unrealistic.

Fix: Adjust Phase 9 to "January - March 2027" (mid-tax-season launch for Pro). CPAs are busiest Jan-Feb; launching Pro in February/March catches the deadline rush. This also prevents Phase 8 consumer launch from being compromised by Pro development.

**M2 [Strategy]: B2B API and FileFree Pro are being conflated**

Section 5L Channel 2 describes a "Tax-as-a-Service API" for fintech platforms. Section 1C describes "FileFree Pro" for CPAs. These are different products with different buyers, pricing, and technical requirements. The plan treats them as separate but doesn't clarify the relationship.

Fix: Add a note to Section 1C: "FileFree Pro (CPA SaaS) and Tax-as-a-Service API (Section 5L) are distinct products sharing the same `packages/tax-engine/`. Pro is a UI product for CPAs. The API is a headless engine for platforms. Pro launches Phase 9 (Year 1). API launches Year 2 after MeF transmitter is proven."

**M3 [CFO]: Infra cost doesn't reflect 5 Vercel apps**

Current plan assumes Vercel Hobby tier (free) for all apps. Hobby tier limits to 1 project per account. With 5 apps (filefree, filefree-pro, launchfree, studio, trinkets), either need Vercel Pro ($20/mo) or separate Hobby accounts (operational complexity).

Fix: Update [docs/FINANCIALS.md](docs/FINANCIALS.md) "At-Scale Variable Costs" to add "Vercel Pro: $20/mo, triggered by 5+ apps or team features." Update monthly burn calculation when Phase 1 monorepo deploys multiple apps.

**M4 [Engineering]: Document is 3,872 lines -- exceeds 3,500 line target**

Section 8 rule 5 says "Keep under 3,500 lines." The plan is now 3,872 lines. The new additions (Section 1C, Phase 9-10, Section 5L) added ~370 lines.

Fix: When Phase 0 tasks are COMPLETE, collapse Phase 0 table per Section 8 rule 1. This recovers ~20 lines. When Phases 1-3 complete, collapse each table. For now, add a note to Section 8: "Current: 3,872 lines. Phase completion collapses will bring this under target."

**M5 [Growth]: 2M user projection double-counts B2B API users**

Section 5L counts B2B API users in the total user count (e.g., Y5: 300K-700K from API). But these users file through partner platforms -- they never visit filefree.ai. They cannot be shown marketplace recommendations (Section 4O), they don't get Fit Scores, and they don't contribute to the data moat for partner matching. Including them in the "2M user" target conflates filing volume with platform users.

Fix: Split the acquisition model into "Direct Users" (visit filefree.ai/launchfree.ai, eligible for marketplace) and "API Filing Volume" (process through partner platforms, generate per-return revenue only). This is important because marketplace valuation multiples (8-15x) apply to direct users with profiles, not headless API volume (3-5x).

**M6 [Partnerships]: PARTNERSHIPS.md doesn't cover B2B CPA sales motion**

The partnership playbook is entirely consumer/affiliate focused. CPA firm sales is a B2B SaaS motion (LinkedIn outreach, product demos, onboarding calls) that's fundamentally different from filling out affiliate network forms. Founder 2's role is unclear for B2B.

Fix: Add Section 3.5 to [docs/PARTNERSHIPS.md](docs/PARTNERSHIPS.md): "FileFree Pro Partner Outreach" with B2B-specific templates, ownership (Founder 1 owns CPA outreach since it's product-led, Founder 2 focuses on consumer partnerships), and CPA society event strategy.

### LOW Severity

**L1 [QA]: Circuit breaker pattern needs B2B SLA consideration** -- Consumer users tolerate "try again later." CPA firms processing 50+ docs/day need uptime guarantees. Document minimum SLA (99.5% during tax season) and circuit breaker degradation behavior for Pro users in Section 2B.2.

**L2 [Strategy]: CPA referral channel (Path F) is under-emphasized in competitive moat** -- Section 4O "Competitive Moat" has 5 points but doesn't mention the B2B-to-B2C referral flywheel. Add point 6: "B2B distribution moat: CPA firms using FileFree Pro become referral channels for consumer FileFree. No competitor has both a B2B product AND a free consumer product creating bidirectional distribution."

**L3 [Engineering]: Phase 1 monorepo scaffold should include `filefree-pro/` placeholder** -- P1.7 scaffolds LaunchFree, P1.9 scaffolds Studio, P1.9b scaffolds Trinkets. Add P1.9c to scaffold `apps/filefree-pro/` with a placeholder landing page. Costs 1 hour and prevents a "where does this go?" decision later.

**L4 [CFO]: B2B SaaS revenue in FINANCIALS.md should show annual billing discount impact** -- Section 1C offers 20% annual billing discount but FINANCIALS.md revenue table uses monthly rates. If 50% of firms choose annual, effective monthly revenue drops 10%. Add a note or adjust projections.

## Part 3: Architectural Consolidation Summary

The key insight from this review: **the venture now has a "platform core" that powers 5 products**. The architectural moat is the shared `packages/` layer:

```mermaid
flowchart TB
    subgraph products ["5 Products (Revenue)"]
        C1["FileFree\n(Free filing)"]
        C2["FileFree Pro\n($49-199/mo SaaS)"]
        C3["LaunchFree\n(Free formation)"]
        C4["Trinkets\n(AdSense SEO)"]
        C5["Tax API\n($5-15/return)"]
    end

    subgraph core ["Platform Core (The Moat)"]
        P1["tax-engine\n(calc + forms + MeF)"]
        P2["document-processing\n(OCR + extraction)"]
        P3["data\n(50-state configs)"]
        P4["intelligence\n(profiles + matching)"]
        P5["auth\n(SSO + multi-tenant)"]
    end

    subgraph infra ["Infrastructure ($284/mo)"]
        I1["Render x2"]
        I2["Neon PostgreSQL"]
        I3["Vercel x5"]
        I4["GCP Cloud Vision"]
    end

    C1 --> P1
    C1 --> P2
    C1 --> P4
    C2 --> P1
    C2 --> P2
    C3 --> P3
    C4 --> P1
    C5 --> P1
    C5 --> P2

    P1 --> I1
    P2 --> I4
    P4 --> I2
    products --> I3
```



Every new product added to this platform has near-zero marginal infrastructure cost because it shares the same packages. This is the architectural moat: a competitor building just one of these products must invest the same infrastructure cost we've already amortized across five.