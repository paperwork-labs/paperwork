---
name: Market Insights and Presets
overview: "Consolidated plan: enhance the Market Dashboard with deep insights (action queue, 52w histogram, breadth trends, RRG, signals) AND overhaul MarketTracked presets to align with dashboard logic, then cross-link both pages together."
todos:
  - id: filter-engine
    content: Audit SortableTable filter engine; add lt/lte/gte operators if missing
    status: completed
  - id: fix-presets
    content: Fix 'Giants' Stage 2 bug, replace redundant 'Bullish Trend Day', add 5 new presets + deep-link slugs
    status: completed
  - id: action-queue-ui
    content: Render existing action_queue data as an 'Action Queue' card on the dashboard
    status: completed
  - id: range-histogram
    content: "Backend: bucket range_pos_52w into histogram; Frontend: bar chart"
    status: completed
  - id: breadth-trend
    content: "Backend: breadth time series from MarketSnapshotHistory; Frontend: sparkline"
    status: completed
  - id: rrg-sectors
    content: "Backend: compute RS-Ratio + RS-Momentum for sector ETFs; Frontend: scatter plot"
    status: completed
  - id: earnings-fundamentals
    content: "Backend: upcoming_earnings + fundamental_leaders; Frontend: cards"
    status: completed
  - id: rsi-divergence
    content: "Backend: detect RSI divergences; Frontend: Divergence Watch card"
    status: completed
  - id: td-sequential
    content: "Backend: filter actionable TD Sequential signals; Frontend: card"
    status: completed
  - id: gap-analysis
    content: "Backend: surface top unfilled gap symbols; Frontend: card"
    status: completed
  - id: cross-links
    content: Dashboard setup/transition headers + symbols link to MarketTracked deep links
    status: completed
  - id: tests
    content: Frontend tests for presets/deep links + backend tests for new dashboard sections
    status: completed
isProject: false
---

# Market Insights + Preset Alignment (Consolidated)

Two plans merged into one deliverable. The cross-linking work is the natural bridge — dashboard enhancements create the data, presets mirror the logic, and deep links connect them.

## Phase 1: Foundation (Presets + Filter Engine + Action Queue)

### 1a. Audit and extend SortableTable filter engine

- Check [frontend/src/components/SortableTable.tsx](frontend/src/components/SortableTable.tsx) for supported operators
- Add `lt`, `lte`, `gte` operators if missing (needed by pullback/bearish presets)

### 1b. Fix and add MarketTracked presets

In [frontend/src/pages/MarketTracked.tsx](frontend/src/pages/MarketTracked.tsx):

- **Fix "Giants Waking Up"**: `stage_label == '2'` is broken; change to OR rules matching `2A`, `2B`, `2C`
- **Replace "Bullish Trend Day"** (redundant) with **"RS Leaders"**: RS Mansfield > 3, price > SMA 200
- **Add 5 new presets**:
  - "Breakout Watch" — Stage 2*, perf_5d > 0, RS > 0, price > SMA 50
  - "Pullback Buy Zone" — Stage 2*, -4% <= perf_5d <= 2%, RS > 0, price > SMA 50
  - "Stage 1 Base Building" — Stage 1, range_pos_52w < 30
  - "Distribution Warning" — Stage 3, RS < 0
  - "Stage 4 Decline" — Stage 4, price < SMA 50, price < SMA 200
- **Update deep-link slug map** with `breakout`, `pullback`, `rs_leaders`, `base`, `distribution`, `decline`

### 1c. Surface action_queue on dashboard

- [frontend/src/pages/MarketDashboard.tsx](frontend/src/pages/MarketDashboard.tsx): render the existing `action_queue` payload as an "Action Queue" card (zero backend work)

## Phase 2: Dashboard Enhancements (Backend + Frontend)

### 2a. 52-week range histogram

- **Backend** ([backend/services/market/market_dashboard_service.py](backend/services/market/market_dashboard_service.py)): Bucket `range_pos_52w` into 10 bins (0-10%, 10-20%, ..., 90-100%), return as `range_histogram` in payload
- **Frontend**: Small bar chart showing distribution — skewed right = euphoria, skewed left = capitulation

### 2b. Breadth over time

- **Backend**: Query `MarketSnapshotHistory` for last 30-60 days, compute daily `above_sma50_pct` and `above_sma200_pct` time series, return as `breadth_series`
- **Frontend**: Sparkline/area chart showing breadth trend; declining breadth + rising prices = divergence warning

### 2c. Relative Rotation Graph (RRG) for sectors

- **Backend**: For each of the 14 sector ETFs, compute RS-Ratio (normalized `rs_mansfield_pct`) and RS-Momentum (5d change), return as `rrg_sectors` array of `{symbol, name, rs_ratio, rs_momentum}`
- **Frontend**: Scatter plot with 4 labeled quadrants (Leading/Weakening/Lagging/Improving), each ETF as a dot

### 2d. Earnings proximity + fundamental leaders

- **Backend**: Add `upcoming_earnings` (symbols with `next_earnings` within 7 days) and `fundamental_leaders` (top 10 by EPS growth + RS composite)
- **Frontend**: "Upcoming Earnings" card + "Fundamental Leaders" card

### 2e. RSI divergence detection

- **Backend**: Compare `perf_20d` direction vs `rsi` trend. Flag bearish divergences (price up, RSI down) and bullish divergences (price down, RSI up), return as `rsi_divergences`
- **Frontend**: "Divergence Watch" card with bullish/bearish lists

### 2f. TD Sequential signals

- **Backend**: Filter for actionable signals (setup = 9, countdown = 13, or perfect signals), return as `td_signals`
- **Frontend**: "Sequential Signals" card showing symbols at exhaustion points

### 2g. Gap analysis

- **Backend**: Surface top symbols by `gaps_unfilled_up` + `gaps_unfilled_down`, return as `gap_leaders`
- **Frontend**: "Open Gaps" card

## Phase 3: Cross-Linking (Bridge)

### 3a. Dashboard cards link to MarketTracked

In [frontend/src/pages/MarketDashboard.tsx](frontend/src/pages/MarketDashboard.tsx):

- "Breakout Candidates" header links to `/market-tracked?preset=breakout`
- "Pullback Candidates" header links to `/market-tracked?preset=pullback`
- "RS Leaders" header links to `/market-tracked?preset=rs_leaders`
- "Stage Transitions" headers link to `/market-tracked?symbols=X,Y,Z` for the listed symbols
- Individual symbol names link to `/market-tracked?symbols=SYMBOL`

### 3b. Tests

- Update [frontend/src/pages/tests/MarketTrackedDeepLinkFilters.test.tsx](frontend/src/pages/__tests__/MarketTrackedDeepLinkFilters.test.tsx) for new presets and slugs
- Add/update dashboard tests for new sections rendering
- Backend tests for new dashboard service methods (histogram, breadth, RRG, signals)

## Execution Order

- Phase 1 (1a -> 1b -> 1c): Frontend-heavy, small, unblocks Phase 3
- Phase 2 (2a -> 2b -> 2c -> 2d -> 2e -> 2f -> 2g): Backend + frontend, each item is independent
- Phase 3 (3a -> 3b): Ties everything together

## Files Involved

- [frontend/src/components/SortableTable.tsx](frontend/src/components/SortableTable.tsx) — filter engine operators
- [frontend/src/pages/MarketTracked.tsx](frontend/src/pages/MarketTracked.tsx) — presets + deep-link slugs
- [frontend/src/pages/MarketDashboard.tsx](frontend/src/pages/MarketDashboard.tsx) — new sections + cross-links
- [backend/services/market/market_dashboard_service.py](backend/services/market/market_dashboard_service.py) — new data sections in `build_dashboard()`
- [backend/models/market_data.py](backend/models/market_data.py) — read-only reference (MarketSnapshot columns)
- Frontend + backend test files

