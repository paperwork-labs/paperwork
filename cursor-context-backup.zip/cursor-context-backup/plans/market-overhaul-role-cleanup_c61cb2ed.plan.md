---
name: market-overhaul-role-cleanup
overview: Implement ticker universe expansion, tracked/dashboard UX upgrades, role cleanup, and analyst-only entry/exit editing with backend-first enforcement and regression tests.
todos:
  - id: prod-admin-stability
    content: Fix production admin endpoint failures (/admin/users, /admin/schedules) and ensure error responses preserve CORS headers.
    status: completed
  - id: ci-migration-enforcement
    content: Enforce Option A migration policy by guaranteeing Alembic upgrade head runs in production deploy workflow.
    status: completed
  - id: expand-universe
    content: Add requested ETF/ticker set into backend tracked universe pipeline and ensure coverage/snapshot flows include them.
    status: completed
  - id: tracked-entry-exit-backend
    content: Implement backend tracked entry/exit annotation storage + endpoints with analyst/admin write RBAC and migration.
    status: completed
  - id: tracked-ui-filters-editing
    content: Add ETF quick filter and analyst/admin inline entry/exit editing UX in MarketTracked with percent+ATR display.
    status: completed
  - id: role-cleanup
    content: Migrate legacy user role to readonly, remove legacy role options from UI/API, and keep canonical 3-role model.
    status: completed
  - id: dashboard-overhaul
    content: Replace MarketDashboard with requested top/bottom and sector/stage tables using backend-ranked payloads.
    status: completed
  - id: tests-and-validation
    content: Add/adjust backend and frontend tests for RBAC, filters, role migration, and new dashboard payload/rendering.
    status: completed
isProject: false
---

# Market + Roles + Tracked Overhaul Plan

## Scope Locked

- Migrate legacy `user` role to `readonly` and remove legacy role paths.
- Entry/exit proximity ranking: **percent distance primary**, while also showing ATR distance as secondary.
- Migration strategy: **Option A** (`AUTO_MIGRATE_ON_STARTUP=false`) with CI/CD-enforced `alembic upgrade head`.

## 0) P0 production stability before feature work

- Fix prod-breaking admin endpoint failures first:
  - `GET /api/v1/admin/users`
  - `GET /api/v1/admin/schedules`
- Ensure failing responses still return browser-visible API errors (with CORS headers), so frontend receives proper status/detail instead of opaque network errors.
- Add targeted backend tests that cover admin endpoint failure modes and serialization edge cases.
- Likely touch:
  - [backend/api/routes/admin.py](/Users/sankalpsharma/development/axiomfolio/backend/api/routes/admin.py)
  - [backend/api/routes/admin_scheduler.py](/Users/sankalpsharma/development/axiomfolio/backend/api/routes/admin_scheduler.py)
  - [backend/api/main.py](/Users/sankalpsharma/development/axiomfolio/backend/api/main.py)

## 1) Enforce Option A migration policy

- Keep `AUTO_MIGRATE_ON_STARTUP=false` in runtime services.
- Ensure production deploy path always runs Alembic migrations before/with app rollout.
- Add deploy verification step (revision + critical enum/value checks) to catch drift early.
- Likely touch:
  - [render.yaml](/Users/sankalpsharma/development/axiomfolio/render.yaml) (policy consistency only if needed)
  - [.github/workflows/cd.yml](/Users/sankalpsharma/development/axiomfolio/.github/workflows/cd.yml)
  - [docs/PRODUCTION.md](/Users/sankalpsharma/development/axiomfolio/docs/PRODUCTION.md)

## 2) Expand tracked universe with requested ETFs/tickers

- Update tracked universe seed/constant sources so requested symbols are always present, then flow through existing snapshot/coverage jobs.
- Likely touch:
  - [backend/services/market/constants.py](/Users/sankalpsharma/development/axiomfolio/backend/services/market/constants.py)
  - [backend/services/market/universe.py](/Users/sankalpsharma/development/axiomfolio/backend/services/market/universe.py)
  - [backend/tasks/market_data_tasks.py](/Users/sankalpsharma/development/axiomfolio/backend/tasks/market_data_tasks.py)
- Keep DB-first behavior and avoid hardcoding in frontend.

## 3) Market Tracked: ETF quick filter + sector context + entry/exit columns

- Add ETF quick preset/filter in tracked UI (including deep-link support) and ensure sector/industry columns remain available/visible.
- Add `entry_price` and `exit_price` columns with clean inline edit UX:
  - empty cell: quick add
  - populated cell: edit mode with confirm/cancel icons (tick/cross)
- Gate edit controls to `analyst`/`admin`; viewers can read only.
- Likely touch:
  - [frontend/src/pages/MarketTracked.tsx](/Users/sankalpsharma/development/axiomfolio/frontend/src/pages/MarketTracked.tsx)
  - [frontend/src/components/SortableTable.tsx](/Users/sankalpsharma/development/axiomfolio/frontend/src/components/SortableTable.tsx) (only if cell action primitives are needed)
  - [frontend/src/services/api.ts](/Users/sankalpsharma/development/axiomfolio/frontend/src/services/api.ts)

## 4) Backend support for tracked entry/exit annotations (authoritative)

- Add backend persistence for per-symbol tracked annotations (`entry_price`, `exit_price`, timestamps, updated_by).
- Expose read endpoint for tracked snapshots including these values and write endpoint(s) for analyst/admin updates.
- Enforce RBAC in backend dependencies/routes (never frontend-only checks).
- Likely touch:
  - [backend/models/market_data.py](/Users/sankalpsharma/development/axiomfolio/backend/models/market_data.py) (or a dedicated new model)
  - [backend/api/routes/market_data.py](/Users/sankalpsharma/development/axiomfolio/backend/api/routes/market_data.py)
  - [backend/api/dependencies.py](/Users/sankalpsharma/development/axiomfolio/backend/api/dependencies.py)
  - new Alembic migration in [backend/alembic/versions](/Users/sankalpsharma/development/axiomfolio/backend/alembic/versions)

## 5) Role cleanup: remove legacy `user` role

- Data migration: convert existing `users.role='USER'/'user'` to `READONLY`.
- Remove legacy role choice from admin UI and API parsing; only `admin`, `analyst`, `readonly` remain.
- Preserve backward-safe handling at API boundary temporarily for in-flight clients, but canonical persisted roles are only the 3 above.
- Likely touch:
  - [backend/models/user.py](/Users/sankalpsharma/development/axiomfolio/backend/models/user.py)
  - [backend/api/routes/admin.py](/Users/sankalpsharma/development/axiomfolio/backend/api/routes/admin.py)
  - [frontend/src/pages/SettingsUsers.tsx](/Users/sankalpsharma/development/axiomfolio/frontend/src/pages/SettingsUsers.tsx)
  - new Alembic migration in [backend/alembic/versions](/Users/sankalpsharma/development/axiomfolio/backend/alembic/versions)

## 6) Market Dashboard overhaul to requested layout

- Replace current cards/lists with requested tables and counts:
  - Top 10 closest to entry
  - Top 10 closest to exit
  - Sector ETF table: sector name, 1D change, stage, days in stage
  - List: stocks entering stage 2a
  - Stage count block: Stage 1/2a/2b/2c/3/4
  - Top 10 and Bottom 10 momentum matrix for columns:
    - 1D, 5D, 20D, (Price-21DMA)/ATR, (Price-50DMA)/ATR, (Price-200DMA)/ATR
- For each ranked cell, show `TICKER (value)`.
- Keep backend doing heavy-lift aggregation/ranking; frontend mostly render.
- Likely touch:
  - [backend/services/market/market_dashboard_service.py](/Users/sankalpsharma/development/axiomfolio/backend/services/market/market_dashboard_service.py)
  - [backend/api/routes/market_data.py](/Users/sankalpsharma/development/axiomfolio/backend/api/routes/market_data.py)
  - [frontend/src/pages/MarketDashboard.tsx](/Users/sankalpsharma/development/axiomfolio/frontend/src/pages/MarketDashboard.tsx)

## 7) Testing + rollout safety

- Backend tests:
  - role migration behavior + role parser constraints
  - analyst/admin write permissions for entry/exit
  - dashboard payload structure/ranking determinism
- Frontend tests:
  - tracked ETF filter/deep-link behavior
  - entry/exit inline edit permissions + confirm/cancel flows
  - dashboard render of new tables/counts
- Run targeted suites first, then type-check/lint for touched files.

