---
name: Notion Polish + Sprint 0
overview: Polish the Notion workspace (icons, clickable links, Sprint 0 task board), then begin building the code foundation (Task 0.1 Docker dev environment) as the first step toward making personas useful.
todos:
  - id: notion-icons
    content: Add distinctive icons to all child pages in FileFree HQ for visual scanning
    status: completed
  - id: notion-clickable-links
    content: Replace bold text references with clickable mention-page links in Quick Start Guide and FileFree HQ
    status: completed
  - id: notion-sprint0-board
    content: Create Sprint 0 Tasks database in Notion with all action items, owners, priorities, and due dates
    status: completed
  - id: notion-hq-reorganize
    content: "Reorganize FileFree HQ layout: Sprint 0 board at top, then Partnership Hub, then Strategy/Docs"
    status: completed
  - id: build-task-01
    content: Build Task 0.1 Docker dev environment (docker-compose, Makefile, Dockerfiles, env files, README)
    status: completed
isProject: false
---

# Notion Polish + Sprint 0 Kickoff

## Part 1: Notion Improvements

### 1A. Add icons to all child pages in FileFree HQ

Update each page title with a distinctive icon so the sidebar is scannable at a glance:

- Quick Start Guide -- already has rocket icon, keep it
- Partnership Pipeline (database) -- icons are set at database level, may need separate update
- Pitch Package -- add briefcase or money icon
- Co-Founder Weekly Cadence -- add calendar icon
- Partnership Playbook -- add handshake icon
- Strategy & Market Analysis -- add chart icon
- Product Overview -- add phone/app icon

### 1B. Make page references clickable in Quick Start Guide

The current Quick Start Guide uses bold text like `**Pitch Package**` which isn't clickable. Replace with `<mention-page>` tags that link to the actual Notion pages. All 6 page references need updating.

### 1C. Make page references clickable in FileFree HQ body

Same issue on the HQ landing page -- bold text references like `**Partnership Pipeline**` should be clickable `<mention-page>` links.

### 1D. Create Sprint 0 Task Board in Notion

Create a new database under FileFree HQ called "Sprint 0 Tasks" with columns:

- Task (title)
- Owner (select: Founder 1 / Founder 2 / Either)
- Status (select: Not Started / In Progress / Done / Blocked)
- Priority (select: P0 / P1 / P2)
- Due Date
- Notes
- Category (select: Legal / Infra / Partnerships / Content / IRS)

Pre-populate with all Sprint 0 action items:

**P0 (This Week):**

- EFIN Application (Form 8633) -- Founder 1, IRS category
- Register LLC -- Founder 1, Legal category
- Create social media accounts (TikTok, IG, X, YouTube) -- Either, Content category
- Apply to Impact.com (Marcus, Wealthfront affiliates) -- Either, Partnerships category
- Apply to CJ Affiliate (Betterment) -- Either, Partnerships category
- Apply to Fidelity affiliate program -- Either, Partnerships category

**P1 (This Week / Next Week):**

- Hetzner VPS setup + Postiz deploy -- Founder 1, Infra category
- Create TikTok Ads Manager account -- Either, Content category
- Create Meta Ads Manager account -- Either, Content category
- Book Column Tax demo call -- Founder 2, Partnerships category

**P2 (Next Week):**

- Draft Privacy Policy v1 -- Founder 1, Legal category
- Draft Terms of Service v1 -- Founder 1, Legal category
- Draft first 10 social posts -- Founder 1, Content category
- Record first 5 founder videos -- Founder 1, Content category

### 1E. Reorganize FileFree HQ layout

Restructure the HQ page into clear sections with the new task board prominently placed:

- "Action Items" section at the top with Sprint 0 Tasks database (inline)
- "Partnership Hub" section with Pipeline + Playbook + Cadence
- "Strategy & Docs" section with Pitch Package + Product Overview + Strategy
- Move "What is FileFree?" and Founding Team to the bottom

---

## Part 2: Answers to Your Questions (already provided in chat)

- **Hetzner vs Render**: Different services. Render = managed backend hosting (api.filefree.tax). Hetzner = raw VPS for Postiz + n8n (social/automation tools).
- **Column Tax**: E-file ONLY. Not needed until October 2026. Demo call is about pricing negotiation and sandbox access. Not urgent -- your co-founder can book it anytime in the next 1-2 months.
- **Personas as agents**: The .mdc files work now when you invoke them in Cursor. To make them fully autonomous (auto-drafting content, weekly reports), you need n8n on Hetzner running scheduled workflows. That's Task B.6 -- can be set up in 1-2 hours once you have the VPS.

---

## Part 3: What I Build Next (after Notion polish)

Once Notion is polished, I start **Task 0.1 -- Docker Dev Environment** which creates the entire local development stack:

- `docker-compose.yml` (PostgreSQL, Redis, FastAPI, Next.js)
- `Makefile` (dev, test, lint, format, migrate commands)
- Dockerfiles for both services
- `.env.example` files, `.gitignore`, `README.md`

This is the foundation everything else builds on. After that, Tasks 0.2 (Next.js + design system) and 0.3 (FastAPI + database) can follow immediately.