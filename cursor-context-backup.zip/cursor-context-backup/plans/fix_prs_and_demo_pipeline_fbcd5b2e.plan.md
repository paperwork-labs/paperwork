---
name: Fix PRs and Demo Pipeline
overview: "Address all Copilot review comments on PR #13 and PR #14, fix the gitleaks CI failure, and implement the demo pipeline improvements (rate limit, blur detection, OCR error handling, 429 CTA)."
todos:
  - id: fix-gitleaks-ci
    content: "Add permissions (contents: read, pull-requests: read) to secrets-scan job in ci.yaml"
    status: completed
  - id: fix-timeout-cleanup
    content: Use try/finally for clearTimeout in all 3 fetch functions in ops/route.ts
    status: completed
  - id: fix-estimate-label
    content: Fix tax estimator to compare federal-only withholding (remove state from refund calc)
    status: completed
  - id: fix-dates
    content: Update KNOWLEDGE.md and TASKS.md dates to 2026-03-11
    status: completed
  - id: fix-reduced-motion
    content: Add useReducedMotion to ops page for accessibility
    status: completed
  - id: fix-rate-limit
    content: "Make demo rate limit conditional: 3/day prod, 1000/day dev"
    status: completed
  - id: fix-blur
    content: Add high-res bypass (>=1500px) and lower BLUR_THRESHOLD to 5
    status: completed
  - id: fix-ocr-errors
    content: Add specific exception handling in ocr_service.py with graceful fallbacks
    status: completed
  - id: rate-limit-cta
    content: Add RateLimitStep to demo page showing signup CTA on 429
    status: completed
  - id: test-and-push
    content: "Run all tests and lints, commit, push to PR #14"
    status: completed
isProject: false
---

# Fix PRs, CI, and Demo Pipeline

All changes land on `feat/config-credential-safety` (PR #14), which is stacked on `feat/demo-refund-estimate` (PR #13).

## 1. Fix Gitleaks CI Failure

The `secrets-scan` job fails with `Resource not accessible by integration` because the default `GITHUB_TOKEN` lacks permission to read PR commits.

**Fix**: Add explicit `permissions` to the job in `[.github/workflows/ci.yaml](.github/workflows/ci.yaml)`:

```yaml
secrets-scan:
  name: Secrets Scan
  runs-on: ubuntu-latest
  permissions:
    contents: read
    pull-requests: read
  steps: ...
```

## 2. Address Copilot Comments (Both PRs)

### 2a. Timeout cleanup with try/finally (3 locations in `[web/src/app/api/ops/route.ts](web/src/app/api/ops/route.ts)`)

All three fetch functions (`checkService`, `fetchN8nWorkflows`, `fetchGitHubCI`) create `setTimeout` timers that leak if `fetch()` throws. Fix by moving `clearTimeout` into a `finally` block:

```typescript
const controller = new AbortController();
const timeout = setTimeout(() => controller.abort(), TIMEOUT_MS);
try {
  const res = await fetch(...);
  // handle response
} finally {
  clearTimeout(timeout);
}
```

### 2b. Fix refund estimate label (Copilot: "total withheld includes state but label says federal")

In `[web/src/lib/tax-estimator.ts](web/src/lib/tax-estimator.ts)`, change the estimator to compare **federal withholding only** against federal tax:

```typescript
// Before: totalWithheld = federalWithheldCents + stateWithheldCents
// After:
const net = federalWithheldCents - federalTax;
```

Keep `totalWithheld` in the result for informational display but compute refund/owed only from federal. Remove the `stateWithheldCents` parameter since it's not needed for the federal-only estimate.

### 2c. Update stale dates

- `[docs/KNOWLEDGE.md](docs/KNOWLEDGE.md)` line 5: `2026-03-08` -> `2026-03-11`
- `[docs/TASKS.md](docs/TASKS.md)` line 3: `2026-03-08` -> `2026-03-11`

### 2d. Respect prefers-reduced-motion on ops page

`[web/src/app/ops/page.tsx](web/src/app/ops/page.tsx)` already imports from `@/types/ops`. Add `useReducedMotion` from `@/lib/motion` and conditionally disable ping animation and slow auto-refresh interval when reduced motion is preferred.

### 2e. Ops dashboard auth note

The `/ops` and `/api/ops` routes are public. For now (internal tool, no sensitive data leaked), add a `TODO` comment. We will not block the PR on this.

## 3. Demo Pipeline Fixes

### 3a. Conditional rate limit (`[api/app/routers/documents.py](api/app/routers/documents.py)`)

Make rate limit depend on `ENVIRONMENT`:

```python
from app.config import settings
DEMO_RATE_LIMIT = "3/day" if settings.ENVIRONMENT == "production" else "1000/day"

@router.post("/demo-upload")
@limiter.limit(DEMO_RATE_LIMIT)
```

### 3b. Fix blur false positives (`[web/src/lib/image-quality.ts](web/src/lib/image-quality.ts)`)

- Add high-resolution bypass: skip blur check if `max(width, height) >= 1500` (clean digital scans are inherently high-res)
- Lower `BLUR_THRESHOLD` from `15` to `5`

### 3c. OCR error handling (`[api/app/services/ocr_service.py](api/app/services/ocr_service.py)`)

Wrap each stage in `process_w2` with specific exception handling:

- `google.api_core.exceptions.PermissionDenied` / `google.auth.exceptions.DefaultCredentialsError` -> log + fallback to mock
- `openai.AuthenticationError` -> log + fallback to mock
- `openai.RateLimitError` -> raise `HTTPException(429)` with user-friendly message
- Network/timeout errors -> raise `HTTPException(503)`
- Generic exceptions -> log + fallback to mock

### 3d. Rate limit CTA in demo (`[web/src/app/demo/page.tsx](web/src/app/demo/page.tsx)`)

Detect 429 from axios error and show a dedicated `RateLimitStep` instead of the generic error screen:

```typescript
// In processFile catch block:
if (axios.isAxiosError(err) && err.response?.status === 429) {
  setStep("rate-limited");
  return;
}
```

New `RateLimitStep` component shows a conversion-friendly message with signup CTA.

## 4. Test and Push

- Run `make test` and `make lint` in API
- Run `npm test` and `npx tsc --noEmit` in web
- Commit and push to PR #14

