---
name: AxiomFolioFullRebrandPlan
overview: Full rebrand to AxiomFolio across repo, images, configs, and database names with a safe data migration and Render-first production rollout.
todos: []
isProject: false
---

# AxiomFolio Full Rebrand Plan

## Scope (confirmed)

- Rename everything: repo, image/registry names, service names, UI strings, docs.
- Rename DB identifiers: new database name/prefixes with a **data migration** to preserve tables.

## Phase 1: Repo + registry rename

- Rename the GitHub repo to `axiomfolio` and update any references to the old repo name.
- Update GHCR image names and CI pipeline outputs to match the new repo path.
  - Example: `[.github/workflows/cd.yml](.github/workflows/cd.yml)`.
- Update badges, links, and automation references that include the old repo slug.
  - Example: `[README.md](README.md)`, `[docs/PR_AUTOMATION.md](docs/PR_AUTOMATION.md)`, `[.github/](.github/)`.

## Phase 2: Codebase rename sweep

- Update user‑facing strings and docs to AxiomFolio (UI, backend metadata, README, production docs).
  - Example files: `[frontend/index.html](frontend/index.html)`, `[frontend/src/components/layout/DashboardLayout.tsx](frontend/src/components/layout/DashboardLayout.tsx)`, `[backend/api/main.py](backend/api/main.py)`, `[backend/config.py](backend/config.py)`, `[README.md](README.md)`, `[docs/PRODUCTION.md](docs/PRODUCTION.md)`.
- Update package metadata and identifiers (frontend package name, etc.).
  - Example: `[frontend/package.json](frontend/package.json)`.
- Replace or update brand assets (logo, favicon, wordmark) and Ladle stories.
  - Example: `[frontend/src/assets/](frontend/src/assets/)`, `[frontend/src/stories/](frontend/src/stories/)`.
- Rename internal service labels where they surface externally (OpenAPI title, health response, logs).
  - Example: `[backend/api/main.py](backend/api/main.py)`, `[backend/config.py](backend/config.py)`.

## Phase 3: Render/Fly/infra config renames

- Rename Render services, database, redis, cron jobs to `axiomfolio-*`.
  - Example: `[render.yaml](render.yaml)`.
- Update env templates and defaults for AxiomFolio domains and DB naming.
  - Example: `[infra/env.prod.example](infra/env.prod.example)`.
- Update local/dev orchestration names and compose project naming if exposed.
  - Example: `[infra/compose.dev.yaml](infra/compose.dev.yaml)`, `[infra/compose.test.yaml](infra/compose.test.yaml)`, `[Makefile](Makefile)`, `[run.sh](run.sh)`.
- Rename Fly app configs to AxiomFolio if Fly is kept aligned for future use.
  - Example: `[fly.backend.toml](fly.backend.toml)`, `[fly.worker.toml](fly.worker.toml)`, `[fly.cron.toml](fly.cron.toml)`.

## Phase 4: Domains + DNS + TLS

- Point `axiomfolio.com` and `api.axiomfolio.com` to the Render services.
- Verify TLS certificates are issued and CORS is aligned with the new domains.
- Update OAuth redirect URIs or external integrations that depend on domain names.

## Phase 5: Database migration (preserve old tables)

- Create the new `axiomfolio` database (managed provider).
- Perform a full data migration from the old database to the new one.
  - Preferred: `pg_dump` / `pg_restore` (or provider snapshot‑clone + rename).
- Validate schema parity and row counts before cutover, and keep a rollback snapshot.

## Phase 6: Cutover + validation

- Point production env vars to the new DB and new service names.
- Run DB migrations via CI against the new DB.
- Smoke test `/health`, login flow, portfolio endpoints, and cron job execution.
- Confirm background workers, cron scheduling, and queues are processing as expected.

## Phase 7: Post‑cutover hygiene

- Verify monitoring/alerts (logs, rate limits, job failures).
- Ensure backups are enabled for the new DB and document rollback steps.

## Notes

- Old tables persist as long as we migrate or clone into the new DB; otherwise a fresh DB will be empty.
- Full rename of internal package/module paths can be deferred if risk is high; do it in a separate, controlled refactor if needed.

## TODOs

- Rename repo + registry names and update CI image paths.
- Apply AxiomFolio rename across UI, backend metadata, docs, assets, and package metadata.
- Rename Render/Fly/infra resources, compose project names, and env templates.
- Configure domains/DNS/TLS and update external integration URLs.
- Migrate DB data to the new AxiomFolio database with validation and rollback snapshot.
- Validate app health, core flows, workers/cron, and monitoring post‑cutover.

