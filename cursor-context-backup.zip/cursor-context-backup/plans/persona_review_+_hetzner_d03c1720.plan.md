---
name: Persona Review + Hetzner
overview: "Multi-persona review identified 3 categories of gaps: stale doc paths in persona files, missing Hetzner ops stack deployment configs, and production readiness items. This plan fixes the gaps and sets up the Hetzner VPS for Postiz + n8n."
todos:
  - id: fix-persona-paths
    content: Fix stale doc paths in strategy.mdc, workflows.mdc, partnerships.mdc, cfo.mdc (KNOWLEDGE.md -> docs/KNOWLEDGE.md, TASKS.md -> docs/TASKS.md)
    status: pending
  - id: update-hetzner-pricing
    content: Update Hetzner CX33 pricing in docs/TASKS.md and cfo.mdc to reflect current EUR 5.49/mo
    status: pending
  - id: hetzner-deploy-configs
    content: Create infra/hetzner/ with compose.yaml (Postiz + n8n + PostgreSQL + Redis + Temporal), env.example, setup.sh bootstrap script, and README.md
    status: pending
  - id: knowledge-entry
    content: Add D20 to docs/KNOWLEDGE.md documenting the multi-persona review findings and Hetzner ops stack decision
    status: pending
isProject: false
---

# Multi-Persona Review + Hetzner Ops Stack Setup

## Persona Review Findings

### What's Solid (No Action Needed)

- **Engineering**: Project structure is clean (`api/`, `web/`, `docs/`, `infra/`). Docker Compose, Makefile, Dockerfiles, health endpoint all working. `engineering.mdc` already updated to new paths.
- **Legal**: No PII-handling code exists yet. Disclaimer framework is documented. Privacy/ToS are Sprint 0 P2 tasks. No gaps.
- **QA**: `test_health.py` exists. No code to audit yet. CI/CD (GitHub Actions) is a Sprint 1 item per TASKS.md Task 0.1.
- **Growth**: Content strategy is documented. Landing page is Sprint 1. No gaps.
- **Tax Domain / CPA**: Tax data directory exists. Tax engine comes in Sprint 2. Nothing premature to flag.
- **Partnerships**: PARTNERSHIPS.md, PITCH_PACKAGE.md, Notion Pipeline, Sprint 0 task board all set up. No gaps.
- **UX**: No frontend code beyond placeholder. Design system comes in Task 0.2. No gaps.

### What Needs Fixing

**1. Stale doc paths in 4 persona files**

After moving docs to `docs/`, these persona files still reference `KNOWLEDGE.md` and `TASKS.md` at repo root:

- [strategy.mdc](.cursor/rules/strategy.mdc): 4 references to `KNOWLEDGE.md` (lines 71, 73, 79, 91) -- should be `docs/KNOWLEDGE.md`. Line 71 also says "(repo root)" which is wrong now.
- [workflows.mdc](.cursor/rules/workflows.mdc): 5 references to `KNOWLEDGE.md` (lines 28, 36, 38, 93, 113) and 2 to `TASKS.md` (lines 17, 132) -- should be `docs/KNOWLEDGE.md` and `docs/TASKS.md`.
- [partnerships.mdc](.cursor/rules/partnerships.mdc): Need to check for any doc path references.
- [cfo.mdc](.cursor/rules/cfo.mdc): Need to check for any doc path references.

**2. Hetzner CX33 pricing is stale in docs**

TASKS.md and cfo.mdc reference "CX33: 8GB RAM, 2 vCPU, 80GB SSD at $7.50/mo". Current Hetzner pricing: CX33 is EUR 5.49/mo (4 vCPU, 8GB RAM, 80GB SSD). Update the cost references.

**3. Missing Hetzner ops stack deployment configs**

No deployment configs exist for the Hetzner VPS that runs Postiz + n8n. Need to create:

- `infra/hetzner/compose.yaml` -- Docker Compose for the ops stack (Postiz, n8n, PostgreSQL, Redis, Temporal)
- `infra/hetzner/env.example` -- Environment variables
- `infra/hetzner/README.md` -- Setup guide (SSH, Docker install, deploy, connect domains)

This is a different stack from the product dev environment (`infra/compose.dev.yaml`). The Hetzner VPS runs social media operations and workflow automation, not the FileFree product.

---

## Hetzner VPS Setup Guide

The user has created and verified their Hetzner account. Steps to provision:

### In Hetzner Console (user does manually)

1. **Create a project**: Click "New project" > name it "FileFree Ops"
2. **Add SSH key**: Security > SSH Keys > Add. Paste your public key (`cat ~/.ssh/id_ed25519.pub` or generate one with `ssh-keygen -t ed25519`)
3. **Create server**:
  - Location: Ashburn, VA (US East) or Falkenstein (EU, cheapest)
  - Image: Ubuntu 24.04
  - Type: **CX33** (Shared vCPU, Intel, 4 vCPU, 8GB RAM, 80GB SSD) -- EUR 5.49/mo
  - Networking: Public IPv4 + IPv6
  - SSH Key: select the key you just added
  - Name: `filefree-ops`
4. **Note the IP address** once created

### Automated setup (I create the configs + bootstrap script)

- `infra/hetzner/setup.sh` -- Bootstrap script: install Docker, Docker Compose, configure firewall (allow 80, 443, 22), set up swap
- `infra/hetzner/compose.yaml` -- Postiz + n8n + PostgreSQL + Redis + Temporal
- `infra/hetzner/env.example` -- All env vars needed
- `infra/hetzner/README.md` -- Step-by-step from "I have an IP" to "Postiz is live"

After running setup, user SSHs in, copies env file, runs `docker compose up -d`, and the ops stack is live.

---

## Production Readiness (Not Blocking, But Worth Noting)

These are Sprint 1 items, not blockers, but flagged for awareness:

- **Vercel**: Connect repo for auto-deploy of `web/` on push to main. No action needed yet.
- **Render**: Connect repo with `render.yaml` for auto-deploy of `api/`. No action needed yet.
- **Neon**: Create free-tier database. Needed when Task 0.3 (FastAPI + database) starts.
- **Upstash**: Create free-tier Redis. Needed when Task 0.3 starts.
- **GitHub Actions**: CI pipeline. Typically Task 0.1 scope but can add later.

None of these block Sprint 0 or Hetzner setup. They're called out so we don't forget them.