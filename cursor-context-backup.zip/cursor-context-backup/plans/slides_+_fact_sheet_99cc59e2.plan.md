---
name: Slides + Fact Sheet
overview: Create a fact-check/source verification document for Olga's interview prep, generate a PPTX via python-pptx, and attempt a Gamma.app export as a second option. Olga picks the best slide format.
todos:
  - id: source-notes
    content: Create interview-source-notes.md with verified facts, sourced claims, and suggested-answer flags
    status: completed
  - id: pptx-python
    content: Generate deal-review-slides.pptx via python-pptx with dark theme and exact slide content
    status: completed
  - id: gamma-attempt
    content: Attempt Gamma.app slide creation via browser tool
    status: completed
  - id: convert-notes-docx
    content: Convert interview-source-notes.md to .docx via pandoc
    status: completed
isProject: false
---

# Slides + Source Verification Doc

## 1. Create Source Verification Document

New file: `olgaSharma/interview-source-notes.md` (+ `.docx` conversion)

Three sections:

**Verified from the Job Posting** (direct quotes from [openai.com/careers](https://openai.com/careers/account-director-digital-native-large-enterprise-san-francisco/)):

- "Manage ~five key accounts"
- "Own a consumption revenue target"
- "14+ years selling PaaS/SaaS"
- "Achieving revenue targets >$1M per year for more than 3 years"
- "Partner with solutions and research engineering"
- Comp range: $176K-$350K + equity

**Verified from Olga's Own Materials** (resume, PPTX, H1 PSC):

- Every number on the slides ($1.5M, 89 apps, 180%, 40% net-new, 8 partners, 9% acceptance, 112% sales, 140% MAP/MAU, Targo Top 5, $351K SmileDirectClub, 140% expansion, 220% quota, Visa/Square/Sephora)
- The competing team story
- All company names and role details

**Suggested Answers (Olga Must Customize)**:

- "Deal you lost" answer: framework is provided, she needs to insert her real deal
- "Underperforming partner" answer: generic framing provided, she should fill in specifics
- "Biggest mistake as a leader" answer: suggested structure, needs her real story
- "How do you handle ambiguity?" pivoting example: needs her specific situation
- Any dollar amounts for deals she's referencing from memory should be double-checked

**Things NOT to Say** reminder list (carried from prep doc)

## 2. Generate PPTX via python-pptx

Install `python-pptx` and write a Python script that generates `olgaSharma/deal-review-slides.pptx` with:

- Dark background (#0f0f0f or closest dark)
- Clean white text, Inter or Calibri font
- 5 slides matching the exact content from [deal-review-slides.html](olgaSharma/deal-review-slides.html)
- Stat cards for key metrics
- Proper slide titles and bullet formatting
- 16:9 aspect ratio

This gives a real `.pptx` file she can open in PowerPoint or Google Slides.

## 3. Attempt Gamma.app Export

Use the browser tool to:

1. Navigate to gamma.app
2. Create a presentation from the slide content
3. Export as PPTX

If login/signup blocks progress, skip this step and note it. The python-pptx output + HTML-to-PDF are the reliable fallbacks.

## 4. Convert Source Notes to .docx

Use pandoc to convert `interview-source-notes.md` to `interview-source-notes.docx` for Google Docs sharing.

## Deliverables

- `olgaSharma/interview-source-notes.md` (+ `.docx`) -- Fact-check and source verification document
- `olgaSharma/deal-review-slides.pptx` -- PowerPoint deck via python-pptx
- `olgaSharma/deal-review-slides.pptx` (Gamma version, if successful) -- Alternative polished deck
- Existing `olgaSharma/deal-review-slides.html` remains as a third option

Olga reviews all three slide formats and picks her favorite.