---
name: Chakra v3 + Ladle
overview: Finish a correct Chakra UI v3 adoption with a real token/semantic-token design system (light/dark), remove remaining v2 shims, and add a Ladle component library published to GitHub Pages for visual review.
todos:
  - id: system-tokens
    content: Create Chakra v3 system.ts with tokens + semanticTokens (light/dark) + recipes; wire into App.tsx
    status: completed
  - id: ui-primitives
    content: Add AppCard/Page/FormField and base recipes for Button/Input; migrate auth pages to use semantic tokens
    status: completed
    dependencies:
      - system-tokens
  - id: remove-v2-shims
    content: Remove remaining useColorModeValue shims and v2-only imports/props across all pages/components; migrate primitives (Menu/Tabs/Dialog)
    status: in_progress
    dependencies:
      - ui-primitives
  - id: ladle-setup
    content: Add Ladle to frontend, create token/component stories, and ensure it uses the Chakra v3 system provider
    status: completed
    dependencies:
      - system-tokens
  - id: ladle-gh-pages
    content: Add GitHub Actions workflow to build Ladle and publish to GitHub Pages
    status: completed
    dependencies:
      - ladle-setup
  - id: smoke-verify
    content: Smoke verify key routes and Ladle build locally; ensure no console export errors remain
    status: pending
    dependencies:
      - remove-v2-shims
      - ladle-gh-pages
---

# Chakra v3 Correct Adoption + Ladle Library

## Scope (approved)

- Full Chakra v3 migration sprint (no long-lived band-aids)
- Proper light/dark support via semantic tokens
- Add **Ladle** as the canonical component library, published to **GitHub Pages**

## Phase 1 — Design system foundation (v3-correct)

- Create `system` in [`frontend/src/theme/system.ts`](frontend/src/theme/system.ts) using `createSystem(defaultConfig, { globalCss, theme: { tokens, semanticTokens, recipes } })`.
- Define semantic tokens used everywhere:
- `bg.canvas`, `bg.panel`, `bg.card`, `bg.input`
- `fg.default`, `fg.muted`, `fg.subtle`
- `border.subtle`, `border.strong`
- `shadow.card`
- Light/dark variants for each.
- Wire ChakraProvider to use this system in [`frontend/src/App.tsx`](frontend/src/App.tsx).

## Phase 2 — Shared UI primitives (stop ad-hoc styles)

Add small primitives that encode Snowball-ish + Apple-ish feel:

- `AppCard` (wrap `CardRoot/CardBody` with standard bg/border/shadow)
- `Page` + `PageHeader` (title/subtitle/actions)
- `FormField` (v3 `FieldRoot/FieldLabel` + helper/error)
- Button recipe (primary/secondary) + Input recipe (focus ring, radii)

Files (new):

- `frontend/src/components/ui/AppCard.tsx`
- `frontend/src/components/ui/Page.tsx`
- `frontend/src/components/ui/FormField.tsx`

## Phase 3 — Auth polish (fix current visual issues)

- Ensure `/login` + `/register` headings/text use semantic tokens (fix “black on dark”).
- Ensure background/canvas is consistent across light/dark.

Files:

- [`frontend/src/pages/Login.tsx`](frontend/src/pages/Login.tsx)
- [`frontend/src/pages/Register.tsx`](frontend/src/pages/Register.tsx)
- [`frontend/src/components/layout/AuthLayout.tsx`](frontend/src/components/layout/AuthLayout.tsx)

## Phase 4 — Remove remaining v2 shims + migrate all routes

- Sweep and remove:
- any `useColorModeValue` shim functions
- any v2-only imports/props (`useToast`, `FormControl`, `InputLeftElement/RightElement`, `MenuButton/MenuList`, `isLoading`, `IconButton icon`, etc.)
- Convert remaining components to v3 primitives:
- Menu: `MenuRoot/MenuTrigger/MenuContent`
- Tabs: `TabsRoot/TabsList/TabsTrigger/TabsContent`
- Dialog: `DialogRoot/...`
- Standardize on `react-hot-toast` for notifications (no Chakra v2 toast hook).

## Phase 5 — Ladle component library (published)

- Add Ladle under `frontend/`:
- `npm` scripts: `ladle` (dev) and `ladle:build`
- `ladle.config.*` wiring so Ladle uses the same Chakra v3 `system` provider.
- Add stories:
- Token gallery (brand palette + semantic tokens light/dark)
- Buttons / Inputs / Cards / Field / Tabs / Dialog / Menu / Table
- AuthCard layout
- Add GitHub Action to build Ladle and publish to GitHub Pages.

## Phase 6 — Verification

- Manual smoke:
- `/login`, `/register`, `/` shell, `/portfolio`, `/settings`