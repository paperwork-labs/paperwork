---
name: Render Blueprint Simplify
overview: Adjust render_prod Blueprint to use keyvalue Redis and simplify cron commands to satisfy Render’s validator.
todos:
  - id: switch-keyvalue
    content: Change Redis service to keyvalue and update references
    status: completed
  - id: simplify-cron-command
    content: Simplify admin_coverage_restore command quoting
    status: completed
  - id: validate-blueprint
    content: Re-check Blueprint in Render after changes
    status: completed
isProject: false
---

# Render Blueprint Simplify

## Updates

- Switch Redis to Key Value service:
  - Change Redis service `type` to `keyvalue` in [render.yaml](/Users/sankalpsharma/development/axiomfolio/render.yaml).
  - Update all `fromService` references for Redis to `type: keyvalue`.
- Simplify cron command quoting:
  - Replace the nested JSON `--kwargs` string with a plain command using defaults (or move kwargs to env vars) for `admin_coverage_restore` in [render.yaml](/Users/sankalpsharma/development/axiomfolio/render.yaml).
- Keep the schema-aligned structure already present (runtime fields, static site config, cron services).

## Verify

- Re-open Blueprint in Render on branch `render_prod` and confirm it loads without the blank error.
- If still failing, run Render API validation for exact errors.

