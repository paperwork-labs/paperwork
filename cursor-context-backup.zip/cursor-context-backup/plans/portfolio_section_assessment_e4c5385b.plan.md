---
name: Portfolio Section Assessment
overview: A comprehensive audit of the portfolio section, identifying what's built, what's broken/stubbed, and a prioritized roadmap to bring it to production quality as a "viewer" experience -- connect brokerages, sync data, view holdings/positions/options, see analytics and insights.
todos:
  - id: types-consolidation
    content: Consolidate scattered portfolio TypeScript types into a shared types/portfolio.ts file
    status: pending
  - id: fix-transactions
    content: Rebuild Transactions page from stub -- sortable table, date range, type filters, using existing backend APIs
    status: pending
  - id: fix-categories
    content: Rebuild Categories page from stub -- CRUD dialogs, position assignment, target allocations
    status: pending
  - id: shared-components
    content: Build reusable portfolio components (stat cards, allocation chart, performance chart)
    status: pending
  - id: portfolio-dashboard
    content: Build proper Portfolio Overview dashboard with summary stats, allocation, performance chart, account breakdown
    status: pending
  - id: enhance-holdings
    content: Enhance holdings table with more columns, clickable rows to Workspace
    status: pending
  - id: options-page
    content: Build Options positions page (group by underlying, greeks, expiry timeline)
    status: pending
  - id: analytics-insights
    content: Build analytics views -- performance, tax optimization, dividends
    status: pending
  - id: polish
    content: Loading skeletons, error boundaries, empty states, mobile responsiveness, tests
    status: pending
isProject: false
---

# Portfolio Section: Current State and Improvement Plan

## Current State Summary

The portfolio section has a **strong backend** and a **partially-migrated frontend**. The backend models, brokerage clients, and sync services are production-grade. The frontend has 2 functional pages, 2 stubs, and several missing features.

### What's Working


| Area | Status |
| ---- | ------ |


**Backend (solid)**

- 12+ database tables covering positions, trades, tax lots, transactions, dividends, options, transfers, margin interest, account balances, portfolio snapshots
- IBKR sync (FlexQuery + real-time) -- production-ready, 11-step sync
- Tastytrade sync -- production-ready, handles equities + options
- Schwab OAuth flow -- partially implemented (PKCE ready, API calls placeholder)
- Celery-based async sync with status tracking
- Portfolio analytics service (Sharpe, beta, volatility, tax optimization)
- Tax lot service (FIFO/LIFO/HIFO, cost basis, sale simulation)
- Activity aggregator with materialized views
- Encrypted credential storage via `CredentialVault`

**Frontend (partial)**

- [Portfolio.tsx](frontend/src/pages/Portfolio.tsx) -- Holdings table + heatmap (equities only, functional)
- [PortfolioWorkspace.tsx](frontend/src/pages/PortfolioWorkspace.tsx) -- Symbol deep-dive with charts, tax lots, dividends (functional, feature-rich)
- [SettingsBrokerages.tsx](frontend/src/pages/SettingsBrokerages.tsx) -- Brokerage connection wizard, sync management (functional)
- Account filtering and selection infrastructure (AccountContext, AccountSelector, AccountFilterWrapper)
- API hooks covering ~20+ endpoints

### What's Broken / Stubbed

- **[PortfolioCategories.tsx](frontend/src/pages/PortfolioCategories.tsx)** -- Empty stub with "Under migration" badge. Needs CRUD for categories (create, assign positions, set target allocations).
- **[Transactions.tsx](frontend/src/pages/Transactions.tsx)** -- Empty stub with "Under migration" badge. Backend APIs exist (`/statements`, `/dividends`, activity endpoints) but the UI is a placeholder.
- **Options page** -- No dedicated options UI page exists despite backend support (`/options/unified/portfolio`, `/options/unified/summary`). Options are explicitly filtered OUT of the main Portfolio page.
- **Portfolio Dashboard** -- The current `/portfolio` route is just a holdings table, not a true dashboard. There's a `/dashboard` API endpoint but nothing renders summary stats, allocation charts, performance over time, etc.

### What's Missing Entirely (viewer-POV features)

1. **Portfolio Overview Dashboard** -- A proper summary view showing total portfolio value, asset allocation pie/treemap, performance chart over time, key metrics (Sharpe, beta, day P&L), account breakdown
2. **Options Positions View** -- Dedicated page showing options by underlying, strategy grouping (spreads, strangles), greeks, expiration calendar
3. **Transaction History** -- Filterable/searchable table of all trades, dividends, fees, transfers with date range controls
4. **Performance Analytics** -- Time-weighted returns, benchmark comparison, drawdown analysis, sector/industry exposure
5. **Tax Insights** -- Tax lot harvesting opportunities, wash sale warnings, short vs long-term gains summary, estimated tax liability
6. **Portfolio Categories (CRUD)** -- Create custom groupings, set target allocations, view rebalancing suggestions
7. **Dividend Tracker** -- Dividend income calendar, yield analysis, upcoming ex-dates, annual income projection
8. **Consolidated Types** -- Portfolio types are scattered across components; need a shared `types/portfolio.ts`

---

## Recommended Approach

### Guiding Principles

- **Backend-first**: The backend already does the heavy lifting. Most improvements are frontend work consuming existing APIs.
- **Read-only viewer**: No trade execution in the portfolio section. That's for the Strategy section later.
- **Incremental delivery**: Fix broken stubs first, then build new pages one at a time.
- **Shared types**: Consolidate scattered TypeScript interfaces into `types/portfolio.ts` before building new pages.
- **Reusable components**: Build chart/table components that work across pages (allocation chart, performance chart, stat cards).

### Architecture Vision

```
PORTFOLIO section (/portfolio/*)
  |
  |-- Overview (Dashboard)     <-- NEW: summary stats, allocation, performance chart
  |-- Holdings                 <-- ENHANCE: current Portfolio.tsx, add more columns
  |-- Workspace                <-- DONE: per-symbol deep dive
  |-- Options                  <-- NEW: options positions view
  |-- Transactions             <-- REBUILD: from stub
  |-- Categories               <-- REBUILD: from stub
  |-- Dividends                <-- NEW: dividend tracker
  |-- Analytics                <-- NEW: performance + tax insights
```

### Navigation Restructure

Current sidebar items: Dashboard, Workspace, Categories, Transactions

Proposed sidebar items:

- **Overview** (new dashboard with stats/charts)
- **Holdings** (enhanced current Portfolio.tsx)
- **Workspace** (existing, no change)
- **Options** (new)
- **Transactions** (rebuilt)
- **Categories** (rebuilt)

Analytics and Dividends can live as tabs or sub-views within Overview or Holdings rather than top-level nav items, keeping the sidebar clean.

---

## Phased Roadmap

### Phase 1: Fix Foundations (unblock everything)

- Consolidate portfolio TypeScript types into `frontend/src/types/portfolio.ts`
- Build shared stat card and chart components (allocation pie, performance line)
- Fix the Transactions page (table with filtering, date range, type filters -- backend APIs exist)
- Fix the Categories page (CRUD dialogs, assign positions, target allocation)

### Phase 2: Portfolio Overview Dashboard

- Replace the basic holdings-only `/portfolio` page with a proper dashboard
- Summary cards: total value, day P&L, unrealized P&L, cash balance
- Asset allocation chart (by sector, by account, by category)
- Performance sparkline or chart (from portfolio_snapshots)
- Account breakdown cards
- This becomes the new landing page for the Portfolio section

### Phase 3: Enhance Holdings + Add Options

- Enhance the holdings table (more columns: avg cost, day change, weight %, sector)
- Make holdings table rows clickable to navigate to Workspace
- Build Options positions page (group by underlying, show greeks, expiry timeline)

### Phase 4: Analytics and Insights

- Performance analytics tab (time-weighted returns, benchmark comparison, drawdown)
- Tax optimization view (harvesting opportunities, wash sale alerts, short/long term summary)
- Dividend tracker (calendar view, yield analysis, income projection)

### Phase 5: Polish and Production Readiness

- Skeleton loading states for all portfolio pages
- Error boundaries per section
- Empty states with helpful guidance
- Mobile responsiveness for portfolio pages
- End-to-end tests for brokerage connection and sync flows

