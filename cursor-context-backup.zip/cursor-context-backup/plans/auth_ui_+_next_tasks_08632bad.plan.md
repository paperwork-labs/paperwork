---
name: Auth UI + Next Tasks
overview: Add sign up/login buttons to the landing page and navigation, then outline the next engineering tasks from Sprint 3 in priority order.
todos:
  - id: nav-cta
    content: Add global nav with Sign In/Sign Up + update hero CTA from waitlist to Get Started
    status: completed
  - id: tasks-update
    content: Mark Task 2.2 as DONE in TASKS.md and KNOWLEDGE.md
    status: completed
  - id: filing-flow
    content: "Task 2.3: Filing flow layout, step navigation, filing CRUD, data confirmation page"
    status: completed
  - id: tax-calc
    content: "Task 2.4: Tax calculator engine (integer cents), filing details page, AI insights"
    status: completed
  - id: summary-pdf
    content: "Task 2.5: Return summary with animated reveal, PDF generation, viral share card"
    status: completed
  - id: polish
    content: "Task 2.6: Component library (SSNInput, CurrencyDisplay, etc.) + mobile audit"
    status: completed
  - id: analytics
    content: "Task 2.7: PostHog events, Sentry DSN, GitHub Actions CI"
    status: completed
isProject: false
---

# Sign Up Button + Next Engineering Tasks

## Why there is no Sign Up button

The auth pages exist and work (`/auth/register`, `/auth/login`) -- PR #10 is merged. But the **landing page hero** still has a waitlist email form as its primary CTA, and there is no global nav bar with "Sign In" / "Sign Up" links. The pages are fully functional but unreachable unless you type the URL.

**Fix needed**: Add a navigation header to the landing page (and globally) with "Sign In" / "Sign Up" buttons, and update the hero CTA from the waitlist form to a "Get Started" button pointing to `/auth/register`.

### What to change

1. **Global nav component** (`web/src/components/nav.tsx`) -- Logo left, "Sign In" / "Sign Up" right. On mobile: hamburger or minimal inline. Auth-aware: if logged in, show user avatar/initial + "Dashboard" link instead.
2. **Landing page hero** (`[web/src/components/landing/hero.tsx](web/src/components/landing/hero.tsx)`) -- Replace waitlist form with "Get Started Free" primary CTA linking to `/auth/register`. Keep the "Or try it now -- snap your W-2" demo link below it. Optionally keep waitlist as a secondary path.
3. **Wire nav into layout** (`[web/src/app/layout.tsx](web/src/app/layout.tsx)`) -- Include the nav globally (excluded on auth pages where the layout already has its own header).

---

## Sprint 3 Engineering Tasks -- What is Next

Sprint 2 (OCR Demo) is 4/4 complete. Sprint 3 (Full MVP) is now 2/7 complete (2.1 backend auth + 2.2 frontend auth). Here is the remaining task order:


| Priority | Task                               | Description                                                                                                                | Est. |
| -------- | ---------------------------------- | -------------------------------------------------------------------------------------------------------------------------- | ---- |
| 1        | **2.2 polish**                     | Add sign up/login buttons to landing page + global nav (the fix above)                                                     | 2-3h |
| 2        | **2.3 Filing Flow Layout**         | Progress bar, step navigation, filing CRUD endpoints, data confirmation page with OCR auto-fill cascade                    | 6-8h |
| 3        | **2.4 Tax Calculator**             | Filing details page (filing status selection), tax calculator engine (integer cents math), AI insights, 100% test coverage | 6-8h |
| 4        | **2.5 Return Summary + PDF**       | Animated refund reveal, breakdown charts, PDF generation via @react-pdf/renderer, viral share card                         | 6-8h |
| 5        | **2.6 Component Library + Polish** | SSNInput, CurrencyDisplay, SecureBadge, skeleton states, mobile audit at 375px                                             | 4-6h |
| 6        | **2.7 Analytics + Production**     | PostHog events, Sentry DSN, CI pipeline (GitHub Actions)                                                                   | 4-6h |


### Recommendation

Start with **2.2 polish** (nav + CTA buttons) since it is small and immediately visible, then move into **2.3 Filing Flow** which is the next major feature. Tasks 2.3 through 2.5 form the core filing pipeline and should be done in sequence. Task 2.6 (polish) and 2.7 (analytics) can happen in parallel or after.

Also worth noting: TASKS.md still shows Task 2.2 as not done -- should be marked complete when we start work.