---
name: fix-login-oauth
overview: Diagnose and fix the OAuthCreateAccount error, surface clear login state on the homepage, and add tests to verify Google sign-in flow locally.
todos:
  - id: repro-logs
    content: Reproduce login error and capture server logs
    status: completed
  - id: schema-check
    content: Verify Prisma schema/migration for emailVerified and clean auth tables
    status: completed
  - id: login-ux
    content: Improve homepage/login signed-in and error messaging
    status: completed
  - id: playwright-test
    content: Add Playwright login smoke test with mocked provider
    status: completed
  - id: manual-verify
    content: Run manual Google login to confirm redirect and welcome chip
    status: completed
---

# Fix OAuth Login and Surface State

1) Reproduce + inspect error

- Re-run login locally, capture server logs and NextAuth error code. Confirm Prisma schema/migrations applied and DB rows for User/Account are clean.

2) Fix adapter schema mismatch

- Ensure `emailVerified` column exists and is nullable in the DB; regenerate Prisma client if needed. Clear existing NextAuth tables to remove bad records.

3) Add clear login state UX

- On `/` show signed-in pill and assistant link; on `/login` show concise error text if present and a single retry button.

4) Add automated checks

- Add a Playwright smoke test that stubs NextAuth provider (test-only) to assert successful session creation and homepage welcome state.

5) Verify end-to-end

- Manual: run dev server, perform Google login, confirm redirect to `/assistant` and welcome chip. Review logs for any adapter errors.