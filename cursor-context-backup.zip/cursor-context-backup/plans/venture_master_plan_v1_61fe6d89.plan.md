---
name: Venture Master Plan v1
overview: "The ONE authoritative plan for the entire venture. Supersedes ALL prior plans. Includes: LLC naming (Section 0B), trademark/legal risk (Section 0C), valuation (Section 0D), AI model routing strategy (Section 0E), Trinkets product line (Section 0F), brand palettes, 50-state data pipeline (Section 3B), command center spec (Section 3), McKinsey self-review with 12+ findings."
todos:
  - id: p0-domains
    content: "P0.1-P0.2: launchfree.ai + filefree.ai PURCHASED. Migrate filefree.tax to filefree.ai (Vercel, DNS, 301s)."
    status: pending
  - id: p0-infra
    content: "P0.3-P0.7: Google Workspace setup (add paperworklabs.com + Olga seat), GDrive HQ folder, secure @launchfree handles, form Paperwork Labs LLC in CA + DBA filings, migrate DNS subdomains to paperworklabs.com."
    status: pending
  - id: p0-legal
    content: "P0.8-P0.9: File FILEFREE + LAUNCHFREE trademarks on USPTO Supplemental Register (~$2,100 total). Add Content Review Gate checklist to all persona .mdc files. Update privacy/terms pages per Section 0C."
    status: pending
  - id: p1-monorepo
    content: "Phase 1: Restructure repo into pnpm workspace monorepo. Extract packages/ui+auth+analytics. Scaffold launchfree + studio + trinkets apps. Update infra."
    status: pending
  - id: p1-5-trinkets
    content: "Phase 1.5: Build first trinket (financial calculators) manually to establish pattern. Create docs/templates/trinket-one-pager.md + trinket-prd.md. Test Trinket Factory agent pipeline (GPT-5.4 Discovery -> Claude Sonnet PRD -> Claude Sonnet Build). 3-5 days."
    status: pending
  - id: p2-state-data
    content: "Phase 2: Build 50-state data pipeline (Section 3B). AI-extract all 50 states from Tax Foundation + aggregator tables. Source registry, Zod schemas, state engine, sanity checks, 3 n8n workflows (weekly source monitor, monthly deep validator, annual refresh). ~6 hrs human review."
    status: pending
  - id: p3-launchfree
    content: "Phase 3: Build LaunchFree MVP (landing page, formation wizard, PDF gen, RA credits, Stripe, dashboard, legal pages)."
    status: pending
  - id: p4-command-center
    content: "Phase 4: Build paperworklabs.com command center -- full spec (13 admin pages in 3 tiers). Tier 1: company landing page, mission control, agent monitor, infra health. Tier 2: analytics, support inbox, social command, state data. Tier 3: revenue, campaigns, user intelligence."
    status: pending
  - id: p5-user-intelligence
    content: "Phase 5: Build User Intelligence Platform (packages/cross-sell, packages/email, venture identity, user events/segments, onboarding emails, recommendation engine v1, campaign system with CAN-SPAM compliance)."
    status: pending
  - id: p6-agents
    content: "Phase 6: Restructure all personas (9 venture-wide updates, 3 splits, 6 new -- including agent-ops.mdc). Build faceless social pipeline. Build 12 new n8n workflows. Migrate Notion to GDrive."
    status: pending
  - id: p7-filefree-prep
    content: "Phase 7 (Oct 2026): Resume FileFree Sprint 4, Column Tax integration, audit shield partnership, Refund Plan, cross-sell campaigns."
    status: pending
  - id: p8-filefree-launch
    content: "Phase 8 (Jan 2027): MeF transmitter, e-file go-live, Tax Opt Plan, Product Hunt launch."
    status: pending
  - id: cleanup-plans
    content: Archive 15 superseded plan files (including deep_research_tightening + utility_tool_empire_strategy + naming_ra_trinkets_updates). Create .cursor/rules/plans.mdc ordering rule. Create .cursor/plans/archive/ directory. Update docs/KNOWLEDGE.md with D35-D45. Update docs/TASKS.md with venture-wide sprint sections.
    status: pending
isProject: false
---

# Venture Master Plan v1

**Date**: March 12, 2026 | **Supersedes**: All prior strategy plans including deep_research_tightening (5 plans archived)

---

## 0. Venture Overview

**Model**: One human + AI agent workforce + partnerships co-founder (outcome-driven, flexible commitment)

**Products**:

- **LaunchFree** (launchfree.ai) -- Free LLC formation service ($0 service fee; user pays state filing fees only, disclosed upfront). AI-powered 50-state comparison helps users pick the cheapest, best-fit state. Revenue: RA credits, banking/payroll/insurance referrals. Launches Summer 2026.
- **FileFree** (filefree.ai) -- Free tax filing. Revenue: refund routing, financial referrals, audit shield, Tax Opt Plan. Launches January 2027.
- **Trinkets** (tools.filefree.ai) -- Collection of simple utility tools (financial calculators, converters, generators). Revenue: AdSense + cross-sell to main products. Complexity: LOW. Built as `apps/trinkets/` in monorepo. See Section 0F.

**HQ**: paperworklabs.com -- Venture command center, admin dashboard, agent monitor, cross-sell campaigns. Public portfolio page + authenticated `/admin/` panel.

**Personal site**: sankalpsharma.com -- Founder's personal portfolio/blog. Links to Paperwork Labs and products. Separate from company ops.

**Entity**: Paperwork Labs LLC (California). DBA filings for "FileFree", "LaunchFree", and "Trinkets". See Section 0B for naming research, legal structure, and CA vs WY comparison.

**Trademark status**: "FILEFREE" and "LAUNCHFREE" to be filed on USPTO Supplemental Register. See Section 0C for full trademark and legal risk framework.

**Domains purchased**: paperworklabs.com, filefree.ai, launchfree.ai (March 2026). Existing: filefree.tax, sankalpsharma.com. Also owned: axiomfolio.com, launchfree.llc, taxfilefree.com (not actively used).

**AI Model Strategy**: 9 models across 7 roles. See Section 0E for authoritative routing registry (owned by AI Ops Lead persona).

**Monthly burn (real)**: ~~$284/mo. Breakdown: Hetzner $6 + Render x2 $14 + Google Workspace x2 $12 + domains ~$20 + OpenAI ~$10 + ElevenLabs $5 + cyber insurance ~$150 (est. $1,800/yr amortized) + CA franchise tax ~$67 (est. $800/yr amortized). At scale add: Stripe fees (2.9%+$0.30 per transaction), variable AI costs (~~$0.005-0.02/OCR doc, ~$15-17/mo social pipeline), partner wholesale costs. Vercel/Neon/Upstash all free tier until scale triggers listed in FINANCIALS.md.

---

## 0B. LLC Naming: Research-Backed Decision

### DECIDED: Paperwork Labs LLC (March 2026)

**Name**: Paperwork Labs LLC
**Domain**: paperworklabs.com (purchased March 2026)
**Website**: Clean static portfolio page at paperworklabs.com (see spec below)

### Why "Paperwork Labs"

**Thematic fit**: Both FileFree and LaunchFree literally eliminate paperwork (tax forms, LLC filings). The name is a wink at the problem we solve. "Labs" signals "we build things" -- the standard convention for multi-product tech holding companies.

**Research-backed**:

- "Labs" suffix is the #2 most common compound naming pattern in successful tech companies (23% of YC-backed companies use compound constructions) ([source: TradmarkLens](https://trademarklens.com/guides/us-tech-startup-naming-trends))
- .com available (paperworklabs.com) -- critical since 67%+ of successful startups use .com
- Zero existing companies named "Paperwork Labs" in US tech/fintech
- "PAPERWORKS" trademark (Serial #98659864) is Class 016 (paper stationery) -- no conflict with our Class 036/042
- paperwork.to (Dubai Document AI startup) is in a completely different market/country -- no confusion for a US holding LLC
- "Paperwork Forms" (Canada, 1 employee, municipality forms) is a different name -- "Labs" differentiates

**Names considered and rejected**:

- Toastworks LLC -- Toast Inc. (NYSE: TOST, $25B) sued Toast Labs Inc. in 2016. Too risky.
- Halftoast LLC -- Still in Toast Inc. blast radius.
- Butterside Labs -- "Butters" is British slang for ugly. Unnecessary baggage.
- Crisp Labs LLC -- Clean but less thematically connected than "Paperwork."
- Sharma Ventures LLC -- Personal name signals "small operation," not scalable.

### paperworklabs.com Static Site

Clean, minimal holding company portfolio page. Not a product site -- a company page.

- **Content**: Company name, one-liner ("We build tools that eliminate paperwork"), portfolio cards for FileFree / LaunchFree / Trinkets with links, team section (Sankalp + Olga), legal footer
- **Tech**: Static page served from `apps/studio/` on Vercel free tier with `paperworklabs.com` custom domain
- **Design**: Studio/Command Center zinc palette (neutral, professional)
- **Legal footer**: "Paperwork Labs LLC | California | FileFree, LaunchFree, and Trinkets are products of Paperwork Labs LLC"
- **Cost**: $0/yr hosting (Vercel free), ~$12/yr domain renewal

### Structure (Confirmed -- California LLC)

**Why California, not Wyoming (DECIDED March 2026)**:

The original plan recommended Wyoming. After analysis, California is the clear choice for a CA-resident founder:


| Factor                     | Wyoming                                                     | California                               |
| -------------------------- | ----------------------------------------------------------- | ---------------------------------------- |
| Filing fee                 | $100                                                        | $70                                      |
| Annual report              | $60/yr                                                      | $0 (no annual report required)           |
| Franchise tax              | $0 (but CA charges you anyway since founder is CA resident) | $800/yr (first year exempt for new LLCs) |
| RA cost                    | $25-29/yr                                                   | $49-125/yr                               |
| Privacy                    | Excellent (no owner disclosure)                             | Poor (public disclosure required)        |
| Foreign registration in CA | Required (~$70 extra)                                       | Not needed                               |
| Asset protection           | Strong (charging order protection for single-member)        | Weak                                     |
| **Year 1 total**           | **~$1,094** (with CA foreign reg + franchise tax)           | **~$119** (first year franchise exempt)  |
| **Year 2+ total**          | **~$985/yr**                                                | **~$849/yr**                             |


**Bottom line**: Wyoming's $0 income tax doesn't help a CA resident -- California taxes all your income regardless of where the LLC is formed. Wyoming would require foreign LLC registration in CA ($70), double RA fees, and double compliance. The only real Wyoming advantages (privacy, charging order protection) don't justify ~$975/yr extra pre-revenue.

**Revisit trigger**: When revenue exceeds $250K and asset protection justifies dual-state cost, consider Wyoming holding company with CA subsidiary.

**Now (pre-revenue):** Single California LLC (Paperwork Labs LLC) + DBA filings for "FileFree", "LaunchFree", and "Trinkets"

- California filing: $70
- DBA filing: ~$10-25 per name
- Franchise tax: $0 first year (exempt for new LLCs), $800/yr after
- RA: ~$49/yr
- Total year 1: ~$119-145

**At $50K+ combined revenue:** Convert to holding company structure

- Parent LLC (Paperwork Labs LLC) stays as-is
- Create FileFree LLC (subsidiary)
- Create LaunchFree LLC (subsidiary)
- Each subsidiary has its own bank account, EIN, and liability shield
- Clean separation for future acquisition or investment

---

## 0C. Trademark and Legal Risk Framework

### CRITICAL: filefree.com Is Owned by Intuit

**Confirmed via WHOIS** (March 11, 2026):

- Domain: filefree.com
- Registrar: MarkMonitor Inc. (Intuit's enterprise registrar)
- Created: June 29, 1999 (27 years ago)
- Status: clientDeleteProhibited, clientTransferProhibited, clientUpdateProhibited
- DNS: Akamai (same infrastructure as intuit.com)

Intuit has owned this domain since before TurboTax even offered online filing. They also faced FTC enforcement for deceptive "free" advertising (TurboTax "free" was ruled misleading because ~100M filers were ineligible). This means Intuit is HYPERSENSITIVE to "free" branding in the tax space.

### Trademark Risk Analysis

**"FileFree" as a trademark:**

- Likely **descriptive** ("file [taxes] free") -- the USPTO would probably refuse registration on the Principal Register without proof of secondary meaning (requires 5 years of substantially exclusive commercial use)
- CAN be registered on the **Supplemental Register** immediately -- this establishes a priority date, allows use of (R) symbol on the Supplemental Register
- Being descriptive is a **double-edged sword**: harder for US to register, but also harder for Intuit to claim exclusive rights to a descriptive phrase
- **FreeTaxUSA** (TaxHawk, Inc.) successfully built and defended a descriptive mark in the same space -- but they've been operating since 2001

**"LaunchFree" as a trademark:**

- Also descriptive, but NO known competitor claims it
- Easier to defend than FileFree -- no Intuit domain conflict
- Same registration strategy: Supplemental Register first

### Trademark Filing Plan


| Mark                           | Classes                                                   | Register              | Cost            | Timeline                                         |
| ------------------------------ | --------------------------------------------------------- | --------------------- | --------------- | ------------------------------------------------ |
| FILEFREE (stylized wordmark)   | Class 036 (Financial services), Class 042 (SaaS)          | Supplemental Register | $350 x 2 = $700 | File after product launch (need specimen of use) |
| LAUNCHFREE (stylized wordmark) | Class 035 (Business formation services), Class 042 (SaaS) | Supplemental Register | $350 x 2 = $700 | File after product launch                        |
| FILEFREE (logo/design mark)    | Class 036, Class 042                                      | Supplemental Register | $350 x 2 = $700 | File with wordmark, separate application         |
| Total                          |                                                           |                       | ~$2,100         | All within 90 days of launch                     |


After 5 years of commercial use: petition to move to Principal Register with evidence of acquired distinctiveness (user counts, media coverage, brand recognition surveys).

### STRICT LEGAL GUIDELINES (All Personas Must Follow)

**Brand Name Rules:**

1. ALWAYS write "FileFree" (one word, two capital F's). NEVER "File Free", "file free", "Filefree", "FILE FREE", "File-Free"
2. ALWAYS write "LaunchFree" (one word, L and F capitalized). NEVER "Launch Free", "launch free", "Launchfree"
3. When used in a sentence, the brand name is a PROPER NOUN: "FileFree helps you file taxes" (not "file free with FileFree")
4. NEVER use "file free" as a verb phrase in marketing copy. Say "file your taxes for free" or "file at zero cost" -- keep the brand name and the concept separate
5. Domain references: always `filefree.tax` or `filefree.ai` -- NEVER reference `filefree.com` anywhere, ever

**FTC "Free" Compliance Rules:**

1. Our service IS actually free for ALL users. This is our strongest legal position. The moment we add a condition that makes filing not-free for some users, we are exposed to the EXACT FTC action that hit Intuit
2. DOCUMENT THIS COMMITMENT: "Filing is free. 100% of filers. 100% of the time. No income limits. No complexity limits for supported forms. No asterisks. No small print."
3. If we EVER add paid tiers for filing, the free tier must remain fully functional -- not artificially limited to push users to pay
4. RA credits on LaunchFree: MUST clearly disclose that base RA price is $49/yr and credits reduce or eliminate the cost. Cannot advertise "Free RA" without immediately visible qualification

**Circular 230 Compliance (Tax Content):**

1. We provide TAX EDUCATION, not TAX ADVICE. This distinction is legally critical.
2. Every screen, email, social post, or AI response that discusses tax topics must include: "This is general tax information, not tax advice. For advice specific to your situation, consult a qualified tax professional."
3. NEVER say "you should" + tax action (e.g., "you should claim the standard deduction"). ALWAYS say "many filers in your situation" or "the standard deduction is typically..."
4. Social media: EVERY tax tip post ends with the disclaimer. No exceptions. Build it into the Postiz template.

**UPL (Unauthorized Practice of Law) Compliance (LLC Content):**

1. We provide BUSINESS FORMATION SERVICES, not LEGAL ADVICE.
2. NEVER say "you should form in Delaware" or "you need an operating agreement." ALWAYS say "many entrepreneurs choose Delaware because..." or "operating agreements are commonly used to..."
3. Every LaunchFree formation page includes: "LaunchFree provides business formation services. We are not a law firm and do not provide legal advice. For legal questions specific to your situation, consult a licensed attorney."
4. State-specific recommendations: present data ("Wyoming charges $100, Delaware charges $140, California charges $70 + $800 annual franchise tax") and let the user decide. Don't recommend.

**Cross-Sell Email Compliance:**

1. Opt-in checkbox (unchecked by default) on every signup form: "I consent to [LLC Name] using my information across FileFree, LaunchFree, and related services to send me product updates and recommendations. I can unsubscribe from any product at any time."
2. Every email includes: physical business address (CAN-SPAM), one-click unsubscribe, clear sender identification
3. Cross-product emails only sent to users who opted in
4. FTC disclosure on any partner/affiliate recommendation: "We may earn a commission if you sign up through this link."

**Content Review Gate:**
Every piece of user-facing content (email, social post, in-app message, landing page copy) must pass this checklist before publishing:

- Brand names spelled correctly (FileFree, LaunchFree -- proper nouns, correct casing)
- "Free" claims are 100% accurate with no hidden conditions
- Tax content uses education framing, not advice ("many do X" not "you should X")
- Legal content uses services framing, not advice
- Circular 230 / UPL disclaimer present where applicable
- FTC affiliate disclosure present if recommending partner products
- CAN-SPAM compliant (unsubscribe, physical address, honest subject line)
- No reference to filefree.com anywhere

### Legal Risk Matrix (Stress Test Addition)


| Risk                                              | Severity | Gap                                                                                                                                                                                                                 | Remediation                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| ------------------------------------------------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **50-state data errors -> incorrect LLC filings** | CRITICAL | Disclaimers cover opinions, not facts. Wrong filing fees or deadlines = negligence exposure even with disclaimers.                                                                                                  | Add source-linking on every data point ("Fee: $70, source: CA SOS, last verified: 2026-03-01"). Add prominent "last verified" date on every state page. Add user confirmation step ("I confirm I've verified this fee on [state SOS link]"). Add ToS data accuracy disclaimer: "Filing fees and deadlines are sourced from state government websites and verified monthly. We make every effort to keep this data current but cannot guarantee accuracy. Always verify with your state's Secretary of State before filing." |
| **FTC "Free" scrutiny**                           | HIGH     | "Free LLC" headline is misleading re: state fees. RA credit system is a landmine ("free RA" claim). Intuit precedent heightens FTC scrutiny of "free" claims in adjacent spaces.                                    | **RULES**: (1) NEVER use "Free LLC" as a standalone headline. Always: "Free LLC Formation Service" or "$0 Service Fee." (2) State filing fees must appear in the same visual field as any "free" claim -- not below the fold, not on a different page. (3) RA credits: NEVER say "Free RA." Always: "RA starting at $49/yr. Earn credits to reduce your cost." (4) Every landing page with "free" in the headline must pass FTC Free Guide compliance review.                                                               |
| **AI operating agreements (UPL risk)**            | HIGH     | "AI-generated, state-specific operating agreement" crosses from template fill-in to document drafting. LegalZoom survived UPL challenges specifically because they did NOT auto-generate -- they offered templates. | **DECISION**: Use template model, not generation. LaunchFree provides state-specific operating agreement TEMPLATES (pre-written by a licensed attorney, stored as PDFs). AI EXPLAINS clauses ("This section covers member voting rights. Most single-member LLCs use...") but does NOT select, modify, or draft clause language. Marketing: "Operating agreement template included" not "AI-generated operating agreement." The attorney consultation (Section 0G #3) should validate this approach.                        |
| **Cross-sell consent language**                   | MEDIUM   | Current: "I'd like to hear about other [LLC Name] products." Too vague for CCPA and lacks per-brand granularity. Missing TCPA gap if SMS is ever added.                                                             | **FIX**: Replace with explicit cross-product data use: "I consent to [LLC Name] using my information across FileFree, LaunchFree, and related services to send me product updates and recommendations. I can unsubscribe from any product at any time." Add separate SMS consent checkbox if SMS is ever added (TCPA requires express written consent for marketing texts). Add per-brand unsubscribe capability in email footer: "Unsubscribe from FileFree emails                                                         |


### Legal Protection Checklist (Stress Test Addition)

Before collecting ANY user PII or processing ANY tax/legal data:


| Item                                      | Status   | Deadline         | Notes                                                                                                                                  |
| ----------------------------------------- | -------- | ---------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| E&O + Cyber liability insurance ($1M)     | NOT DONE | Before first SSN | $1,500-3,000/yr. Covers data breach, errors in tax calcs, professional liability                                                       |
| Data breach response plan (SANS template) | NOT DONE | Before first SSN | 2-page doc: discovery, containment, notification, remediation. State AG notification timelines vary (CA: 72hrs)                        |
| Terms of Service (attorney-reviewed)      | NOT DONE | Before launch    | Limitation of liability, arbitration clause, data accuracy disclaimer, AI-assisted filing disclosure                                   |
| Privacy Policy (CCPA + state laws)        | NOT DONE | Before launch    | Data collection, retention (24hr for images), sharing (Cloud Vision, OpenAI -- with SSN masking), deletion rights                      |
| Tax filing disclaimer (Circular 230)      | NOT DONE | Before launch    | On every screen that touches tax data                                                                                                  |
| LLC formation disclaimer (UPL)            | NOT DONE | Before launch    | On every LaunchFree page                                                                                                               |
| Startup attorney consultation             | NOT DONE | Before Phase 3   | 1 hour, ~$300-500. Key questions: UPL boundaries for AI formation guidance, RA liability exposure, tax prep liability vs CPA liability |


**Liability Comparison -- How Competitors Handle It**:


| Company                                   | Approach                                                                                                          | Key Protections                                                                                                                     |
| ----------------------------------------- | ----------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------- |
| **Credit Karma Tax** (now Cash App Taxes) | "Not a substitute for professional tax advice." Accuracy guarantee (pays IRS penalties if their math is wrong).   | Strong ToS limitation of liability. E&O insurance. Accuracy guarantee builds trust.                                                 |
| **FreeTaxUSA**                            | "$100K accuracy guarantee." Covers IRS penalties from calculation errors.                                         | Clear "education not advice" framing. Guarantee is capped and excludes user input errors.                                           |
| **LegalZoom**                             | "We are not a law firm." Survived multiple UPL lawsuits by positioning as document preparation, not legal advice. | Operating agreement TEMPLATES, not custom drafting. Clear disclaimers on every page. Separate lawyer marketplace for actual advice. |
| **TurboTax**                              | Expert review add-on ($$$). Free tier has no accuracy guarantee.                                                  | Massive legal team. FTC consent decree for "free" advertising.                                                                      |


**Our approach**: Follow FreeTaxUSA model for tax (accuracy guarantee capped at $10K, covers OUR calculation errors only, not user input errors). Follow LegalZoom model for LLC (templates, not drafting). Get E&O insurance before collecting any data.

### 50-State Data Accuracy Standard (Stress Test Addition)

Every state data point displayed to users must meet this standard:

1. **Source-linked**: Every fee, deadline, and requirement shows its source ("CA SOS, last verified 2026-03-01")
2. **Freshness visible**: "Last verified" date displayed prominently. If >90 days old, show warning badge.
3. **User confirmation**: Before any filing action, user sees: "Please verify this information on [state SOS website link] before proceeding. Filing fees and requirements can change."
4. **Automated freshness**: n8n State Data Validator (Agent #21) checks DAILY for volatile states (CA, NY, TX, FL, IL, WA, NJ, MA, GA, PA) and WEEKLY for all others. Any state >30 days since last verification shows yellow warning. Any state >60 days triggers red alert to Compliance Monitor and EA daily briefing.
5. **Error correction**: If a user reports incorrect data, treat it as a P0 bug. Fix within 24 hours, notify affected users, log in incident report.

---

## 0D. Valuation Estimate (Realistic)

### Comparable Companies


| Company              | Revenue       | Valuation                             | Multiple      | Model                                     | Notes                                   |
| -------------------- | ------------- | ------------------------------------- | ------------- | ----------------------------------------- | --------------------------------------- |
| Credit Karma         | ~$1B (2019)   | $7.1B (2020 acq)                      | 7.1x revenue  | Free credit scores, referral monetization | Closest model comp to FileFree          |
| LegalZoom            | $751M LTM     | $994M EV (2026)                       | 1.3x revenue  | LLC formation + compliance, $79-299/pkg   | Public, mature, compressed multiple     |
| ZenBusiness          | Est. $200M+   | $1B+ (last raise)                     | ~5x revenue   | LLC formation, $0-349/pkg                 | VC-backed                               |
| Formation Nation     | Est. $20-30M  | $49M cash + $15M earnout + $50M stock | ~3-4x revenue | LLC formation (Inc Authority brand)       | Acquired by LegalZoom Feb 2025          |
| FreeTaxUSA (TaxHawk) | Est. $50-100M | Private (est. $200-500M)              | ~4-5x est.    | Free federal, $15 state                   | Bootstrapped since 2001, ~150 employees |


### Our Venture Valuation Scenarios

**Valuation Method**: EV/Revenue multiple. For bootstrapped fintech with AI, current market range is 4-8x revenue for growth-stage, 2-4x for early-stage ([source: Finro, WindsorDrake Q1 2026](https://www.finrofca.com/news/fintech-valuation-mid-2025)).

**Scenario A: Conservative (Year 2, Combined ~$100K revenue)**

- Multiple: 3-5x (early-stage bootstrapped)
- Valuation: $300K-500K
- Context: Pre-traction, product live but small user base

**Scenario B: Moderate (Year 3, Combined ~$500K revenue, 50K+ users)**

- Multiple: 5-8x (growth-stage fintech with AI + cross-sell)
- Valuation: $2.5M-4M
- Context: Proven unit economics, two products cross-selling, 50K+ combined users

**Scenario C: Aggressive (Year 4-5, Combined ~$2M revenue, 200K+ users)**

- Multiple: 6-10x (scaled fintech platform)
- Valuation: $12M-20M
- Context: MeF transmitter live ($0/return moat), 50-state coverage, proven referral revenue
- Acquisition interest from: LegalZoom (cross-sell), Intuit (competitive threat removal), fintech aggregators

**Scenario D: Home Run (Year 5+, Combined ~$5M+ revenue, 500K+ users)**

- Multiple: 8-12x (if "AI financial advisor" narrative takes hold)
- Valuation: $40M-60M
- Context: Credit Karma playbook proven at smaller scale, AI advisory relationship established
- This requires: partnership revenue firing on all cylinders, advisory product retention, brand trust at scale

**Formation Nation comp caveat (stress test)**: LegalZoom paid ~$115M for Formation Nation (Inc Authority brand), but Formation Nation was a mature, profitable business with estimated $20-30M revenue and years of operating history. Comparing a pre-revenue startup to an acquired mature company is misleading. The relevant takeaway is that the business formation MARKET commands 3-4x revenue multiples, which validates the sector. A pre-revenue startup in this space would need to demonstrate traction (10K+ users, growing MoM) before any acquisition interest materializes.

**"Home run" multiple reality check (stress test)**: The 8-12x multiple in Scenario D assumes the "AI financial advisor" narrative takes hold with investors, which requires proof points (high NPS, demonstrated advisory value, user retention). For a single-founder bootstrapped operation, realistic exit multiples are 4-6x revenue until institutional investors or strategic acquirers validate the platform thesis. The 8-12x range is aspirational and requires Credit Karma-level user engagement data.

**What makes our valuation story unique**: Two products with shared infrastructure and cross-sell moat. Each product individually is worth 3-5x revenue. Together with cross-sell data and AI advisory relationship, the portfolio premium could push multiples higher. This is the Credit Karma playbook: the platform IS the data, and the data compounds with every user. But Credit Karma took 8 years to reach acquisition -- plan accordingly.

---

## 0E. AI Model Routing Strategy (Authoritative -- Owned by AI Ops Lead)

**Last reviewed**: March 12, 2026 | **Next review**: April 12, 2026

### Routing Principle: Quality-First

Use the best model for the task. Only downgrade when a cheaper model produces equivalent quality (not "good enough" -- equivalent). The founder is willing to pay more for better results. Cost optimization happens by routing to the right tier, not by forcing cheaper models where quality suffers.

The AI Ops Lead persona (`agent-ops.mdc`) owns this registry and all model routing decisions. Engineering implements but does not choose models.

**GPT-5 readiness**: When GPT-5 releases, evaluate immediately. If it outperforms current assignments at comparable cost, swap. Do not wait for a scheduled review cycle.

### Model Landscape (March 2026)


| #   | Model             | Input/1M | Output/1M | Context | Role                                                                                                                       |
| --- | ----------------- | -------- | --------- | ------- | -------------------------------------------------------------------------------------------------------------------------- |
| 1   | GPT-4o-mini       | $0.15    | $0.60     | 128K    | **The Intern**: cheapest bulk extraction, classification, summaries                                                        |
| 2   | Gemini 2.5 Flash  | $0.30    | $2.50     | 1M      | **The Workhorse**: smart + cheap. Wins 5/8 benchmarks vs GPT-4o at 81% less cost. Default for non-specialized tasks.       |
| 3   | o4-mini           | $1.10    | $4.40     | 200K    | **The Math Brain**: budget reasoning. 99.5% AIME 2025. Tax/financial verification.                                         |
| 4   | Gemini 2.5 Pro    | $1.25    | $10.00    | 1M      | **The Researcher**: #1 Chatbot Arena. Deep analysis, long-context research, SEO content.                                   |
| 5   | GPT-4o            | $2.50    | $10.00    | 128K    | **The Creative Director**: brand voice, social scripts, marketing copy. Confirmed superior "distinctive narrative pull."   |
| 6   | GPT-5.4           | $2.50    | $15.00    | 1M      | **The Autonomous Agent**: only model with native computer-use. Browsing, form filling, competitor analysis.                |
| 7   | Claude Sonnet 4.6 | $3.00    | $15.00    | 200K    | **The Senior Engineer + Lawyer**: code (79.6% SWE-bench), compliance, instruction adherence, templates.                    |
| 8   | Claude Opus 4.6   | $5.00    | $25.00    | 1M      | **The Principal Engineer**: escalation only. 80.8% SWE-bench (only 1.2% above Sonnet). For >32K output, extended autonomy. |
| 9   | o3                | $10.00   | $40.00    | 200K    | **Nuclear Option**: complex multi-step reasoning. Dense visual analysis. Almost never needed.                              |


### Decision Tree

```
Is it deterministic? ──YES──> Code (Tier 0, $0)
        │ NO
Is it high-volume + simple? ──YES──> GPT-4o-mini ($0.15/$0.60)
        │ NO
Needs math reasoning? ──YES──> o4-mini ($1.10/$4.40)
        │ NO
Brand voice / creative copy? ──YES──> GPT-4o ($2.50/$10)
        │ NO
Browse websites autonomously? ──YES──> GPT-5.4 ($2.50/$15)
        │ NO
Code gen or compliance? ──YES──> Claude Sonnet ($3/$15)
        │ NO
Default ──> Gemini 2.5 Flash ($0.30/$2.50)
```

### Model x Workflow Registry

**FileFree**


| Workflow                      | Model            | Tier | Why                                           | ~Cost/Run |
| ----------------------------- | ---------------- | ---- | --------------------------------------------- | --------- |
| OCR field mapping (>85% conf) | GPT-4o-mini      | 1    | Cheapest structured output                    | $0.001    |
| OCR field mapping (<85% conf) | GPT-4o vision    | 2B   | Needs image understanding                     | $0.02     |
| Tax calc verification         | o4-mini          | 2    | 99.5% AIME math reasoning                     | $0.005    |
| Tax explanations (streaming)  | Claude Sonnet    | 2A   | Accuracy-critical, Circular 230               | $0.005    |
| Refund optimization tips      | Claude Sonnet    | 2A   | Educational framing, cautious                 | $0.005    |
| Error messages                | Gemini 2.5 Flash | 1.5  | Smart enough, 83% cheaper than Sonnet         | $0.001    |
| FAQ generation                | Gemini 2.5 Flash | 1.5  | General intelligence, not compliance-critical | $0.001    |


**LaunchFree**


| Workflow                   | Model            | Tier | Why                                           | ~Cost/Run |
| -------------------------- | ---------------- | ---- | --------------------------------------------- | --------- |
| State data structuring     | GPT-4o-mini      | 1    | Cheapest Zod schema mapping                   | $0.001    |
| State data deep validation | Gemini 2.5 Pro   | 2    | 1M context, #1 Arena, 50% cheaper than Sonnet | $0.01     |
| State fee lookups          | Gemini 2.5 Flash | 1.5  | Simple lookup, 90% cheaper than Sonnet        | $0.001    |
| Formation guidance AI      | Claude Sonnet    | 2A   | UPL compliance, cautious framing              | $0.01     |
| Operating agreement gen    | Claude Sonnet    | 2A   | Legal document, precision matters             | $0.03     |


**Trinket Factory**


| Workflow                    | Model            | Tier | Why                                           | ~Cost/Run |
| --------------------------- | ---------------- | ---- | --------------------------------------------- | --------- |
| Market discovery (browsing) | GPT-5.4          | 2C   | Computer-use for competitor sites             | $0.02     |
| SEO keyword analysis        | Gemini 2.5 Flash | 1.5  | Data analysis, no computer-use needed         | $0.005    |
| 1-pager from template       | Claude Sonnet    | 2A   | Best instruction adherence                    | $0.02     |
| PRD from template           | Claude Sonnet    | 2A   | Technical spec, structured output             | $0.03     |
| Code generation             | Claude Sonnet    | 2A   | 79.6% SWE-bench, best for code                | $0.10     |
| Massive refactor            | Opus 4.6         | 3    | Escalation: >32K output or multi-hour session | $0.50     |


**Social Content Pipeline**


| Workflow          | Model            | Tier    | Why                                       | ~Cost/Run |
| ----------------- | ---------------- | ------- | ----------------------------------------- | --------- |
| Script generation | GPT-4o           | 2B      | Brand voice, "distinctive narrative pull" | $0.01     |
| Image prompt gen  | Gemini 2.5 Flash | 1.5     | Accuracy, not voice. 81% cheaper.         | $0.002    |
| Image generation  | DALL-E 3         | Special | Purpose-built                             | $0.04     |
| Voiceover         | ElevenLabs Flash | Special | Purpose-built                             | $0.05     |
| Content calendar  | Gemini 2.5 Flash | 1.5     | Analytical, not creative                  | $0.002    |


**Cross-Sell & Marketing**


| Workflow            | Model            | Tier | Why                             | ~Cost/Run |
| ------------------- | ---------------- | ---- | ------------------------------- | --------- |
| Email copy          | GPT-4o           | 2B   | Brand voice critical            | $0.01     |
| Landing page copy   | GPT-4o           | 2B   | Conversion-focused creative     | $0.01     |
| SEO blog content    | Gemini 2.5 Pro   | 2    | Long-form research, 50% cheaper | $0.02     |
| Compliance review   | Claude Sonnet    | 2A   | CAN-SPAM, FTC, Circular 230     | $0.005    |
| Content Review Gate | Claude Sonnet    | 2A   | Constraint-following            | $0.01     |
| A/B test variants   | Gemini 2.5 Flash | 1.5  | Volume, test many cheaply       | $0.002    |


**Command Center / Ops**


| Workflow             | Model          | Tier | Why                            | ~Cost/Run |
| -------------------- | -------------- | ---- | ------------------------------ | --------- |
| Analytics digest     | GPT-4o-mini    | 1    | Cheapest summarization         | $0.001    |
| Competitive intel    | Gemini 2.5 Pro | 2    | Analytical depth, 1M context   | $0.02     |
| Source monitoring    | GPT-4o-mini    | 1    | Simple diff comparison         | $0.001    |
| Financial modeling   | o4-mini        | 2    | Math reasoning for projections | $0.005    |
| Legal policy updates | Claude Sonnet  | 2A   | Legal precision                | $0.02     |


### Role Distribution Summary


| Model             | Role                                | % of Tasks |
| ----------------- | ----------------------------------- | ---------- |
| GPT-4o-mini       | The Intern                          | 15%        |
| Gemini 2.5 Flash  | The Workhorse (default catch-all)   | 25%        |
| o4-mini           | The Math Brain                      | 5%         |
| Gemini 2.5 Pro    | The Researcher                      | 10%        |
| GPT-4o            | The Creative Director               | 10%        |
| GPT-5.4           | The Autonomous Agent                | 10%        |
| Claude Sonnet 4.6 | The Senior Engineer + Lawyer        | 20%        |
| Opus 4.6          | The Principal Engineer (escalation) | 3%         |
| o3                | Nuclear Option                      | 2%         |


### Monthly Cost Estimates


| Stage                | AI Agent Costs | Notes                                      |
| -------------------- | -------------- | ------------------------------------------ |
| Pre-launch (testing) | ~$4/mo         | 50 test docs, 30 test videos, 1-2 trinkets |
| Launch (100 users)   | ~$15/mo        | Real OCR, explanations, social             |
| Growth (1K users)    | ~$40/mo        | Higher volume, cross-sell campaigns        |
| Scale (10K users)    | ~$110/mo       | Still tiny vs $15-50/yr revenue per user   |


### Implementation

All model routing is implemented via **n8n** (the unified orchestration layer). Each n8n workflow node specifies its model via the AI Agent node's provider + model selection. No separate orchestration platform (Ruflo, etc.) is needed. n8n supports OpenAI, Anthropic, and Google providers natively.

### Interactive Session Guidance (Cursor IDE)

The routing strategy above covers **automated workflows** (n8n, batch operations). For interactive human-AI pair programming in Cursor:


| Session Type                             | Recommended Model               | Rationale                                                                                                                                                 |
| ---------------------------------------- | ------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Strategy / architecture / deep reasoning | Claude Opus 4.6                 | Quality delta matters for high-stakes decisions ($100K+ impact). Deeper reasoning chains, better multi-dimensional tradeoff analysis, catches edge cases. |
| Complex multi-file refactors             | Claude Opus 4.6                 | 1M context window, 80.8% SWE-bench, handles large scope without losing context.                                                                           |
| Routine coding / component building      | Claude Sonnet 4.6               | 79.6% SWE-bench (only 1.2% below Opus). 40% cheaper. Identical quality for scoped tasks.                                                                  |
| Quick fixes / single-file edits          | Claude Sonnet 4.6 or fast model | Minimal quality difference for small scope.                                                                                                               |


**Verdict**: Using Opus for strategy sessions is **not overkill**. Opus for thinking, Sonnet for typing.

### Maintenance Protocol (AI Ops Lead Responsibility)

1. **New model release**: Evaluate benchmarks + pricing vs current assignments. Generate swap recommendation within 48 hours.
2. **Monthly**: Pull API usage from provider dashboards, calculate cost per workflow, flag anomalies. Update `docs/AI_MODEL_REGISTRY.md`.
3. **Quarterly**: Full persona audit + model assignment review.
4. **When adding workflows**: Consult this registry's decision tree before choosing a model.

---

## 0F. Trinkets: Utility Tool Revenue Stream

### Overview

Trinkets is a collection of simple, client-side utility tools (financial calculators, converters, generators) that serve three purposes:

1. **Test the agent infrastructure** -- the Trinket Factory pipeline validates our end-to-end agent workflow (Discovery -> PRD -> Build)
2. **Build shared libraries** -- the first trinket establishes reusable patterns (`packages/tool-template`)
3. **Passive revenue** (bonus) -- AdSense monetization, cross-sell to FileFree/LaunchFree

### Market Reality (Data-Backed)

The utility tool space is dominated by established players:

- **iLovePDF**: 216M monthly visits, DA 91, ~$4M/yr (ads + premium). Founded 2010.
- **SmallPDF**: 61M monthly visits, DA 83, ~$11M/yr (freemium SaaS at $9/mo). Founded 2013.
- **PDF2Go**: 5-12M monthly visits, ~$670K/yr (AdSense + credits). Founded 2009.

SEO reality for new domains: 3-6 months for long-tail keywords (KD < 30), 6-12 months for meaningful traffic, 12+ months for competitive keywords. A new domain will NOT rank for "pdf to word" (KD 80+) within Year 1.

**Revenue projections (conservative)**: Year 1: ~$50-300. Year 2: ~$5K-20K. Year 3+: $20K-100K if SEO compounds.

### The Trinket Factory Agent Pipeline

Instead of manually picking tools, the agent infrastructure discovers, specs, and builds them:

```
Stage 1: DISCOVERY (GPT-5.4)
  Computer-use: browse competitor sites, analyze UX/pricing/SEO
  + Gemini Flash for SEO keyword analysis
  Output: 1-pager from template (docs/templates/trinket-one-pager.md)
  -> Human reviews -> Approve/Reject

Stage 2: SPEC (Claude Sonnet)
  Takes approved 1-pager as input
  Writes precise PRD from template (docs/templates/trinket-prd.md)
  -> Human reviews -> Approve/Reject

Stage 3: BUILD (Claude Sonnet)
  Takes approved PRD + established pattern from first trinket
  Generates code, creates PR for human review
  79.6% SWE-bench = best code quality
```

### First Trinket: Financial Calculators

Pre-decided idea (agent validates, not selects). Includes:

- Mortgage calculator, compound interest, savings goal, budget planner
- All client-side JavaScript (zero API costs, zero server costs)
- Aligns with FileFree's financial brand (cross-sell opportunity)
- Hosted on Vercel free tier as `apps/trinkets/` in the monorepo

### Technical Pattern

```
apps/trinkets/                  (Next.js SSG, Vercel free, tools.filefree.ai)
  src/app/
    calculators/
      mortgage/page.tsx
      compound-interest/page.tsx
      savings-goal/page.tsx
      budget-planner/page.tsx
    converters/                  (future: pdf-to-word, image converters)
    generators/                  (future: qr-code, invoice, etc.)
  src/components/
    tool-layout.tsx              (shared: header, cross-sell CTA, ad slots, footer)
    seo-head.tsx                 (per-tool JSON-LD, meta tags)
    ad-unit.tsx                  (Google AdSense)
    cross-sell-cta.tsx           (links to FileFree/LaunchFree)
```

**URL structure**: Use subdirectory-style paths for topical clustering (helps Google understand authority):

- `tools.filefree.ai/calculators/mortgage`
- `tools.filefree.ai/calculators/compound-interest`
- `tools.filefree.ai/converters/pdf-to-word` (future)

All processing is browser-based (pdf-lib, heic2any, browser-image-compression, qrcode.js). Zero server cost. Zero backend needed. No auth required -- cross-sell CTAs funnel traffic to FileFree/LaunchFree.

### Domain Strategy

Stay on `tools.filefree.ai` subdomain. Do NOT buy individual domains per trinket. SEO research confirms: subdomain inherits some authority from parent domain, individual domains start at DA 0 and cost $10-15/yr each. At Year 1 trinkets revenue of $50-300, buying 15+ domains is negative ROI.

**Graduation criteria**: If a single trinket exceeds 10K monthly visits, consider buying a standalone domain and 301-redirecting from the subdomain URL. This is a growth optimization, not a launch decision.

### Build Timing

Phase 1.5: After monorepo restructure (Phase 1), before 50-state data pipeline (Phase 2). Time budget: 3-5 days. Then hands-off for 6 months while building main products. Check traffic at Month 6.

---

## 0F-2. AI Branding in Financial Services: Help or Hurt?

**Research finding**: AI branding in financial services is a double-edged sword. The answer depends on what you're branding as AI-powered.

**Where "AI-powered" HELPS trust**:

- **Automation / speed**: "AI reads your W-2 in seconds" -- people trust AI for tedious data entry
- **Cost reduction**: "AI eliminates the middleman, so filing is free" -- people understand AI = cheaper
- **Accuracy in calculation**: "AI double-checks your math" -- people trust computers with arithmetic
- **Data analysis**: "AI compares all 50 states to find the best fit" -- people trust AI for research

**Where "AI-powered" HURTS trust**:

- **Advice / judgment**: "AI-powered tax advice" -- people want human judgment for high-stakes decisions
- **Legal documents**: "AI-generated operating agreement" -- legal liability anxiety
- **Personal data handling**: Over-emphasizing AI processing of SSNs or financial data creates concern

**Our approach**: Use "AI-powered" for process/speed/cost messaging, NEVER for advice/judgment messaging. Say "AI handles the tedious stuff so you don't have to" not "AI tells you what to do." The product is the human experience of simplicity, not the AI behind it.

**Competitors' approach**: Credit Karma barely mentions AI. TurboTax emphasizes "expert review" (human). FreeTaxUSA doesn't mention tech at all. Cash App Taxes focuses on "free + easy." Takeaway: users care about outcomes (free, fast, accurate), not the technology stack.

**DECISION**: Lead with outcomes ("free, 5 minutes, accurate"), not with "AI-powered." Mention AI when it explains WHY something is free or fast, but never as the headline value prop. The brand voice speaks as a competent friend, not as a robot.

---

## 0G. Critical Pre-Code Actions (Stress Test Finding)

These are existential risk mitigations that cost under $5K total. Complete before writing any product code (i.e., before Phase 1).


| #   | Action                                                        | Cost                                        | Deadline                          | Blocks                                                                                                                                                                                                                         |
| --- | ------------------------------------------------------------- | ------------------------------------------- | --------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 1   | **Get cyber liability insurance** (E&O + cyber, $1M coverage) | $1,500-3,000/yr                             | Before first SSN is collected     | Phase 7 (FileFree launch). Non-negotiable for handling SSNs. A single breach without it is company-ending.                                                                                                                     |
| 2   | **Draft data breach response plan**                           | $0 (self-authored from SANS/NIST templates) | Before first SSN is collected     | Phase 7. Need: notification timeline by state tier, template notification letter, forensics firm contact, first-call list.                                                                                                     |
| 3   | **1-hour startup attorney consultation**                      | ~$300-500                                   | Before Phase 3 (LaunchFree MVP)   | Two specific questions: (a) does AI-assisted operating agreement survive UPL analysis in CA, TX, NY, FL? (b) is wholesale RA arrangement structured to minimize agency liability?                                              |
| 4   | **Decide LLC name**                                           | $0                                          | Hard deadline: 2 weeks from today | Phase 0.6 (LLC filing) -> EIN -> bank account -> Stripe -> trademarks. On the critical path. Stop researching, pick one, file.                                                                                                 |
| 5   | **Apply for EFIN (Form 8633)**                                | $0                                          | THIS WEEK                         | Phase 8 (MeF transmitter). 45-day IRS processing. Chain: EFIN -> Software Developer ID -> ATS testing (October 2026) -> Comms test (November) -> Go-live (January 2027). Every day of delay compresses the October ATS window. |


**Why this section exists**: The stress test identified that the plan has strong technical architecture but weak operational/legal preparedness. These 5 actions are the highest-ROI items in the entire plan — they cost <$5K and prevent catastrophic outcomes. None require code.

---

## 0H. Repo Rename (Deferred)

The repo is currently named `fileFree` (the original product). Now that "Paperwork Labs" is confirmed, rename to `paperwork-labs` when ready. Do this during a quiet period when no PRs are open, no agents are running, and no CI is in-flight. **Ask the founder before executing this rename.**

**What changes**: GitHub repo name, Render blueprint references, Vercel project names, all `package.json` names, import paths referencing the repo, DNS CNAME records, and `.cursor/rules/` absolute path references.

**When**: After LLC filing (Phase 0.6) and during a quiet window. Not urgent -- the rename is cosmetic and can happen anytime.

---

## 1. Revenue Model (Corrected)

### Timeline

- **H2 2026**: LaunchFree earns revenue (6 months post-launch)
- **Jan-Apr 2027**: FileFree first tax season (4 months, NOT a full year)
- **2028**: Cross-sell kicks in, at-scale attach rates

### FileFree First Tax Season (Jan-Apr 2027)


| Stream                | Pessimistic Rate | Moderate Rate | Aggressive Rate | Rev Per | 5K Filers (Pess.) | 10K Filers (Mod.) | 30K Filers (Agg.) |
| --------------------- | ---------------- | ------------- | --------------- | ------- | ----------------- | ----------------- | ----------------- |
| Refund routing HYSA   | 1%               | 2%            | 4%              | $50     | $2.5K             | $10K              | $60K              |
| Financial referrals   | 0.5%             | 1%            | 1.5%            | $75     | $1.9K             | $7.5K             | $34K              |
| Audit Shield          | 1%               | 3%            | 5%              | $20     | $1K               | $6K               | $30K              |
| Tax Optimization Plan | 1%               | 2%            | 3%              | $29     | $1.5K             | $5.8K             | $26K              |
| Refund advance        | 0%               | 0%            | 0%              | --      | $0                | $0                | $0                |
| **TOTAL**             |                  |               |                 |         | **$7K**           | **$29K**          | **$150K**         |


**Rate justification** (stress test): Credit Karma achieves 2-4% on financial referrals at maturity after years of trust-building with 100M+ profiles. FreeTaxUSA hits 8-12% on audit shield as an established brand. A brand-new product with zero trust history should model Year 1 rates at 40-60% of mature rates. The pessimistic scenario assumes only 5K filers (realistic for a new, unknown product with no marketing budget) and bottom-tier attach rates.

### LaunchFree H2 2026 (~6 months)


| Stream                     | Pess. Volume | Mod. Volume | Agg. Volume | Rev Per | Pess. Total | Mod. Total | Agg. Total |
| -------------------------- | ------------ | ----------- | ----------- | ------- | ----------- | ---------- | ---------- |
| RA credits (1-3% buy)      | 20           | 100         | 150         | $49     | $1K         | $5K        | $7K        |
| Banking referrals (2-5%)   | 40           | 150         | 250         | $50     | $2K         | $7.5K      | $12.5K     |
| Payroll referrals (0.5-1%) | 10           | 30          | 50          | $100    | $1K         | $3K        | $5K        |
| **TOTAL**                  |              |             |             |         | **$4K**     | **$15.5K** | **$25K**   |


### Combined (Year 1)


| Scenario        | LaunchFree (H2 2026) | FileFree (Jan-Apr 2027) | **Total**  |
| --------------- | -------------------- | ----------------------- | ---------- |
| **Pessimistic** | $4K                  | $7K                     | **$11K**   |
| Moderate        | $15.5K               | $29K                    | **$44.5K** |
| Aggressive      | $25K                 | $150K                   | **$175K**  |


**Why the pessimistic scenario matters**: It models what happens if (a) user acquisition is slow (5K filers, 2K formations), (b) attach rates are bottom-tier for an unknown brand, and (c) partnerships are self-serve affiliates only (no Founder 2 deals closed). At $11K Year 1 revenue, the venture survives (burn is ~$284/mo real cost) but takes longer to reach meaningful revenue. This is the floor, not the target.

**Year 2 (2028)**: $150K-600K (dependent on retention, growth trajectory, and partnership maturity)

### Plan B Revenue: Zero Partnerships Closed

If Founder 2 closes no deals. Key insight: MOST fintech affiliate programs are self-serve (apply online, no calls, no relationship). The original Plan B underestimated this.

**Confirmed Self-Serve Affiliate Programs** (Founder 1 applies in one afternoon):


| Program                      | Platform     | Commission                  | Application                            |
| ---------------------------- | ------------ | --------------------------- | -------------------------------------- |
| Betterment (HYSA/investing)  | Impact.com   | $25-$1,250 per referral     | Self-serve at betterment.com/affiliate |
| SoFi (banking/investing)     | Impact.com   | $50-$100 per funded account | Self-serve via Impact                  |
| Wealthfront (HYSA/investing) | Direct       | $30-$75 per funded account  | wealthfront.com/affiliates             |
| Ally Bank (HYSA/savings)     | CJ Affiliate | $5-$12 per signup           | Self-serve via CJ dashboard            |
| Robinhood (investing)        | Impact.com   | $5-$20 per funded account   | Self-serve via Impact                  |
| Chime (banking)              | CJ Affiliate | $10-$50 per direct deposit  | Self-serve via CJ                      |
| Acorns (micro-investing)     | CJ Affiliate | $5-$10 per signup           | Self-serve via CJ                      |



| Stream                                                                    | Available Without Partnerships?                | Year 1 Revenue |
| ------------------------------------------------------------------------- | ---------------------------------------------- | -------------- |
| Tax Optimization Plan ($29/yr)                                            | YES -- direct Stripe sale                      | $1.5K-8.7K     |
| Self-serve HYSA affiliates (Betterment, SoFi, Wealthfront)                | YES -- self-serve application                  | $2.5K-15K      |
| Self-serve investment affiliates (Robinhood, Acorns)                      | YES -- self-serve application                  | $1K-5K         |
| Self-serve banking affiliates (Ally, Chime)                               | YES -- self-serve application                  | $500-3K        |
| Trinkets AdSense                                                          | YES -- self-serve                              | $50-300        |
| Audit shield (direct sale via Stripe at $24, partner with individual EAs) | PARTIAL -- no wholesale, but direct sale works | $1K-5K         |
| RA credits                                                                | NO -- requires RA wholesale partner            | $0             |
| Refund advance                                                            | NO -- requires lending partner                 | $0             |
| **TOTAL (Plan B)**                                                        |                                                | **$6.5K-37K**  |


**Plan B is not just survivable -- it's viable.** Founder 2 raises the ceiling (premium partnership terms, co-marketing deals, exclusive rates) but does NOT set the floor. The venture generates meaningful affiliate revenue from self-serve programs that require zero relationship-building. These should be submitted in Phase 0 regardless of Founder 2's availability -- there is no reason to wait.

### Partnership Milestone Deadlines (Hard Dates)


| Milestone                                                          | Owner     | Deadline       | Consequence If Missed                                           |
| ------------------------------------------------------------------ | --------- | -------------- | --------------------------------------------------------------- |
| Submit self-serve affiliate apps (Marcus, Wealthfront, Betterment) | Founder 1 | April 2026     | Delays referral revenue by approval processing time (1-2 weeks) |
| Book Column Tax demo call                                          | Founder 2 | May 2026       | No interim e-file for October extension season                  |
| Column Tax sandbox access                                          | Founder 2 | June 2026      | Cannot test e-file integration; fallback = PDF download only    |
| RA wholesale partner signed (CorpNet or equivalent)                | Founder 2 | July 2026      | Launch LaunchFree without RA service; add later                 |
| TaxAudit/audit shield partnership                                  | Founder 2 | September 2026 | Launch FileFree without audit shield; add Year 2                |
| At least 1 banking partner confirmed                               | Either    | October 2026   | Refund routing not available for first tax season               |


### Partnership Documentation Strategy

Every partnership gets a comprehensive, agent-produced documentation package. This ensures bulletproof preparation for every partner conversation.

**Per-Partner Package** (generated by Partnership Dev agent + relevant domain agents):

1. **Partner Brief** (1-pager): Company overview, their product, how we integrate, revenue model for both sides, competitive landscape
2. **Integration Spec**: Technical integration requirements, API endpoints, data flow, PII handling
3. **Legal Memo**: Compliance considerations specific to this partner type (FTC disclosures for affiliate, data sharing agreements, Circular 230 for tax-adjacent)
4. **Financial Model**: Revenue projections at 3 volume tiers (pessimistic, moderate, aggressive), margin analysis, break-even point
5. **Pitch Deck** (5 slides): Problem, our product, integration value prop, projected volume, ask

**Quarterly Review Cadence**:

- Q1 (March): Review all active partnerships. Update financial projections with actuals. Identify underperformers.
- Q2 (June): Pipeline review. Score prospects by: revenue potential, integration complexity, strategic value. Prioritize top 3.
- Q3 (September): Pre-season prep. Ensure all tax season partnerships (HYSA, audit shield) are integration-tested.
- Q4 (December): Final partner readiness check before FileFree tax season.

**Legal Doc Freshness**: Compliance Monitor agent (#33) tracks partner agreement expiry dates and data sharing agreement renewal dates. Alerts 30 days before expiry.

### LaunchFree "Free" Framing (Honest, Defensible)

**What's actually free (our service -- $0 forever)**:

- LLC formation filing (prep + submit): $0
- Operating agreement template (state-specific, attorney-reviewed): $0
- EIN filing walkthrough: $0
- Compliance calendar + reminders: $0
- 50-state comparison AI guide (compares filing fees, annual costs, franchise tax, privacy, speed): $0

**What's NOT free (government fees -- clearly disclosed upfront)**:

- State filing fee: $35-$500 (depends on state)
- We help users find the cheapest legitimate option for their situation

**Cheapest states to form** (marketing content):


| State    | Filing Fee | Annual Cost              | Notes                     |
| -------- | ---------- | ------------------------ | ------------------------- |
| Montana  | $35        | $20/yr                   | Cheapest filing in the US |
| Kentucky | $40        | $15/yr                   | Low ongoing costs         |
| Arkansas | $45        | $150/yr                  | Higher annual             |
| Colorado | $50        | $10/yr                   | Very low annual           |
| Arizona  | $50        | $0/yr (no annual report) | No ongoing state cost     |
| Michigan | $50        | $25/yr                   | Moderate                  |


**Framing language** (use across all marketing):

> "LaunchFree handles the paperwork for $0. You only pay what your state charges -- and we'll help you pick the most affordable one."

**The differentiator**: Competitors (LegalZoom $149+, ZenBusiness $0+$199 upsells, Northwest $39) either charge service fees, bury state fees in the total, or upsell aggressively. LaunchFree's AI state comparison guide is unique -- no competitor helps you choose which state to form in based on your actual situation (home state, business type, budget, privacy needs). This is the moat.

**Competitive comparison**:


| Service        | Service Fee | Upsells                                             | State Fee Transparency        | State Comparison                    |
| -------------- | ----------- | --------------------------------------------------- | ----------------------------- | ----------------------------------- |
| LegalZoom      | $0-$299     | Heavy ($199 RA, $159 operating agreement, $159 EIN) | Buried in total               | No                                  |
| ZenBusiness    | $0          | Heavy ($199/yr Pro, $349/yr Premium)                | Shown separately              | No                                  |
| Northwest      | $39         | Moderate ($125/yr RA included Y1)                   | Shown separately              | No                                  |
| Incfile        | $0          | Heavy ($149-$349 bundles)                           | Shown separately              | No                                  |
| **LaunchFree** | **$0**      | **None (revenue from partner referrals)**           | **Upfront, before you start** | **Yes (AI-powered, all 50 states)** |


### Audit Shield Economics

- **What**: Prepaid IRS audit representation via Enrolled Agent/CPA. Covers defense costs (up to $1M), not taxes owed. 3-year federal coverage.
- **White-label partner**: TaxAudit / Protection Plus (same provider FreeTaxUSA, TaxAct, TurboTax use)
- **Our cost**: $10/return (firm-level wholesale)
- **Our price**: $19-24 (match FreeTaxUSA as low-cost leader)
- **Margin**: $9-14/sale (47-58% gross margin)
- **Attachment rate**: 5-8% first season, 10-15% at scale
- **Action**: Add TaxAudit partnership to Founder 2 pipeline (3-6 month lead time)

---

## 2. Architecture

### Monorepo (pnpm workspaces, no Turborepo)

```
venture/
  apps/
    filefree/            (filefree.ai -- Next.js, existing code from web/)
    launchfree/          (launchfree.ai -- Next.js, scaffolded)
    studio/              (paperworklabs.com -- Next.js, COMMAND CENTER + portfolio)
    trinkets/            (utility tools -- Next.js SSG, Vercel free, Phase 1.5)
  packages/
    ui/                  (22 shadcn components + theme + chat widget)
    auth/                (shared auth: hooks, middleware, session)
    analytics/           (PostHog + attribution + PII scrubbing)
    data/                (50-state formation + tax data + engine)
    cross-sell/          (recommendation engine, campaign triggers)
    email/               (shared email templates, React Email)
  apis/
    filefree/        (Python/FastAPI -- existing code from api/)
    launchfree/      (Python/FastAPI -- scaffolded)
    studio/          (Python/FastAPI -- command center backend, aggregator)
  infra/
    compose.dev.yaml
    hetzner/
    env.dev.example
  docs/
    KNOWLEDGE.md
    templates/
      trinket-one-pager.md
      trinket-prd.md
  pnpm-workspace.yaml
  package.json
  Makefile
  render.yaml
```

### Federated Identity (Separable by Design)

**The tension**: We want seamless SSO for UX, but each product must be independently valuable and separable if acquired.

**The pattern**: Each product owns its own user table in its own database. The venture layer adds SSO and cross-product intelligence on top, but is removable without breaking either product.

```
PRODUCT DATABASES (independent, can be separated):

  filefree DB:
    users: id, email, name, password_hash, ...filefree-specific fields...
           venture_identity_id (OPTIONAL, nullable FK)

  launchfree DB:
    users: id, email, name, password_hash, ...launchfree-specific fields...
           venture_identity_id (OPTIONAL, nullable FK)

VENTURE DATABASE (studio, never sold):

  venture_identities: id, email, name, created_at
  identity_products: venture_identity_id, product, product_user_id, first_used
  user_events: id, venture_identity_id, event_type, product, metadata, timestamp
  user_segments: venture_identity_id, segment, computed_at
```

**How SSO works**: User signs up on FileFree -> FileFree creates its local user -> event fires to studio -> studio creates/updates venture_identity -> if user later signs up on LaunchFree with same email -> LaunchFree creates its local user, sends event -> studio links both product accounts to one venture_identity.

**If FileFree is acquired**: Remove the `venture_identity_id` column. FileFree still works independently. The buyer gets a complete product with its own user system.

### Authentication Architecture

**User Auth (FileFree, LaunchFree)**:

- Providers: Google OAuth + Apple Sign-In (cover 95%+ of users). Optional email/password fallback.
- Implementation: `packages/auth/` using Auth.js v5 (NextAuth), shared across all Next.js apps.
- SSO across subdomains: Cookie domain set to `.filefree.ai` (covers `filefree.ai` and `tools.filefree.ai`). LaunchFree on `launchfree.ai` cannot share cookies (different domain) -- cross-product linking via venture identity system (email match in Studio DB).
- Each product keeps its own user table (separable-by-design). The `venture_identity_id` nullable FK links them.

**Admin Auth (paperworklabs.com + admin panels on all products)**:

- Same Google OAuth flow as users. After OAuth, middleware checks if the authenticated email is in the admin allowlist. If yes, admin routes accessible. If no, 403.
- Admin allowlist stored in environment variable: `ADMIN_EMAILS=sankalp@sankalpsharma.com,olga@sankalpsharma.com` (Google Workspace primary emails)
- Admin routes: `/admin/`* on paperworklabs.com, `/admin/`* on FileFree, `/admin/`* on LaunchFree. All protected by the same `packages/auth/withAdminAuth` middleware.
- No separate admin login page. Same SSO, just an authorization check on top.

**Trinkets Auth**: No auth. Public utility tools. Cross-sell CTAs link to FileFree/LaunchFree where users sign up. If we ever want saved preferences, use localStorage or add optional Google sign-in later.

`**packages/auth/` exports**: `AuthProvider`, `useSession`, `useAdmin`, `withAdminAuth` (middleware), `isAdmin` (server-side check).

### Cursor Workspace Scoping

The monorepo supports focused AI context by opening specific directories as Cursor workspaces:

- **Working on LaunchFree frontend**: Open `apps/launchfree/` as workspace root
- **Working on FileFree frontend**: Open `apps/filefree/` as workspace root
- **Working on shared packages**: Open `packages/` as workspace root
- **Working on infrastructure or cross-cutting**: Open repo root `venture/`

Each `apps/` and `apis/` directory can have its own `.cursor/rules/` with product-specific personas.

### Brand Palettes (Multi-Brand Theme System)

**FileFree** (Tax / Trust / Calm): Violet-Indigo family

- Primary: `#4F46E5` (Indigo 600)
- Gradient: `#8B5CF6` -> `#9333EA` (Violet 500 -> Purple 600)
- Background: `#020817` (Slate 950)
- Typography: Inter + JetBrains Mono

**LaunchFree** (Business Formation / Energy / Action): Teal-Cyan family

- Primary: `#0D9488` (Teal 600)
- Gradient: `#14B8A6` -> `#06B6D4` (Teal 400 -> Cyan 500)
- Background: `#0A0F1A` (deep navy)
- Typography: Inter + JetBrains Mono

**Studio/Command Center** (Internal / Data / Ops): Zinc-Neutral family

- Primary: `#71717A` (Zinc 500)
- Background: `#09090B` (Zinc 950)
- Typography: Inter + JetBrains Mono

**Trinkets / Tools** (Utility / Approachable / Helpful): Amber-Orange family

- Primary: `#F59E0B` (Amber 500)
- Gradient: `#F59E0B` -> `#EA580C` (Amber 500 -> Orange 600)
- Background: `#0C0A09` (Stone 950)
- Typography: Inter + JetBrains Mono

**Implementation**: CSS `[data-theme]` selectors in `packages/ui/themes.css`. Each app sets its theme via `<body data-theme="trinkets">`. All shadcn components inherit the right colors automatically. 4 themes: `filefree`, `launchfree`, `studio`, `trinkets`. Uses split complementary color theory for family cohesion with clear differentiation ([source: thegrowthuxstudio.com](https://thegrowthuxstudio.com/split-complementary-colors-what-they-say-about-your-brand-product-and-design-maturity/)).

### Port Map (Local Development)

All ports start from `x001` to avoid conflicts with default ports (3000, 8000) from other projects.


| Service            | Port | Notes                             |
| ------------------ | ---- | --------------------------------- |
| **Frontends**      |      |                                   |
| apps/filefree      | 3001 | Next.js `--port 3001`             |
| apps/launchfree    | 3002 | Next.js `--port 3002`             |
| apps/trinkets      | 3003 | Next.js `--port 3003`             |
| apps/studio        | 3004 | Next.js `--port 3004`             |
| **Backends**       |      |                                   |
| apis/filefree      | 8001 | uvicorn `--port 8001`             |
| apis/launchfree    | 8002 | uvicorn `--port 8002`             |
| apis/studio        | 8003 | uvicorn `--port 8003`             |
| **Infrastructure** |      |                                   |
| PostgreSQL         | 5432 | Default (shared, schema-isolated) |
| Redis              | 6379 | Default (shared, key-prefixed)    |


**Environment variables per app**: Each frontend sets `NEXT_PUBLIC_API_URL=http://localhost:800X` matching its backend.

**Dev commands** (root `package.json` scripts via pnpm):


| Command               | What It Starts    | Use Case                               |
| --------------------- | ----------------- | -------------------------------------- |
| `pnpm dev:filefree`   | 3001 + 8001       | Working on FileFree                    |
| `pnpm dev:launchfree` | 3002 + 8002       | Working on LaunchFree                  |
| `pnpm dev:trinkets`   | 3003 (no backend) | Working on Trinkets (client-side only) |
| `pnpm dev:studio`     | 3004 + 8003       | Working on Studio                      |
| `pnpm dev:all`        | All ports         | Cross-product testing                  |


Each dev command uses `concurrently` to start both frontend and backend. Trinkets has no backend (all client-side processing). `pnpm dev:all` starts everything for integration testing.

---

## 3. paperworklabs.com: The Command Center (Detailed Spec)

The command center is the control plane for the entire venture. It is what makes the "one human + AI agents" model operationally viable. 14 admin pages organized in 3 tiers based on operational priority, plus a public docs viewer.

### Tier 1 -- Build First (enables daily operations)

**P4.1 Company Landing Page** (`/` -- public, paperworklabs.com)

- Hero: "Paperwork Labs" wordmark, one-liner ("We build tools that eliminate paperwork")
- Portfolio: Cards linking to FileFree, LaunchFree, and Trinkets with descriptions and status badges
- Team: Sankalp + Olga
- Footer: legal info ("Paperwork Labs LLC | California"), social links, contact email
- Data source: Static

**P4.2 Admin Auth** (`/admin/`* -- protected)

- Google OAuth via `packages/auth/` shared library (Auth.js v5)
- Admin gate: `ADMIN_EMAILS` env var allowlist (Sankalp + Olga's Google Workspace primary emails)
- `withAdminAuth` middleware on all `/admin/`* routes -- same OAuth flow, authorization check on top
- No separate admin login page, no role system (two founders only)

**P4.3 Studio-API Scaffold** (Backend)

- FastAPI on Hetzner CX33 (shared with n8n, Postiz)
- Aggregator backend: pulls data from all external APIs (Render, Vercel, n8n, PostHog, Stripe)
- PostgreSQL for venture_identities, user_events, campaigns

**P4.4 Mission Control Dashboard** (`/admin`)

- Activity feed: live terminal-style log of all agent actions (monospace, auto-scroll, new entries from top)
- Summary cards: total users, revenue this month, active agents, uptime
- Quick links to each product's admin
- Data sources: n8n executions, Render health, Vercel deployments, PostHog events, Stripe revenue
- **Compliance Status Indicator**: traffic-light badge (green/yellow/red) for: cyber insurance active, data breach plan current, EFIN cert valid, privacy policy reviewed within 90 days, ToS reviewed within 90 days. Data from Compliance & Security Monitor agent (#33).
- **Data Integrity Dashboard**: per-state freshness badges (green: <30 days, yellow: 30-60 days, red: >60 days since last verification). Volatile states (CA, NY, TX, FL, IL) validated daily. Drill-down shows source URLs and last-verified timestamps. Data from State Data Validator agent (#21).

**P4.5 Agent Monitor** (`/admin/agents`)

- List of all n8n workflows with status (active/paused/failed)
- Last execution time, success/failure count, average execution duration
- Click into any workflow to see recent executions and logs
- Alert badges for failed executions
- Data source: n8n API (workflows + executions endpoints)

**P4.6 Infrastructure Health** (`/admin/infrastructure`)

- Render services: status, deploy history, resource usage
- Vercel deployments: status per app
- Hetzner VPS: CPU, RAM, disk from monitoring API
- Neon databases: connection count, storage used
- Upstash Redis: command count, memory
- Data sources: Render API, Vercel API, Hetzner API, Neon API, Upstash API

### Tier 2 -- Build Next (enables growth operations)

**P4.7 Analytics** (`/admin/analytics`)

- PostHog dashboard embeds or API pulls
- Key metrics: DAU, signup funnel, feature usage, retention
- Per-product breakdown
- Data source: PostHog API

**P4.8 Support Inbox** (`/admin/support`)

- All support conversations (chat widget + email) in one feed
- AI response drafts, human overrides
- Conversation status: open, resolved, escalated
- Data source: PostgreSQL (conversation store on Hetzner)

**P4.9 Social Media Command** (`/admin/social`)

- View scheduled posts across all platforms
- Approve/reject AI-drafted content
- Performance metrics per post
- Data source: Postiz API

**P4.10 State Data Observatory** (`/admin/data`)

- All 50 states with freshness indicators (green/yellow/red)
- Last verified date, data sources, change history
- Alert for states with stale data (>30 days since verification)
- Data source: `packages/data/` JSON files + n8n validator results

### Tier 3 -- Build When Revenue Flows

**P4.11 Revenue & Spend Intelligence** (`/admin/revenue`)

- Stripe revenue by product, stream, time period
- Affiliate revenue from partner dashboards
- MRR, churn, ARPU calculations
- **Spend overview panel**: monthly burn by category (infra, AI/ML, domains, SaaS tools, legal, marketing). Data from `docs/FINANCIALS.md` Monthly Actuals section (EA logs, CFO analyzes). Trend chart showing burn rate over time.
- Data source: Stripe API + affiliate dashboard APIs + FINANCIALS.md

**P4.12 Campaign Control** (`/admin/campaigns`)

- Create/manage cross-sell campaigns
- Target segments, message templates, schedule
- Performance: open rate, click rate, conversion
- Data source: Campaign tables in studio DB

**P4.13 User Intelligence** (`/admin/users`)

- Venture identity browser: see all users across products
- Segments: "Filed taxes + formed LLC", "High income + no LLC", etc.
- Cross-product journey visualization
- Data source: Venture identity DB + cross-product queries

**P4.14 Docs Viewer** (`/docs` -- public, no auth needed)

- Renders company docs from the git repo as clean, readable HTML pages
- Pages: Master Plan, Financials, Knowledge Base, Tasks, AI Model Registry
- Uses `react-markdown` or `next-mdx-remote` to render markdown fetched from GitHub API (raw content URL)
- Clean typography, table styling, anchor links for section navigation
- Responsive and mobile-friendly -- designed for non-technical readers
- No GitHub account needed to read
- **Primary use case**: Founder shares `paperworklabs.com/docs/financials` with wife to review company finances, or `paperworklabs.com/docs/master-plan` to read the full strategy
- Data source: GitHub raw content API (e.g., `https://raw.githubusercontent.com/{owner}/{repo}/main/docs/FINANCIALS.md`)
- Cached with React Query (staleTime: 5 min) so pages load instantly after first visit
- Table of contents sidebar generated from markdown headings

### UX Guidelines (Admin)

- Use shadcn Table components for all list views. No custom data grid libraries.
- Use Recharts (already in stack) for trend charts. Keep to 3 chart types: line, bar, pie.
- No animations or transitions in admin pages. Instant renders.
- Every page loads in <1 second. React Query with aggressive caching (staleTime: 60s for most data, 5s for health checks).
- Activity Feed is the most important UX element -- feels like a live terminal.
- Mobile responsive is nice-to-have, not required (except `/docs` -- that MUST be mobile-friendly).

### 3A. Document Access Strategy

Not everyone in the founder's life uses GitHub or Notion. Documents need to be accessible where people actually are.

**Two-layer system**:


| Doc Type                                                                    | Source of Truth                     | Readable At                      | Collaborative At       | Who Reads                       |
| --------------------------------------------------------------------------- | ----------------------------------- | -------------------------------- | ---------------------- | ------------------------------- |
| Company docs (FINANCIALS, KNOWLEDGE, TASKS, MASTER PLAN, AI_MODEL_REGISTRY) | `docs/*.md` in git repo             | paperworklabs.com/docs/* (P4.14) | Git PRs (founder only) | Founder, wife, future investors |
| Agent outputs (daily briefings, weekly plans, reports)                      | Google Drive (`Venture HQ/`)        | Google Drive link sharing        | Google Docs comments   | Founder, wife                   |
| Trinket one-pagers                                                          | Google Docs (created from template) | Google Drive link sharing        | Google Docs comments   | Founder, wife, future team      |
| Trinket PRDs                                                                | Google Docs (created from template) | Google Drive link sharing        | Google Docs comments   | Founder, future engineers       |
| Social content drafts                                                       | Postiz queue                        | Postiz UI                        | Postiz UI              | Founder                         |


**Why not just Google Docs for everything?**

Company docs (financials, master plan, tasks) change frequently via AI agents in Cursor. Markdown in git is the natural output format. Keeping them in git gives version history, PR review, and diff tracking. The Studio docs viewer (P4.14) makes them readable for anyone with a browser.

**Why not just markdown for everything?**

Trinket one-pagers and PRDs need collaborative review -- the founder might want to highlight a section, leave a comment like "I don't think this SEO angle works", or share with wife for a sanity check. Google Docs handles this natively. Markdown in git doesn't.

**Agent output routing**:


| Agent                            | Output Format              | Destination                              |
| -------------------------------- | -------------------------- | ---------------------------------------- |
| EA daily briefing                | Google Doc                 | `Venture HQ/Operations/Daily Briefings/` |
| EA weekly plan                   | Google Doc                 | `Venture HQ/Operations/Weekly Plans/`    |
| Market Discovery Agent (trinket) | Google Doc (from template) | `Venture HQ/Trinkets/One-Pagers/`        |
| PRD Agent (trinket)              | Google Doc (from template) | `Venture HQ/Trinkets/PRDs/`              |
| Competitive Intel                | Google Doc                 | `Venture HQ/Intelligence/`               |
| Analytics Reporter               | Google Doc                 | `Venture HQ/Operations/Analytics/`       |
| Social Content bots              | Postiz queue entry         | Postiz                                   |
| Decision logging (EA)            | Markdown commit            | `docs/KNOWLEDGE.md` in git               |
| Expense logging (EA)             | Markdown commit            | `docs/FINANCIALS.md` in git              |
| Task updates (EA)                | Markdown commit            | `docs/TASKS.md` in git                   |


**Google Drive folder structure** (set up in P0.4):

```
Venture HQ/
├── Operations/
│   ├── Daily Briefings/
│   └── Weekly Plans/
├── Trinkets/
│   ├── One-Pagers/
│   └── PRDs/
├── Intelligence/
│   ├── Competitive/
│   └── Analytics/
├── Content/
│   └── Social Drafts/
└── Legal/
    ├── LLC Docs/
    └── Compliance/
```

---

## 3B. 50-State Data Pipeline: The "Never Stale" Architecture

### The Principle

This is an AI-powered data pipeline that populates, validates, and keeps fresh ALL 50 states from day one. The marginal cost of state #11 through #50 is near zero when AI does the extraction.

### Data Structures

**Formation Data** (`packages/data/states/formation/{STATE}.json`):

```json
{
  "state": "WY",
  "state_name": "Wyoming",
  "formation": {
    "entity_types": ["LLC", "Corporation", "Nonprofit"],
    "filing_fee_cents": 10000,
    "filing_fee_source": "https://sos.wyo.gov/Business/docs/LLCFees.pdf",
    "expedited_fee_cents": 10000,
    "expedited_turnaround_days": 1,
    "standard_turnaround_days": 15,
    "online_filing_url": "https://wyobiz.wyo.gov/",
    "filing_method": ["online", "mail"],
    "articles_of_organization_template": true
  },
  "naming_rules": {
    "required_designator": ["LLC", "L.L.C.", "Limited Liability Company"],
    "restricted_words": ["bank", "insurance", "trust"],
    "name_search_url": "https://wyobiz.wyo.gov/Business/FilingSearch.aspx",
    "name_reservation_fee_cents": 5000,
    "name_reservation_duration_days": 120
  },
  "registered_agent": {
    "required": true,
    "must_be_state_resident_or_entity": true,
    "commercial_ra_allowed": true
  },
  "annual_requirements": {
    "annual_report_required": true,
    "annual_report_fee_cents": 6000,
    "annual_report_due": "first day of anniversary month",
    "annual_report_url": "https://wyobiz.wyo.gov/",
    "state_tax_type": "none",
    "franchise_tax": false
  },
  "taxes": {
    "has_state_income_tax": false,
    "corporate_tax_rate": null,
    "sales_tax_rate": 4.0,
    "notes": "Wyoming has no state income tax or corporate tax"
  },
  "last_verified": "2026-03-15",
  "last_verified_source": "Wyoming Secretary of State website",
  "sources": []
}
```

**Tax Data** (`packages/data/states/tax/{STATE}.json`):

```json
{
  "state": "CA",
  "state_name": "California",
  "tax_year": 2025,
  "has_income_tax": true,
  "tax_type": "graduated",
  "brackets": {
    "single": [
      { "min": 0, "max": 1113600, "rate": 1.0 },
      { "min": 1113601, "max": 2639400, "rate": 2.0 }
    ]
  },
  "standard_deduction": {
    "single": 573700,
    "married_joint": 1147400
  },
  "personal_exemption_cents": 15400,
  "source": "California Franchise Tax Board 2025 Tax Rate Schedules",
  "source_url": "https://www.ftb.ca.gov/file/personal/tax-rates.html",
  "all_values_in_cents": true,
  "last_verified": "2026-03-15"
}
```

### Source Registry

Each of the 50 states has a registered data source config:

```typescript
// packages/data/sources/registry.ts
export const sourceRegistry: Record<StateCode, StateSourceConfig> = {
  WY: {
    sos_url: "https://sos.wyo.gov/",
    dor_url: null,
    tax_foundation_ref: "wyoming",
    aggregator_urls: ["worldpopulationreview.com", "chamberofcommerce.org"],
    scrape_method: "structured_table"
  },
  // ... 49 more states
};
```

### State Engine

```typescript
// packages/data/engine/index.ts
export function getStateFormationRules(stateCode: string): StateFormationRules
export function getStateTaxRules(stateCode: string): StateTaxRules
export function calculateStateTax(stateCode: string, income: number, filingStatus: string): TaxResult
export function getAllStates(): StateSummary[]
export function getStateFreshness(): StateFreshnessReport
```

LaunchFree imports formation functions. FileFree imports tax functions. Both share the engine.

### AI-Powered Extraction Pipeline

```
Step 1: Scrape structured tables from Tax Foundation + aggregator sites
Step 2: GPT-4o-mini structured extraction -> 50 JSON files (formation + tax)
Step 3: Cross-validate against state SOS/DOR sites directly
Step 4: Zod schema validation (type safety)
Step 5: Sanity checks (is filing fee within $50-$800 range? Is tax rate within 0-13%?)
Step 6: Human review in batch (~4-6 hours total for all 50 states)
Step 7: PR with all 50 state files, human approves and merges
```

### Three n8n Monitoring Workflows

**1. Weekly Source Monitor** (`venture-source-monitor`)

- Trigger: Weekly cron
- Action: Scrape Tax Foundation + aggregator sites, compute content hashes, detect changes
- If change detected: create GitHub Issue with diff details + source link

**2. Monthly Deep Validator** (`venture-deep-validator`)

- Trigger: Monthly cron (1st of month)
- Action: Scrape all 50 state SOS + DOR sites directly, AI cross-validate against stored data
- Flag discrepancies, generate report for human review

**3. Annual Refresh** (`venture-annual-refresh`)

- Trigger: October (when IRS releases new Revenue Procedure)
- Action: Full federal + state refresh cycle
- Parse new bracket/deduction changes, generate PR with proposed JSON updates

### Validation

- Zod schemas enforce every state file has all required fields
- Sanity checks catch impossible values (negative fees, >100% tax rates)
- Test suite validates all 50 files on every CI run
- Any missing or malformed data fails the build
- 100% test coverage required for the state engine

---

## 4. User Intelligence Platform (Not Just Cross-Sell)

### 4A. The Strategic WHY

This is the Credit Karma playbook. Filing taxes and forming LLCs generates financial profile data -- income, deductions, business type, state, refund size, partner product interest -- that makes every subsequent recommendation more valuable. Each user interaction compounds into a richer profile that drives higher-converting, more relevant partner recommendations.

**Why this matters for valuation**: A pure SaaS tool that files taxes is worth 3-5x revenue. A platform that KNOWS users' financial profiles and can intelligently match them to financial products is worth 8-12x revenue. The difference is the data asset. Credit Karma was acquired for $8.1B not because of free credit scores, but because of 100M financial profiles that enabled targeted product recommendations at 40%+ conversion rates.

**The flywheel**: Free filing -> financial profile data -> better partner recommendations -> higher conversion -> more revenue -> invest in product -> more users -> more data -> better recommendations.

User Intelligence is not a feature. It IS the product.

### 4B. Data Model

```
venture_identities: id, email, name, created_at
identity_products: venture_identity_id, product, product_user_id, first_used
user_events: id, venture_identity_id, event_type, product, metadata, timestamp
user_segments: venture_identity_id, segment, computed_at
user_financial_profile: venture_identity_id, income_bracket, filing_status, has_biz_income,
                        state, refund_amount_bracket, partner_interests[], updated_at
campaigns: id, name, segment_target, message_template, channel, status, schedule
campaign_events: id, campaign_id, venture_identity_id, event_type, timestamp
recommendations: id, venture_identity_id, partner_product, score, status, created_at
recommendation_outcomes: id, recommendation_id, outcome_type, revenue_cents, timestamp
```

### 4C. Event Taxonomy (Exhaustive)

Every user action that has intelligence value is captured as a UserEvent. Events are immutable (append-only log).

```
ACQUISITION EVENTS:
  signup                    -- product, source (organic/referral/paid/social), utm_params
  signup_source_attributed  -- final attribution after dedup
  referral_click            -- referrer_id, referred_product

FILEFREE EVENTS:
  w2_uploaded               -- document_id, upload_method (camera/file)
  w2_ocr_completed          -- document_id, confidence_score, field_count
  w2_manual_edit            -- document_id, field_name (signals OCR quality)
  filing_started            -- filing_id, filing_status_type
  filing_completed          -- filing_id, refund_or_owed, amount_cents
  refund_routing_selected   -- routing_type (direct_deposit/hysa/ira)
  pdf_downloaded            -- filing_id
  efile_submitted           -- filing_id, transmitter (column_tax/own_mef)
  efile_accepted            -- filing_id, acceptance_date
  partner_cta_viewed        -- partner_id, placement (refund_plan/dashboard/email)
  partner_cta_clicked       -- partner_id, placement
  partner_signup_completed  -- partner_id, estimated_revenue_cents
  tax_opt_plan_purchased    -- plan_tier, amount_cents
  tax_opt_plan_cancelled    -- plan_tier, reason

LAUNCHFREE EVENTS:
  state_selected            -- state_code, is_home_state
  name_search_started       -- query_text
  name_available            -- query_text, state_code
  formation_started         -- formation_id, state_code, entity_type
  formation_completed       -- formation_id, total_cost_cents
  ra_purchased              -- formation_id, ra_provider, annual_cost_cents
  ra_credit_earned          -- credit_type, amount_cents
  operating_agreement_generated -- formation_id
  ein_filing_started        -- formation_id
  compliance_calendar_viewed -- formation_id
  banking_cta_clicked       -- partner_id (Mercury, Relay, etc.)
  payroll_cta_clicked       -- partner_id (Gusto, etc.)
  insurance_cta_clicked     -- partner_id

TRINKETS EVENTS:
  tool_used                 -- tool_slug, input_params_hash (no PII)
  tool_result_viewed        -- tool_slug, time_on_page_ms
  cross_sell_cta_clicked    -- tool_slug, target_product

CROSS-PRODUCT EVENTS:
  cross_product_opt_in      -- source_product, consent_timestamp
  cross_product_opt_out     -- source_product
  email_sent                -- campaign_id, template_id
  email_opened              -- campaign_id
  email_clicked             -- campaign_id, link_id
  email_unsubscribed        -- campaign_id
  in_app_notification_shown -- notification_id
  in_app_notification_clicked -- notification_id
```

### 4D. Segments (Rules-Based, Growing to ML)

**Initial segments (Year 1, rules-based)**:


| Segment                    | Rule                                                         | Action                           |
| -------------------------- | ------------------------------------------------------------ | -------------------------------- |
| `filed_taxes_no_llc`       | Filed via FileFree + no LaunchFree account + has_1099_income | Cross-sell LLC formation         |
| `has_llc_no_taxes`         | Formed LLC via LaunchFree + no FileFree account              | Cross-sell tax filing (seasonal) |
| `high_income_no_ira`       | Income >$75K + no IRA referral click                         | Recommend HYSA/IRA partner       |
| `new_user_7d`              | Signed up in last 7 days                                     | Onboarding email sequence        |
| `abandoned_formation`      | Started formation wizard + didn't complete in 48h            | Nudge email                      |
| `abandoned_filing`         | Started filing + didn't complete in 7 days                   | Nudge email                      |
| `refund_no_routing`        | Got refund >$500 + chose direct deposit (not HYSA)           | HYSA recommendation              |
| `multi_product_user`       | Uses both FileFree and LaunchFree                            | VIP segment, priority support    |
| `high_engagement_trinkets` | Used 3+ trinket tools                                        | Cross-sell to main products      |
| `ra_renewal_approaching`   | RA expires within 30 days                                    | Renewal reminder + credit offer  |


**Year 2 expansion (basic ML with enough data)**:

- Propensity scoring: predict likelihood of cross-product adoption
- Churn prediction: identify users likely to abandon before they do
- Partner match scoring: rank partner products by predicted conversion per user profile

**Year 3 (predictive, proactive)**:

- "Based on your tax profile, you could save $X by forming an LLC before year-end"
- "Users with your income and filing status typically benefit from a HYSA. Here's why."
- Seasonal predictions: anticipate tax season behavior based on prior year patterns

### 4E. Recommendation Engine Logic

The engine is a rules-based pipeline: `(segment + milestone + timing + consent) -> action`.

```
RULE 1: Post-Filing LLC Cross-Sell
  IF segment = "filed_taxes_no_llc"
     AND income > 50000
     AND has_1099_income = true
     AND days_since_filing > 14
     AND cross_product_opted_in = true
  THEN action: send_email
       template: "biz_income_llc_nudge"
       delay: 72h after filing completion
       expected_conversion: 3-5%
       estimated_revenue: $0 (free formation) but enables RA + partner revenue

RULE 2: Refund HYSA Recommendation
  IF event = "filing_completed"
     AND refund_amount > 50000 (cents = $500)
     AND refund_routing != "hysa"
  THEN action: show_in_app_recommendation
       template: "refund_hysa_card"
       placement: refund_plan_screen
       delay: immediate (show during filing flow)
       expected_conversion: 8-12%
       estimated_revenue: $25-50 per signup (HYSA affiliate)

RULE 3: Post-Formation Tax Cross-Sell (Seasonal)
  IF segment = "has_llc_no_taxes"
     AND month IN [11, 12, 1, 2, 3]
     AND cross_product_opted_in = true
  THEN action: send_email
       template: "llc_tax_season_nudge"
       delay: January 15 (filing season start)
       expected_conversion: 5-8%

RULE 4: Abandoned Formation Recovery
  IF event = "formation_started"
     AND no "formation_completed" within 48h
  THEN action: send_email
       template: "formation_almost_done"
       delay: 48h after start
       followup: 7 days later if still incomplete
       expected_conversion: 15-25%

RULE 5: RA Credit Upsell
  IF event = "ra_purchased"
     AND ra_credits_earned = 0
     AND days_since_ra_purchase > 7
  THEN action: send_email
       template: "earn_ra_credits"
       delay: 7 days
       expected_conversion: 10-15%
```

### 4F. Journey Mapping

Common user paths with estimated conversion rates at each step:

```
PATH A: FileFree -> LaunchFree (biz income detection)
  File taxes (100%) -> has 1099 income (15% of filers) -> see LLC cross-sell (if opted in)
  -> click CTA (8%) -> start formation (60%) -> complete (75%) -> RA purchase (50%)
  Net conversion: ~0.27% of all filers become LaunchFree RA customers
  Revenue per converted user: $99/yr RA + partner referrals

PATH B: LaunchFree -> FileFree (tax season cross-sell)
  Form LLC (100%) -> receive tax season email (if opted in) -> click CTA (12%)
  -> start filing (70%) -> complete (85%)
  Net conversion: ~7% of LLC formers file taxes via FileFree
  Revenue per converted user: partner referrals + Tax Opt Plan potential

PATH C: Trinkets -> FileFree (financial calculator -> tax filing CTA)
  Use calculator (100%) -> see cross-sell CTA (100%) -> click (2-3%)
  -> sign up for FileFree (40%) -> complete filing (varies by season)
  Net conversion: ~1% of trinket users become FileFree users
  Revenue: low per user but high volume (SEO traffic)

PATH D: FileFree -> HYSA partner (refund routing)
  Complete filing (100%) -> see Refund Plan screen (100%) -> has refund (75%)
  -> click HYSA CTA (8-12%) -> complete HYSA signup (50%)
  Net conversion: ~3-4.5% of filers become HYSA customers
  Revenue per converted user: $25-50 affiliate fee
```

### 4G. Revenue Connection Map

How user intelligence events drive the 77% of revenue from referrals:


| User Data Point           | Eligible Partner Products         | Est. Conversion | Revenue/Conversion |
| ------------------------- | --------------------------------- | --------------- | ------------------ |
| Income >$75K + no IRA     | HYSA (Marcus, Wealthfront)        | 8-12%           | $25-50             |
| Has 1099 income           | LLC formation (LaunchFree)        | 3-5%            | $99/yr RA          |
| Formed LLC, no bank       | Business banking (Mercury, Relay) | 10-15%          | $50-100            |
| Formed LLC, has employees | Payroll (Gusto)                   | 5-8%            | $50-200            |
| Formed LLC, no insurance  | Business insurance (Next)         | 3-5%            | $30-75             |
| Refund >$1K               | HYSA for refund deposit           | 8-12%           | $25-50             |
| Filing complete           | Audit shield (TaxAudit)           | 2-4%            | $15-30             |
| High engagement           | Tax Optimization Plan ($29/yr)    | 5-10%           | $29/yr             |


### 4H. Cross-Product Consent

- Opt-in checkbox (unchecked by default) on every signup form
- Consent stored per user, per product, with timestamp
- Cross-product emails only sent to users who explicitly opted in
- Single unsubscribe covers all brands (same legal entity)
- Consent audit trail maintained for CCPA/GDPR compliance
- Re-consent required if privacy policy materially changes

### 4I. Campaign System

- Create campaigns targeting specific segments
- Message templates with personalization tokens (name, refund amount, state, LLC name)
- Schedule: immediate, daily, weekly, one-time, event-triggered
- Channels: email, in-app notification, in-app card
- Performance tracking: send, open, click, convert, revenue attributed
- CAN-SPAM compliant: unsubscribe, physical address, honest subject line
- A/B testing: subject lines, send times, template variants (track via campaign_events)
- Suppression rules: max 2 emails/week, no emails within 24h of previous, respect quiet hours

### 4J. Onboarding Email Sequences

**LaunchFree (5-email welcome series)**:

1. Day 0: "Welcome! Here's what's next for your LLC" (compliance checklist, next steps)
2. Day 3: "3 things every new LLC owner forgets" (EIN, operating agreement, bank account)
3. Day 7: "Your compliance calendar (free)" (annual report dates, state deadlines)
4. Day 14: "Banking for your LLC" (partner referral -- Mercury/Relay)
5. Day 30: "Tax season is coming -- FileFree can help" (cross-sell, opt-in only)

**FileFree (3-email post-filing series)**:

1. Day 0: "Your return is filed! Here's your summary" (refund amount, key numbers)
2. Day 7: "5 ways to increase next year's refund" (educational, Circular 230 compliant)
3. Day 30: "Starting a business? LaunchFree makes it free" (cross-sell, opt-in only)

---

## 5. Social Media Pipeline (Faceless / AI-Driven)

### 5A. Strategy: Faceless + Occasional Founder

**Daily (automated, zero founder time)**:

- Faceless educational content: AI script + ElevenLabs voice clone + stock footage/screen recordings + text overlays
- Produced by n8n pipeline, queued in Postiz as drafts
- 1-2 posts/day across TikTok, IG Reels, YouTube Shorts, X

**Weekly (10 min founder time)**:

- 1 quick founder-face video: "This week's tax tip" or "Building FileFree update"
- Recorded on phone, minimal editing
- This 1 video is the trust anchor -- proves a real human is behind it

**Result: ~30 posts/week, <30 min/week founder time** (down from 45-60 min/DAY in original plan)

### 5B. Pipeline Architecture (DIY n8n, ~$0.10/video)

```
[8:00am] n8n cron fires
    |
    v
[Trend Research] n8n fetches trending finance/tax topics (GNews API + Reddit API)
    |
    v
[Script Generation] GPT-4o generates 3 scripts with hooks (brand voice -- see Section 0E)
    |
    v
[Image Generation] GPT-4o generates image prompt -> DALL-E 3 background ($0.04/image)
    |
    v
[Voice Generation] ElevenLabs: cloned founder voice OR brand voice ($0.05/1K chars)
    |
    v
[Visual Assembly] FFmpeg (Hetzner): image + audio + auto-captions -> video
    |
    v
[Platform Optimization] Resize for TikTok/IG/YT/X, add platform-specific captions + hashtags
    |
    v
[Queue in Postiz] n8n pushes to Postiz via REST API as "draft"
    |
    v
[5-min Human Review] Founder opens Postiz, approves/rejects/edits, schedules
    |
    v
[Publish + Track] Postiz publishes -> PostHog tracks UTMs -> n8n pulls analytics weekly
```

**Model routing for content** (per Section 0E):

- Script generation: **GPT-4o** (The Creative Director -- brand voice, narrative pull)
- Image prompts: **GPT-4o** (creative copy)
- Background images: **DALL-E 3** ($0.04/image)
- Voiceover: **ElevenLabs** (not an LLM -- dedicated voice synthesis)
- NOT Gemini or Claude for content scripts (GPT-4o is confirmed superior for "distinctive narrative pull")

### 5C. Cost: ~$3/month for 30 videos (both brands combined)


| Component        | Cost per video   | 30 videos/month |
| ---------------- | ---------------- | --------------- |
| GPT-4o script    | ~$0.01           | $0.30           |
| DALL-E 3 image   | $0.04            | $1.20           |
| ElevenLabs voice | ~$0.05           | $1.50           |
| FFmpeg assembly  | $0 (Hetzner VPS) | $0              |
| **Total**        | **~$0.10**       | **~$3.00**      |


### 5D. Content Themes

**FileFree** (tax/finance):

- Tax tips, refund hacks, "did you know" tax facts
- IRS deadline reminders, filing status guides
- W-2 box explainers, tax myth busters
- "Photo to Done in 5 minutes" product demos

**LaunchFree** (business formation):

- LLC tips, state comparisons, RA explained
- "Your LLC costs less than Netflix"
- Business compliance, annual report reminders
- "3 things every new LLC owner forgets"

### 5E. Hook Bank (Proven Templates)

**FileFree -- Pain hooks** (highest engagement in finance):

1. "The IRS already knows about this. Do you?"
2. "If you made under $75K last year, stop scrolling."
3. "That $89 you paid TurboTax? You didn't have to."

**FileFree -- Curiosity hooks**:
4. "I filed my taxes in 4 minutes. Here's how."
5. "CPAs don't want you to know this about free filing."
6. "Your tax refund isn't a gift. It's money they held hostage."

**FileFree -- Transformation hooks**:
7. "I went from owing $2,000 to getting $1,400 back. One form."
8. "Filing taxes used to take 3 hours. Now it takes 3 minutes."

**LaunchFree -- Formation hooks**:
9. "You can start an LLC for $0 in 10 states."
10. "ZenBusiness charges $199/yr. Here's what you actually need."
11. "3 tax deductions you unlock the day you form an LLC."
12. "Nobody tells you about the $800 California LLC fee."
13. "Stop running your side hustle as a sole prop."

**Production rules**:

- First 1.5 seconds = everything (algorithms judge intro retention)
- Bold text overlay (5-8 words) -- 60%+ of views are silent
- Change visuals every 2-3 seconds to maintain completion rate
- One CTA per video, never more

### 5F. 30-Day Pre-Launch Content Calendar

**Week 1 (Days 1-7): Founder Journey -- Build in Public**

- Day 1: "I quit my job to build a free tax app. Here's why." (X thread + TikTok)
- Day 2: "What TurboTax charges for vs what it costs them" (TikTok comparison)
- Day 3: "Day 1 of building FileFree" (behind-the-scenes TikTok, show code/terminal)
- Day 4: "The IRS has a free filing tool and nobody knows about it" (educational IG Reel)
- Day 5: "How much it actually costs to run a tax app (showing real numbers)" (X thread)
- Day 6-7: Engage with tax-related comments/threads on X, reply to r/tax and r/personalfinance

**Week 2 (Days 8-14): Tax Myths Busted**

- "You don't owe taxes on Venmo payments (unless...)" (TikTok)
- "The tax bracket myth that's costing you money" (TikTok + IG Reel)
- "No, your employer didn't steal your money. Here's what Box 1 actually means" (TikTok)
- "POV: you finally understand your W-2" (TikTok with screen recording of /demo)
- X polls: "What's the most confusing thing about filing taxes?"

**Week 3 (Days 15-21): Product Tease**

- "I scanned a W-2 and my app read every field in 3 seconds" (TikTok screen recording)
- "Before: 45 minutes on TurboTax. After: 3 minutes on FileFree." (TikTok split-screen)
- "This is what free tax filing actually looks like" (IG Reel, honest, no hype)
- Carousel: "5 things you're overpaying for that should be free" (IG)
- YouTube Short: "How AI reads your W-2 (explained in 60 seconds)"

**Week 4 (Days 22-30): Community Building**

- "Who else is stressed about filing? Comment your #1 question" (engagement bait)
- "I'll explain your W-2 in the comments" (TikTok -- comment-driven)
- "The waitlist is open. Here's exactly what FileFree does." (CTA post with link in bio)
- Pin first-week launch post on TikTok/IG with waitlist CTA

### 5G. Platform-Specific Rules

**TikTok** (primary -- cheapest reach for Gen Z):

- Format: Vertical 9:16, 15-60 seconds
- Hook: First 0.5s must stop the scroll. Pattern interrupts, bold text, unexpected statements.
- Audio: Use trending sounds (check TikTok Creative Center weekly)
- CTAs: "Link in bio" (no clickable links in posts). Pin comment with URL.
- Key metric: Completion rate > raw views

**Instagram Reels** (secondary -- better targeting for paid):

- Re-edit TikTok with IG-style captions + 20-30 hashtags + long caption
- Captions: Long-form, storytelling, save-bait ("Save this for tax season")
- Key metric: Saves > likes (saves signal value to algorithm)

**X / Twitter** (thought leadership + community):

- Text-first. Threads for explainers. Quote tweets for engagement.
- Sharp, concise, slightly spicy.
- Reply to people asking tax questions in #taxseason threads.
- Key metric: Quotes > retweets (deeper engagement)

**YouTube Shorts** (long-tail discovery):

- Same vertical video, add subscribe CTA overlay
- Description: Keyword-heavy ("how to file taxes free 2026" type phrases)
- Group into playlists: "Tax Basics", "W-2 Explained", "Money Tips"
- Key metric: Subscriber conversion rate from Shorts

### 5H. Validation Strategy

1. Week 1-2: Build the n8n pipeline (~4 hours using community templates as starting point)
2. Week 2-3: Generate 10 videos per brand (20 total) using the pipeline
3. Post to TikTok + IG with manual review before each post
4. Week 4: Analyze performance. Benchmark: >500 avg views, >40% completion rate
5. If validated: enable auto-scheduling with review queue
6. If not: adjust format before another 2-week test

### 5I. Content Compliance (Content Review Gate)

Every piece of social content must pass the Content Review Gate (Section 0C) before publishing:

- No unauthorized tax advice (education only -- Circular 230)
- No "you should" language for legal matters (UPL compliance)
- FTC disclosure on any partner/affiliate mentions
- "Free" claims are accurate and unconditional
- First 30 days: founder reviews EVERY post manually (no auto-publish)
- After 30 days: pre-approved templates can auto-publish; novel content still requires review

### 5J. Founder LLC Journey Content Series (NORTH STAR)

**The meta-narrative**: "I'm building a free LLC formation app while forming my own LLC. Here's every step, every cost, every frustration -- and why I'm building something better."

The founder is forming a California LLC RIGHT NOW. This is the exact journey LaunchFree users will go through. Every step becomes social content -- authentic, educational, and positions LaunchFree as the solution.

**LLC Formation Steps -> Content Hooks**:


| Step                     | What Happens                                                             | Content Hook (TikTok/IG/X)                                                                            | Emotion                     |
| ------------------------ | ------------------------------------------------------------------------ | ----------------------------------------------------------------------------------------------------- | --------------------------- |
| 1. Choose a name         | Search CA SOS business database, discover your name is taken, try 5 more | "I tried to name my company and California said no. 5 times."                                         | Frustration -> relatability |
| 2. File Articles of Org  | Fill out Form LLC-1 on CA SOS website, pay $70                           | "Starting an LLC costs $70 in California. Here's the 3-minute form nobody shows you."                 | Demystification             |
| 3. Wait for approval     | CA SOS processing time (can be weeks)                                    | "Day 1 vs Day 14 of waiting for California to approve my LLC..."                                      | Anticipation                |
| 4. Get an EIN            | IRS.gov, free, takes 5 minutes online                                    | "The IRS gave me a tax ID in 5 minutes. For free. Why does anyone pay $70 for this?"                  | Outrage at upsellers        |
| 5. Operating Agreement   | Write one (or use a template, or AI generates it)                        | "LegalZoom charges $99 for this document. I had AI write mine in 30 seconds."                         | Product demo moment         |
| 6. Registered Agent      | Set up RA service                                                        | "Your LLC needs a 'registered agent.' Here's what that actually means (and why it costs $49-249/yr)." | Education                   |
| 7. Statement of Info     | File LLC-12 within 90 days of formation                                  | "90 days after forming your LLC, California wants MORE paperwork. Here's what to do."                 | Compliance awareness        |
| 8. Business bank account | Apply at Mercury/Relay/local bank                                        | "I opened a business bank account in 10 minutes. From my phone."                                      | Partner demo moment         |
| 9. Franchise tax reality | Discover the $800/yr CA franchise tax                                    | "Nobody told me California charges $800/yr just to EXIST as an LLC. Here's the workaround."           | Shock -> education          |
| 10. First year exempt    | Discover first-year exemption                                            | "Plot twist: your first year is actually FREE. Here's the fine print."                                | Relief                      |
| 11. Compliance calendar  | Set up annual reminders                                                  | "The 5 dates every LLC owner needs to know. Miss one and your LLC gets dissolved."                    | Urgency                     |
| 12. DBA filing           | File "Doing Business As" for brand names                                 | "My LLC name isn't my brand name. Here's why you need a DBA (and what it costs)."                     | Practical                   |


**Content Format per Step** (each step produces 3-5 pieces):

1. **TikTok/Reel (primary)**: 30-60s screen recording of the actual process + voiceover. Real screens, real forms, real costs. Raw and authentic.
2. **X thread**: 5-7 tweet breakdown with screenshots. Educational, save-worthy.
3. **IG carousel**: Step-by-step visual guide (5-7 slides). Highly saveable, shareable.
4. **Blog/guide page** (SEO): Full written guide on launchfree.ai (e.g., "How to File Articles of Organization in California"). Each page targets "[state] LLC formation" keywords.
5. **Behind-the-scenes TikTok**: "Day X of building a free LLC formation app while forming my own LLC" (build-in-public narrative arc).

**Why This Goes Viral**:

- **Pain is universal**: Everyone forming an LLC hits the same confusion. This content validates their frustration.
- **Real receipts**: Showing actual forms, actual costs, actual timelines. Not hypothetical.
- **Outrage hooks**: "LegalZoom charges $249 for something that takes 3 minutes" triggers shares.
- **Build-in-public**: "I'm building the solution to the problem I'm showing you" is a compelling narrative arc.
- **Each step is searchable**: People Google "how to get an EIN" (110K monthly searches), "California LLC cost" (12K), "do I need a registered agent" (8K). This content ranks.

**Revenue Flywheel**:

```
Viral LLC content (TikTok/IG/X)
    |
    v
Traffic to launchfree.ai (SEO guides + social CTAs)
    |
    v
Users form LLCs via LaunchFree ($0 service fee)
    |
    v
Cross-sell: RA ($99/yr), banking (Mercury/Relay affiliate $50-100),
            payroll (Gusto $50-200), insurance (Next $30-75)
    |
    v
Partner revenue ($$$) -- this is the 77% revenue driver
    |
    v
Reinvest in more content + product
```

**Integration with 30-Day Calendar** (Section 5F): LLC journey steps 1-4 map to Week 1-2 founder content. Steps 5-8 map to Week 3. Steps 9-12 map to Week 4. Each step's TikTok/Reel is the "founder spotlight" content that runs alongside the automated faceless content pipeline.

**Cross-reference**: Phase 0.6 (Form LLC) in Section 7 -- every Phase 0 step becomes content. LaunchFree social hooks in Section 5E.

---

## 5K. User Acquisition Strategy (Stress Test Addition)

The plan projects 10K-30K FileFree filers and 2K-5K LaunchFree users but never modeled how they arrive. Social content is one channel, not the strategy. This section fills that gap.

### Channel-by-Channel Projections (Year 1)


| Channel                                   | Monthly Investment              | Time to Impact   | Year 1 Users (Est.) | Notes                                                                                                   |
| ----------------------------------------- | ------------------------------- | ---------------- | ------------------- | ------------------------------------------------------------------------------------------------------- |
| **Organic TikTok/Reels**                  | $15-17/mo (pipeline cost)       | 2-4 months       | 500-3,000           | Faceless + founder content. 90%+ of videos get <500 views; the bet is on the 1-2 that go viral.         |
| **SEO / Content**                         | $0 (AI-written, founder-edited) | 6-12 months      | 1,000-5,000         | Blog posts: "cheapest state for LLC", "free tax filing 2027", "LLC vs sole prop". Long tail, compounds. |
| **Product Hunt + HN launch**              | $0                              | Day 1 spike only | 500-2,000           | One-time spike. LaunchFree PH launch, FileFree PH launch. Plan for both.                                |
| **Reddit / personal finance communities** | $0 (time cost)                  | 1-3 months       | 200-1,000           | r/personalfinance, r/smallbusiness, r/tax. Authentic answers that mention product. Never spam.          |
| **TikTok Spark Ads**                      | $100-300/mo                     | Immediate        | 1,000-5,000         | Boost top-performing organic videos only. $0.05-0.10/click. Budget in FINANCIALS.md.                    |
| **Referral program**                      | $0-5/referral (tax credit)      | 3-6 months       | 500-2,000           | "Refer a friend, both get [benefit]". Implement in Phase 7.                                             |
| **Cross-sell (LaunchFree -> FileFree)**   | $0                              | Jan 2027         | 500-2,000           | Every LLC former needs to file taxes. Built-in pipeline.                                                |
| **TOTAL REALISTIC RANGE**                 |                                 |                  | **5,200-23,000**    |                                                                                                         |


### Customer Acquisition Cost (CAC) Model


| Segment                 | CAC              | Lifetime Value (LTV) | LTV:CAC  | Verdict                                                       |
| ----------------------- | ---------------- | -------------------- | -------- | ------------------------------------------------------------- |
| Organic (SEO + social)  | ~$0              | $15-50 (Year 1)      | Infinite | Build this first. It compounds.                               |
| Paid social (Spark Ads) | $0.50-2.00       | $15-50               | 7-100x   | Profitable from day 1 IF content converts. Test with $200/mo. |
| Product Hunt / HN       | ~$0              | $15-50               | Infinite | One-time, non-repeatable. Nice but not a strategy.            |
| Referral                | $5 (credit cost) | $15-50               | 3-10x    | Excellent unit economics. Build in Phase 7.                   |


### Pre-Launch Audience Building (Start NOW, Before Products Ship)


| Action                                                 | Owner          | Timeline           | Goal                                         |
| ------------------------------------------------------ | -------------- | ------------------ | -------------------------------------------- |
| Start LLC Journey content series (Section 5J)          | Founder 1      | March-April 2026   | 500+ followers before LaunchFree launch      |
| Publish 3 SEO blog posts on paperworklabs.com/blog     | Founder 1 + AI | April 2026         | Index in Google for long-tail LLC keywords   |
| Post in r/smallbusiness and r/Entrepreneur weekly      | Founder 1      | Ongoing            | Build credibility, understand user language  |
| Launch waitlist with referral incentive                | Founder 1      | Already live       | Grow to 500+ emails before LaunchFree launch |
| Submit to BetaList, Indie Hackers, Startup directories | Founder 1      | 1 month pre-launch | 200-500 signups from startup community       |


### Bootstrapped Growth Case Studies

**FreeTaxUSA**: Built to 10M+ filers with zero VC funding. Strategy: SEO-first (ranks #1 for "free tax filing"), word-of-mouth from happy users, price undercut (federal free, state $14.99). No paid social until 1M+ users. Lesson: product quality IS the marketing.

**Credit Karma**: Grew to 100M users pre-acquisition on free credit scores + SEO + word-of-mouth. Zero paid ads for first 3 years. Lesson: give away something valuable that competitors charge for, and users become evangelists.

**Our playbook**: Follow both patterns. Free filing IS the hook (like Credit Karma's free credit score). SEO compounds over time (like FreeTaxUSA's dominance). Social content builds brand recognition. Paid amplification ($100-300/mo max) only boosts proven organic winners.

### Brand Mission Alignment

Every piece of content should reinforce one of these mission pillars:

- **Accessibility**: "Taxes shouldn't cost $89" / "Your LLC shouldn't cost $500"
- **Transparency**: "No hidden fees, no bait-and-switch, no surprise renewals"
- **Empowerment**: "You don't need a CPA for a simple return" / "You don't need a lawyer to form an LLC"
- **AI as helper**: "AI does the work, you just confirm"

Content that doesn't tie back to a mission pillar gets killed. This is how brands build recognition -- relentless consistency, not volume.

### Viral Mechanics

- **Refund amount sharing**: "I just filed my taxes for free and I'm getting $X back" (shareable card with FileFree branding)
- **LLC formation celebration**: "I just started my business!" (shareable certificate with LaunchFree branding)
- **Comparison calculator**: "How much are you overpaying for tax prep?" (interactive widget, generates shareable result)
- **Referral loops**: Referrer and referee both get a benefit (e.g., priority support, Tax Optimization Plan discount)

### What's NOT in the Strategy (Honest Gaps)

- **Paid search (Google Ads)**: Too expensive for "LLC formation" ($15-30/click). Not viable until revenue covers it.
- **Influencer partnerships**: No budget and no traction to pitch. Revisit at 10K+ users.
- **Email list buying**: Never. Destroys trust and violates CAN-SPAM intent.
- **PR / press**: No story yet. Revisit after Product Hunt launch with traction data.

**Ad budget**: $100-300/mo max for TikTok Spark Ads + Meta boost, starting at LaunchFree launch. Only boost organic content that already performed well. This is NOT a paid-first strategy.

---

## 6. Agent Architecture (Venture-Wide)

### 6A. The Problem: All Agents Are FileFree-Specific

All 12 Cursor personas and 6 n8n workflows were built for FileFree as a standalone product:

- `social.mdc` references @filefree handles, "Gen Z tax filing app"
- `brand.mdc` references filefree.tax domain, FileFree-specific colors
- `growth.mdc` references tax-specific SEO, TurboTax competition
- `partnerships.mdc` references HYSA referrals, tax partnerships only
- n8n workflows all output to FileFree-specific databases

Now that we're a venture with LaunchFree, Trinkets, and paperworklabs.com, the agent architecture needs to be **product-aware, not product-locked**.

### 6B. Three-Tier Persona Model

Agents are organized into three tiers:

**Tier 1: Venture-Level Personas** (shared across all products, `alwaysApply` or broad globs)


| #   | Persona         | File               | Specific Changes Needed                                                                                                                                               |
| --- | --------------- | ------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1   | Staff Engineer  | `engineering.mdc`  | Add monorepo conventions (pnpm workspace, `packages/*` imports), multi-app patterns, `apis/` folder structure. Remove FileFree-only path references.                  |
| 2   | UX/UI Lead      | `ux.mdc`           | Add `packages/ui` shared design system reference, multi-brand theming (`[data-theme]` selectors), cross-product navigation patterns.                                  |
| 3   | Chief of Staff  | `strategy.mdc`     | Expand from FileFree context to full venture. Add LaunchFree + Trinkets product context, Google Drive HQ structure, venture KPIs.                                     |
| 4   | General Counsel | `legal.mdc`        | Add LLC formation compliance (UPL disclaimers for LaunchFree), RA legal requirements, FTC "free" guidance for both products. Add Content Review Gate checklist.       |
| 5   | CFO             | `cfo.mdc`          | Expand unit economics to both products + trinkets. Add shared infra cost allocation (Hetzner split), per-product revenue projections, RA margin analysis.             |
| 6   | QA Lead         | `qa.mdc`           | Add formation data validation rules, cross-product security (venture identity PII), state data pipeline validation. Expand PII definitions to include LLC owner data. |
| 7   | Partnership Dev | `partnerships.mdc` | Add LaunchFree partnerships (banking: Mercury/Relay, payroll: Gusto, RA providers: CorpNet, insurance: Next). Update pipeline tracking for both products.             |
| 8   | Workflows       | `workflows.mdc`    | Add LaunchFree-specific workflow templates (ship formation feature, state data update, compliance alert).                                                             |
| 9   | AI Ops Lead     | `agent-ops.mdc`    | Already venture-wide. Add reference to `docs/AI_MODEL_REGISTRY.md`.                                                                                                   |


**Tier 2: Product-Level Personas** (activated by glob patterns, product-specific knowledge)


| #   | Persona                     | File                                              | Globs                                                                      | Purpose                                                                         |
| --- | --------------------------- | ------------------------------------------------- | -------------------------------------------------------------------------- | ------------------------------------------------------------------------------- |
| 10  | Tax Domain Expert           | `tax-domain.mdc`                                  | `apps/filefree/`**, `apis/filefree/`**, `packages/data/**/tax-*`           | IRS rules, brackets, MeF schemas                                                |
| 11  | CPA / Tax Advisor           | `cpa.mdc`                                         | `apps/filefree/**`                                                         | Tax advisory content quality                                                    |
| 12  | FileFree Social             | `filefree-social.mdc` (rename from `social.mdc`)  | `apps/filefree/**/social/**`                                               | FileFree content: @filefree handles, tax hooks, TurboTax positioning            |
| 13  | FileFree Growth             | `filefree-growth.mdc` (extract from `growth.mdc`) | `apps/filefree/**`                                                         | Tax-specific SEO, TurboTax competition keywords                                 |
| 14  | FileFree Brand              | `filefree-brand.mdc` (extract from `brand.mdc`)   | `apps/filefree/**`                                                         | Violet-indigo palette, FileFree voice                                           |
| 15  | **Formation Domain Expert** | `formation-domain.mdc` (NEW)                      | `apps/launchfree/`**, `apis/launchfree/`**, `packages/data/**/formation-*` | State LLC rules, RA requirements, annual report deadlines, entity types         |
| 16  | **LaunchFree Social**       | `launchfree-social.mdc` (NEW)                     | `apps/launchfree/**/social/`**                                             | LaunchFree content: @launchfree handles, formation hooks, LegalZoom positioning |
| 17  | **LaunchFree Growth**       | `launchfree-growth.mdc` (NEW)                     | `apps/launchfree/`**                                                       | Formation-specific SEO, "free LLC" keywords, LegalZoom/ZenBusiness positioning  |
| 18  | **LaunchFree Brand**        | `launchfree-brand.mdc` (NEW)                      | `apps/launchfree/`**                                                       | Teal-cyan palette, LaunchFree voice                                             |
| 19  | **Studio**                  | `studio.mdc` (NEW)                                | `apps/studio/`**                                                           | paperworklabs.com company site + command center UX                              |


### 6C. Persona Split Specs

`**social.mdc` -> `filefree-social.mdc` + `launchfree-social.mdc`**:


| Attribute                       | filefree-social.mdc                                                           | launchfree-social.mdc                                                                 |
| ------------------------------- | ----------------------------------------------------------------------------- | ------------------------------------------------------------------------------------- |
| Handles                         | @filefree.tax, @filefreetax                                                   | @launchfree (TikTok, IG, X, YT)                                                       |
| Voice                           | Smart friend who makes taxes feel easy                                        | Smart friend who makes business formation feel easy                                   |
| Content pillars                 | Tax myths, W-2 explainers, refund tips, filing demos                          | LLC tips, state comparisons, compliance, RA explained                                 |
| Hook themes                     | Pain (TurboTax costs), curiosity (tax hacks), transformation (filed in 3 min) | Pain (LegalZoom costs), curiosity (LLC benefits), transformation (launched in 10 min) |
| Competitors to position against | TurboTax, H&R Block, FreeTaxUSA                                               | LegalZoom, ZenBusiness, GoDaddy, Northwest                                            |
| Compliance                      | Circular 230 (tax education only)                                             | UPL (formation services, not legal advice)                                            |
| Posting cadence                 | 7-10/week tax season, 2-3/week off-season                                     | 3-5/week consistent year-round                                                        |


`**brand.mdc` -> `filefree-brand.mdc` + `launchfree-brand.mdc`**:

- FileFree: violet-indigo palette (`from-violet-500 to-purple-600`), tax-anxiety-killing tone
- LaunchFree: teal-cyan palette (`from-teal-500 to-cyan-600`), entrepreneurial empowerment tone
- Shared: Inter + JetBrains Mono typography, dark mode default, same animation patterns

`**growth.mdc` -> `filefree-growth.mdc` + `launchfree-growth.mdc`**:

- FileFree: SEO targets "free tax filing", "file taxes online free", competitor comparison pages vs TurboTax
- LaunchFree: SEO targets "free LLC formation", "how to start an LLC", state-specific landing pages, competitor comparisons vs LegalZoom/ZenBusiness

### 6D. Current Agents (18 -- Already Built)

12 Cursor personas + 6 n8n workflows:


| #     | Agent                                                                                           | Type                     | Status                                                  |
| ----- | ----------------------------------------------------------------------------------------------- | ------------------------ | ------------------------------------------------------- |
| 1-12  | Engineering, UX, Growth, Social, Strategy, Legal, CFO, QA, Tax Domain, CPA, Partnerships, Brand | Cursor personas (.mdc)   | Active (FileFree-specific, pending venture-wide update) |
| 13-18 | Social Content, Growth Content, Strategy Check-in, Partnership Outreach, CPA Review, QA Scanner | n8n autonomous workflows | Active (output to Notion, pending GDrive migration)     |


### 6E. New Agents to Build (12+)


| #   | Agent                         | Type                    | Trigger                                                                               | Purpose                                                                                                                                                                                                                                                                   |
| --- | ----------------------------- | ----------------------- | ------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 19  | L1 Support (DocBot)           | n8n webhook             | User message                                                                          | Answer from knowledge base (60% resolution target)                                                                                                                                                                                                                        |
| 20  | L2 Support (OpsBot)           | n8n webhook             | DocBot escalation                                                                     | Execute actions: check status, resend email, reset password                                                                                                                                                                                                               |
| 21  | State Data Validator          | n8n cron (daily/weekly) | Daily for volatile states (CA, NY, TX, FL, IL, WA, NJ, MA, GA, PA), weekly for others | Check state SOS websites for fee/rule changes. Flag stale data (>30 days) to Compliance Monitor.                                                                                                                                                                          |
| 22  | IRS Update Monitor            | n8n cron (October)      | Annual                                                                                | Parse new Revenue Procedure for bracket changes                                                                                                                                                                                                                           |
| 23  | Competitive Intel             | n8n cron (weekly)       | Mondays                                                                               | Monitor LegalZoom/ZenBusiness/TurboTax pricing + features                                                                                                                                                                                                                 |
| 24  | Analytics Reporter            | n8n cron (weekly)       | Sundays                                                                               | Pull PostHog data, generate weekly metrics report                                                                                                                                                                                                                         |
| 25  | Infra Health Monitor          | n8n cron (hourly)       | Continuous                                                                            | Check Render/Vercel/Hetzner status, alert on issues (see Section 7B)                                                                                                                                                                                                      |
| 26  | Affiliate Revenue Tracker     | n8n cron (daily)        | Daily                                                                                 | Check affiliate dashboards, report conversions                                                                                                                                                                                                                            |
| 27  | LaunchFree Social Bot         | n8n cron (daily)        | 8am                                                                                   | Draft LaunchFree social content for Postiz                                                                                                                                                                                                                                |
| 28  | LaunchFree Growth Bot         | n8n cron (weekly)       | Mondays                                                                               | Draft LaunchFree SEO articles                                                                                                                                                                                                                                             |
| 29  | LaunchFree Compliance Bot     | n8n cron (monthly)      | 1st                                                                                   | State filing deadline alerts for users                                                                                                                                                                                                                                    |
| 30  | Knowledge Base Sync           | n8n cron (nightly)      | 2am                                                                                   | Sync Google Drive docs to support agent context                                                                                                                                                                                                                           |
| 31  | AI Ops Lead                   | Cursor persona (.mdc)   | On demand                                                                             | Model routing, cost tracking, persona audits                                                                                                                                                                                                                              |
| 32  | Executive Assistant (EA)      | Cursor persona + n8n    | Daily cron + on-demand                                                                | Daily briefing, weekly planning, decision tracking, financial tracking, doc maintenance. See Section 6J1.                                                                                                                                                                 |
| 33  | Compliance & Security Monitor | n8n cron (daily)        | 6am                                                                                   | Tracks: cyber insurance status, data breach plan currency, EFIN cert status, 50-state data freshness, legal doc expiry (ToS, privacy policy last-reviewed dates). Outputs daily compliance status to Slack #compliance-alerts and weekly summary to Mission Control P4.4. |


### 6F. n8n Workflow Updates (Existing 6)


| #   | Workflow                     | Changes Needed                                                           |
| --- | ---------------------------- | ------------------------------------------------------------------------ |
| 1   | Social Content Generator     | Rename to `filefree-social-content`. Output to GDrive instead of Notion. |
| 2   | Growth Content Writer        | Rename to `filefree-growth-content`. Output to GDrive.                   |
| 3   | Weekly Strategy Check-in     | Expand to cover both products. Output to GDrive.                         |
| 4   | QA Security Scan             | Scan both APIs. Output to GitHub Issues (keep as-is).                    |
| 5   | Partnership Outreach Drafter | Add LaunchFree partners. Output to GDrive.                               |
| 6   | CPA Tax Review               | Keep FileFree-only. Output to GDrive.                                    |


### 6G. n8n Workflow Dependency Graph

```
Knowledge Base Sync (nightly 2am)
    |
    v
L1 Support Bot <-- user webhook
    |
    v (escalation)
L2 Support Bot

Analytics Reporter (weekly)
    |
    v (feeds into)
Weekly Strategy Check-in

State Data Validator (monthly)
    |
    v (creates GitHub Issues for)
IRS Update Monitor (annual, October)

FileFree Social Content (daily 8am) --> Postiz queue
LaunchFree Social Bot (daily 8am)  --> Postiz queue
    |
    v (both feed analytics to)
Analytics Reporter

Competitive Intel (weekly) --> GDrive report
    |
    v (informs)
Growth Content Writer (weekly) --> GDrive draft

Infra Health Monitor (hourly) --> Slack #ops-alerts
Affiliate Revenue Tracker (daily) --> GDrive report
LaunchFree Compliance Bot (monthly) --> user emails
```

### 6H. AI Operations Lead (`agent-ops.mdc`)

**Authority**: Owns ALL model routing decisions across the venture. Engineering implements model assignments but does not choose them independently.

**Responsibilities**:

1. **Model Registry**: Maintain Section 0E and `docs/AI_MODEL_REGISTRY.md` as living documents. Update when new models release.
2. **Cost Monitoring**: Monthly API usage audit. Flag workflows exceeding expected cost by >50%.
3. **Persona Audit**: Quarterly review of all .mdc personas. Ensure system prompts are current and effective.
4. **New Model Evaluation**: When a new model drops, evaluate benchmarks + pricing vs current assignments. Generate swap recommendation within 48 hours.
5. **Workflow Optimization**: Identify tasks where a cheaper model could achieve the same quality.

### 6I. Company Org Chart: Agents as Employees

Agents are employees. The full company is staffed from day one -- every role is defined with a system prompt and clear domain, even if some are initially in **Standby** (activated when workload appears). This is not premature scaling; this is organizational design. A company defines all roles before hiring into them.

#### Org Chart (Tree Structure)

```
FOUNDER (Root -- final arbiter on all escalations)
├── CHIEF OF STAFF (EA Interactive -- ea.mdc)
│   ├── EA Ops Monitor (n8n: ea-daily, ea-weekly)
│   └── Compliance & Security Monitor (n8n: daily)
│
├── VP ENGINEERING (engineering.mdc)
│   ├── Tax Domain Expert (tax-domain.mdc)
│   ├── Formation Domain Expert (formation-domain.mdc)
│   ├── Studio Lead (studio.mdc)
│   ├── AI Ops Lead (agent-ops.mdc)
│   └── QA Lead (qa.mdc)
│       ├── QA Security Scanner (n8n)
│       └── State Data Validator (n8n: daily/weekly)
│           └── IRS Update Monitor (n8n: annual October)
│
├── VP PRODUCT (ux.mdc)
│   └── UX/UI decisions for all products
│
├── VP GROWTH
│   ├── FileFree Growth (filefree-growth.mdc)
│   │   ├── FileFree Social (filefree-social.mdc)
│   │   └── FileFree Content Pipeline (n8n: daily)
│   ├── LaunchFree Growth (launchfree-growth.mdc)
│   │   ├── LaunchFree Social (launchfree-social.mdc)
│   │   └── LaunchFree Content Pipeline (n8n: daily)
│   └── Analytics Reporter (n8n: weekly)
│
├── VP BRAND
│   ├── FileFree Brand (filefree-brand.mdc)
│   └── LaunchFree Brand (launchfree-brand.mdc)
│
├── GENERAL COUNSEL (legal.mdc)
│   ├── Content Review Gate (built into all content personas)
│   └── LaunchFree Compliance Bot (n8n: monthly)
│
├── CFO (cfo.mdc)
│   └── Affiliate Revenue Tracker (n8n: daily)
│
├── VP PARTNERSHIPS (partnerships.mdc -- Founder 2 primary)
│   └── Partnership Outreach Drafter (n8n)
│
├── CPA / TAX ADVISOR (cpa.mdc)
│   └── CPA Tax Review (n8n)
│
├── CUSTOMER SUCCESS
│   ├── L1 Support Bot (n8n: webhook)
│   ├── L2 Support Bot (n8n: webhook)
│   └── Knowledge Base Sync (n8n: nightly)
│
├── COMPETITIVE INTEL (n8n: weekly)
│
├── STRATEGY (strategy.mdc)
│   └── Weekly Strategy Check-in (n8n)
│
├── WORKFLOWS (workflows.mdc)
│
└── INFRA HEALTH MONITOR (n8n: hourly)
```

**Total: 24 Cursor personas + 19 n8n workflows = 43 agents**

#### Agent Status Levels

Every agent has one of three statuses:


| Status      | Meaning                                                    | System Prompt         | Runs?                                       |
| ----------- | ---------------------------------------------------------- | --------------------- | ------------------------------------------- |
| **Active**  | Role is live, executing work                               | Written and deployed  | Yes                                         |
| **Standby** | Role is defined, system prompt ready, waiting for workload | Written, NOT deployed | No -- activated by founder when needed      |
| **Planned** | Role is defined in org chart only                          | Not yet written       | No -- write system prompt before activation |



| Agent                       | Type   | Status  | Notes                                               |
| --------------------------- | ------ | ------- | --------------------------------------------------- |
| Engineering                 | Cursor | Active  | Existing                                            |
| UX/UI Lead                  | Cursor | Active  | Existing                                            |
| Strategy                    | Cursor | Active  | Existing                                            |
| Legal                       | Cursor | Active  | Existing                                            |
| CFO                         | Cursor | Active  | Existing                                            |
| QA Lead                     | Cursor | Active  | Existing                                            |
| Partnerships                | Cursor | Active  | Existing                                            |
| Workflows                   | Cursor | Active  | Existing                                            |
| Tax Domain                  | Cursor | Active  | Existing                                            |
| CPA / Tax Advisor           | Cursor | Active  | Existing                                            |
| Social (general)            | Cursor | Active  | Existing -- splits into product-specific in Phase 6 |
| Growth (general)            | Cursor | Active  | Existing -- splits into product-specific in Phase 6 |
| Brand (general)             | Cursor | Active  | Existing -- splits into product-specific in Phase 6 |
| EA Interactive              | Cursor | Active  | ea.mdc                                              |
| AI Ops Lead                 | Cursor | Active  | agent-ops.mdc                                       |
| Formation Domain            | Cursor | Standby | Write system prompt in Phase 2                      |
| Studio Lead                 | Cursor | Standby | Write system prompt in Phase 1                      |
| FileFree Social             | Cursor | Planned | Phase 6 split                                       |
| FileFree Growth             | Cursor | Planned | Phase 6 split                                       |
| FileFree Brand              | Cursor | Planned | Phase 6 split                                       |
| LaunchFree Social           | Cursor | Planned | Phase 6 split                                       |
| LaunchFree Growth           | Cursor | Planned | Phase 6 split                                       |
| LaunchFree Brand            | Cursor | Planned | Phase 6 split                                       |
| Compliance Monitor          | n8n    | Standby | Activate in Phase 3                                 |
| 6 existing n8n workflows    | n8n    | Active  | Social, Growth, Strategy, QA, Partnership, CPA      |
| EA Daily / EA Weekly        | n8n    | Standby | Activate after Slack hub is set up                  |
| State Data Validator        | n8n    | Standby | Activate in Phase 2                                 |
| Infra Health Monitor        | n8n    | Standby | Activate in Phase 1                                 |
| L1/L2 Support Bots          | n8n    | Planned | Activate when support volume justifies              |
| Competitive Intel           | n8n    | Standby | Activate before first product launch                |
| Analytics Reporter          | n8n    | Standby | Activate when PostHog events > 1K/week              |
| Affiliate Revenue Tracker   | n8n    | Planned | Activate when affiliate revenue exists              |
| LaunchFree Content Pipeline | n8n    | Planned | Activate in Phase 6                                 |
| LaunchFree Compliance Bot   | n8n    | Standby | Activate in Phase 3                                 |
| Knowledge Base Sync         | n8n    | Planned | Activate with support bot                           |
| IRS Update Monitor          | n8n    | Standby | Activate October 2026                               |


#### 6I-1. Governance Protocol: Multi-Agent Consensus

When a significant change is proposed (new feature, architecture decision, legal/compliance change, content strategy shift), it must pass through the relevant agents in the org chart before implementation. This prevents single-persona blind spots.

**Protocol** (inspired by RACI matrix + hierarchical consensus):

```
1. PROPOSE: Founder or agent proposes a change
       |
       v
2. ROUTE: EA routes the proposal to all AFFECTED leaf-node agents
   (e.g., "add 1099 support" routes to: Tax Domain, Engineering, QA, Legal, CPA)
       |
       v
3. REVIEW: Each agent reviews from its domain perspective
   - Tax Domain: "Are the IRS rules correct?"
   - Engineering: "Is the architecture sound?"
   - QA: "Are there security/PII implications?"
   - Legal: "Are there compliance risks?"
   - CPA: "Is the tax logic accurate?"
       |
       v
4. VERDICT: Each agent returns APPROVE / CONCERN / BLOCK
   - APPROVE: No issues in my domain
   - CONCERN: Minor issue, can proceed with noted caveat
   - BLOCK: Serious issue, must resolve before proceeding
       |
       v
5. RESOLVE:
   - All APPROVE -> implement
   - Any CONCERN -> implement with caveats logged to KNOWLEDGE.md
   - Any BLOCK -> escalate to parent node in org chart
     - Parent resolves or escalates further
     - Founder is final arbiter (root node)
```

**When to use full governance**: Architecture changes, new form/schedule support, legal/compliance decisions, partner integrations, security-affecting changes. NOT for: bug fixes, copy changes, routine tasks.

**Implementation**: In Cursor, the founder invokes relevant personas sequentially or asks a "review council" question that triggers multiple personas. In n8n, automated governance runs as a workflow for content (e.g., social post -> Legal Content Review Gate -> approve/reject).

#### 6I-2. Overlap Resolution


| Overlap            | Personas                            | Resolution                                                                                                                                                   |
| ------------------ | ----------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Financial tracking | CFO + EA                            | **EA owns operational tracking** (logging expenses, updating FINANCIALS.md). **CFO owns analysis** (unit economics, vendor evaluation, scaling projections). |
| Strategic planning | Strategy + EA                       | **EA owns tactical planning** (daily/weekly). **Strategy owns strategic direction** (product roadmap, market positioning).                                   |
| Persona audits     | Agent-Ops + QA                      | **Agent-Ops owns model/prompt optimization**. **QA owns security/compliance review**. Different audit dimensions.                                            |
| Social content     | filefree-social + launchfree-social | **Separate globs** prevent co-activation. Shared social infra uses `social-infra.mdc` stub.                                                                  |


#### 6I-3. EA Agent Split


| Role               | Implementation                                 | Responsibilities                                                                                              | Trigger                                      |
| ------------------ | ---------------------------------------------- | ------------------------------------------------------------------------------------------------------------- | -------------------------------------------- |
| **EA Interactive** | `ea.mdc` (Cursor persona)                      | Decision logging, task status queries, ad-hoc ops questions, expense logging, routing proposals to governance | Founder asks operational questions in Cursor |
| **EA Ops Monitor** | `venture-ea-daily` + `venture-ea-weekly` (n8n) | Daily briefing (7am -> Slack #daily-briefing), weekly planning (Sunday 6pm -> GDrive), n8n health checks      | Cron schedules                               |


The interactive EA should NOT generate briefings. The ops monitor should NOT update docs -- it produces reports for the founder to act on.

**Social pipeline cost**: ElevenLabs Starter ($5/mo or startup grant) + Hetzner for FFmpeg (~$6/mo) = **$11-17/mo**.

### 6J. Agent Interaction Model

The founder needs a clear mental model for how to communicate with the AI workforce. Three interaction patterns:

**Pattern 1: CURSOR PERSONAS (interactive -- they join your conversation)**

How: Open a file matching a persona's glob pattern, or explicitly invoke by asking a relevant question.


| Action                                           | What Happens                                     |
| ------------------------------------------------ | ------------------------------------------------ |
| Open `apps/filefree/...`                         | Engineering + FileFree product personas activate |
| Ask "review this for legal compliance"           | `legal.mdc` activates                            |
| Ask "what should I work on today?"               | `ea.mdc` activates                               |
| Ask "is this model the right choice?"            | `agent-ops.mdc` activates                        |
| Ask "log this decision: we chose California LLC" | `ea.mdc` logs to `docs/KNOWLEDGE.md`             |


When: During coding/strategy sessions in Cursor IDE. These are your real-time collaborators.

**Pattern 2: N8N AUTONOMOUS WORKFLOWS (they work while you sleep)**

How: Run on cron schedules or webhook triggers. No founder action needed.


| Time        | Workflow                               | Output Location                      | Founder Action             |
| ----------- | -------------------------------------- | ------------------------------------ | -------------------------- |
| 2am daily   | Knowledge Base Sync                    | Internal DB                          | None (background)          |
| 7am daily   | EA Daily Briefing                      | GDrive + Slack `#daily-briefing`     | Read (5 min)               |
| 8am daily   | Social Content (FileFree + LaunchFree) | Postiz queue                         | Review/approve (5 min)     |
| Hourly      | Infra Health Monitor                   | Slack `#ops-alerts` (only on issues) | Act if alerted             |
| Daily       | Affiliate Revenue Tracker              | GDrive report                        | Check weekly               |
| Sunday 6pm  | EA Weekly Planning                     | GDrive                               | Review and adjust (10 min) |
| Mondays     | Competitive Intel + Growth Content     | GDrive                               | Review at leisure          |
| Monthly 1st | State Data Validator + Compliance Bot  | GitHub Issues + user emails          | Review issues              |


Daily founder time: ~15-20 minutes reviewing agent outputs. Mostly reading briefings and approving social content.

**Pattern 3: ON-DEMAND N8N WORKFLOWS (you trigger them)**

How: n8n webhook URL, Slack slash command, or direct n8n execution.


| Command                       | What Runs                                                                        | Output            |
| ----------------------------- | -------------------------------------------------------------------------------- | ----------------- |
| `/trinket-discover [keyword]` | Market Discovery Agent: researches keyword, finds competitors, sizes opportunity | 1-pager in GDrive |
| `/support [user question]`    | L1 DocBot: answers from knowledge base                                           | Slack response    |
| `/competitive-check`          | Competitive Intel: immediate scan of competitor pricing/features                 | GDrive report     |
| `/ea [question]`              | EA agent: ad-hoc operational query                                               | Slack response    |


### 6J1. Executive Assistant Agent (#32) -- Detail Spec

The EA is the founder's most frequently used agent. It bridges Cursor (interactive) and n8n (autonomous).

**Dual implementation**: `.cursor/rules/ea.mdc` (Cursor persona) + `venture-ea-daily` / `venture-ea-weekly` (n8n workflows)

**What makes the EA different from other agents**: It has write access to documentation. When the founder makes a decision in any conversation, the EA logs it. When a phase task completes, the EA updates `docs/TASKS.md`. When money is spent, the EA updates `docs/FINANCIALS.md`.

**Documents owned by EA**:


| Document                      | Update Frequency       | Trigger                              |
| ----------------------------- | ---------------------- | ------------------------------------ |
| `docs/KNOWLEDGE.md`           | Per conversation       | Founder makes a decision             |
| `docs/TASKS.md`               | Per task completion    | Phase milestone hit                  |
| `docs/FINANCIALS.md`          | Per expense            | Domain purchase, subscription change |
| `docs/VENTURE_MASTER_PLAN.md` | Strategic changes only | Major direction shift                |


---

## 7. Execution Phases

### Phase 0: Infrastructure (Weeks 1-3, Realistic)

**Dependency chain**: P0.1 (DONE) -> P0.2, P0.3, P0.4, P0.5 (parallel) -> P0.6 (blocked on LLC name) -> P0.7 -> P0.8 (needs specimen, after launch) -> P0.9 (parallel with anything)

**Pre-code blockers (Section 0G)**: EFIN application, cyber insurance, LLC name decision, attorney consult, breach response plan. These run parallel to Phase 0 tasks below.


| Task                         | Owner     | Branch                   | Files/Specs                                                                                                                                                                                                                                        | Acceptance Criteria                                                                                                                                                                                | Depends On                             | Status             |
| ---------------------------- | --------- | ------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------- | ------------------ |
| P0.1 Buy domains             | Founder 1 | N/A (no code)            | N/A                                                                                                                                                                                                                                                | launchfree.ai + filefree.ai registrar confirmed                                                                                                                                                    | None                                   | DONE               |
| P0.2 Migrate FileFree domain | Founder 1 | `chore/domain-migration` | `web/next.config.ts` (redirects), Vercel dashboard (custom domain), DNS provider (A/CNAME records)                                                                                                                                                 | filefree.ai serves the app. filefree.tax 301-redirects to filefree.ai. All existing links preserved. SSL cert issued.                                                                              | P0.1                                   | NOT STARTED        |
| P0.3 Google Workspace        | Founder 1 | N/A (no code)            | Google Admin console: add filefree.ai, launchfree.ai as secondary domains. Create aliases: hello@, support@, legal@ for each.                                                                                                                      | Emails received at [hello@filefree.ai](mailto:hello@filefree.ai), [hello@launchfree.ai](mailto:hello@launchfree.ai). SPF/DKIM/DMARC configured for all domains.                                    | P0.1                                   | NOT STARTED        |
| P0.4 Google Drive HQ         | Founder 1 | N/A (no code)            | Create folder structure: `Venture HQ/Operations/Daily Briefings/`, `Venture HQ/Operations/Weekly Plans/`, `Venture HQ/Trinkets/One-Pagers/`, `Venture HQ/Trinkets/PRDs/`, `Venture HQ/Intelligence/`. Add GDrive MCP server to `.cursor/mcp.json`. | GDrive accessible from Cursor via MCP. Folder structure matches EA spec in `ea.mdc`.                                                                                                               | P0.3                                   | NOT STARTED        |
| P0.5 Secure social handles   | Founder 1 | N/A (no code)            | Register @launchfree on TikTok, Instagram, X, YouTube. Set profile pic to monogram, link to launchfree.ai.                                                                                                                                         | All 4 accounts created, profile pics set, bios written, URLs point to launchfree.ai.                                                                                                               | P0.1                                   | NOT STARTED        |
| P0.6 Form LLC                | Founder 1 | N/A (no code)            | California SOS online filing. DBA filings at county clerk (FileFree, LaunchFree, Trinkets).                                                                                                                                                        | Articles of Organization filed with CA SOS. Confirmation number received. DBA filings submitted. EIN applied for on IRS.gov (same day as LLC confirmation). Bank account opened.                   | LLC name decided (Section 0G #4)       | BLOCKED (name TBD) |
| P0.7 Migrate DNS subdomains  | Founder 1 | `chore/dns-migration`    | DNS provider records: ops.paperworklabs.com -> Hetzner (n8n), social.paperworklabs.com -> Hetzner (Postiz). Point paperworklabs.com -> Vercel (apps/studio). Remove old filefree.tax subdomains.                                                   | n8n accessible at ops.paperworklabs.com. Postiz accessible at social.paperworklabs.com. paperworklabs.com serves studio app. Old subdomains return 404 or redirect.                                | P0.2                                   | NOT STARTED        |
| P0.8 File trademarks         | Founder 1 | N/A (no code)            | USPTO TEAS Plus application. FILEFREE: Class 036 + 042. LAUNCHFREE: Class 035 + 042. Supplemental Register.                                                                                                                                        | Applications filed. Serial numbers received. Docket dates noted in TASKS.md.                                                                                                                       | Product launch (needs specimen of use) | DEFERRED           |
| P0.9 Legal compliance setup  | Founder 1 | `chore/legal-compliance` | Update `.cursor/rules/social.mdc`, `growth.mdc`, `brand.mdc` to include Content Review Gate checklist from Section 0C. Create/update `web/src/app/(legal)/privacy/page.tsx`, `web/src/app/(legal)/terms/page.tsx`.                                 | Every content-producing persona .mdc includes the Content Review Gate checklist verbatim. Privacy policy and ToS pages updated with cross-sell consent language from Section 0C Legal Risk Matrix. | None (can start immediately)           | NOT STARTED        |


### Phase 1: Monorepo Restructure (Weeks 3-8, Realistic)

**Dependency chain**: P1.1 -> P1.2 -> P1.3, P1.4 (parallel) -> P1.5 -> P1.6 -> P1.7, P1.8, P1.9, P1.9b (parallel) -> P1.10 -> P1.11

**This is the highest-risk phase**: Every file in the repo moves. Imports break. CI breaks. Expect 4-6 weeks, not 2-3.


| Task                             | Branch                         | Files/Specs                                                                                                                                                                                                                                                                                                                                                                                   | Acceptance Criteria                                                                                                                                                                                                                                                             | Depends On                    |
| -------------------------------- | ------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------- |
| P1.1 Init pnpm workspace         | `feat/monorepo-init`           | `package.json` (root, workspaces config), `pnpm-workspace.yaml` (packages: `apps/`*, `apis/`*, `packages/*`), `.npmrc` (shamefully-hoist=true if needed). Remove root `node_modules/` and `package-lock.json`.                                                                                                                                                                                | `pnpm install` succeeds from root. `pnpm -r list` shows all workspace packages. No npm lockfile present.                                                                                                                                                                        | None                          |
| P1.2 Extract packages/ui         | `feat/shared-ui`               | `packages/ui/package.json`, `packages/ui/src/components/` (22 shadcn components from `web/src/components/ui/`), `packages/ui/src/lib/utils.ts`, `packages/ui/src/lib/motion.ts`, `packages/ui/src/themes.css` (4 brand themes with `[data-theme]` selectors -- see Section 2 palettes), `packages/ui/tsconfig.json`, `packages/ui/tailwind.config.ts` (if needed, or Tailwind v4 CSS config). | `import { Button } from '@venture/ui'` works from any app. All 22 components render correctly. `themes.css` provides filefree (violet-indigo), launchfree (teal-cyan), studio (zinc-neutral), trinkets (amber-orange) CSS variable sets. `pnpm build` succeeds for packages/ui. | P1.1                          |
| P1.3 Extract packages/auth       | `feat/shared-auth`             | `packages/auth/package.json`, `packages/auth/src/hooks/use-auth.ts`, `packages/auth/src/hooks/use-idle-timeout.ts`, `packages/auth/src/lib/api.ts` (base API client with auth headers), `packages/auth/src/components/session-timeout-dialog.tsx`.                                                                                                                                            | `import { useAuth } from '@venture/auth'` works. Auth flow (login, logout, session refresh) functional from any app.                                                                                                                                                            | P1.1                          |
| P1.4 Extract packages/analytics  | `feat/shared-analytics`        | `packages/analytics/package.json`, `packages/analytics/src/posthog.ts`, `packages/analytics/src/attribution.ts`, `packages/analytics/src/components/posthog-provider.tsx`, `packages/analytics/src/components/providers.tsx`.                                                                                                                                                                 | `import { PostHogProvider } from '@venture/analytics'` works. Events fire to PostHog from any app.                                                                                                                                                                              | P1.1                          |
| P1.5 Move web/ -> apps/filefree/ | `feat/move-filefree`           | Move entire `web/` directory to `apps/filefree/`. Update ALL internal imports from `@/components/ui/*` to `@venture/ui`, `@/hooks/use-auth` to `@venture/auth`, etc. Update `apps/filefree/package.json` name to `@venture/filefree`.                                                                                                                                                         | `pnpm dev:filefree` starts on port 3001. All pages render. No broken imports. Tests pass.                                                                                                                                                                                       | P1.2, P1.3, P1.4              |
| P1.6 Move api/ -> apis/filefree/ | `feat/move-filefree-api`       | Move entire `api/` directory to `apis/filefree/`. Update `infra/compose.dev.yaml` volume mounts and build context. Update `render.yaml` root directory. Update Makefile targets.                                                                                                                                                                                                              | `make dev` starts the API on port 8001. All existing endpoints return correct responses. Alembic migrations run.                                                                                                                                                                | P1.5                          |
| P1.7 Scaffold apps/launchfree/   | `feat/scaffold-launchfree`     | Copy `apps/filefree/` structure. Strip product-specific pages (keep: layout, auth, landing). Update package.json name to `@venture/launchfree`. Set `[data-theme="launchfree"]` in root layout. Bare landing page with teal-cyan branding.                                                                                                                                                    | `pnpm dev:launchfree` starts on port 3002. Landing page renders with teal-cyan theme. Auth flow works via shared packages.                                                                                                                                                      | P1.5                          |
| P1.8 Scaffold apis/launchfree/   | `feat/scaffold-launchfree-api` | Copy `apis/filefree/` base patterns (auth middleware, repository pattern, response envelope, config, health endpoint). Strip FileFree-specific routes. Update compose.dev.yaml.                                                                                                                                                                                                               | `apis/launchfree/` starts on port 8002. `/health` returns 200. Auth middleware functional.                                                                                                                                                                                      | P1.6                          |
| P1.9 Scaffold apps/studio/       | `feat/scaffold-studio`         | Next.js app at `apps/studio/`. Package name `@venture/studio`. `[data-theme="studio"]` (zinc-neutral). Pages: `/` (public portfolio/landing), `/admin` (protected, placeholder), `/docs` (public, P4.14 Docs Viewer).                                                                                                                                                                         | `pnpm dev:studio` starts on port 3003. Landing page renders. `/docs` renders a markdown file from the repo.                                                                                                                                                                     | P1.5                          |
| P1.9b Scaffold apps/trinkets/    | `feat/scaffold-trinkets`       | Next.js SSG app at `apps/trinkets/`. Package name `@venture/trinkets`. `[data-theme="trinkets"]` (amber-orange). Pages: `/` (tool directory), `tool-layout.tsx` component, AdSense placeholder component, SEO head component.                                                                                                                                                                 | `pnpm dev:trinkets` starts on port 3004. Tool directory renders. SSG build succeeds (`pnpm build` produces static HTML).                                                                                                                                                        | P1.5                          |
| P1.10 Update infra               | `feat/monorepo-infra`          | `infra/compose.dev.yaml` (update all service build contexts and volume mounts for new paths), `render.yaml` (update root dirs for Render deployment), `Makefile` (add `dev:filefree`, `dev:launchfree`, `dev:studio`, `dev:trinkets`, `dev:all` targets), `.github/workflows/ci.yml` (add `dorny/paths-filter@v3` per Section F11 spec).                                                      | `make dev` starts all services. `make test` runs all test suites. `make lint` lints all workspaces. CI runs path-filtered builds on PR.                                                                                                                                         | P1.6, P1.7, P1.8, P1.9, P1.9b |
| P1.11 Verify                     | N/A (manual)                   | Run all 4 frontends + 2 APIs simultaneously. Verify port assignments: filefree :3001, launchfree :3002, studio :3003, trinkets :3004, filefree-api :8001, launchfree-api :8002.                                                                                                                                                                                                               | All 6 processes start without port conflicts. Each frontend renders its branded theme. Each API responds to `/health`. Cross-package imports resolve.                                                                                                                           | P1.10                         |


### Phase 1.5: First Trinket + Agent Pipeline Test (Week 3-4, 3-5 days)


| Task                                      | Details                                                                                                                                      |
| ----------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------- |
| P1.5.1 Build financial calculator trinket | Mortgage, compound interest, savings goal, budget planner. Client-side JS. Establishes the `apps/trinkets/` pattern.                         |
| P1.5.2 Create tool-layout component       | Shared layout: header, ad unit slots, SEO head, footer, internal links between tools                                                         |
| P1.5.3 Create trinket templates           | `docs/templates/trinket-one-pager.md` + `docs/templates/trinket-prd.md` -- templates the agent pipeline uses                                 |
| P1.5.4 Test Trinket Factory pipeline      | Run the 3-stage agent pipeline (GPT-5.4 Discovery -> Claude Sonnet PRD -> Claude Sonnet Build) on a second trinket idea to validate the flow |
| P1.5.5 Deploy to Vercel                   | SSG, AdSense placeholder, verify SEO (JSON-LD, sitemap, meta tags)                                                                           |


This phase tests the venture's agent infrastructure end-to-end while producing a real deployed product. The financial calculators are pre-decided; the agent pipeline validates a second trinket idea from market discovery.

### Phase 2: 50-State Data Infrastructure (Week 4-7)

This is not a coding task with a side of research. This is an AI-powered data pipeline that populates, validates, and keeps fresh ALL 50 states from day one. The marginal cost of state #11 through #50 is near zero when AI does the extraction. See Section 3B for the full architecture spec.


| Task                                    | Details                                                                                                                                      |
| --------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------- |
| P2.1 Create packages/data scaffold      | TypeScript types, Zod schemas (formation + tax), directory structure, state engine API                                                       |
| P2.2 Build Source Registry              | 50 state configs: SOS URL, DOR URL, Tax Foundation reference, aggregator URLs, scrape method per source                                      |
| P2.3 AI-extract 50-state tax data       | Scrape Tax Foundation 2026 table -> GPT-4o structured extraction -> 50 JSON files -> cross-validate against state DOR sites                  |
| P2.4 AI-extract 50-state formation data | Scrape aggregator tables (WorldPopReview, ChamberOfCommerce) -> GPT-4o extraction -> 50 JSON files -> cross-validate against state SOS sites |
| P2.5 Human review + approval            | Founder reviews AI extractions in batch (est. 4-6 hours total). Each state JSON gets `last_verified`, `sources[]`, `verified_by`             |
| P2.6 Build state engine                 | getStateFormationRules(), getStateTaxRules(), calculateStateTax(), getAllStates(), getStateFreshness()                                       |
| P2.7 Validation suite                   | Zod schemas + sanity checks + 100% test coverage + CI enforcement                                                                            |
| P2.8 n8n: Source Monitor workflow       | Weekly cron: scrape Tax Foundation + aggregator sites, compute content hashes, detect changes, alert on diffs                                |
| P2.9 n8n: Deep Validator workflow       | Monthly cron: scrape all 50 state SOS + DOR sites directly, AI cross-validate against our stored data, flag discrepancies                    |
| P2.10 n8n: Annual Update workflow       | October cron: triggered by IRS Revenue Procedure release, full federal + state refresh cycle                                                 |


### Phase 3: LaunchFree MVP (Week 6-10)


| Task                              | Details                                                          |
| --------------------------------- | ---------------------------------------------------------------- |
| P3.1 LaunchFree landing page      | Hero, how it works, state selector, pricing, trust badges        |
| P3.2 Formation wizard             | State selection -> name check -> details -> review -> submit     |
| P3.3 Articles of Organization PDF | @react-pdf/renderer, state-specific templates                    |
| P3.4 Backend: formation service   | Create formation, store state, generate PDF, track status        |
| P3.5 RA credit system             | $49/yr base, earn credits via partner actions (banking, payroll) |
| P3.6 Stripe integration           | RA subscription, one-time formation fees (for paid states)       |
| P3.7 LaunchFree dashboard         | User's LLC status, compliance checklist, RA status, next steps   |
| P3.8 Legal pages                  | Privacy policy, ToS for LaunchFree (adapt from FileFree)         |


### Phase 4: Command Center (Week 8-14, parallel with Phase 3)

The command center is the control plane for the entire venture. It is what makes the "one human + 37 agents" model operationally viable. Every page is spec'd in detail in Section 3.

**Tier 1 -- Build First (enables daily operations):**


| Task                           | Page                    | Data Sources                                            | Complexity |
| ------------------------------ | ----------------------- | ------------------------------------------------------- | ---------- |
| P4.1 Studio landing page       | `/` public              | Static                                                  | Low        |
| P4.2 Admin auth                | `/admin/`*              | Hardcoded admin email check                             | Low        |
| P4.3 Studio API scaffold       | Backend                 | FastAPI + Redis on Hetzner                              | Medium     |
| P4.4 Mission Control dashboard | `/admin`                | n8n + Render + Vercel + Hetzner + Stripe + PostHog APIs | High       |
| P4.5 Agent Monitor             | `/admin/agents`         | n8n API (workflows + executions)                        | Medium     |
| P4.6 Infrastructure health     | `/admin/infrastructure` | Render + Vercel + Hetzner + Neon + Upstash APIs         | Medium     |
| P4.14 Docs viewer              | `/docs/`* (public)      | GitHub raw content API -> react-markdown                | Low        |


**Tier 2 -- Build Next (enables growth operations):**


| Task                         | Page               | Data Sources                               | Complexity |
| ---------------------------- | ------------------ | ------------------------------------------ | ---------- |
| P4.7 Analytics               | `/admin/analytics` | PostHog API or embeds                      | Medium     |
| P4.8 Support inbox           | `/admin/support`   | Support bot PostgreSQL (Hetzner)           | Medium     |
| P4.9 Social media command    | `/admin/social`    | Postiz API                                 | Medium     |
| P4.10 State Data observatory | `/admin/data`      | packages/data JSON + n8n validator results | Low        |


**Tier 3 -- Build When Revenue Flows:**


| Task                       | Page               | Data Sources                                | Complexity |
| -------------------------- | ------------------ | ------------------------------------------- | ---------- |
| P4.11 Revenue intelligence | `/admin/revenue`   | Stripe API + affiliate dashboards           | Medium     |
| P4.12 Campaign control     | `/admin/campaigns` | Campaign tables in studio DB                | High       |
| P4.13 User intelligence    | `/admin/users`     | Venture identity DB + cross-product queries | High       |


### Phase 5: User Intelligence Platform (Week 10-12)


| Task                                  | Details                                                                                                                                                                                                                                                                                                    |
| ------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| P5.1 Venture identity data model      | VentureIdentity, IdentityProduct, UserEvent, UserSegment, Campaign, CampaignEvent tables                                                                                                                                                                                                                   |
| P5.2 Cross-product opt-in consent     | "I consent to [LLC Name] using my information across FileFree, LaunchFree, and related services to send me product updates and recommendations. I can unsubscribe from any product at any time." Unchecked default. Per-brand unsubscribe in email footer. See Section 0C Legal Risk Matrix for full spec. |
| P5.3 packages/cross-sell engine       | Rules-based recommendation engine: segments + milestones + timing -> action                                                                                                                                                                                                                                |
| P5.4 packages/email templates         | React Email templates: onboarding series + cross-sell + partner offers (Legal reviewed)                                                                                                                                                                                                                    |
| P5.5 LaunchFree onboarding emails     | 5-email welcome series via n8n + Gmail (with cross-product opt-in respect)                                                                                                                                                                                                                                 |
| P5.6 LaunchFree -> FileFree campaigns | Tax season blast, post-formation nudge (only for users who opted in)                                                                                                                                                                                                                                       |
| P5.7 User event tracking              | Emit UserEvents from both products on key milestones (formed LLC, filed taxes, clicked partner)                                                                                                                                                                                                            |
| P5.8 Campaign analytics + admin       | PostHog events, UTM tracking, campaign performance in admin dashboard                                                                                                                                                                                                                                      |


### Phase 6: Agent Restructure + Social Pipeline (Week 10-14)


| Task                                        | Details                                                                                                    |
| ------------------------------------------- | ---------------------------------------------------------------------------------------------------------- |
| P6.1 Update 9 venture-level personas        | engineering, strategy, legal, cfo, qa, partnerships, ux, workflows (update content for venture-wide scope) |
| P6.2 Split 3 personas into product-specific | social -> filefree-social + launchfree-social; brand -> split; growth -> split                             |
| P6.3 Create 6 new personas                  | formation-domain, launchfree-social, launchfree-growth, launchfree-brand, studio, agent-ops                |
| P6.4 Update 6 existing n8n workflows        | Rename, update outputs from Notion to GDrive                                                               |
| P6.5 Build faceless content pipeline        | n8n workflow: topics -> GPT script -> ElevenLabs -> video assembly -> Postiz                               |
| P6.6 Build 12 new n8n workflows             | Support bots, state validator, competitive intel, analytics, infra monitor, campaign engine                |
| P6.7 Migrate Notion to Google Drive         | Move docs, update n8n output nodes                                                                         |


### Phase 7: FileFree Season Prep (October 2026)


| Task                                  | Details                                                                                                                                 |
| ------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------- |
| P7.1 Resume FileFree Sprint 4         | All 50 state tax calcs (data already built in P2.3), PDF polish                                                                         |
| P7.2 Column Tax integration           | SDK integration, sandbox testing                                                                                                        |
| P7.3 TaxAudit partnership             | White-label audit shield integration (if Founder 2 closed deal)                                                                         |
| P7.4 Refund Plan screen               | HYSA referrals, financial product recs, audit shield upsell                                                                             |
| P7.5 Transactional emails             | Welcome, filing confirmation, abandonment drip                                                                                          |
| P7.6 FileFree -> LaunchFree campaigns | Post-filing cross-sell for users with biz income                                                                                        |
| P7.7 Marketing page refresh           | Social proof, filing counter, comparison table                                                                                          |
| P7.8 1099-NEC + Schedule C support    | Freelancer/gig income. 1099-NEC extraction via OCR pipeline, Schedule C business income/expenses                                        |
| P7.9 Dependent support                | Dependent information capture, Child Tax Credit ($2,000/child), EITC calculations, HOH filing status                                    |
| P7.10 Schedule B (interest/dividends) | Interest and ordinary dividend income, auto-populate from 1099-INT/1099-DIV                                                             |
| P7.11 Schedule 1 (additional income)  | Student loan interest, educator expenses, HSA deductions, IRA contributions                                                             |
| P7.12 All 50 state return engines     | Data-driven state tax calculation engine. Each state defined in JSON (rates, brackets, credits, conformity). ALL 50 states from launch. |


### Form Coverage Roadmap


| Milestone                      | Forms                                                                                                  | Notes                                                      |
| ------------------------------ | ------------------------------------------------------------------------------------------------------ | ---------------------------------------------------------- |
| **January 2027 launch**        | 1040 + Schedule 1 + Schedule B + Schedule C + 1099-NEC/INT/DIV + dependents + ALL 50 state returns     | Covers ~80% of US filers                                   |
| **February 2027 (mid-season)** | Schedule A (itemized deductions) + Schedule D (capital gains basics)                                   | Covers homeowners + basic investors                        |
| **Year 2 (2027-2028 season)**  | Schedule E (rental), Schedule SE (self-employment tax), multi-state, HSA (Form 8889), K-1 pass-through | Covers small landlords, full self-employed, health savings |
| **Year 3+**                    | Depreciation (Form 4562), AMT (Form 6251), brokerage import (CSV/API), foreign income (Form 2555)      | Edge cases, power users                                    |


**MeF ATS testing scope**: The October 2026 ATS testing must cover 1040 + Schedule 1 + B + C + state return XML schemas for ALL 50 states. Start XML generator development by June 2026.

### 7D. MeF Local Validation Engine (Zero-Risk ATS Strategy)

ATS testing is schema validation -- the IRS programmatically checks your XML output against published schemas. This is exactly what AI excels at. By building a local validation engine FIRST, we achieve near-100% first-submission pass rate to ATS.

**Key facts** (verified):

- IRS ATS requires ~13 test scenarios for Form 1040 (published as PDFs on irs.gov)
- ALL XML schemas are publicly downloadable from irs.gov/downloads/irs-schema
- State MeF schemas are published by E-Standards (statemef.com), the FTA-recognized body
- State returns piggyback on the federal submission -- you don't submit 50 separate state packages
- 42 states + DC participate in the 1040 MeF program. Only CA FTB and MA DOR run independent systems.

**Pipeline**:


| Step                          | Timeline       | Agent Work                                                                                                                                                              | Human Work                               |
| ----------------------------- | -------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------- |
| P7.13 Schema acquisition      | June 2026      | Download ALL IRS + E-Standards XML schemas. Parse into Zod types (TS) and Pydantic models (Python). Build schema version tracker.                                       | None                                     |
| P7.14 Local validation engine | June-July 2026 | Build XML generator from tax calculation output. Build local schema validator. Generate all 13 IRS test scenarios programmatically. Iterate until 100% local pass rate. | Review 2-3 generated XML files           |
| P7.15 Test return factory     | August 2026    | For each of 42 MeF-participating states, generate a test return with correct state schema piggyback. Validate ALL state attachments locally. Generate coverage report.  | Review coverage report                   |
| P7.16 ATS submission          | October 2026   | Submit all 13 federal scenarios (already locally validated). Monitor acknowledgments. Auto-fix and resubmit any rejections.                                             | Contact e-Help Desk if non-schema issues |
| P7.17 Communication test      | November 2026  | Automated end-to-end transmission test.                                                                                                                                 | Verify acknowledgment                    |


**For CA FTB and MA DOR** (independent systems): Use Column Tax as e-file partner for these 2 states only in Year 1. Apply for their independent transmitter programs in Year 2.

**Residual risk**: Zero for schema-related failures. Only risk is IRS process delays (their systems being slow), mitigated by starting June not October.

### 7E. Tiered State Tax Engine Architecture

Federal tax is uniform. State tax is chaos. The engine uses three tiers to handle all 50 states efficiently:

**Tier 1 -- Conforming States (~30 states)**: Start from federal AGI or taxable income, apply state-specific rate brackets, standard deduction, and credits. Entirely data-driven via JSON config. Examples: Colorado (flat 4.4% of federal taxable income), Utah (flat 4.65%), Michigan (flat 4.25%).

**Tier 2 -- Semi-Conforming States (~12 states)**: Start from federal AGI but with state-specific modifications. JSON config + small modifier functions per state. Examples: Virginia (starts from federal AGI, subtracts VA-specific deductions, applies VA brackets), Georgia (adjusts for GA standard deduction amounts).

**Tier 3 -- Independent States (~5 states: CA, NJ, PA, MA, NH)**: Fully custom calculation modules per state. Agent generates initial module from state tax form instructions (publicly available PDFs). Human reviews tax logic. Example: California starts from federal AGI but has its own Schedule CA with ~40 modification items.

**No-income-tax states (7: AK, FL, NV, SD, TX, WA, WY)**: No state return needed. Config flag: `"hasIncomeTax": false`.

**Budget**: Tier 1 states take minutes each (config only). Tier 2 states take hours each. Tier 3 requires 2-3 days per state. Total extra budget: 2 weeks in Phase 7.

### Phase 8: FileFree Launch (January 2027)


| Task                            | Details                                                                                                                                               |
| ------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------- |
| P8.1 MeF transmitter            | Build XML generator, pass IRS ATS testing (October), communication test (November). Test schemas for 1040 + Schedules 1, B, C + all 50 state returns. |
| P8.2 E-file go-live             | Switch from Column Tax to own transmitter for supported forms                                                                                         |
| P8.3 Tax Optimization Plan      | Stripe, $29/yr, premium dashboard                                                                                                                     |
| P8.4 Product Hunt + HN launch   | Coordinate with filing season start                                                                                                                   |
| P8.5 Paid amplification         | TikTok Spark Ads + Meta boost on winning organic content                                                                                              |
| P8.6 Schedule A (itemized)      | Mid-season release (February 2027). Mortgage interest, SALT, charitable contributions                                                                 |
| P8.7 Schedule D (capital gains) | Mid-season release (February 2027). Basic stock sales, 1099-B import                                                                                  |
| P8.8 Refund Advance integration | If partner secured. Early refund access as acquisition tool                                                                                           |


### Background Tasks (Continuous)


| Task                                                                          | Owner     | Deadline                   | Status      | Notes                                                                           |
| ----------------------------------------------------------------------------- | --------- | -------------------------- | ----------- | ------------------------------------------------------------------------------- |
| EFIN application (Form 8633)                                                  | Founder 1 | THIS WEEK                  | NOT STARTED | 45-day processing. Blocks entire MeF chain. See Section 0G.                     |
| Self-serve affiliate apps (Marcus, Wealthfront, Betterment via Impact.com/CJ) | Founder 1 | April 2026                 | NOT STARTED | Plan B revenue. Online forms, no calls needed. Do this regardless of Founder 2. |
| Cyber liability insurance ($1M E&O + cyber)                                   | Founder 1 | Before first SSN collected | NOT STARTED | $1,500-3,000/yr. Non-negotiable. See Section 0G.                                |
| Data breach response plan                                                     | Founder 1 | Before first SSN collected | NOT STARTED | 2-page doc from SANS/NIST templates. See Section 0G.                            |
| Startup attorney consult (1 hour)                                             | Founder 1 | Before Phase 3             | NOT STARTED | UPL + RA questions. ~$300-500. See Section 0G.                                  |
| Column Tax partnership                                                        | Founder 2 | June 2026                  | NOT STARTED | Book demo, negotiate sandbox access.                                            |
| TaxAudit/audit shield partnership                                             | Founder 2 | September 2026             | NOT STARTED | 3-6 month lead time, start Q2 2026.                                             |
| HYSA affiliate applications (banking partners)                                | Founder 2 | October 2026               | NOT STARTED | At least 1 banking partner for first tax season.                                |
| MeF certification prep                                                        | Founder 1 | Start June 2026            | NOT STARTED | XML generator -> ATS testing (October) -> Comms test (November).                |
| TikTok Spark Ads budget                                                       | Founder 1 | At LaunchFree launch       | NOT STARTED | $100-300/mo max. Boost proven organic winners only. See Section 5K.             |
| Pre-launch audience building                                                  | Founder 1 | Ongoing, start NOW         | NOT STARTED | SEO blog posts, Reddit, waitlist growth. See Section 5K.                        |


### Phase Timeline (Agent-Augmented)

The 8-phase plan spans infrastructure (now) through FileFree launch (January 2027) -- 10 months. With a full AI agent workforce handling research, content, documentation, data extraction, and code generation, the human bottleneck is decision-making and review, not execution volume. The timeline below reflects agent-augmented capacity.


| Phase                          | Aspirational | Realistic                     | Rationale                                                                                                                                                                                                                | Can Defer?                                                   |
| ------------------------------ | ------------ | ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------ |
| Phase 0 (Infrastructure)       | 1 week       | 2-3 weeks                     | LLC name decision is blocking. EFIN application has 45-day processing. Non-code tasks take longer than expected.                                                                                                         | NO -- critical path                                          |
| Phase 1 (Monorepo)             | 2-3 weeks    | 4-6 weeks                     | pnpm workspace restructure, shared package extraction, 4 apps scaffolded, infra updates. This is fiddly and breaks things.                                                                                               | NO -- everything depends on it                               |
| Phase 1.5 (First Trinket)      | 3-5 days     | 1-2 weeks                     | Overlaps with late Phase 1. Agent pipeline testing adds uncertainty.                                                                                                                                                     | YES -- defer to after Phase 3 if behind                      |
| Phase 2 (50-State Data)        | 3-4 weeks    | 4-6 weeks                     | AI extraction is fast but human review of 50 states is the bottleneck (4-6 hours). n8n workflows need testing.                                                                                                           | NO -- LaunchFree depends on it                               |
| Phase 3 (LaunchFree MVP)       | 4-5 weeks    | 8-12 weeks                    | This is an entire product. Formation wizard, state-specific PDF generation, Stripe integration, RA credit system, dashboard. The "submit LLC" step is hand-waved -- most states do NOT have filing APIs. See note below. | NO -- this is the first revenue product                      |
| Phase 4 (Command Center)       | 6 weeks      | 4-6 weeks (Tier 1 only)       | Build Tier 1 only during Phase 3. Tier 2-3 deferred until post-LaunchFree launch.                                                                                                                                        | PARTIAL -- Tier 2-3 defers                                   |
| Phase 5 (User Intelligence)    | 2-3 weeks    | 3-4 weeks                     | Requires Phase 3 completion. Cross-product data model, consent UI, email templates, campaign engine.                                                                                                                     | YES -- can launch LaunchFree without it, add within 2 months |
| Phase 6 (Agent Restructure)    | 4 weeks      | 2-3 weeks (with right-sizing) | Reduced agent count (see Section 6 stress test). Most personas are config files, not code. Social pipeline is the only complex build.                                                                                    | PARTIAL -- social pipeline defers                            |
| Phase 7 (FileFree Season Prep) | October 2026 | October 2026 (HARD DEADLINE)  | IRS season doesn't move. Must start MeF XML generator by June 2026 to hit October ATS testing window.                                                                                                                    | NO -- date is external                                       |
| Phase 8 (FileFree Launch)      | January 2027 | January 2027 (HARD DEADLINE)  | Tax season start. IRS accepts returns ~late January.                                                                                                                                                                     | NO -- date is external                                       |


**Timeline**: 10 months (March 2026 - January 2027). The primary bottleneck is founder decision-making and context-switching between products. Mitigation: batch similar work (e.g., all legal tasks in one sprint), use agents to pre-research and draft so founder reviews rather than creates, and protect 2-hour deep work blocks daily. Phase 7 is tight but achievable if EFIN application happens THIS WEEK and MeF XML development starts by June 2026.

### Critical Path (Stress Test Addition)

```
LLC Name Decision (NOW) -> Phase 0.6 (file LLC) -> EIN -> Bank Account -> Stripe -> Trademarks
                                                                                 |
EFIN Application (NOW) -------- 45 days ---------> Software Dev ID -> ATS Testing (Oct 2026) -> MeF Launch (Jan 2027)
                                                                                 |
Phase 1 (Monorepo) -> Phase 2 (50-State) -> Phase 3 (LaunchFree) -> Phase 7 (FileFree Prep) -> Phase 8 (Launch)
```

**Three hard deadlines that cannot move**:

1. **EFIN approval**: Must apply NOW. 45-day processing means approval by May 2026 at earliest. Late application compresses the October ATS testing window.
2. **MeF ATS testing**: IRS opens ATS testing window each fall. Must have XML generator complete by June 2026 to test in October. Miss this and FileFree e-file delays to January 2028.
3. **Tax season**: IRS starts accepting returns late January. Product must be live by then.

### LaunchFree "Submit LLC" Reality Check (Stress Test Addition)

The formation wizard says "submit" but most states do NOT have e-filing APIs for LLC Articles of Organization. The reality:


| Method                                 | States                                   | Implementation                                                                                                                                        |
| -------------------------------------- | ---------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------- |
| Online filing portal exists (web form) | ~15-20 states (e.g., CA, DE, WY, TX, FL) | We CANNOT auto-submit. We can pre-fill a printable form, generate the PDF, and provide step-by-step walkthrough with screenshots of the state portal. |
| Mail-only filing                       | ~20-25 states                            | Generate completed PDF + cover letter. User prints, signs, mails with check. We provide pre-addressed envelope instructions.                          |
| Registered agent submits               | ~10 states                               | Partner RA handles submission. This is the premium path.                                                                                              |


**Honest UX**: LaunchFree "prepares your LLC filing" -- it does NOT "file for you" in most states. The language must reflect this. The value is in the AI state comparison, document preparation, and compliance calendar -- not in pressing a "submit" button that doesn't exist for 35+ states.

### 7B. Alerting Strategy

The Infra Health Monitor (Agent #25) needs a clear alerting hierarchy:


| Severity | Condition                                                | Alert Channel                   | Response Time     |
| -------- | -------------------------------------------------------- | ------------------------------- | ----------------- |
| CRITICAL | Render/Vercel DOWN, API 5xx rate >5%                     | Slack #ops-alerts + Email + SMS | Immediate         |
| WARNING  | API response time >2s, error rate >1%, disk >80%         | Slack #ops-alerts + Email       | Within 1 hour     |
| INFO     | Deploy completed, cron job finished, daily health report | Slack #ops-alerts only          | Next business day |


**Alert routing**:

- All alerts go to Slack `#ops-alerts` channel (see Section 14 for full Slack hub architecture)
- CRITICAL also sends email to founder + SMS via Twilio ($0.0075/SMS, ~$2/month max)
- n8n handles all alert routing logic (Slack API nodes + Twilio API)

**Monitoring endpoints**:

- Render: `https://api.render.com/v1/services/{id}` (health status)
- Vercel: `https://api.vercel.com/v9/deployments` (deployment status)
- Hetzner: direct HTTP health check to n8n/Postiz endpoints
- Neon: connection test via studio API health endpoint
- Upstash: Redis PING via studio API health endpoint

### 7C. Trinkets Domain Decision

**Decision**: Use `tools.filefree.ai` subdomain. Do NOT buy individual domains per trinket.

**Rationale** (SEO research-backed):

- No domain purchase needed (we own filefree.ai)
- Easy DNS setup (CNAME to Vercel)
- Subdomain inherits some domain authority from filefree.ai (confirmed: subdirectories > subdomains > new domains for SEO authority)
- Individual exact-match domains (e.g., `freemortgagecalculator.com`) have been devalued by Google since 2012 EMD update
- New domains start at DA 0 -- won't outrank established tools (NerdWallet, Bankrate, Calculator.net) for years
- At Year 1 trinkets revenue of $50-300, buying 15+ domains at $10-15/yr each is negative ROI
- Cross-sell CTAs naturally funnel traffic from trinkets to FileFree/LaunchFree

**Graduation criteria**: If a single trinket exceeds 10K monthly visits, consider buying a standalone domain and 301-redirecting. This is a growth optimization, not a launch decision.

**URL structure**: Subdirectory-style paths on the subdomain for topical clustering: `tools.filefree.ai/calculators/mortgage`, `tools.filefree.ai/converters/pdf-to-word`. See Section 0F for full technical pattern.

**Vercel config**: Add `tools.filefree.ai` as a custom domain to the `apps/trinkets/` Vercel project.

---

## 8. Plan Hygiene

### Plans to Archive (Superseded by This Document)

These plans from the venture strategy conversations are fully superseded:

1. `venture_master_strategy_ceeba1fd.plan.md`
2. `definitive_execution_plan_d3b7c878.plan.md`
3. `consolidated_strategic_review_11e18e9f.plan.md`
4. `revenue_social_agents_review_2da9fa89.plan.md`
5. `adjacent_business_opportunities_6683a5fc.plan.md`
6. `bizfree_stress_test_deep_a5395931.plan.md`
7. `bizfree_credit_model_review_46727fa1.plan.md`
8. `bizfree_naming_strategy_5fb6b573.plan.md`
9. `naming_strategy_deep_dive_ddcb53aa.plan.md`
10. `company_structure_deep_dive_f2e01bce.plan.md`
11. `adulting_os_strategic_master_plan_1a3a9b0d.plan.md` (+ duplicate `_262c0a19`)
12. `support_automation_strategy_3ed0ae08.plan.md` (+ duplicate `_590011fb`)
13. `deep_research_tightening_cc2f702c.plan.md`
14. `utility_tool_empire_strategy_383c8c1f.plan.md` (+ `_37aa2741`)
15. `naming_ra_trinkets_updates_ef9d6883.plan.md`

### Plan Ordering Rule

Create a Cursor rule (`.cursor/rules/plans.mdc`) that enforces:

- **One master plan per venture decision cycle** (this document is v1)
- Plans are prefixed with version and date: "Venture Master Plan v1 (2026-03-11)"
- Sub-plans for specific coding tasks reference the master plan section
- When a plan is superseded, move it to `.cursor/plans/archive/` (create dir)
- Never create a plan without checking if an existing one covers the scope

### Anti-Bloat Rules

This plan is the company OS. It must stay readable. Rules:

1. **Phase Completion Collapse**: When a Phase is COMPLETE, collapse its task table to a single summary line: "Phase 1: COMPLETE -- monorepo restructure, 14 tasks, merged via PRs #15-28." Detailed tasks live in git history and TASKS.md.
2. **KNOWLEDGE.md Rotation**: Every 6 months, archive decisions older than 6 months to `docs/archive/KNOWLEDGE_YYYY_HN.md`. Keep the active file under 500 lines.
3. **TASKS.md Sprint Archive**: Completed sprints collapse to a one-line summary. Detailed task history lives in git. Keep TASKS.md under 500 lines of active content.
4. **Superseded Doc Archive**: Any doc fully superseded by this master plan moves to `docs/archive/`. Currently superseded: STRATEGY_REPORT.md, UTILITY_SITES_STRATEGY.md, SOCIAL_ROADMAP.md.
5. **Master Plan Target**: Keep under 3,500 lines. If approaching, collapse completed phases and merge redundant sections.

### docs/TASKS.md Update

When execution begins, the Phase 0-8 tasks above get merged into `docs/TASKS.md` as new sprints, replacing the current Sprint 4+ sections with the corrected venture-wide roadmap. The existing Sprint 0-3 (completed work) stays as historical record.

---

## 9. McKinsey Self-Review: All Personas Critique This Plan

Each persona reviewed the plan from their perspective. Findings grouped by severity. Detailed research for each finding is in the `deep_research_tightening` plan (archived but retained as reference).

### CRITICAL Findings

**F1. Scope Risk: 13 Admin Pages + 3 Products (CFO + Strategy)**

The command center has 13 admin pages across 3 tiers. Combined with LaunchFree MVP + FileFree resume + social pipeline, this is a large scope for a single founder.

**MITIGATION**: Build all 13 pages but in 3 tiers (Tier 1 with MVP, Tier 2 post-launch, Tier 3 with revenue). Managed via tiering, no scope cut.

**F2. CAN-SPAM + Company Structure (Legal + CPA)**

CAN-SPAM is opt-OUT (not opt-IN) for same-entity commercial emails. Since we're a single LLC with DBAs, cross-brand emails are technically from one sender. However, state privacy laws (CCPA) and trust best practices demand explicit opt-in.

**DECISION**: Single LLC + DBAs. Opt-in checkbox exceeds CAN-SPAM (opt-out law) but satisfies state privacy laws and builds trust. See Section 0B-0C.

### HIGH Findings

**F3. Social Content Pipeline Validation (Growth)**

DIY n8n pipeline at $0.10/video. Build pipeline first, validate with actual output for 2 weeks. No deferral -- the pipeline IS the test. See Section 5 for full spec.

**F4. 50-State Data Pipeline: All 50, Day One (Engineering + Tax Domain)**

The "research mountain" concern assumed manual research (30-60 min/state = 25-50 hours). With the AI-powered pipeline described in Section 3B:

- GPT does the extraction from structured web tables (~5 min/state AI time)
- Human reviews in batch (4-6 hours total for all 50 states)
- Three n8n monitoring workflows keep data fresh perpetually

**DECISION**: All 50 states, day one. The pipeline spec (Section 3B) guarantees this.

**F6. Brand Palettes for Each Product (UX + Brand)**

Multi-brand design systems use CSS variable theming with `[data-theme]` selectors. FileFree: violet-indigo. LaunchFree: teal-cyan. Studio: zinc-neutral. Implementation via `packages/ui/themes.css`. Split complementary color theory for family cohesion.

---

### MEDIUM Findings

**F7. RA Legal + Trademark Risk (Legal -- CRITICAL RESEARCH)**

### RA Service Requirements (Expanded)

Being a Registered Agent is NOT "vibe codeable." Research confirms ([howtostartabusiness.org](https://www.howtostartabusiness.org/registered-agent/requirements/)):

- **All 50 states**: physical street address (no PO box), available during business hours, 18+
- **Delaware**: commercial RAs must obtain state certificate
- **Nevada**: commercial RAs must be licensed
- **California**: 60-day resignation notice required
- **Alaska**: prohibits non-corporate LLCs from serving as RA
- Failure to forward legal documents = **default judgment** against user's LLC. This is liability we do NOT want.

### RA Pricing Reality (Corrected)

**For our own Wyoming LLC**: $25-29/yr (Wyoming-specific budget providers like wyomingllc.info at $25/yr or Rocky Mountain RA at $29/yr).

**For LaunchFree users (all 50 states)**: Wholesale volume pricing from CorpNet:


| Volume (active users) | Our Cost/User/Yr | What We Charge         | Margin |
| --------------------- | ---------------- | ---------------------- | ------ |
| 0-19 users            | ~$149/yr         | $149/yr (pass-through) | $0     |
| 20-50 users           | $119/yr          | $119-149/yr            | $0-30  |
| 51-150 users          | $99/yr           | $99-119/yr             | $0-20  |
| 151-500 users         | $89/yr           | $99/yr                 | $10    |
| 501-1,000 users       | $59/yr           | $79/yr                 | $20    |
| 1,001+ users          | $49/yr           | $49-79/yr              | $0-30  |


**GoDaddy "Free LLC" -- Competitive Analysis**: GoDaddy (via LegalZoom partnership) offers $0 service fee for LLC formation. But users still pay state fees ($100-800) + RA (~$150/yr) + upsells (operating agreement, EIN filing). ZenBusiness similarly baits at $99/yr RA, renews at $199/yr. LegalZoom charges $249/yr for RA.

**LaunchFree's REAL Competitive Moat** (it's NOT just "free filing" -- everyone does that now):

1. **No bait-and-switch**: Transparent pricing, no surprise renewals ($99/yr flat vs ZenBusiness $199 renewal)
2. **AI-powered guidance**: GPT-powered wizard in plain English, generates operating agreement, walks through EIN
3. **RA credit system**: Earn credits through referrals/activity, reduce cost toward $0 (at scale when wholesale hits $49)
4. **Cross-sell trust**: "You already trust us with your taxes. Now launch your business."
5. **All 50 state data, AI-maintained**: Formation requirements, fees, pros/cons -- updated by AI agents, not stale blog posts
6. **Compliance calendar**: Automated reminders for annual reports, franchise taxes, RA renewals (competitors charge $100+/yr for this)

**RECOMMENDATION (phased)**:

- **Phase 1 (0-500 users)**: Partner RA at wholesale. Charge $99/yr (transparent, cheaper than ZenBusiness $199 and LegalZoom $299). Position as "no surprise renewals."
- **Phase 2 (500+ users)**: Drop to $79/yr as volume pricing kicks in. Introduce credit system.
- **Phase 3 (1,000+ users)**: Drop to $49/yr or offer free RA with financial product partnerships. DIY RA only at this scale.

DIY RA deferred indefinitely. Requires:

- Physical addresses in all 50 states (~$2,500-5,000/yr via virtual offices)
- E&O insurance for RA liability
- State-by-state commercial RA registration where required
- Compliance staff or very robust automation

### Trademark Risk: filefree.com Is Intuit's (CONFIRMED)

See Section 0C for the full analysis. Summary:

- filefree.com owned by Intuit since 1999 (WHOIS confirmed: MarkMonitor registrar)
- "FileFree" is descriptive in the tax space -- harder to register BUT harder for Intuit to enforce
- File on **USPTO Supplemental Register** ($700 per mark, 2 classes each)
- After 5 years of commercial use, petition for Principal Register
- NEVER reference filefree.com anywhere. We operate on filefree.tax / filefree.ai.
- FTC "free" compliance: our service IS free, no conditions, no asterisks -- this is our strongest legal position

### Strict Legal Guidelines

Section 0C contains the complete compliance framework that ALL personas, agents, social content, emails, and marketing must follow. Key rules:

1. Brand names always as proper nouns (FileFree, LaunchFree -- exact casing)
2. Never use "file free" as a verb phrase in marketing (say "file your taxes for free")
3. Circular 230 disclaimer on all tax content
4. UPL disclaimer on all legal/formation content
5. FTC affiliate disclosure on all partner recommendations
6. Content Review Gate checklist before ANY publishing

---

**F8. Cross-Sell Compliance: Four Regulatory Frameworks (CPA + Legal -- Holistic)**

Cross-sell messages touch FOUR regulatory frameworks simultaneously:

**1. CAN-SPAM** (email): Unsubscribe, physical address, honest subjects. Penalty: $51,744/email.
**2. FTC "Free" Guide** (advertising): Service must actually be free with no hidden conditions. RA credits must disclose base $49/yr price. Penalty: FTC enforcement.
**3. IRS Circular 230** (tax advice): EDUCATION only, never specific advice. "Many filers..." not "You should..."
**4. State UPL laws** (legal advice): Formation SERVICES not legal advice. "Many choose Delaware because..." not "You should form in Delaware."

### Message Framework

- BAD: "You should form an LLC to protect yourself" (legal advice -- UPL violation)
- GOOD: "Many sole proprietors choose to form an LLC for liability protection. Here's how it works." (education)
- BAD: "Your LLC needs to file taxes" (directive -- Circular 230 risk)
- GOOD: "LLC owners typically need to file business taxes. FileFree makes it free." (informational)
- BAD: "Free RA service!" (misleading -- base price is $49/yr)
- GOOD: "RA service starting at $49/yr. Earn credits to reduce or eliminate the cost." (transparent)

### Every User-Facing Message Must Pass the Content Review Gate (Section 0C)

This includes: emails, social posts, in-app notifications, AI-generated tips, push notifications, landing page copy, and partner recommendation pages. No exceptions. The checklist is in Section 0C and must be built into every content persona's system prompt.

---

**F9. Admin Dashboard UX: Functional Over Beautiful (UX)**

The command center is internal tooling, not a customer-facing product. The UX bar is different: speed to insight over visual polish.

**RECOMMENDATION**:

- Use shadcn Table components for all list views (agents, campaigns, state data, users). No custom data grid libraries.
- Use Recharts (already in stack) for trend charts. Keep to 3 chart types: line, bar, pie.
- No animations or transitions in admin pages. Instant renders.
- Every page should load in <1 second. React Query with aggressive caching (staleTime: 60s for most data, 5s for health checks).
- The Activity Feed on Mission Control is the most important UX element -- it should feel like a live terminal. Monospace font, new entries slide in from top, auto-scroll.
- Mobile responsive is nice-to-have, not required. The founder will use this on a laptop, not a phone.

---

### LOW Findings

**F10. Social Media Content Quality Review (QA)**

Tax/finance content has regulatory requirements (IRS Circular 230 disclaimers, FTC disclosures for referrals). A fully automated pipeline with 5-min human review risks publishing non-compliant content.

**RECOMMENDATION**: For the first 30 days, founder reviews EVERY post before publishing (not just 5 min glance). After 30 days, establish a "pre-approved template" system where the n8n pipeline can only generate content from approved template structures. Novel content still requires manual review.

---

**F11. Monorepo CI: Path-Filtered Builds (Engineering -- Detailed Spec)**

pnpm workspaces without Turborepo means CI runs ALL tests on every PR by default. With 3 apps + 3 APIs + shared packages, this becomes 10+ minutes.

**SOLUTION**: `dorny/paths-filter@v3` ([source: oneuptime.com](https://oneuptime.com/blog/post/2025-12-20-monorepo-path-filters-github-actions/view)) -- the industry standard for monorepo CI:

```yaml
jobs:
  detect-changes:
    runs-on: ubuntu-latest
    outputs:
      filefree: ${{ steps.filter.outputs.filefree }}
      launchfree: ${{ steps.filter.outputs.launchfree }}
      shared: ${{ steps.filter.outputs.shared }}
    steps:
      - uses: dorny/paths-filter@v3
        id: filter
        with:
          filters: |
            filefree:
              - 'apps/filefree/**'
            launchfree:
              - 'apps/launchfree/**'
            shared:
              - 'packages/**'
              - 'pnpm-lock.yaml'

  filefree-ci:
    needs: detect-changes
    if: needs.detect-changes.outputs.filefree == 'true' ||
        needs.detect-changes.outputs.shared == 'true'
    # lint + test + build for filefree only
```

Key rules:

- Shared `packages/**` changes trigger ALL downstream apps
- `pnpm-lock.yaml` changes trigger everything (dependency change)
- Docs-only changes trigger nothing (`paths-ignore: ['**/*.md', 'docs/**']`)
- Gitleaks runs on EVERY PR regardless (security is non-optional)
- Expected CI: 2-3 min per affected app vs 10+ min for everything

This is the same selective-build behavior Turborepo provides, without adding Turborepo to the stack.

---

**F12. ElevenLabs Voice Clone Quality (Growth)**

Voice clones require the founder to record 30+ minutes of clean audio for a quality clone. If the clone sounds robotic, it undermines the "human" trust signal the voice is supposed to provide.

**RECOMMENDATION**: Before committing to ElevenLabs ($22/mo), test with their free tier (10K characters). Record 3 sample videos with the cloned voice. If quality is insufficient, use a stock AI voice instead of a clone -- it sets a different expectation ("this is AI content") rather than an uncanny "is this real?" reaction.

---

### Summary of Revisions Based on Self-Review


| #   | Finding                      | Severity | Action                                                                                                                    | Impact on Plan                              |
| --- | ---------------------------- | -------- | ------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------- |
| F1  | Scope risk                   | CRITICAL | Build all 13 admin pages in 3 tiers (Tier 1 with MVP, Tier 2 post-launch, Tier 3 with revenue)                            | Managed via tiering, no scope cut           |
| F2  | CAN-SPAM + company structure | CRITICAL | Single LLC + DBAs. Opt-in checkbox exceeds CAN-SPAM (opt-out law) but satisfies state privacy laws                        | Section 0B-0C added. Privacy policy updated |
| F3  | Social content pipeline      | HIGH     | DIY n8n pipeline ($0.10/video). Build pipeline first, validate with actual output for 2 weeks                             | No deferral -- pipeline IS the test         |
| F4  | 50-state data pipeline       | RESOLVED | All 50 states day one via AI extraction from structured sources (Section 3B). ~6 hrs human review                         | No scope reduction. Full coverage.          |
| F5  | Founder 2 bandwidth          | RESOLVED | Scale with traction. Zero work needed until products have live users.                                                     | Acknowledged as pre-product stage           |
| F6  | studio + brand palettes      | HIGH     | Hetzner-hosted studio. Multi-brand CSS variable theming (violet/teal/zinc/amber -- 4 products)                            | Section 2 palettes added to P1.2            |
| F7  | RA legal + trademark risk    | CRITICAL | Partner RA for v1. filefree.com is Intuit's (confirmed). File Supplemental Register. Full legal guidelines in Section 0C. | New Section 0C added. Strict brand rules.   |
| F8  | Cross-sell compliance        | HIGH     | 4 regulatory frameworks (CAN-SPAM, FTC Free, Circular 230, UPL). Content Review Gate checklist mandatory.                 | Section 0C contains master checklist        |
| F9  | Admin UX approach            | MEDIUM   | Functional over beautiful: shadcn tables, Recharts, no animations                                                         | UX guideline, no scope change               |
| F10 | Content compliance           | LOW      | 30-day manual review period                                                                                               | Delays full automation by 30 days           |
| F11 | CI path filters              | MEDIUM   | `dorny/paths-filter@v3`. Shared pkg changes trigger all apps. 2-3 min per app vs 10+ min total.                           | Detailed YAML spec in F11                   |
| F12 | Voice clone quality          | LOW      | Test ElevenLabs free tier (10K chars) before committing. Startup grants program: 12mo free with 33M chars.                | Apply for ElevenLabs startup grant          |


---

## 10. Key Decisions Still Needed (Founder Input Required)

1. ~~**LLC Name**~~: DECIDED -- **Paperwork Labs LLC** (California). Domain: paperworklabs.com (purchased March 2026). DBA filings for FileFree, LaunchFree, Trinkets. See Section 0B.
2. ~~**RA Strategy**~~: DECIDED -- Partner RA with wholesale volume pricing. $99/yr initial, drop with scale. See revised F7.
3. ~~**Phase 4 Scope**~~: DECIDED -- Full 13-page command center in 3 tiers. See Section 3.
4. ~~**Social Content Validation**~~: DECIDED -- Build pipeline first, validate with actual output for 2 weeks. See F3.
5. ~~**Founder 2 Priority**~~: DECIDED -- Scale with traction. Zero work needed pre-product. See F5.
6. ~~**Domain purchases**~~: DECIDED -- paperworklabs.com + launchfree.ai + filefree.ai PURCHASED (March 2026). Also own: axiomfolio.com, launchfree.llc, taxfilefree.com.
7. **Trademark filing timing**: File immediately after product launch (need specimen of use) or file intent-to-use now ($350 extra per class)?
8. ~~**AI Model Routing**~~: DECIDED -- 9-model strategy. See Section 0E. Owned by AI Ops Lead persona.
9. ~~**Trinkets product line**~~: DECIDED -- Phase 1.5, financial calculators first, then agent pipeline validates subsequent ideas. See Section 0F.
10. ~~**Trinkets domain**~~: DECIDED -- `tools.filefree.ai` subdomain. No purchase needed, inherits domain authority, easy DNS. See Section 7C.
11. ~~**LLC State**~~: DECIDED -- **California LLC** (March 2026). Founder is a CA resident; Wyoming would require foreign registration, double RA, and CA franchise tax anyway. CA year 1: ~$119 vs WY year 1: ~$1,094. See Section 0B for full comparison. Revisit Wyoming when revenue >$250K and asset protection justifies dual-state cost.

---

## 11. Valuation Estimate

**MERGED**: This section previously duplicated Section 0D. See **Section 0D** for the single authoritative valuation analysis with comparable companies, scenario modeling, and comp rationale.

---

## 14. Agent Communication Hub: Slack + Email Aliases

### Why Slack

The venture operates like a company with AI employees. Employees need a persistent communication channel that isn't just Cursor chat windows (which are ephemeral). Slack provides:

- Persistent message history (searchable, linkable)
- Channel-based organization (functional departments)
- Two-way agent interaction via n8n webhooks
- Mobile app for founder on-the-go checks
- Integrations ecosystem (GitHub, Vercel, Render, Google Drive notifications)

### Channel Structure


| Channel            | Purpose                                              | Who Posts                                   |
| ------------------ | ---------------------------------------------------- | ------------------------------------------- |
| #general           | Company-wide announcements, decisions                | Founder, EA                                 |
| #daily-briefing    | EA Ops Monitor daily summary (7am)                   | EA Ops Monitor (n8n)                        |
| #weekly-planning   | Weekly planning output (Sunday 6pm)                  | EA Ops Monitor (n8n)                        |
| #compliance-alerts | Compliance Monitor status updates                    | Compliance Monitor (n8n)                    |
| #ops-alerts        | Infrastructure health alerts (CRITICAL/WARNING/INFO) | Infra Health Monitor (n8n)                  |
| #social-content    | Social post drafts for review/approval               | Social Content Pipeline (n8n)               |
| #dev-feed          | GitHub PR notifications, Vercel deploys, CI results  | GitHub/Vercel integrations                  |
| #partnerships      | Partnership pipeline updates, outreach drafts        | Partnership Outreach (n8n)                  |
| #data-integrity    | State data validation results, stale data alerts     | State Data Validator (n8n)                  |
| #revenue           | Affiliate conversions, Stripe events                 | Affiliate Tracker (n8n), Stripe integration |


### Two-Way Agent Interaction

**Founder -> Agent (Slack -> n8n)**:

- Founder posts in a channel with a command format (e.g., `/agent status`, `/agent brief me on partnerships`)
- n8n Slack trigger node picks up the message
- Routes to appropriate agent workflow
- Agent responds in-thread

**Agent -> Founder (n8n -> Slack)**:

- n8n workflows post to appropriate channels via Slack API
- Urgent items go to #ops-alerts (plus email/SMS for CRITICAL)
- Routine reports go to #daily-briefing

**Cursor -> Slack (Slack MCP)**:

- Use Slack MCP in Cursor to read/post messages from within the IDE
- EA persona can check Slack context before answering operational questions
- Decisions made in Cursor get logged to #general via EA

### Professional Email Aliases (Google Workspace)

Department-level email aliases on Google Workspace. All route to founder's inbox. Agents draft replies, founder approves and sends.


| Alias                                                       | Domain        | Purpose                                   |
| ----------------------------------------------------------- | ------------- | ----------------------------------------- |
| [hello@filefree.tax](mailto:hello@filefree.tax)             | filefree.tax  | General FileFree inquiries                |
| [support@filefree.tax](mailto:support@filefree.tax)         | filefree.tax  | FileFree user support                     |
| [legal@filefree.ai](mailto:legal@filefree.ai)               | filefree.ai   | Legal inquiries, DMCA, compliance         |
| [partnerships@filefree.ai](mailto:partnerships@filefree.ai) | filefree.ai   | Partnership inquiries (Founder 2 primary) |
| [hello@launchfree.ai](mailto:hello@launchfree.ai)           | launchfree.ai | General LaunchFree inquiries              |
| [support@launchfree.ai](mailto:support@launchfree.ai)       | launchfree.ai | LaunchFree user support                   |


**Outbound Email Flow**:

1. Agent (Partnership Outreach, Support Bot) drafts email in Google Docs or Slack thread
2. Founder reviews draft in Slack (#partnerships or #support)
3. Founder approves -> Agent sends via Gmail API (n8n Gmail node) from appropriate alias
4. Sent email logged in Slack thread for audit trail

**Setup**: Google Workspace already active on sankalpsharma.com. Add paperworklabs.com, filefree.tax, filefree.ai, and launchfree.ai as alias domains in Google Workspace Admin. Create Olga a Workspace seat ($6/mo). Create group aliases for each department. Route all to founder's primary inbox.

### Stress Test: Communication Overload

Risk: 10+ channels with multiple agents posting could overwhelm the founder.

Mitigations:

- **Notification tiers**: Only #ops-alerts and #compliance-alerts send push notifications. All other channels are check-when-ready.
- **Daily digest**: EA Ops Monitor's 7am #daily-briefing summarizes everything the founder needs to know. If nothing is on fire, the founder only reads this one channel.
- **Mute by default**: #dev-feed, #revenue, #data-integrity are muted. Founder checks manually or via weekly planning.
- **Escalation chain**: If an agent posts something that needs immediate founder attention, it goes to #ops-alerts with CRITICAL tag, plus email + SMS.

