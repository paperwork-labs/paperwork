---
name: prod-admin-market-data-schedules
overview: Define production admin access, streamline market data flow, make coverage restore dynamic, and clean up scheduling/scripts for a production deployment.
todos:
  - id: admin-seed-prod
    content: Add gated prod admin seeding + docs updates
    status: completed
  - id: market-data-consolidation
    content: Refactor tracked universe/coverage/provider fetch duplication
    status: completed
  - id: dynamic-history-window
    content: Compute history_days from last successful run (min 5)
    status: completed
  - id: prod-schedules
    content: Align cron defaults and document prod scheduling
    status: completed
  - id: scripts-cleanup
    content: Remove unused ATR scripts, keep run_task.py
    status: completed
isProject: false
---

# Production Admin + Market Data Cleanup Plan

## Context and goals

- Enable safe admin access in prod without relying on `DEBUG` and keep it one-time/guarded.
- Consolidate market data flow and remove duplicated logic across routes/tasks/services.
- Make `bootstrap_daily_coverage_tracked` choose a dynamic backfill window based on last successful run (min 5 days).
- Align scheduling sources of truth for prod (Render cron + RedBeat templates).
- Remove unused/broken scripts while preserving `run_task.py`.

## Proposed changes

- **Prod admin seeding**
  - Update startup logic in `[backend/api/main.py](backend/api/main.py)` to allow a controlled prod admin seed via a new env flag (e.g., `ADMIN_SEED_ENABLED=true`) instead of `DEBUG`.
  - Keep safeguards: only seed if no existing admin user matches username/email.
  - Document required envs in `[docs/PRODUCTION.md](docs/PRODUCTION.md)`.
- **Market data consolidation**
  - Use `tracked_symbols()`/`tracked_symbols_from_db()` from `[backend/services/market/universe.py](backend/services/market/universe.py)` everywhere; remove local helpers from routes/tasks.
  - Route coverage endpoints in `[backend/api/routes/market_data.py](backend/api/routes/market_data.py)` should delegate to `market_data_service` for coverage bucketing.
  - Move `_fetch_daily_for_symbols()` out of `[backend/tasks/market_data_tasks.py](backend/tasks/market_data_tasks.py)` into `[backend/services/market/market_data_service.py](backend/services/market/market_data_service.py)` and reuse.
  - Extract snapshot history persistence into the service layer and call it from tasks to reduce duplication.
- **Dynamic coverage restore window**
  - In `[backend/tasks/market_data_tasks.py](backend/tasks/market_data_tasks.py)`, compute `history_days` as:
    - days since last successful `bootstrap_daily_coverage_tracked` (from `job_run`/task status),
    - with a minimum of 5 days.
  - Keep `history_batch_size` default 25.
  - Ensure this value is used for snapshot history backfill only (daily bars still use the 200-day backfill step already in the task).
- **Schedules for prod**
  - Align defaults across `[backend/tasks/celery_app.py](backend/tasks/celery_app.py)`, `[backend/tasks/job_catalog.py](backend/tasks/job_catalog.py)`, and `[render.yaml](render.yaml)` for the daily restore job (20-day default but dynamic logic overrides when needed).
  - Confirm Render cron jobs are the active scheduler for prod; keep RedBeat defaults for dev/empty Redis bootstraps.
  - Update `[docs/PRODUCTION.md](docs/PRODUCTION.md)` with the schedule source of truth and required jobs.
- **Scripts cleanup**
  - Remove unused/broken scripts:
    - `[backend/scripts/run_atr_universe.py](backend/scripts/run_atr_universe.py)`
    - `[backend/scripts/setup_atr_cron.sh](backend/scripts/setup_atr_cron.sh)`
  - Keep `[backend/scripts/run_task.py](backend/scripts/run_task.py)` since cron jobs depend on it.

## Risks / notes

- Admin seeding in prod should be explicitly gated via env flag and never on by default.
- Dynamic backfill needs reliable job history; if no prior runs, fall back to 20 days.

## Validation

- Unit test the dynamic history window calculation (mock `job_run` status).
- Smoke test admin seeding in a fresh DB with the env flag set.
- Verify coverage endpoints still return expected structure after consolidation.

