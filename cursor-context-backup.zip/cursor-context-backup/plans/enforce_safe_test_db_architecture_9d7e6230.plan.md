---
name: Enforce Safe Test DB Architecture
overview: Enforce a single safe test database pathway, ban destructive patterns, and introduce env/test config hygiene without touching prod .env.
todos:
  - id: enforce-single-db
    content: Enforce db_session-only access; remove direct engines/sessions
    status: completed
  - id: lint-ban-sessionlocal
    content: Add pytest/plugin lint to fail SessionLocal/engine/create_engine imports
    status: completed
  - id: schema-guard
    content: Add schema guard + skip when TEST_DATABASE_URL missing/matches prod
    status: completed
  - id: destructive-marker
    content: Mark destructive tests, require opt-in, keep inside db_session
    status: completed
  - id: env-test-docs
    content: Add .env.test.example + doc for test env loading
    status: completed
---

# Enforce Safe Test DB Architecture

## What we'll do

- Add a single-path DB test policy: all tests use `db_session`; ban direct `SessionLocal`/engine usage.
- Introduce a hard lint/pytest plugin to fail on importing `SessionLocal`/`engine`/`create_engine` from `backend.database` in tests.
- Gate destructive tests: mark any table-clearing tests with a custom marker and require explicit opt-in; ensure they only use `db_session`.
- Add schema guard fixture to skip DB tests when required tables aren’t migrated in the test DB.
- Ensure Alembic in tests runs only against `TEST_DATABASE_URL`; default skip DB tests when `TEST_DATABASE_URL` is unset.
- Add `.env.test` sample (non-prod) and document loading it for pytest/CI; leave `.env` untouched.

## Files to touch

- `backend/tests/conftest.py`: add schema guard, destructive marker enforcement, lint/guard plugin for SessionLocal/engine/create_engine imports, default skip when TEST_DATABASE_URL missing.
- `backend/tests/pytest.ini` (or existing config): register custom marker for destructive tests and plugin settings.
- `backend/tests/test_*` (destructive ones): add marker and ensure they use `db_session` only.
- `docs/TESTS.md` (or similar): document the policy and env usage (.env.test for pytest/CI).
- Add `.env.test.example`: test-safe DB env (no prod creds), loaded by CI/pytest; do not touch `.env`.

## Implementation steps

- Implement plugin/fixture: fail on SessionLocal/engine/create_engine imports in tests; skip DB tests if TEST_DATABASE_URL missing or equals DATABASE_URL; add schema guard for required tables.
- Tag destructive tests with marker (e.g., `destructive`) and require explicit enable flag; keep operations inside `db_session`.
- Ensure Alembic test setup uses TEST_DATABASE_URL only; no fallback to app DB.
- Add `.env.test.example` and doc updates for loading it in CI/pytest; runtime Docker Compose stays on `.env`.

## Todos

- enforce-single-db
- destructive-marker
- schema-guard
- lint-ban-sessionlocal