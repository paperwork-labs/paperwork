---
name: Filters+Schedules
overview: Add a global SortableTable filter builder (AND/OR rules) with text/number/select/date operators, then apply it to MarketTracked; also add friendly cron display in Admin Schedules and fix Stage/RS empties.
todos:
  - id: filters-core
    content: Implement global SortableTable filter builder (AND/OR, text/number/select/date) as opt-in component
    status: pending
  - id: filters-markettracked
    content: Enable filter builder in MarketTracked with column-specific filter types and options
    status: pending
    dependencies:
      - filters-core
  - id: schedules-friendly-cron
    content: Add friendly cron display in AdminSchedules using preview endpoint + user timezone
    status: pending
  - id: stage-rs-fix
    content: Diagnose and fix Stage/RS empty values; add admin hint + warnings
    status: pending
  - id: tests-filters-schedules
    content: Add/update tests for filters, MarketTracked filter UI, and friendly cron display
    status: pending
    dependencies:
      - filters-core
      - filters-markettracked
      - schedules-friendly-cron
      - stage-rs-fix
---

# Global Filter Builder + Schedules + Stage/RS

## Scope updates (per latest request)
- **Global** filter builder in `SortableTable` (opt‑in) with **AND/OR** rules.
- Support **text**, **number**, **select**, and **date** comparisons.
- Apply first to **MarketTracked** (Level 1–4 table).
- Keep schedule UX changes and Stage/RS fixes from the previous plan.

---

## 1) SortableTable: opt‑in rule builder (AND/OR)
**Files:**
- [frontend/src/components/SortableTable.tsx](frontend/src/components/SortableTable.tsx)
- (new) [frontend/src/components/filters/FilterBuilder.tsx](frontend/src/components/filters/FilterBuilder.tsx)
- (new) [frontend/src/components/filters/filterTypes.ts](frontend/src/components/filters/filterTypes.ts)

### Design
- `SortableTable` accepts an optional `filters` prop:
  - `filters.enabled: boolean`
  - `filters.columns: FilterColumnDef[]` (per column config)
  - `filters.defaultLogic: 'AND'|'OR'`
- Filter UI sits **above the table** (compact, matching existing Chakra style):
  - Rows of rules: **Field** + **Operator** + **Value** + remove
  - Add rule button; logic toggle AND/OR
  - Responsive: on small screens, fields stack

### Filter types (v1)
- **Text**: contains, equals, starts with, ends with, is empty
- **Number**: `>`, `>=`, `<`, `<=`, `=`, between, is empty
- **Select**: equals (dropdown), is empty
- **Date**: before, after, on, between (dates in user TZ)

### Evaluation
- Apply filters **client-side** on table data (derived rows).
- AND/OR logic across rules; each rule can be negated (optional).

---

## 2) MarketTracked: enable global filters
**File:** [frontend/src/pages/MarketTracked.tsx](frontend/src/pages/MarketTracked.tsx)
- Add `filters` config to `SortableTable` using the existing columns:
  - Text: symbol, sector, industry, stage_label
  - Number: ATR, SMA, RS, range %, etc.
  - Date: as_of_timestamp
  - Select: stage_label (values from data set)

---

## 3) Admin Schedules: friendly cron (user TZ)
**Files:**
- [frontend/src/pages/AdminSchedules.tsx](frontend/src/pages/AdminSchedules.tsx)
- [backend/api/routes/admin_scheduler.py](backend/api/routes/admin_scheduler.py)

### UX
- Add a “Schedule (friendly)” column:
  - Use `/admin/schedules/preview` to show next run in **user timezone**.
  - Render e.g. “Daily at 03:00 AM PT (UTC 11:00)” or “Hourly at :00”.
- Keep raw cron visible for power users.

---

## 4) Stage/RS empty: fix + explain
**Files:**
- [backend/services/market/indicator_engine.py](backend/services/market/indicator_engine.py)
- [backend/services/market/market_data_service.py](backend/services/market/market_data_service.py)
- [backend/tasks/market_data_tasks.py](backend/tasks/market_data_tasks.py)
- [frontend/src/pages/AdminDashboard.tsx](frontend/src/pages/AdminDashboard.tsx)

### Actions
- Ensure Mansfield RS has SPY history; if missing, surface a clear warning in task result.
- Ensure stage calculation has required lookback; if not, log + set null.
- Add Admin Dashboard hint: “If Stage/RS empty, run Recompute Indicators.”

---

## 5) Tests
- Add unit tests for filter evaluation (AND/OR, operators).
- Add UI test for MarketTracked filter row rendering.
- Add schedules test verifying friendly column renders with user TZ.

---

## Validation
- `make test`
- `make test-frontend`
