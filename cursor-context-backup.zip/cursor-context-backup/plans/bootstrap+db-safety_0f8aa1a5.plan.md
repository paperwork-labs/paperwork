---
name: Bootstrap+DB-safety
overview: Spin up full stack, validate core flows, then harden test isolation so tests can never affect real data, and produce a prioritized improvement backlog.
todos:
  - id: phase1-boot-verify
    content: Boot full docker stack, verify health/docs/frontend/flower, and capture logs + current-state report.
    status: pending
  - id: phase1-core-flows
    content: Validate auth/RBAC and at least one async broker job path; confirm celery schedules visible and functioning.
    status: pending
  - id: db-safety-compose
    content: Add a dedicated test Postgres service + separate volume and wire pytest to use TEST_DATABASE_URL pointing ONLY to postgres_test/quantmatrix_test.
    status: pending
  - id: db-safety-guards
    content: Harden conftest + session guards to require postgres_test host and *_test dbname; fail fast if misconfigured.
    status: pending
  - id: recommendations-backlog
    content: After observing runtime behavior, produce a prioritized improvement backlog (risk/effort) with DB safety at the top.
    status: pending
---

# QuantMatrix “Spin Up + DB Safety Hardening + Improvement Backlog” Gameplan

## Primary outcomes
- **Full stack up (Docker)**: Postgres, Redis, Backend, Frontend, Celery worker/beat, Flower.
- **Green core flows**: backend health/docs, frontend API proxy, auth/RBAC, celery scheduling, and at least one broker async job path.
- **Hard guarantee**: tests can **never** drop or mutate your real DB/tables (e.g., `price_data`) again.
- **Staff-level recommendations**: a prioritized improvement backlog with risk/effort notes.

## Phase 1 — Spin up and take a current-state snapshot
### 1) Boot the stack
Preferred:
- `./run.sh start` (or `docker compose up -d --build` if needed)

### 2) Verify service endpoints
- Backend: `http://localhost:8000/health`, `http://localhost:8000/docs`
- Frontend: `http://localhost:3000`
- Flower: `http://localhost:5555`

### 3) Validate integration wiring
- Frontend Vite proxy: `/api/*` → `http://backend:8000` per [`frontend/vite.config.ts`](/Users/sankalpsharma/development/quantmatrix/frontend/vite.config.ts)
- Backend startup behavior and migrations: [`backend/api/main.py`](/Users/sankalpsharma/development/quantmatrix/backend/api/main.py)

### 4) Validate auth/RBAC and admin
- Confirm login + `GET /api/v1/auth/me` includes role
- Confirm admin routes under `/api/v1/admin/*` are correctly guarded (403 for non-admin)

### 5) Validate Celery + schedules
- Confirm worker/beat running and tasks visible in Flower
- Cross-check expected schedules/runbooks in [`backend/tasks/README.md`](/Users/sankalpsharma/development/quantmatrix/backend/tasks/README.md)

### 6) Exercise broker “async job” paths
- Confirm aggregator endpoints respond
- Trigger at least one safe async connect/sync flow and observe `job_id` + status polling

### 7) Produce a current-state report
Deliver:
- Green / Yellow / Red
- Top operational risks
- Top 3–5 immediate fixes

## Phase 2 — **DB Safety Hardening (Priority)**
Your requirement: “bad tests must never drop tables again” (especially `price_data`). We’ll implement **multiple independent safety layers** so a single misconfiguration can’t cause damage.

### Safety layer A — Dedicated test Postgres + separate Docker volume (strongest)
- Add a **test-only Postgres service** (`postgres_test`) with its own **named volume**, separate from dev.
- Wire tests to connect only to that DB using `TEST_DATABASE_URL`.
- Ensure the test DB is not reachable/used by backend runtime containers.

### Safety layer B — Fail-fast guards in pytest + DB session factory
We already have good starts:
- Test harness refuses `TEST_DATABASE_URL == app DATABASE_URL`: [`backend/tests/conftest.py`](/Users/sankalpsharma/development/quantmatrix/backend/tests/conftest.py)
- Runtime session factory guard in tests: [`backend/database.py`](/Users/sankalpsharma/development/quantmatrix/backend/database.py)

We will solidify by adding stricter checks:
- **Host/service name** must be `postgres_test`
- **DB name** must match `*_test` (e.g., `quantmatrix_test`)
- Optional: refuse to run if a “canary” indicates a non-test environment (e.g., DB contains known non-test markers)

### Safety layer C — “No destructive ops” defaults
- Keep transaction+savepoint isolation (already in `db_session` fixture).
- Ensure no tests call `Base.metadata.drop_all()` or other destructive operations unless explicitly flagged and opt-in (policy already exists via `--allow-destructive-tests`).

### Safety layer D — Operational guardrails
- Update test run commands to always set `TEST_DATABASE_URL` (and to spin up `postgres_test` first).
- Add a short runbook in docs: “How tests run” and “What to do if TEST_DATABASE_URL missing”.

## Phase 3 — Codebase improvement recommendations (after we have runtime signal)
We’ll prioritize recommendations based on what we see during spin-up.

Initial likely high-ROI items (subject to confirmation during Phase 1):
- **Config consistency**: `backend/config.py` mixes `settings` with legacy constants; converge on `settings` only.
- **Startup safety**: `backend/api/main.py` runs Alembic upgrade and logs warnings on failure; decide whether to fail-fast vs degrade.
- **Route/module health**: reconcile comments vs actual router includes (avoid “disabled-but-imported” drift).
- **Test/CI discipline**: add a dedicated “test compose profile” and make it the only supported path.

```mermaid
flowchart LR
  devUser[DevMachine] --> be[Backend_8000]
  devUser --> fe[Frontend_3000]

  be --> pgDev[Postgres_dev_volume]
  be --> r[Redis]

  testRunner[PytestRunner] --> pgTest[Postgres_test_volume]

  worker[CeleryWorker] --> r
  worker --> pgDev
  beat[CeleryBeat] --> r
  flower[Flower] --> r
```
