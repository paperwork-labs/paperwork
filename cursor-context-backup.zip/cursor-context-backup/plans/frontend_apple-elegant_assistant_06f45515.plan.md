---
name: Frontend Apple-Elegant Assistant
overview: ""
todos:
  - id: setup-design
    content: Set Apple-esque tokens, layout shell
    status: completed
  - id: onboarding
    content: Implement allowlist/JWT/OAuth onboarding
    status: completed
    dependencies:
      - setup-design
  - id: status-dash
    content: Build health/status dashboard
    status: completed
    dependencies:
      - setup-design
  - id: search-browse
    content: Implement Gmail/docs search UI
    status: completed
    dependencies:
      - setup-design
  - id: jobs-logs
    content: Add jobs list and sync trigger UI
    status: completed
    dependencies:
      - setup-design
  - id: tests
    content: Add component/page tests & snapshots
    status: completed
    dependencies:
      - onboarding
      - status-dash
      - search-browse
      - jobs-logs
---

# Frontend Apple-Elegant Assistant

High-level: Build a refined, Apple-esque Next.js UI that covers allowlisted onboarding + Gmail linking (C) and read-only status/search (B), backed by existing FastAPI endpoints.

## UX Scope

- Onboarding: allowlist/email entry, JWT issuance, Google OAuth start/callback handoff, success state.
- Status: environment/ports, API health (/assistant/api/health), DB/Redis reachability summary, agent/account linkage, latest job runs.
- Search/browse: Gmail threads/messages & docs with filters (date, account, category), attachment preview metadata; empty and loading states.
- Jobs/logs: queued/running/completed ingest jobs with retry/backoff notes.

## UI System

- Apple-esque: high contrast on white, generous whitespace, SF-like typography stack, subtle translucency/shadows, focus rings; dark-ready palette tokens.
- Components: shell with top nav + left rail, cards, table/list rows, tag chips for categories/topics, status pills, CTA buttons for “Link Gmail” and “Run sync”.

## Data Flow

- Client data via `fetch`/SWR from FastAPI (`/assistant/api/health`, ingest enqueue, JWT issuance, Gmail OAuth start/callback stubs).
- Background job status read-only (no live trades) aligns with backend-first rule; live connections only when starting OAuth.

## Target Files

- Frontend: `frontend/src/app/layout.tsx`, `frontend/src/app/page.tsx`, `frontend/src/app/globals.css`, plus new feature routes/components under `frontend/src/app/(assistant)/` and shared UI under `frontend/src/app/components/`.
- Backend (read-only use): existing health/JWT/OAuth/ingest endpoints.

## Architecture Diagram

```mermaid
flowchart TD
  user[User] --> ui[Next.js UI]
  ui --> api[FastAPI /assistant/api]
  api --> db[Postgres]
  api --> redis[Redis]
  api --> gmail[Gmail API]
  api --> jobs[Worker Jobs]
```



## Implementation Steps

1) Establish design tokens and base shell (Apple-like typography, spacing, cards, nav).2) Build allowlist/onboarding flow: email entry → JWT issuance → OAuth start link; show callback guidance.3) Create status dashboard: health check, DB/Redis indicators, account linkage, recent jobs.4) Implement search/browse: query inputs, filters, results list with threads/docs, attachment metadata, empty/loading states.