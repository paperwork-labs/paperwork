---
name: AxiomFolioProductionPlan
overview: Prepare a hybrid rebrand (external-facing AxiomFolio while keeping internal repo/module names) and a Render-first production rollout, using the PR 148 deployment assets as the baseline and adding domain/DNS, branding, and config updates needed for axiomfolio.com.
todos: []
isProject: false
---

# AxiomFolio Rebrand + Render Production Plan

## Scope decisions (locked)

- **Hybrid branding:** External surfaces (UI, docs, domains, deploy names) become AxiomFolio; internal repo/module names remain `quantmatrix` to reduce risk.
- **Hosting:** Start with Render as primary; Fly stays optional later using the existing Fly configs.

## Phase 1: Align on target domains and routing

- Choose canonical URLs and subdomains (recommendation): `https://axiomfolio.com` for the UI and `https://api.axiomfolio.com` for the API.
- Decide whether to keep a redirect from any legacy domain (e.g., `thequantmatrix` or `quantmatrix`), but keep it optional since there’s no current production traffic.

## Phase 2: Apply branding changes (UI + external docs + Ladle)

- Update UI-visible branding strings and favicon/title.
  - Example files: `[frontend/index.html](frontend/index.html)` (title), `[frontend/src/components/layout/DashboardLayout.tsx](frontend/src/components/layout/DashboardLayout.tsx)` (logo text).
- Update public-facing app metadata (OpenAPI title + app name).
  - Example files: `[backend/api/main.py](backend/api/main.py)`, `[backend/config.py](backend/config.py)`.
- Update docs to reflect AxiomFolio branding and new URLs while keeping internal repo naming.
  - Example files: `[README.md](README.md)`, `[docs/PRODUCTION.md](docs/PRODUCTION.md)`.
- Add AxiomFolio brand surfaces in Ladle.
  - New stories for brand overview + theme tokens (colors, typography, radii).
  - Example files: `[frontend/src/stories/](frontend/src/stories/)`, `[frontend/src/theme/system.ts](frontend/src/theme/system.ts)`.
- Create placeholder brand assets and update later (logo/wordmark + palette tokens).
  - Example files: `[frontend/src/assets/](frontend/src/assets/)`, `[frontend/src/theme/](frontend/src/theme/)`.

## Phase 3: Domain + CORS + frontend API base URL

- Add AxiomFolio domains to CORS and env defaults (keep existing values for local dev).
  - Example file: `[backend/config.py](backend/config.py)`.
- Set the production API base URL to the new API domain.
  - Example file: `[frontend/src/services/api.ts](frontend/src/services/api.ts)` and Render env in `[render.yaml](render.yaml)` (from PR 148).

## Phase 4: Render-first production rollout (using PR 148 assets)

- Use PR 148 configs as the baseline for production (Render, cron jobs, CD pipeline).
  - Key files: `[render.yaml](render.yaml)`, `[.github/workflows/cd.yml](.github/workflows/cd.yml)`, `[docs/PRODUCTION.md](docs/PRODUCTION.md)`.
- Create Render services from `render.yaml` and attach custom domains:
  - `axiomfolio.com` → Render static service (frontend)
  - `api.axiomfolio.com` → Render web service (backend)
- Set Render environment variables for production, including:
  - `CORS_ORIGINS` with the AxiomFolio domains
  - `RATE_LIMIT_DEFAULT`, `SECRET_KEY`, `DATABASE_URL`, `REDIS_URL`, `CELERY_BROKER_URL`, `CELERY_RESULT_BACKEND`
- Configure DNS on Spaceship:
  - `axiomfolio.com` → Render static service (A/ALIAS or CNAME depending on provider instructions)
  - `api.axiomfolio.com` → Render web service (CNAME to Render host)
- Wire CI/CD secrets for Render deploy hooks and DB migration step.

## Phase 5: Migration + verification

- Run production DB migrations via the CI pipeline (per `[docs/PRODUCTION.md](docs/PRODUCTION.md)`).
- Verify health and core flows:
  - `/health` endpoint
  - Login, portfolio summary, and at least one admin endpoint
- Validate scheduled cron jobs (Render cron) enqueue tasks successfully and workers consume them.

## Phase 6: Optional Fly readiness (deferred)

- Keep `[fly.backend.toml](fly.backend.toml)`, `[fly.worker.toml](fly.worker.toml)`, and `[fly.cron.toml](fly.cron.toml)` aligned with new domains and env vars for a later cutover if desired.

## Notes on risk management

- Keep internal names as-is to avoid breaking Docker image paths, GHCR, and worker queues.
- Use staged rollout: deploy backend first, then frontend, then enable cron.

## TODOs

- Set canonical domains and DNS entries for `axiomfolio.com` + `api.axiomfolio.com`.
- Apply AxiomFolio branding updates in frontend + API metadata + docs + Ladle stories.
- Update CORS and API base URL envs for new domains.
- Configure Render services, secrets, and deploy hooks; run CI deploy.
- Validate health checks, UI, and scheduled jobs in production.

