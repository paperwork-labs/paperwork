---
name: Comprehensive Status Roundup
overview: Full roundup of FileFree's current state across engineering, infrastructure, tax calculation coverage, and strategic priorities — with recommendations from all personas.
todos:
  - id: merge-pr12
    content: "Merge PR #12 (OAuth social login) — all CI green"
    status: completed
  - id: fix-demo-blur
    content: Fix demo blurry image warning — lower threshold or skip in demo flow
    status: completed
  - id: demo-refund-estimate
    content: Show estimated refund in demo (assume single filer, add caveat)
    status: completed
  - id: update-docs
    content: "Update KNOWLEDGE.md with D33 (Sprint 3 complete, PR #11/#12, frontend tests) and TASKS.md"
    status: completed
  - id: infra-dashboard
    content: Build infrastructure status dashboard (all services + agents health)
    status: completed
isProject: false
---

# FileFree — Comprehensive Status Roundup (March 2026)

## Current Sprint Progress

**Sprint 0 (Business Ops)**: 4/11 done, 1 partial
**Sprint 1 (Foundation)**: 5/6 done, 1 partial (Sentry DSN missing)
**Sprint 2 (OCR Demo)**: 4/4 COMPLETE
**Sprint 3 (Full MVP)**: 7/7 COMPLETE
**Sprint 4+**: Not started

**Open PRs**: PR #12 (Google/Apple OAuth) — all CI green, ready to merge

---

## Infrastructure + "Employees" (Agent) Status

**Production services:**

- Vercel (frontend): filefree.tax — LIVE, auto-deploy from main
- Render (API): api.filefree.tax — LIVE, $7/mo, 512MB
- Neon (DB): PostgreSQL 17 — connected, free tier
- Upstash (Redis): sessions — connected, free tier
- Hetzner VPS (ops): 204.168.147.100 — $5.49/mo

**Ops tools on Hetzner:**

- n8n ([https://n8n.filefree.tax](https://n8n.filefree.tax)) — 6 workflows imported but may need re-setup after D31 DB isolation
- Postiz ([https://social.filefree.tax](https://social.filefree.tax)) — deployed with Temporal, no social accounts connected yet
- PostHog — events wired (page_view, demo_upload, w2_scanned, filing_step_completed, tax_calculated) but need dashboard verification

**CI/CD:**

- GitHub Actions: 7 jobs (API Lint, API Tests, Web Lint, Web Tests, Web Build, Vercel, Vercel Preview)
- 89 backend tests, 32 frontend tests — all passing

**What's NOT wired yet:**

- PostHog dashboard/funnels not verified in UI
- Sentry DSN not set (code is there, needs env var)
- Postiz has no social accounts connected
- n8n may need re-setup (DB isolation incident D31)

---

## Demo Bug: "Image Appears Blurry" Warning

The quality check in [web/src/lib/image-quality.ts](web/src/lib/image-quality.ts) runs a Laplacian variance blur detection on every upload. When the score is below `BLUR_THRESHOLD`, it shows `"Image appears blurry. Hold steady and make sure the document is well-lit."` via `toast.warning()`.

This is a **warning toast, not a blocker** — the upload still proceeds. However, the threshold may be too aggressive for phone photos of W-2s (paper documents often have low contrast). Options:

- Lower the blur threshold
- Skip quality check on the demo flow (it's a friction point for the viral moment)
- Change from warning to info-level toast

---

## Demo Refund Amount

Currently the demo flow shows extracted W-2 data (employer, wages, withholding) but gates the refund calculation behind signup: *"Create a free account to save your return and calculate your refund."*

**Should we show refund in the demo?** This is a key product question:

- **Pro**: The refund amount IS the wow moment. Showing "$3,247 refund" before signup would massively increase conversion. Credit Karma shows your credit score before signup — same psychology.
- **Con**: Calculation requires filing status (single/married) which we don't ask in the demo flow. We could assume "single" for estimation.
- **Recommendation**: Show an *estimated* refund assuming single filing status, with a note "Estimate assumes single filer. Sign up to calculate your exact return." This gives the dopamine hit while preserving the signup incentive for accuracy.

---

## Tax Calculation Coverage — What Works, What's Missing

### What works today (federal only):

- 4 filing statuses: Single, MFJ, MFS, HoH
- 7 federal tax brackets per status (2025 rates per Rev. Proc. 2024-40 + P.L. 119-21)
- Standard deduction: $15,750 / $31,500 / $15,750 / $23,625
- W-2 income (wages) -> AGI -> taxable income -> federal tax -> refund/owed
- 28 unit tests, 100% coverage
- Integer cents arithmetic (no floats)

### What's missing for "all 50 states + federal":

**Federal gaps:**

- No Schedule 1 (additional income: 1099, unemployment, self-employment)
- No dependents / Child Tax Credit ($2,000/qualifying child)
- No Earned Income Tax Credit (EITC) — huge for low-income filers
- No itemized deductions (Schedule A)
- No education credits (American Opportunity, Lifetime Learning)
- No retirement contribution deductions (IRA, student loan interest)
- No 1099 support (freelancers, contractors, interest/dividends)
- No AMT calculation

**State tax gaps (Task 3.4 — not started):**

- 0 of 50 states implemented
- 9 states have NO income tax: AK, FL, NV, NH (interest/dividends only), SD, TN, TX, WA, WY
- 41 states need tax engines with different bracket structures
- Some states (CA, NY) are complex with multiple schedules, credits, surcharges
- SALT cap ($40,000 for 2025) not implemented

**E-file gaps:**

- No MeF XML generator
- No IRS SOAP service integration
- No state e-file
- Column Tax SDK not integrated (Task 3.3)
- EFIN not yet applied for (Task B.1 — CRITICAL, 45-day processing)

---

## How AI Can Make the Hard Parts Disappear

### 1. State Tax Engines (41 states)

**The hard part**: Each state has unique brackets, credits, rules, and forms.
**AI approach**: Use GPT-4o to parse state tax instructions (PDFs) into structured JSON bracket data, similar to `tax-data/2025.json`. AI generates the state-specific calculation modules and test cases. Human reviews for accuracy. Estimate: 2-3 days with AI vs 2-3 weeks manually.

### 2. MeF XML Generation

**The hard part**: IRS Publication 4164 defines a complex XML schema with 1000+ fields, strict validation, digital signatures.
**AI approach**: Feed IRS MeF schema XSDs to AI, have it generate the XML builder that maps our `TaxCalculation` model to MeF format. AI can also generate the 12 mandatory ATS test scenarios.

### 3. Form Coverage Expansion (1099, Schedule A, etc.)

**The hard part**: Each form has unique rules, calculations, and interactions.
**AI approach**: Same pattern as W-2 OCR — AI reads the IRS form instructions, generates the Pydantic models, calculation functions, and tests. Tax domain expert persona validates.

### 4. Multi-State Filing

**The hard part**: People who work in one state and live in another need two state returns with reciprocity rules.
**AI approach**: Build a state reciprocity database. AI can parse the 28 existing reciprocity agreements from state tax authority websites.

---

## All-Persona Review Highlights

### Engineering (engineering.mdc)

- PR #11 merged with all Copilot comments addressed. PR #12 ready.
- CI is solid (7 jobs). 121 total tests.
- CSRF race condition fixed. UUID validation added.
- **Risk**: No load testing. 512MB Render may not handle tax season spikes.

### UX (ux.mdc)

- Demo blurry warning is friction — should be softer or removed for demo flow.
- Refund amount should be shown in demo for conversion.
- Mobile audit (Task 2.6) marked done but not verified on real devices.

### Growth (growth.mdc)

- No social accounts connected. No content posted. Zero organic reach.
- Demo is the marketing asset — but it gates the wow moment (refund) behind signup.
- **URGENT**: Tax season content should be going out NOW if targeting April 15 extensions.

### Legal (legal.mdc)

- Privacy policy and ToS are live (D25).
- EFIN (Task B.1) NOT APPLIED FOR — this is a 45-day blocker. Every day delayed pushes MeF certification further.
- Need to review social login data handling (Google/Apple send user data).

### CFO (cfo.mdc)

- Monthly burn: $12.49/mo (Hetzner $5.49 + Render $7). Vercel/Neon/Upstash all free tier.
- OCR cost: ~$0.004/doc blended. At 1K users: ~$4/mo in API costs.
- **Risk**: Column Tax pricing unknown. If >$15/return, alternative needed.

### QA (qa.mdc)

- 121 tests total (89 backend + 32 frontend). Good coverage on tax calculator.
- No E2E tests. No real-device mobile testing.
- Image quality check may be too aggressive (false positives on valid W-2 photos).

### Tax Domain (tax-domain.mdc)

- Federal brackets correct for 2025 (verified against Rev. Proc. 2024-40 + P.L. 119-21).
- **MISSING**: EITC, CTC, education credits, 1099 income, state taxes.
- For "simple W-2 only" filers, current calculator IS sufficient for MVP.

### CPA (cpa.mdc)

- AI insights not implemented (placeholder). Should generate personalized tips.
- No W-4 adjustment recommendation (biggest value-add for users).
- Tax optimization plan ($29/yr) has no content yet.

### Strategy (strategy.mdc)

- **EFIN application is the single most critical blocker.** 45-day processing. Missing October ATS window delays by ONE FULL YEAR.
- Column Tax demo not booked (Task B.9).
- Partnership pipeline has zero active conversations.

---

## North Star: Free E-File for All 50 States + Federal

### Current distance from goal:

```
TODAY                     MILESTONE                  NORTH STAR
Federal calc only    →    State tax (41 states)   →  Own MeF Transmitter
No e-file            →    Column Tax interim      →  Free e-file forever
No EFIN              →    EFIN approved           →  IRS ATS certified
W-2 only             →    1099/Sched A/B          →  Full 1040 coverage
```

### Critical path (time-ordered):

1. **APPLY FOR EFIN NOW** — 45-day processing, longest lead item
2. Book Column Tax demo (Founder 2) — need sandbox by June
3. Implement state tax for top 5 states (CA, NY, IL, PA, OH)
4. Build MeF XML generator against IRS Pub 4164
5. October: IRS ATS testing (12 scenarios, pass ALL or wait another year)
6. January 2027: Own transmitter live = FREE FOREVER

### IRS Free File Competitive Landscape

8 providers in the IRS Free File Alliance serve AGI < $84,000 (2025). None are mobile-first or AI-powered. Our differentiation:

- **Speed**: "5 minutes" vs their 30-60 minute flows
- **UX**: Dark mode, animations, Gen Z aesthetic vs 2010-era web forms
- **AI**: OCR snap-to-file vs manual data entry
- **Trust**: Transparent pricing (actually free) vs bait-and-switch upsells
- **Advisory**: Year-round financial relationship vs one-time filing tool

---

## Forward-Looking Review: Your Asks

### Ask 1: Infrastructure Dashboard (n8n, Postiz, PostHog — green/red health)

**PM View**: You want a single pane of glass showing all your tools and AI agents — health status, last activity, which agents talk to which systems. This is an internal ops dashboard, not user-facing. The value is operational confidence: "Is everything actually running?"

**Engineering View**: Two approaches:

- **Option A (Fast, 2-3 hours)**: Build a `/ops` page in the Next.js app (behind auth, admin-only). It hits health endpoints for each service:
  - Render API: `api.filefree.tax/health` (already exists, returns DB + Redis status)
  - n8n: `n8n.filefree.tax/healthz` (built-in endpoint)
  - Postiz: `social.filefree.tax/api/public/v1` (check response)
  - PostHog: check if events arrived in last 24h via PostHog API
  - GitHub Actions: `gh api` for last CI run status
  - Neon / Upstash: piggyback on API health check (already tests DB + Redis)
  - Show each as a card with green/amber/red dot + last-checked timestamp
  - Show n8n workflow list with last run time and status (via n8n API)
- **Option B (Richer, 1-2 days)**: Build it as a standalone HTML canvas/dashboard with live polling, agent flow diagram showing which systems talk to each other, and historical uptime.

**QA View**: Option A is sufficient for now. Key risk: don't expose ops endpoints publicly. Must be admin-only or localhost-only. Health check endpoints should NOT return sensitive info (connection strings, API keys). Our current `/health` endpoint is safe — it only returns `{"status": "healthy", "db_connected": true}`.

**Recommendation**: Option A. Fast, ships today. Add agent connectivity diagram later.

---

### Ask 2: Demo Blur Warning Bug

**PM View**: This is a conversion-killer. The demo is our viral entry point. Any friction between "upload W-2" and "see the magic" costs us users. A warning saying "your image seems blurry" when the OCR still succeeds feels like the app is broken.

**Engineering View**: The issue is in [web/src/lib/image-quality.ts](web/src/lib/image-quality.ts):

- `BLUR_THRESHOLD = 30` — this is a Laplacian variance threshold
- Phone photos of paper W-2s often score below 30 because paper has uniform textures and low edge contrast
- The warning fires as a `toast.warning()` but does NOT block the upload — OCR still runs
- Fix options:
  1. Lower threshold from 30 to 15 (less aggressive, fewer false positives)
  2. Skip blur check entirely in the demo flow (the OCR pipeline has its own quality handling)
  3. Change from `toast.warning` to `toast.info` with softer language like "Tip: For best results, hold steady and use good lighting"
  4. Remove the client-side check and let the OCR pipeline handle quality (Cloud Vision returns low confidence on bad images, which already triggers GPT-4o vision fallback)

**QA View**: Option 4 is the most robust — we already have a two-tier OCR fallback that handles bad images. The client-side blur check is redundant with the backend quality pipeline. If we keep it, option 1+3 combined (lower threshold + softer message) is safest. We should also track the blur scores of images that DO succeed at OCR to calibrate the threshold empirically.

**Recommendation**: Lower threshold to 15 AND change to `toast.info` with softer copy. Track blur scores in PostHog to calibrate later.

---

### Ask 3: Show Refund Amount in Demo

**PM View**: This is the single highest-impact product change we can make right now. The demo currently shows extracted W-2 fields (employer, wages, withholding) but gates the refund behind signup. The refund IS the dopamine hit. Showing "$3,247 estimated refund" before signup would dramatically increase conversion — same psychology as Credit Karma showing your credit score before account creation.

**Engineering View**: 

- The tax calculator already exists and works for all 4 filing statuses
- The demo has all the data needed: `wages` and `federal_tax_withheld` from the extraction
- Only missing piece: filing status (single/married/HoH). For the demo, assume "single" (most common for Gen Z first-time filers)
- Implementation (~1-2 hours):
  1. After extraction succeeds, run `calculate_return()` with extracted wages/withholding + "single" filing status
  2. This can be done **client-side** (no API call needed) — just port the tax bracket math to TypeScript, or call the existing backend endpoint without auth
  3. Show the refund amount with the count-up animation (CurrencyDisplay component already exists)
  4. Add a caveat: "Estimated refund for single filer. Sign up for your exact calculation."
  5. Change CTA from "Ready to calculate your refund?" to "Ready to file and get your $X,XXX refund?"
- **Client-side vs server-side**: Client-side is better for the demo — no auth needed, instant, no additional API call. We already have the bracket data in `tax-data/2025.json`. A lightweight TypeScript port of `calculate_return()` (or bundling the JSON) would work.

**QA View**: 

- Risk: Estimated refund could be wrong if the person isn't single. Needs clear "estimate" labeling.
- Risk: Showing a refund when the person actually owes could damage trust. Mitigate: if owed > 0, show "You may owe $X — sign up for a detailed breakdown" instead of a refund amount.
- Risk: Edge case — if OCR returns bad wage data, the refund estimate will be wildly wrong. Mitigate: only show estimate if confidence > 80%.
- Must include disclaimer: "This is an estimate based on standard deduction for a single filer. Your actual refund depends on your filing status, dependents, and other factors."

**Recommendation**: Build it. Client-side calculation with "single" assumption. Only show if confidence > 80%. Use CurrencyDisplay animation for the dopamine hit. Clear "estimate" label + change CTA to personalized amount.

---

### Ask 4: All 50 States + Federal E-File (North Star)

**PM View**: This is THE strategic question. "Free e-file for all 50 states + federal" is the promise. Currently we can calculate federal tax for W-2-only filers with standard deduction. That covers a real segment (simple filers), but not all 50 states and not complex returns.

**Phased approach to "all 50 states"**:

- **Phase 1 (Now - April)**: Federal-only for simple W-2 filers. PDF download. Demo with estimated refund.
- **Phase 2 (April - June)**: Add 9 no-income-tax states (free — just detect and skip). Add top 5 income-tax states (CA, NY, IL, PA, OH — covers ~40% of US population).
- **Phase 3 (June - October)**: Remaining 36 income-tax states. Column Tax SDK integration for e-file.
- **Phase 4 (October - January)**: Own MeF transmitter. IRS ATS testing. Full coverage.

**Engineering View — How AI collapses the timeline:**

**State tax engines (the 41-state problem)**:

- Each state publishes their tax brackets, standard deductions, and credits annually
- The pattern is identical to our federal engine: load brackets from JSON, apply progressive rates
- AI can parse all 41 state tax instruction PDFs and generate `tax-data/2025-{state}.json` files in the same format as our federal brackets
- The `calculate_state_tax()` function is a copy of `calculate_federal_tax()` with state-specific data
- AI generates test cases from each state's published examples
- **Estimated effort with AI: 3-5 days for all 41 states** (vs 3-4 weeks manually)
- Complexity outliers: CA (mental health surcharge), NY (metro commuter tax), OR (kicker credit) — these need manual attention

**MeF XML generation**:

- IRS Pub 4164 specifies the XML schema. The XSD files are publicly available
- AI can generate the XML builder from our `TaxCalculation` model → MeF XML mapping
- The 12 ATS test scenarios are published — AI can generate test fixtures
- **Biggest blocker is NOT the code** — it's the EFIN application (45-day processing) and ATS testing (only opens in October)

**QA View — What can go wrong:**

- **State tax accuracy**: Every state calculation must be verified against official examples. A single wrong bracket boundary could produce incorrect returns for thousands of users. Recommend: for each state, validate against 3+ worked examples from the state's revenue department.
- **Multi-state filing**: ~15% of filers work in one state and live in another. Reciprocity agreements between 28 state pairs add complexity. Defer to Phase 3.
- **Credits**: EITC alone has 17 eligibility conditions and phase-out ranges. CTC has AGI-based phase-outs. Each credit is a mini-calculation engine. Prioritize CTC first (simplest, biggest user impact).
- **E-file rejection risk**: IRS rejects ~3% of e-filed returns. Most common: SSN mismatch, dependent already claimed. Need rejection handling UX + clear error messages.

**Recommendation**: Build state tax engines using the AI-assisted approach (parse PDFs -> JSON -> calculator). Start with the 9 no-tax states (trivial) + top 5 income-tax states. The federal calculator architecture is already correct — it's a matter of scaling the data, not redesigning the system.

---

### Ask 5: Infrastructure Dashboard — What It Should Look Like

**PM View**: You want to see at a glance: "Are all my systems healthy? Are my AI agents working? When did each thing last run?"

**Proposed layout** (single `/ops` page, admin-only):

- **Services grid** — one card per service:
  - Render API (green/red + response time)
  - Neon DB (connected/disconnected)
  - Upstash Redis (connected/disconnected)
  - Vercel (deployment status)
  - Hetzner VPS (reachable/unreachable)
  - n8n (healthy/down + workflow count)
  - Postiz (healthy/down + connected accounts)
  - PostHog (events in last 24h count)
  - GitHub Actions (last CI run pass/fail)
- **Agent (n8n workflow) table** — one row per workflow:
  - Social Content Generator — last run, status, output count
  - Growth Content Writer — last run, status
  - Weekly Strategy Check-in — last run (should be every Monday 9am)
  - QA Security Scan — last run, issues found
  - Partnership Outreach Drafter — last run
  - CPA Tax Review — last run
- **Connection map** — simple diagram showing data flow:
  - User -> Vercel -> Render API -> Neon + Redis
  - n8n -> OpenAI + Notion + GitHub
  - Postiz -> Social platforms (TikTok, IG, X, YouTube)

---

## Recommended Next Actions (Priority Order)

1. **Merge PR #12** (OAuth) — ready now, all CI green
2. **Fix demo blur + add estimated refund** — highest conversion impact
3. **EFIN application** (Task B.1) — APPLY TODAY, 45-day blocker
4. **Build ops dashboard** (`/ops` page, admin-only)
5. **Connect Postiz social accounts** + start posting content
6. **Verify PostHog dashboard** — confirm events are flowing
7. **Start state tax (Task 3.4)** — AI-assisted, top 5 states first
8. **Update docs** — KNOWLEDGE.md + TASKS.md with current state

