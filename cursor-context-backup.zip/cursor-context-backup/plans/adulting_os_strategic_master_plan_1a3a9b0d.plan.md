---
name: ""
overview: ""
todos: []
isProject: false
---

# Adulting OS Strategic Master Plan (Pivot: LaunchFree First)

**Status**: Approved & Active
**Date**: March 11, 2026
**Strategy**: "LaunchFree Summer, FileFree Winter."
**North Star**: A portfolio of AI-powered "adulting" tools sharing a single codebase, brand identity, and operations stack.

## 1. The Pivot: LaunchFree First

- **Why**: Tax season is over (April 15 is too close/risky). Business formation is year-round and peaks in Summer/January.
- **Synergy**: LaunchFree builds the "Business Profile" -> FileFree files the "Business Taxes" (Schedule C) later.
- **Speed**: 90% of FileFree's code (Auth, OCR, PDF Gen, UI) is reusable.
- **Growth Engine**: "Viral Social Automation" is the primary lever. LaunchFree's growth will be driven by automated social content (TikTok/IG/X) teasing the "Launch in 5 minutes" promise.

## 2. Corporate Structure & Naming

- **Parent Entity**: **Sharma Ventures LLC** (Recommended).
  - *Why*: Professional, flexible, holds IP for all future projects.
  - *Alt*: `Sharma Vibes LLC` (Too casual for IRS/Banking compliance).
- **Venture Studio Domain**: `sankalpsharma.com`
  - *Role*: The "HQ" site listing your portfolio. Brands *you* as the builder.
- **Product Brands**:
  - **LaunchFree** (`launchfree.ai`) - Business Formation.
  - **FileFree** (`filefree.tax`) - Tax Filing.

## 3. Technical Architecture: The Monorepo

To support "shared code" and "fast details," we move to a Monorepo structure (using Turborepo).

```text
adulting-os/
├── apps/
│   ├── launchfree/ (Next.js - New)
│   └── filefree/   (Next.js - Existing code moved here)
├── packages/
│   ├── ui/         (Shared shadcn/ui, Tailwind config, Fonts)
│   ├── core/       (Shared Auth, Database Schema, OCR Logic, PDF Engine)
│   └── email/      (Shared Transactional Email templates)
└── infra/          (Shared Docker/Render configs)
```

- **Benefit**: Fix a bug in `OCR` once, both apps get it. Share `Auth` session cookies (optional future state).

## 4. Operations & Support (Centralized)

- **Email Strategy**: **BUY, DO NOT BUILD.**
  - *Reason*: Self-hosted email = spam folder hell.
  - *Recommendation*: **Zoho Mail** (Forever Free plan supports up to 5 users + custom domains) OR **Google Workspace** ($6/mo).
  - *Setup*:
    - Primary: `sankalpsharma.com` (Google/Zoho)
    - Aliases: `support@launchfree.ai` -> forwards to `support@sankalpsharma.com` (or shared inbox).
    - Support Tool: **HelpScout** or **Front** (startup plans) eventually. For now, a shared Gmail label is fine.
- **Documentation Strategy**: **Google Drive (Primary)**.
  - *Tool*: Google Drive MCP (`@modelcontextprotocol/server-gdrive`).
  - *Why*: User preference for crisp docs.
  - *Migration*: Move all Strategy, Roadmap, and Decision Logs from Notion to Google Drive folder "FileFree HQ".

## 5. Execution Roadmap

### Phase 1: Foundation (Immediate)

- **Entity**: Form `Sharma Ventures LLC`.
- **Assets**: Register `launchfree.ai` & `launchfree.llc`. Secure `@launchfree` socials.
- **Repo**: Refactor current `fileFree` repo into a Turborepo.
  - Move current code to `apps/filefree`.
  - Extract `ui` and `core` packages.
  - Scaffold `apps/launchfree`.
- **Ops**: Set up Google Drive HQ. Connect MCP. Migrate Notion docs.

### Phase 2: LaunchFree MVP (Summer 2026)

- **Feature**: "Form LLC" Questionnaire (Wizard).
- **Engine**: State Filing PDF Generator (reuse FileFree PDF engine).
- **Monetization**:
  - Banking Affiliate (Mercury/Relay/Novo).
  - Registered Agent Partner (White-label or Affiliate).
- **Growth**: "Start your business this summer" viral campaign. Automated social content via Postiz.

### Phase 3: FileFree & Convergence (Winter 2026)

- **Resume**: FileFree development (now benefiting from LaunchFree's polished UI/Core).
- **E-File**: Continue IRS MeF certification (background process).
- **Cross-Pollinate**: "You launched with LaunchFree? File your Schedule C with FileFree."
  - *Feature*: "Import Business Profile" button in FileFree (pulls data from LaunchFree DB).

## 6. Message to Other Agents

- **Context**: This is a multi-product "Venture Studio" strategy.
- **Constraint**: We use **Shared Infrastructure** wherever possible. Do not spin up separate VPSs for each app. Use the centralized `ops.sankalpsharma.com` stack.
- **Code**: Always check `packages/` first before writing new logic. If it applies to both Tax and Formation, put it in `packages/core`.
- **Docs**: The Source of Truth is now **Google Drive**, not Notion. Use the GDrive MCP to read specs.

