---
name: Adulting OS Strategic Master Plan
overview: Consolidated strategic plan for the 'Adulting OS' multi-product portfolio, resolving the BizFree vs LaunchFree decision and defining the execution sequence to protect FileFree's critical path.
todos:
  - id: register-launchfree-domain
    content: Register launchfree.ai domain immediately
    status: pending
  - id: secure-launchfree-socials
    content: Secure @launchfree social handles
    status: pending
  - id: form-parent-llc
    content: Form parent LLC (Sharma Ventures LLC)
    status: pending
  - id: migrate-ops-infra
    content: Migrate n8n/Postiz to ops.sankalpsharma.com
    status: pending
isProject: false
---

# Adulting OS Strategic Master Plan

**Status**: Approved
**Date**: March 11, 2026
**North Star**: Build a portfolio of free, AI-powered "adulting" tools that monetize via financial decisions, starting with Tax (FileFree) and expanding to Formation (LaunchFree).

## 1. Brand Strategy

- **Brand Family**: `[Verb]Free` on high-tech TLDs.
  - Product 1: **FileFree** (`filefree.tax`) - "File your taxes."
  - Product 2: **LaunchFree** (`launchfree.ai`) - "Launch your business." (Selected over "BizFree")
- **Rationale**: "Launch" aligns with Gen Z aspiration and viral content better than "Biz".
- **Parent Entity**: Single LLC (e.g., "Sharma Ventures LLC") holding all IP initially.

## 2. Infrastructure Strategy

- **Centralized Ops**:
  - `ops.sankalpsharma.com`: Hosts n8n (Automation)
  - `social.sankalpsharma.com`: Hosts Postiz (Social Scheduling)
  - **Why**: Shared services that support all products without polluting product domains.
- **Decentralized Product Infra**:
  - Separate Render/Vercel/Neon projects for FileFree vs LaunchFree.
  - **Why**: Strict PII isolation (SSNs vs EINs) and distinct deploy cycles.

## 3. Execution Sequence (Critical)

### Phase 1: Asset Security (March 2026)

- **Domains**: Register `launchfree.ai` (Priority) and `launchfree.llc` (Defensive).
- **Socials**: Secure `@launchfree` handles on TikTok, IG, X, YT.
- **Legal**: Form parent LLC.

### Phase 2: FileFree Focus (April - Oct 2026)

- **Goal**: IRS MeF Transmitter Certification (The "North Star").
- **Ops Migration**: Move n8n/Postiz to `sankalpsharma.com` subdomains to clear the path.
- **Constraint**: Zero engineering hours on LaunchFree. Focus on FileFree stability.

### Phase 3: LaunchFree MVP (Nov 2026 - Jan 2027)

- **Build**: Fork FileFree codebase (90% reuse: Auth, OCR, PDF Gen).
- **Feature**: "Form an LLC" questionnaire + State Filing PDF generation.
- **Launch**: Jan 2027 (Draft off tax season traffic: "Start a business for tax write-offs").

## 4. Financial Outlook (At Scale)

- **FileFree**: High Volume, Seasonal, Low ARPU (~$8).
- **LaunchFree**: Lower Volume, Year-Round, High ARPU (~$150+ via Registered Agent & Banking).
- **Combined**: Balances cash flow and creates a year-round relationship with the user.

## 5. Risks & Mitigations


| Risk                | Mitigation                                                               |
| ------------------- | ------------------------------------------------------------------------ |
| **Split Focus**     | Strict sequencing. No parallel dev until Phase 3.                        |
| **Legal Liability** | Partner with white-label Registered Agent services; do not self-fulfill. |
| **Naming Conflict** | Register domains *today* to prevent sniping.                             |


