---
name: FileFree Next Steps
overview: With the audit complete and infrastructure solid, the next focus is shipping the OCR demo before April 15 and completing Sprint 0 business ops in parallel.
todos:
  - id: landing-polish
    content: "Task 0.4b: Landing page polish — mobile audit, footer links, sitemap, robots, Lighthouse 95+"
    status: completed
  - id: sentry
    content: "Task 0.5: Finish analytics — verify PostHog events, integrate Sentry"
    status: completed
  - id: camera-component
    content: "Task 1.1: Camera component + image quality checks"
    status: completed
  - id: ocr-pipeline
    content: "Task 1.2: Tiered OCR pipeline — Cloud Vision + GPT + demo endpoint"
    status: completed
  - id: try-before-signup
    content: "Task 1.3: Try-before-signup frontend — /demo page with cascade reveal"
    status: completed
  - id: content-seo
    content: "Task 1.4: Content foundation — SEO pages, pricing page, social launch"
    status: completed
isProject: false
---

# FileFree Next Steps Roadmap

## Current State (March 10, 2026)

**What's live and working:**

- `filefree.tax` — landing page with hero, how-it-works, trust badges, comparison, footer, waitlist capture
- `api.filefree.tax` — FastAPI backend, health endpoint, waitlist endpoint, Neon DB connected
- `n8n.filefree.tax` — 6 persona workflows wired to Notion/GitHub (credentials configured)
- `social.filefree.tax` — Postiz back online with Temporal stack
- PostHog integrated with PII scrubbing, privacy/terms pages live
- `/design` route exists for component preview

**Sprint progress:**

- Sprint 0 (Business Ops): 4/11 done, 1 partial
- Sprint 1 (Foundation): 4/6 done, 1 partial
- Sprint 2+ (Product): not started

---

## Immediate Priority: Close Sprint 1 (This Week)

### 1. Task 0.4b — Landing Page Polish

The landing page exists and is functional. Remaining work:

- Verify mobile responsiveness at 375px/390px (the critical breakpoints)
- Ensure footer links to `/privacy` and `/terms` are working
- Add social media links to footer (TikTok, Instagram, X, YouTube)
- Verify waitlist form POSTs to `api.filefree.tax` in production (the `.env.production` fix was just pushed)
- Lighthouse audit — target 95+ on all categories
- Add `sitemap.ts` and `robots.ts` (pulled from Task 1.4 — needed for SEO before content push)

### 2. Task 0.5 — Finish Analytics

PostHog is integrated. Remaining:

- Verify events appear in PostHog dashboard (page views, waitlist signups)
- Set up landing-to-waitlist funnel in PostHog
- Sentry integration (`@sentry/nextjs`, source maps, error boundaries) — lightweight, ~2 hours

---

## Next Sprint: OCR Demo for April 15 (March 16-30)

This is the critical path. The "wow moment" that becomes the marketing asset for tax deadline traffic.

### 3. Task 1.1 — Camera Component + Image Quality

Build the document camera/upload UI:

- `document-camera.tsx` (rear camera, document overlay, capture button)
- `file-upload-zone.tsx` (drag-and-drop with react-dropzone)
- `image-quality.ts` (blur/dimension/size checks)
- Key files: [web/src/components/camera/](web/src/components/camera/), [web/src/lib/image-quality.ts](web/src/lib/image-quality.ts)

### 4. Task 1.2 — Tiered OCR Pipeline + Demo Endpoint

The core backend intelligence:

- `services/image_processor.py` — Pillow preprocessing (EXIF rotate, contrast, resize)
- `services/ocr_service.py` — Cloud Vision + GPT-4o-mini mapping + GPT-4o vision fallback
- `POST /api/v1/documents/demo-upload` — anonymous, rate-limited, no storage
- Mock mode for dev (no API keys needed)
- Key files: [api/app/services/](api/app/services/), [api/app/routers/documents.py](api/app/routers/documents.py)

### 5. Task 1.3 — Try-Before-Signup Frontend

Connect camera to OCR and show the magic:

- `/demo` page — capture/upload, "Reading your W2..." animation, field-by-field cascade reveal
- sessionStorage for extracted data, gate with "Create account to save"
- Update landing page CTA to link to `/demo`
- Key file: [web/src/app/demo/page.tsx](web/src/app/demo/page.tsx)

### 6. Task 1.4 — Content + Social Launch (parallel)

SEO pages and social media execution:

- `sitemap.ts`, `robots.ts`, OG image, JSON-LD
- 3 SEO guide pages (how to file free, what is W2, standard deduction)
- `/pricing` page
- Social media content creation and scheduling in Postiz

---

## Parallel: Sprint 0 Business Ops (Human Tasks)

These don't require code — they require you (the founders) to take action:

- **B.1 EFIN Application** — longest lead item (45 days). Apply THIS WEEK at irs.gov
- **B.2 Company Setup** — LLC registration, bank account, social media accounts
- **B.5/B.9 Column Tax** — book demo call for interim e-file partner
- **B.8 Affiliate Applications** — apply to Marcus, Wealthfront, Betterment, Fidelity (self-serve, no calls)

---

## Recommended Execution Order

```
Week of March 10:
  [CODE] Task 0.4b — landing page polish + deploy
  [CODE] Task 0.5 — finish Sentry
  [HUMAN] B.1 — submit EFIN application
  [HUMAN] B.2 — register LLC, bank account

Week of March 16:
  [CODE] Task 1.1 — camera component
  [CODE] Task 1.2 — OCR pipeline (backend)
  [HUMAN] B.8 — submit affiliate applications

Week of March 23:
  [CODE] Task 1.3 — try-before-signup frontend
  [CODE] Task 1.4 — SEO + content pages
  [HUMAN] B.5/B.9 — Column Tax demo call

Week of March 30 (April 15 push):
  [CODE] Task 1.4 — social media content launch
  [DEPLOY] OCR demo live as marketing asset
```

