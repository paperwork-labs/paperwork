---
name: Render Blueprint Fixes
overview: Update `render.yaml` to match Render’s current Blueprint schema and clean up the local validation venv folder.
todos:
  - id: fix-static-service
    content: Align static site service fields to schema
    status: completed
  - id: fix-docker-services
    content: Use runtime/dockerCommand for docker services
    status: completed
  - id: move-cron-services
    content: Move cron jobs into services as type cron
    status: completed
  - id: redis-allowlist
    content: Add ipAllowList to redis service
    status: completed
  - id: remove-venv
    content: Delete .venv-render-validate folder
    status: completed
isProject: false
---

# Render Blueprint Fixes

## Scope
- Fix the Blueprint schema errors by aligning service types/fields with Render’s schema and moving cron definitions into `services`.
- Delete the local `.venv-render-validate` folder once the Blueprint is corrected.

## Plan
- Update the static site service in [render.yaml](/Users/sankalpsharma/development/axiomfolio/render.yaml):
  - Use `type: web` with `runtime: static`.
  - Rename `publishPath` to `staticPublishPath`.
- Update Docker-based services in [render.yaml](/Users/sankalpsharma/development/axiomfolio/render.yaml):
  - Replace `env: docker` with `runtime: docker` for the API and worker services.
  - For the worker, use `dockerCommand` (not `startCommand`).
- Move cron jobs into `services` as `type: cron` entries in [render.yaml](/Users/sankalpsharma/development/axiomfolio/render.yaml):
  - Remove the top-level `cronJobs` block.
  - Add each cron as a `services` item with `type: cron`, `runtime: docker`, `schedule`, `dockerfilePath`, and `dockerCommand`.
- Update the Redis service in [render.yaml](/Users/sankalpsharma/development/axiomfolio/render.yaml):
  - Add `ipAllowList: []` to satisfy the Key Value schema requirement (blocks external access).
- Delete `.venv-render-validate/` from the repo workspace once Blueprint passes validation.

## Notes
- I’ll keep the existing commands and schedules, only adjusting field names/locations to match schema.
- If you want the frontend build to avoid the optional-deps Rollup issue, I can switch the static build command to a clean `npm install` after the schema fixes are in place.