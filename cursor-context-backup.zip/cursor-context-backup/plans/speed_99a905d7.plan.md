---
name: Speed
overview: Speed up paid-mode daily backfills (last-year-ish) by increasing effective concurrency safely and by raising the index-universe batching default used by the UI. Keep the same runbook buttons; they just run much faster.
todos: []
---

# Speed up daily backfill (paid mode)

## Goal

Make **daily-only backfill for ~1y** much faster in paid mode, without changing operator UX (same Admin Dashboard/Runbook clicks), and without introducing hard-coded magic numbers.

## What’s slow today (confirmed)

- `backfill_last_200_bars` loops symbols **sequentially**.
- `backfill_symbols` is also **sequential** in paid mode (it only sleeps in free mode).
- The “20 at a time” you see is the **default query param** on the *index-universe* endpoint (`/backfill/index-universe?batch_size=20`) used by the runbook button; it’s batching, not a cap.

Key code:

- [`backend/tasks/market_data_tasks.py`](backend/tasks/market_data_tasks.py): `backfill_last_200_bars`, `backfill_symbols`, `backfill_index_universe`
- [`backend/api/routes/market_data.py`](backend/api/routes/market_data.py): `/backfill/index-universe` default `batch_size=20`

## Proposed changes

### 1) Add configurable paid-mode concurrency for daily backfills

- Add new backend settings (via env) in [`backend/config.py`](backend/config.py):