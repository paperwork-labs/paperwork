---
name: Venture Roundup Update
overview: Comprehensive update to align all strategic, architectural, and operational documentation with the new Paperwork Labs multi-product reality — including accelerating Distill to summer 2026 and formalizing agent-driven operations.
todos:
  - id: cursorrules-rewrite
    content: "Rewrite .cursorrules: North Star, Tech Stack, Infrastructure, Key Domain Concepts, API Design, Security, AI/ML Pipeline sections for multi-product Paperwork Labs"
    status: completed
  - id: architecture-rewrite
    content: Full rewrite of docs/ARCHITECTURE.md with multi-product Mermaid diagrams, monorepo structure, data flow, State Filing Engine, agent ops
    status: completed
  - id: pitch-rewrite
    content: Rewrite docs/PITCH_PACKAGE.md as Paperwork Labs multi-product pitch with updated valuation and infrastructure moat
    status: completed
  - id: tasks-restructure
    content: Restructure docs/TASKS.md phases to pull Distill MVP to summer 2026 timeline, update Phase Timeline table
    status: completed
  - id: vmp-strategy-update
    content: "Update docs/VENTURE_MASTER_PLAN.md: add Filing Engine moat, agent ops moat, accelerated Distill timeline, updated valuation scenarios"
    status: completed
  - id: knowledge-decisions
    content: "Add missing decisions to docs/KNOWLEDGE.md (D72-D75: Filing Engine, brand embrace, Distill acceleration, agent ops model)"
    status: completed
  - id: prd-timeline
    content: Update docs/PRD.md phase table and Distill timeline references to reflect summer acceleration
    status: completed
  - id: financials-distill
    content: Add Distill projected revenue line to docs/FINANCIALS.md
    status: completed
  - id: cross-doc-consistency
    content: "Final consistency sweep: verify all timeline, branding, and architectural references align across all docs and personas"
    status: completed
isProject: false
---

# Paperwork Labs — Venture Roundup: Strategy, Architecture, and Timeline Alignment

## Does This Change Everything? Yes.

The shift from "FileFree is the product" to "Paperwork Labs is an infrastructure company with four products" — combined with pulling Distill forward to summer — fundamentally changes five things:

### 1. Strategy Shift

**Before**: Consumer-first, B2B later. Build FileFree, prove it, then package the tech as APIs in Year 2.

**Now**: Infrastructure-first, consumer and B2B in parallel. The State Filing Engine and tax engine are shared infrastructure that powers both consumer products (FileFree, LaunchFree) and B2B APIs (Distill) from day one. This is the **Stripe model** — build infrastructure, then expose it upward as consumer products AND outward as developer APIs.

**Impact**: The pitch changes from "free tax app with future B2B plans" to "compliance infrastructure company that also runs the best free consumer products." That's a fundamentally different valuation conversation.

### 2. Moat Evolution

**Current VMP moat (6 advantages)** is solid but framed around data flywheel. The new moats are:

- **State Filing Engine** — proprietary portal automation for all 50 states. Nobody else has open-sourced this. Building and maintaining it is a multi-year head start.
- **Dual-use infrastructure** — same engine serves consumers at $0 and B2B at $20-40/filing. Marginal cost near zero means competitors can't undercut without building equivalent infrastructure.
- **Agent-maintained compliance data** — 50-state configs auto-updated by AI agents. This is a moat competitors can't easily replicate because it's not just code, it's operational process.
- **Cross-product data compound** — FileFree tax data + LaunchFree formation data + Distill CPA data = richest compliance profile per user in fintech.

The existing VMP moat section needs to add State Filing Engine and agent ops as explicit moats.

### 3. Valuation Impact

**Current projections** (from VMP):

- Year 1: $14.9K (pessimistic) to $264K (aggressive) — consumer only
- Year 2: $215K-$810K — includes modest Distill revenue

**With Distill pulled to summer**: Even 10 CPA firms at $99/mo + 50 API filings/mo at $30 = $12K+$1.5K = **$13.5K MRR by year-end**. That's $162K ARR from B2B alone, which at 6-10x SaaS multiples = **$972K-$1.62M in B2B valuation** on top of consumer.

The valuation narrative shifts from "consumer traction" multiples (3-5x) to "infrastructure/API" multiples (6-10x+). This needs to be reflected in the projections.

### 4. Data Flow (New)

Currently there is NO end-to-end data flow diagram across products. The architecture needs one:

```mermaid
flowchart TB
    subgraph consumers [Consumer Products]
        FF["FileFree (filefree.ai)"]
        LF["LaunchFree (launchfree.ai)"]
        TR["Trinkets (tools.filefree.ai)"]
    end
    subgraph infra [Shared Infrastructure]
        TE["packages/tax-engine"]
        FE["packages/filing-engine"]
        DP["packages/document-processing"]
        SD["packages/data (50-state configs)"]
    end
    subgraph b2b [B2B Platform]
        DS["Distill CPA SaaS"]
        DFAPI["Distill Formation API"]
        DTAPI["Distill Tax API"]
    end
    subgraph ops [Agent Operations]
        AG["AI Agents (Cursor + n8n)"]
    end
    FF --> TE
    FF --> DP
    LF --> FE
    LF --> SD
    DS --> DP
    DS --> TE
    DFAPI --> FE
    DTAPI --> TE
    AG -->|"maintain"| SD
    AG -->|"monitor"| FE
    AG -->|"update"| TE
```



### 5. Architecture

`[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)` is **completely stale** — it still describes single-product FileFree with `api/` directory, no monorepo, no LaunchFree, no Distill, no State Filing Engine. It needs a full rewrite.

`[.cursorrules](.cursorrules)` Tech Stack, North Star, Key Domain Concepts, API Design, Infrastructure, and Security sections are all **still FileFree-only**. This is the file every agent session reads first — it's actively misleading agents about the architecture.

---

## What Needs Updating

### Critical (agents read these every session)

**A. `[.cursorrules](.cursorrules)` — Venture-wide rewrite**

- Lines 37-38: North Star → expand from "Own MeF Transmitter" to venture-level goals (MeF for FileFree, Filing Engine for LaunchFree, Distill API platform)
- Lines 49-108: Tech Stack → rewrite for monorepo (`apps/`*, `packages/`*, `apis/*`), multi-product infra, pnpm workspaces
- Lines 101-107: Tax Data path → update from `api/tax-data/{year}.json` to `packages/data/tax/{year}.json`
- Lines 89-99: Infrastructure → multi-app Vercel/Render setup, Hetzner ops, Stripe Issuing
- Lines 109-122: shadcn/AI UX → make theme-aware (per-product palettes via `data-theme`)
- Lines 167-172: Key Domain Concepts → add LaunchFree (Formation, LLC, StatePortalConfig) and Distill (Firm, Client, Partner) concepts
- Lines 174-179: API Design → add B2B patterns (API keys, firm scoping, rate limits for Distill)
- Lines 163: Security auth exceptions → venture-wide routes
- Lines 79-87: AI/ML Pipeline → add formation document processing, State Filing Engine automation

**B. `[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)` — Full rewrite**

- Currently: Single-product FileFree with old directory structure
- Needs: Multi-product Mermaid diagrams (system overview, data flow, auth flow, OCR pipeline, State Filing Engine, agent operations), monorepo structure, federated identity, per-product infrastructure, agent maintenance architecture

### Important (external-facing or strategic)

**C. `[docs/PITCH_PACKAGE.md](docs/PITCH_PACKAGE.md)` — Multi-product rewrite**

- Currently: FileFree-only pitch with `filefree.tax` domain (stale)
- Needs: Paperwork Labs venture pitch with all four products, updated valuation, infrastructure moat narrative, B2B revenue acceleration

**D. `[docs/TASKS.md](docs/TASKS.md)` — Phase restructuring for summer Distill**

- Currently: Phase 9 (Distill CPA SaaS) = March 2027, Phase 9.5 (Formation API) = Year 2
- Needs: Pull ALL Distill into summer timeline. Shared infrastructure means the incremental work is thin:
  - Phase 3.5: Expand from "Compliance-as-a-Service" to "Distill Full Platform" — CPA SaaS + Formation API + Tax API + Compliance API
  - Formation API tasks (currently Phase 9.5) merge into Phase 3.5 since they wrap the Filing Engine built in Phase 3
  - Tax API wraps `packages/tax-engine` — can scaffold as soon as Phase 1 monorepo ships
  - CPA SaaS reuses document-processing pipeline from FileFree — ~80% shared
  - Compliance API wraps `packages/data` (50-state configs) — lightest lift
- Collapse Phase 9 + 9.5 into Phase 3.5, update Phase Timeline table (lines 885-903)
- Consumer products (LaunchFree, Trinkets, FileFree prep) stay on their current timelines — nothing is deprioritized

**E. `[docs/VENTURE_MASTER_PLAN.md](docs/VENTURE_MASTER_PLAN.md)` — Strategic updates**

- Add State Filing Engine as explicit moat in Section 4O (lines 2420-2429)
- Add agent-maintained operations as moat
- Update Distill timeline from "Year 2" to "Summer 2026 MVP"
- Update valuation scenarios with accelerated B2B revenue
- Add agent operations architecture to Section 12

**F. `[docs/KNOWLEDGE.md](docs/KNOWLEDGE.md)` — Missing decisions**

- Add D72: State Filing Engine strategic decision (build vs buy, three-tier architecture)
- Add D73: Paperwork Labs brand embrace (company name used everywhere)
- Add D74: Distill timeline acceleration (summer 2026 target)
- Add D75: Agent-driven operations model (agents maintain state data, portals, code)
- Update "Last Updated" from 2026-03-12 to 2026-03-16

**G. `[docs/PRD.md](docs/PRD.md)` — Timeline alignment**

- Update Phase table (lines 1154-1170) to reflect Distill acceleration
- Update Distill API section timeline references from "Year 2-3" to summer target

### Nice-to-Have

**H. `[docs/FINANCIALS.md](docs/FINANCIALS.md)` — Add Distill projected revenue line**

**I. Agent operations documentation** — formalize how agents maintain the 50-state data, portal health, and codebase in either ARCHITECTURE.md or a dedicated section in VMP

---

## Summer Timeline — AI-Augmented Development

The entire Paperwork Labs operating model is one founder + AI agents shipping at the velocity of a full engineering team. Traditional dev estimates don't apply. With AI agents:

- Shared infrastructure packages (`tax-engine`, `filing-engine`, `document-processing`, `data`) are built once during Phases 1-3 and immediately available to all products
- ~80% of Distill's tech is shared with FileFree and LaunchFree — the incremental B2B work is multi-tenant auth, firm scoping, API key management, billing, and docs
- Agent-maintained operations (50-state data, portal health, code maintenance) means the founder focuses on product decisions, not maintenance

**Summer target (all products)**:

- **LaunchFree**: Consumer LLC formation, live and filing
- **Distill CPA SaaS**: Multi-tenant dashboard, bulk upload, extraction review, tax software export
- **Distill Formation API**: Filing Engine exposed as B2B endpoints, per-filing Stripe billing, API docs
- **Distill Tax API**: Tax calculation API (e-file endpoint activates January 2027 when MeF transmitter is certified — IRS timeline, not ours)
- **Distill Compliance API**: State compliance calendars, deadline tracking, automated alerts
- **Trinkets**: SEO-driving calculators and tools
- **FileFree Season Prep**: Begins October 2026 for January 2027 launch (IRS hard deadline)

The only constraint that doesn't compress with AI is the IRS certification timeline — MeF transmitter testing has external dependencies. Everything else ships as fast as the agents can build it.