---
name: Regenerate PRD and TASKS
overview: Regenerate docs/PRD.md as a venture-level PRD covering all 5 products (FileFree, LaunchFree, Distill, Trinkets, Studio) and regenerate docs/TASKS.md as a full-spec 10-phase build plan, archiving the historical Sprint 0-6 content to docs/TASKS-ARCHIVE.md.
todos:
  - id: archive
    content: Create docs/TASKS-ARCHIVE.md with historical Sprint 0-6 content from current TASKS.md
    status: completed
  - id: prd
    content: Regenerate docs/PRD.md as venture-level PRD covering all 5 products, 10 phases, new entity/brand, combined revenue model
    status: completed
  - id: tasks
    content: Regenerate docs/TASKS.md as full-spec 10-phase build plan with acceptance criteria, branches, files/specs, dependencies per task
    status: completed
isProject: false
---

# Regenerate PRD.md and TASKS.md from Venture Master Plan

## Context

- [docs/VENTURE_MASTER_PLAN.md](docs/VENTURE_MASTER_PLAN.md) (3965 lines) is the authoritative strategy document covering 5 products, 10+ phases, revenue models, architecture, legal framework, and agent architecture.
- [docs/PRD.md](docs/PRD.md) (810 lines, v6.0, March 9) is outdated -- covers only FileFree, references 3 phases, old entity structure, old domain (filefree.tax not filefree.ai).
- [docs/TASKS.md](docs/TASKS.md) (1379 lines, v8.3, March 11) mixes completed Sprint 0-6 historical specs (~800 lines) with a partially-integrated Venture Phases section. Sprint 4-6 already marked "SUPERSEDED."

## What Changes

### 1. Create docs/TASKS-ARCHIVE.md (new file)

Move the historical Sprint 0-6 content (Sprints 0 through 6 plus the Infrastructure section) from TASKS.md into an archive doc. This preserves the detailed implementation specs for completed work (Task 0.1 through 2.7, B.1 through B.11, I.1) as reference.

- Preserve all `<details>` blocks, acceptance criteria, branch names, and DONE statuses
- Add a header noting this is an archive and pointing to TASKS.md for active work
- Include the original Sprint 0 (Business Ops), Sprint 1 (Foundation), Sprint 2 (OCR Demo), Sprint 3 (Full MVP), Infrastructure (Config), Sprint 4 (Growth), Sprint 5 (Extension Season), Sprint 6 (January 2027) sections exactly as they exist

### 2. Regenerate docs/PRD.md (venture-level)

Transform from FileFree-only PRD into a venture-level PRD for Paperwork Labs LLC. Key sections:

- **Venture Overview**: Entity (Paperwork Labs LLC, California), products, domains, team structure, AI model strategy reference
- **Product 1 -- FileFree** (filefree.ai): Problem, solution, target user, competitive landscape (TurboTax, FreeTaxUSA, april, Cash App), moats, user flow (Screens 0-8), form coverage roadmap, e-file strategy (Column Tax interim -> own MeF transmitter NORTH STAR), success metrics
- **Product 2 -- LaunchFree** (launchfree.ai): Problem, solution, 50-state AI comparison, "Submit LLC" reality check, RA credit system, compliance-as-a-service, competitive landscape (LegalZoom, ZenBusiness, Northwest), success metrics
- **Product 3 -- Distill** (distill.tax): B2B tax automation for CPAs, two product lines (CPA SaaS + API), tech overlap (~80% shared with FileFree), pricing tiers, multi-tenant isolation, DPA requirement, audit trail, competitive positioning vs MagneticTax
- **Product 4 -- Trinkets** (tools.filefree.ai): Utility tool collection, Trinket Factory agent pipeline, domain strategy, revenue model (AdSense + cross-sell), first trinket spec
- **Product 5 -- Studio/Command Center** (paperworklabs.com): Admin dashboard, 3-tier page hierarchy, docs viewer, agent monitor, infrastructure health
- **Revenue Model**: Combined revenue projections from master plan Section 1 (FileFree + LaunchFree + Distill combined Year 1), unit economics, Plan B (zero partnerships), partnership milestones
- **Architecture**: Monorepo structure, federated identity, auth architecture, brand palettes, port map, production reliability (idempotency, circuit breakers, reconciliation, observability, load testing)
- **Data Models**: Per-product models + venture identity schema + marketplace tables
- **API Design**: Per-product endpoint groups
- **Legal and Compliance**: Trademark framework, FTC "Free" rules, Circular 230, UPL, cross-sell consent, PII lifecycle, CCPA
- **Success Metrics**: Per-product KPIs at 2026/2027/2028 horizons
- **Content and Distribution**: SEO, social media, paid amplification, viral loops, autonomous content

Sources from master plan:

- Section 0 (overview, entity, domains)
- Section 0B (LLC naming)
- Section 0C (trademark, legal risk)
- Section 0D (valuation, referenced but not duplicated)
- Section 0E (AI model strategy, referenced)
- Section 0F (Trinkets)
- Section 0I (PII data lifecycle)
- Section 1 (revenue model)
- Section 1B (adjacent revenue)
- Section 1C (Distill)
- Section 2 (architecture)
- Section 3 (command center)
- Section 3B (50-state data pipeline)
- Section 4 (user intelligence platform)
- Existing PRD sections 2-4 (competitive strategy, user flow, technical requirements) updated for venture scope

### 3. Regenerate docs/TASKS.md (10-phase full-spec build plan)

Pure forward-looking task document with full specs. Structure:

- **Header**: Version, date, references to master plan, PRD, PRODUCT_SPEC
- **Critical dates and dependencies** section with the hard deadlines (EFIN, ATS Oct 2026, tax season Jan 2027)
- **Pre-Code Blockers** (Section 0G items: EFIN, cyber insurance, attorney consult, LLC filing)
- **Phase 0: Infrastructure** -- full task table with branch, files/specs, acceptance criteria, dependencies, status (from master plan Section 7)
- **Phase 1: Monorepo Restructure** -- full specs (P1.1 through P1.11, including P1.9c for Distill scaffold)
- **Phase 1.5: First Trinket** -- P1.5.1 through P1.5.5
- **Phase 2: 50-State Data Infrastructure** -- P2.1 through P2.10
- **Phase 3: LaunchFree MVP** -- P3.1 through P3.8, plus Phase 3.5 (Compliance SaaS)
- **Phase 4: Command Center** -- Tier 1/2/3 breakdown (P4.1 through P4.14)
- **Phase 5: User Intelligence Platform** -- P5.1 through P5.12
- **Phase 6: Agent Restructure + Social Pipeline** -- P6.1 through P6.7
- **Phase 7: FileFree Season Prep** -- P7.1 through P7.22 (including MeF local validation, state engines, form coverage, reliability infrastructure)
- **Phase 8: FileFree Launch** -- P8.1 through P8.8
- **Phase 9: Distill** -- P9.1 through P9.11
- **Phase 10: Business Tax Filing** -- P10.1 through P10.7
- **Background Tasks** -- continuous items with hard deadlines
- **Phase Timeline** -- aspirational vs realistic from master plan
- **Critical Path** diagram
- **Form Coverage Roadmap** table

Each task should include:

- Task ID and name
- Owner (Founder 1 / Founder 2 / Either)
- Branch name
- Files/specs (key files that will be created/modified)
- Acceptance criteria
- Dependencies (which tasks must complete first)
- Status
- Sprint/Phase reference to master plan section for deep context

Use `<details>` blocks for tasks with extensive specs to keep the document scannable.

### Cross-references to preserve

- TASKS.md references: PRODUCT_SPEC.md (UX specs), PRD.md (business context), VENTURE_MASTER_PLAN.md (deep strategy), PARTNERSHIPS.md (partner playbook), .cursorrules (coding conventions)
- PRD.md references: PRODUCT_SPEC.md, TASKS.md, PARTNERSHIPS.md, VENTURE_MASTER_PLAN.md, FINANCIALS.md, AI_MODEL_REGISTRY.md
- Both docs should reference the master plan section numbers for deep-dive context (e.g., "See VENTURE_MASTER_PLAN.md Section 1C for full Distill spec")

### What NOT to change

- [docs/PRODUCT_SPEC.md](docs/PRODUCT_SPEC.md) -- UX spec for FileFree, stays as-is (it's product-specific by design)
- [docs/VENTURE_MASTER_PLAN.md](docs/VENTURE_MASTER_PLAN.md) -- source of truth, read-only for this task
- [docs/FINANCIALS.md](docs/FINANCIALS.md), [docs/PARTNERSHIPS.md](docs/PARTNERSHIPS.md), [docs/KNOWLEDGE.md](docs/KNOWLEDGE.md), [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) -- unchanged
- `.cursorrules` and `.cursor/rules/*.mdc` -- unchanged

