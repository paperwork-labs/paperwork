---
name: Per-User Credential Sync
overview: Fix TastyTrade sync to use per-user encrypted credentials from the database instead of global env vars, making the system properly multi-tenant.
todos:
  - id: sync-use-stored-creds
    content: Update TastyTradeSyncService.sync_account() to load AccountCredentials from DB, decrypt via CredentialVault, and call connect_with_credentials(). Remove singleton from TastyTradeClient so each sync gets a fresh instance.
    status: completed
  - id: cleanup-startup-seeding
    content: Remove TASTYTRADE_DISCOVER_ON_STARTUP block from main.py startup (lines 247-306). Update account_config_service to not require env-based TT credentials.
    status: completed
  - id: update-env-comments
    content: Add dev-only fallback comments to env.dev and config.py for TastyTrade env vars
    status: completed
  - id: update-sync-tests
    content: Add test_tastytrade_sync_uses_stored_credentials and test_tastytrade_sync_falls_back_to_env to test_broker_sync_service.py. Update test_client_tastytrade.py singleton test.
    status: completed
isProject: false
---

# Per-User Credential Sync

## Problem

Two credential paths exist but don't connect:

1. **UI path (correct)**: User enters OAuth creds in `SettingsBrokerages.tsx` -> POST `/aggregator/tastytrade/connect` -> `_tt_connect_job()` encrypts and stores creds in `account_credentials` table per-user, sets `api_credentials_stored=True` on the `broker_accounts` row
2. **Sync path (broken)**: `TastyTradeSyncService.sync_account()` (line 49) calls `self.client.connect_with_retry()` which reads from env vars (`settings.TASTYTRADE_CLIENT_SECRET`), completely ignoring per-user stored credentials

Additionally, `TastyTradeClient` is a **singleton** (lines 45-51 of `tastytrade_client.py`), meaning if User A's sync sets the session, User B's sync that starts right after would reuse User A's session. This is wrong for multi-tenant.

## Architecture After Fix

```mermaid
sequenceDiagram
    participant UI as SettingsBrokerages
    participant API as /aggregator/tastytrade/connect
    participant DB as account_credentials
    participant Celery as sync_account_task
    participant SyncSvc as TastyTradeSyncService
    participant Vault as CredentialVault
    participant TT as TastyTrade API

    UI->>API: POST client_secret + refresh_token
    API->>Vault: encrypt_dict(creds)
    API->>DB: store encrypted creds
    Note over DB: per BrokerAccount row

    Celery->>SyncSvc: sync_account(broker_account)
    SyncSvc->>DB: load AccountCredentials for account
    SyncSvc->>Vault: decrypt_dict(encrypted_credentials)
    SyncSvc->>TT: connect_with_credentials(secret, token)
    TT-->>SyncSvc: positions, trades, etc.
```



---

## Change 1: Remove singleton from TastyTradeClient

**File**: [backend/services/clients/tastytrade_client.py](backend/services/clients/tastytrade_client.py)

**Why**: The singleton pattern (lines 45-51) means all syncs share one `session`/`accounts` state. When we move to per-user credentials, each sync must use its own client instance so User A's session doesn't leak to User B.

**What to change**:

Remove the `_instance` and `__new`__ singleton logic (lines 45-51):

```python
# REMOVE these lines:
_instance = None
_lock = asyncio.Lock() if TASTYTRADE_AVAILABLE else None

def __new__(cls):
    if cls._instance is None:
        cls._instance = super().__new__(cls)
    return cls._instance
```

Replace with a simple class-level lock (still needed for retry logic within a single instance):

```python
def __init__(self):
    self.session: Optional[Any] = None
    self.accounts: List[Any] = []
    self.connected = False
    self.connection_start_time: Optional[datetime] = None
    self.retry_count = 0
    self.max_retries = 3
    self.base_retry_delay = 2
    self._lock = asyncio.Lock() if TASTYTRADE_AVAILABLE else None
    self.connection_health: Dict[str, Any] = {
        "status": "disconnected",
        "last_successful_request": None,
        "consecutive_failures": 0,
        "connection_uptime": 0,
    }
```

Remove the `if not hasattr(self, "_initialized")` guard (line 54) since it was only needed for the singleton.

Also remove the module-level singleton instance at the bottom of the file:

```python
# FIND and REMOVE:
tastytrade_client = TastyTradeClient()
```

**Impact on imports**: Files that import `tastytrade_client` (the singleton instance) will need to create their own instances:

- [backend/api/routes/aggregator.py](backend/api/routes/aggregator.py) line 28: `from backend.services.clients.tastytrade_client import tastytrade_client` -- this is used in `_tt_connect_job` and status endpoint. Change to create a local instance: `client = TastyTradeClient()`.
- [backend/api/main.py](backend/api/main.py): TastyTrade autodiscovery already creates `client = TastyTradeClient()` so no change needed there, but the whole block is being removed anyway (see Change 3).

---

## Change 2: TastyTradeSyncService uses stored credentials

**File**: [backend/services/portfolio/tastytrade_sync_service.py](backend/services/portfolio/tastytrade_sync_service.py)

**What to change**: Replace lines 42-51 (the `sync_account` connection block) with credential lookup logic.

Current code (lines 42-51):

```python
async def sync_account(
    self, db: Session, broker_account: BrokerAccount
) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    try:
        await self.client.connect_with_retry()  # <-- always uses env vars
    except Exception:
        pass
```

New code:

```python
async def sync_account(
    self, db: Session, broker_account: BrokerAccount
) -> Dict[str, int]:
    counts: Dict[str, int] = {}

    # Per-user credentials: look up stored OAuth creds for this account
    cred = (
        db.query(AccountCredentials)
        .filter(AccountCredentials.account_id == broker_account.id)
        .first()
    )
    if cred and cred.encrypted_credentials:
        payload = credential_vault.decrypt_dict(cred.encrypted_credentials)
        ok = await self.client.connect_with_credentials(
            client_secret=payload["client_secret"],
            refresh_token=payload["refresh_token"],
        )
        if not ok:
            raise ConnectionError(
                f"TastyTrade OAuth failed for account {broker_account.account_number}"
            )
    else:
        # Dev fallback: env var credentials for seed accounts without stored creds
        await self.client.connect_with_retry()
```

**New imports** needed at top of file:

```python
from backend.models.broker_account import AccountCredentials
from backend.services.security.credential_vault import credential_vault
```

Also, since `TastyTradeClient` is no longer a singleton, create a fresh instance per sync in `__init__` (already does this at line 36: `self.client = TastyTradeClient()`). No change needed here.

---

## Change 3: Remove TASTYTRADE_DISCOVER_ON_STARTUP from main.py

**File**: [backend/api/main.py](backend/api/main.py)

**What**: Delete lines 247-306 (the entire `TASTYTRADE_DISCOVER_ON_STARTUP` block). This code:

- Connects to TastyTrade using env vars
- Discovers accounts
- Seeds them for `user_id=1`
- Does NOT store credentials in `account_credentials`

This bypasses the per-user flow entirely. Users should connect via the UI (`SettingsBrokerages.tsx` -> `/aggregator/tastytrade/connect`) which properly stores encrypted credentials per-user.

**Exact lines to delete** (247-306):

```python
        # Optional: TastyTrade autodiscovery (opt-in only)
        try:
            if (
                TASTYTRADE_AVAILABLE
                ...
            ):
                ...
                await client.disconnect()
        except Exception as e:
            logger.warning(f"TastyTrade autodiscovery skipped: {e}")
```

---

## Change 4: Update aggregator.py to not use singleton

**File**: [backend/api/routes/aggregator.py](backend/api/routes/aggregator.py)

**Lines 28-29** currently import:

```python
from backend.services.clients.tastytrade_client import tastytrade_client, TASTYTRADE_AVAILABLE
```

Change to:

```python
from backend.services.clients.tastytrade_client import TastyTradeClient, TASTYTRADE_AVAILABLE
```

**Line 235** in `_tt_connect_job`:

```python
ok = await tastytrade_client.connect_with_credentials(client_secret, refresh_token)
```

Change to:

```python
client = TastyTradeClient()
ok = await client.connect_with_credentials(client_secret, refresh_token)
```

**Line 244**:

```python
accounts = await tastytrade_client.get_accounts()
```

Change to:

```python
accounts = await client.get_accounts()
```

`**tastytrade_status` endpoint** (uses `tastytrade_client.connected`, `tastytrade_client.connection_health`, `tastytrade_client.accounts`): This endpoint shows connection status. Since there's no longer a global singleton, this should report status based on whether the user's account has stored credentials and last sync status. Replace the singleton state checks with a DB query:

```python
@router.get("/tastytrade/status", response_model=TTStatusResponse)
async def tastytrade_status(
    job_id: Optional[str] = None,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
) -> TTStatusResponse:
    if not TASTYTRADE_AVAILABLE:
        return TTStatusResponse(available=False, connected=False)

    # Check if user has any TT accounts with stored credentials
    from backend.models.broker_account import BrokerAccount, BrokerType, AccountCredentials
    tt_accounts = (
        db.query(BrokerAccount)
        .filter(BrokerAccount.user_id == user.id, BrokerAccount.broker == BrokerType.TASTYTRADE)
        .all()
    )
    has_creds = any(
        db.query(AccountCredentials).filter(AccountCredentials.account_id == a.id).first()
        for a in tt_accounts
    )
    accounts_list = [
        {"account_number": a.account_number, "nickname": a.account_name}
        for a in tt_accounts
    ]

    resp = TTStatusResponse(
        available=True,
        connected=has_creds,
        accounts=accounts_list,
    )
    if job_id and job_id in JOBS:
        job = JOBS[job_id]
        resp.job_id = job_id
        resp.job_state = job.get("state")
        resp.job_error = job.get("error")
    return resp
```

`**tastytrade_disconnect` endpoint**: Update to remove stored credentials from DB rather than calling `tastytrade_client.disconnect()`:

```python
@router.post("/tastytrade/disconnect", response_model=TTStatusResponse)
async def tastytrade_disconnect(
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
) -> TTStatusResponse:
    from backend.models.broker_account import BrokerAccount, BrokerType, AccountCredentials
    tt_accounts = (
        db.query(BrokerAccount)
        .filter(BrokerAccount.user_id == user.id, BrokerAccount.broker == BrokerType.TASTYTRADE)
        .all()
    )
    for a in tt_accounts:
        a.is_enabled = False
        a.api_credentials_stored = False
        a.connection_status = "disconnected"
        db.query(AccountCredentials).filter(AccountCredentials.account_id == a.id).delete()
    db.commit()
    return TTStatusResponse(available=True, connected=False, accounts=[])
```

---

## Change 5: Update env.dev and config.py comments

**File**: [infra/env.dev](infra/env.dev) lines 62-71

Add comment clarifying these are dev-only fallback credentials:

```ini
# Tastytrade OAuth (v12+ SDK)
# DEV FALLBACK ONLY — production uses per-user credentials stored via Settings > Brokerages UI.
# These env vars are only used when a broker_account has no stored AccountCredentials row.
TASTYTRADE_CLIENT_ID=4ed2941d-3b22-4466-b2ac-6c31e0bdd90a
TASTYTRADE_CLIENT_SECRET=...
TASTYTRADE_REFRESH_TOKEN=...
TASTYTRADE_IS_TEST=false
# Removed: TASTYTRADE_DISCOVER_ON_STARTUP (no longer used)
```

**File**: [backend/config.py](backend/config.py) lines 27-34

Update comments:

```python
# TastyTrade Configuration (OAuth -- v12+ SDK)
# Dev fallback only; production credentials stored per-user in account_credentials table
TASTYTRADE_CLIENT_SECRET: Optional[str] = None
TASTYTRADE_REFRESH_TOKEN: Optional[str] = None
TASTYTRADE_IS_TEST: bool = False
# REMOVED: TASTYTRADE_DISCOVER_ON_STARTUP (per-user flow only)
```

Remove `TASTYTRADE_DISCOVER_ON_STARTUP` field from Settings class entirely.

---

## Change 6: Update tests

### 6a. New test: sync uses stored credentials

**File**: [backend/tests/test_broker_sync_service.py](backend/tests/test_broker_sync_service.py)

Add a new test class or test method that:

1. Creates a `BrokerAccount` with `broker=TASTYTRADE`
2. Creates an `AccountCredentials` row with encrypted `{"client_secret": "s", "refresh_token": "r"}`
3. Mocks `TastyTradeClient.connect_with_credentials` to verify it's called with the decrypted values
4. Mocks the sync sub-methods to return empty results
5. Asserts `connect_with_retry` was NOT called

```python
@pytest.mark.asyncio
async def test_tastytrade_sync_uses_stored_credentials(self, db_session, test_user):
    from backend.models.broker_account import AccountCredentials, BrokerType, SyncStatus
    from backend.services.security.credential_vault import credential_vault
    from backend.services.portfolio.tastytrade_sync_service import TastyTradeSyncService

    account = BrokerAccount(
        user_id=test_user.id,
        account_number="TT_CRED_TEST",
        account_name="TT Cred Test",
        broker=BrokerType.TASTYTRADE,
        account_type=AccountType.TAXABLE,
        sync_status=SyncStatus.NEVER_SYNCED,
        api_credentials_stored=True,
    )
    db_session.add(account)
    db_session.flush()

    payload = {"client_secret": "test_secret", "refresh_token": "test_refresh"}
    enc = credential_vault.encrypt_dict(payload)
    cred = AccountCredentials(
        account_id=account.id,
        encrypted_credentials=enc,
        provider=BrokerType.TASTYTRADE,
        credential_type="oauth",
    )
    db_session.add(cred)
    db_session.commit()

    svc = TastyTradeSyncService()
    with (
        patch.object(svc.client, "connect_with_credentials", new_callable=AsyncMock, return_value=True) as mock_creds,
        patch.object(svc.client, "connect_with_retry", new_callable=AsyncMock) as mock_retry,
        patch.object(svc, "_sync_positions", new_callable=AsyncMock, return_value={"positions": 0}),
        patch.object(svc, "_sync_trades", new_callable=AsyncMock, return_value={"trades": 0}),
        patch.object(svc, "_sync_transactions", new_callable=AsyncMock, return_value={"transactions": 0}),
        patch.object(svc, "_sync_dividends", new_callable=AsyncMock, return_value={"dividends": 0}),
        patch.object(svc, "_sync_account_balances", new_callable=AsyncMock, return_value={"account_balances": 0}),
    ):
        result = await svc.sync_account(db_session, account)
        mock_creds.assert_called_once_with(client_secret="test_secret", refresh_token="test_refresh")
        mock_retry.assert_not_called()
```

### 6b. New test: sync falls back to env vars when no stored credentials

```python
@pytest.mark.asyncio
async def test_tastytrade_sync_falls_back_to_env(self, db_session, test_user):
    account = BrokerAccount(
        user_id=test_user.id,
        account_number="TT_NO_CRED",
        broker=BrokerType.TASTYTRADE,
        account_type=AccountType.TAXABLE,
        sync_status=SyncStatus.NEVER_SYNCED,
        api_credentials_stored=False,
    )
    db_session.add(account)
    db_session.commit()

    svc = TastyTradeSyncService()
    with (
        patch.object(svc.client, "connect_with_credentials", new_callable=AsyncMock) as mock_creds,
        patch.object(svc.client, "connect_with_retry", new_callable=AsyncMock, return_value=True) as mock_retry,
        patch.object(svc, "_sync_positions", new_callable=AsyncMock, return_value={"positions": 0}),
        # ... other sync methods mocked ...
    ):
        result = await svc.sync_account(db_session, account)
        mock_retry.assert_called_once()
        mock_creds.assert_not_called()
```

### 6c. Update singleton test

**File**: [backend/tests/test_client_tastytrade.py](backend/tests/test_client_tastytrade.py)

Remove or update `test_client_singleton_pattern` (lines 33-38) since singleton is removed. Replace with a test that verifies two instances are independent:

```python
def test_client_instances_are_independent(self):
    if not TASTYTRADE_AVAILABLE:
        pytest.skip("TastyTrade SDK not available")
    client1 = TastyTradeClient()
    client2 = TastyTradeClient()
    assert client1 is not client2
    client1.connected = True
    assert client2.connected is False
```

### 6d. Update aggregator test

**File**: [backend/tests/test_aggregator_tt_async.py](backend/tests/test_aggregator_tt_async.py)

Line 45: Update `monkeypatch.setattr(agg, "tastytrade_client", DummyTT())` to patch `TastyTradeClient` class instead:

```python
monkeypatch.setattr(agg, "TastyTradeClient", lambda: DummyTT())
```

---

## What stays the same

- **Frontend** `SettingsBrokerages.tsx` -- already correct, submits per-user `client_secret` + `refresh_token`
- **Aggregator connect endpoint** (`_tt_connect_job`) -- already correctly stores encrypted credentials per account via `credential_vault.encrypt_dict()`
- **CredentialVault** -- already works, uses Fernet encryption with `ENCRYPTION_KEY` or `SECRET_KEY`
- **AccountCredentials model** -- already has the right schema (`encrypted_credentials`, `provider`, `credential_type`)
- `**connect_with_credentials()`** on `TastyTradeClient` -- already exists (lines 143-178) and works
- **API_URL override patch** (line 17) -- still needed regardless of credential source
- **Celery task** (`account_sync.py`) -- no changes needed, it just calls `broker_sync_service.sync_account_async()`
- **BrokerSyncService** (`broker_sync_service.py`) -- no changes needed, it routes to `TastyTradeSyncService` which handles the credential logic

## Scope note

This fix is for TastyTrade only. Schwab already follows a per-user OAuth pattern. IBKR uses a different connection model (TWS/Gateway with Flex queries).