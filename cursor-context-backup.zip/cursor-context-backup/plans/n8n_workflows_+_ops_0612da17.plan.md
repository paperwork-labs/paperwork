---
name: n8n workflows + ops
overview: Build a proper frontend config system with credential safety, import n8n workflows, add secrets scanning to CI, and wire everything together.
todos:
  - id: fix-env-gitignore
    content: Stop tracking .env.production/.env.development in git — move secrets to .env.local (gitignored) and keep only non-secret defaults in tracked files
    status: pending
  - id: server-config
    content: Create web/src/lib/server-config.ts — Zod-validated server-side config for service credentials
    status: pending
  - id: client-config
    content: Create web/src/lib/client-config.ts — Zod-validated client-side config for NEXT_PUBLIC_ vars
    status: pending
  - id: migrate-consumers
    content: Migrate all process.env consumers to use the config modules
    status: pending
  - id: secrets-scanner
    content: Add gitleaks to CI and pre-commit to catch credential leaks
    status: pending
  - id: import-workflows
    content: Import 6 persona workflow JSONs into n8n via REST API
    status: pending
  - id: verify
    content: Verify everything — type check, tests, ops dashboard shows live data
    status: pending
isProject: false
---

# n8n Workflows + Config System + Credential Safety

## Problem Found

`web/.env.production` and `web/.env.development` are **tracked by git** and contain the PostHog API key (`phc_tBJ...`). If we add `N8N_API_KEY` or `GITHUB_TOKEN` to these files, they'd be committed to the repo. No secrets scanner exists in CI or pre-commit. This needs to be fixed first.

## 1. Fix env file strategy (credential safety)

Next.js loads env files in this order: `.env` < `.env.local` < `.env.development` < `.env.development.local` < `.env.production` < `.env.production.local`. Files ending in `.local` are meant to be gitignored.

**Current state (broken):**

- `web/.env.development` -- tracked, has non-secret defaults (OK)
- `web/.env.production` -- tracked, has PostHog API key (BAD)

**Target state:**

- `web/.env.development` -- tracked, non-secret defaults only (API_URL=localhost, empty keys)
- `web/.env.production` -- tracked, non-secret defaults only (API_URL=api.filefree.tax, PostHog host URL)
- `web/.env.local` -- gitignored, actual secrets (PostHog key, n8n key, GitHub token)
- `web/.env.production.local` -- gitignored, production secrets (same keys, production values)
- `web/.env.example` -- tracked, documents ALL env vars with blank/placeholder values

Changes:

1. Add `web/.env.local` and `web/.env*.local` to [.gitignore](.gitignore) (`.env.*.local` is already there)
2. Move PostHog key from `web/.env.production` to `web/.env.local`
3. Add `N8N_API_KEY`, `N8N_HOST`, `GITHUB_TOKEN` to `web/.env.local`
4. Create `web/.env.example` documenting all vars
5. `git rm --cached web/.env.production web/.env.development` is NOT needed since they won't have secrets — we just move secrets out
6. Update [infra/env.dev.example](infra/env.dev.example) with new ops vars section

## 2. Create `web/src/lib/server-config.ts`

Server-only Zod-validated config:

```typescript
import { z } from "zod";

const schema = z.object({
  N8N_API_KEY: z.string().default(""),
  N8N_HOST: z.string().default("https://n8n.filefree.tax"),
  GITHUB_TOKEN: z.string().default(""),
});

export const serverConfig = schema.parse({
  N8N_API_KEY: process.env.N8N_API_KEY,
  N8N_HOST: process.env.N8N_HOST,
  GITHUB_TOKEN: process.env.GITHUB_TOKEN,
});
```

## 3. Create `web/src/lib/client-config.ts`

Client-side Zod-validated config consolidating all `NEXT_PUBLIC_*` reads:

```typescript
import { z } from "zod";

const schema = z.object({
  apiUrl: z.string().default("http://localhost:8000"),
  posthogKey: z.string().default(""),
  posthogHost: z.string().default("https://us.i.posthog.com"),
  sentryDsn: z.string().default(""),
  googleClientId: z.string().default(""),
  appleClientId: z.string().default(""),
  appleRedirectUri: z.string().default(""),
});

export const clientConfig = schema.parse({
  apiUrl: process.env.NEXT_PUBLIC_API_URL,
  posthogKey: process.env.NEXT_PUBLIC_POSTHOG_KEY,
  posthogHost: process.env.NEXT_PUBLIC_POSTHOG_HOST,
  sentryDsn: process.env.NEXT_PUBLIC_SENTRY_DSN,
  googleClientId: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID,
  appleClientId: process.env.NEXT_PUBLIC_APPLE_CLIENT_ID,
  appleRedirectUri: process.env.NEXT_PUBLIC_APPLE_REDIRECT_URI,
});
```

## 4. Migrate consumers

Replace raw `process.env` in these files:


| File                                                                                     | Before                                     | After                         |
| ---------------------------------------------------------------------------------------- | ------------------------------------------ | ----------------------------- |
| [web/src/lib/api.ts](web/src/lib/api.ts)                                                 | `process.env.NEXT_PUBLIC_API_URL`          | `clientConfig.apiUrl`         |
| [web/src/lib/posthog.ts](web/src/lib/posthog.ts)                                         | `process.env.NEXT_PUBLIC_POSTHOG_KEY`      | `clientConfig.posthogKey`     |
| [web/src/components/auth/google-sign-in.tsx](web/src/components/auth/google-sign-in.tsx) | `process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID` | `clientConfig.googleClientId` |
| [web/src/components/auth/apple-sign-in.tsx](web/src/components/auth/apple-sign-in.tsx)   | `process.env.NEXT_PUBLIC_APPLE_CLIENT_ID`  | `clientConfig.appleClientId`  |
| [web/src/app/api/ops/route.ts](web/src/app/api/ops/route.ts)                             | `process.env.N8N_API_KEY`                  | `serverConfig.N8N_API_KEY`    |


Skip `design/page.tsx` (`NODE_ENV`) and `instrumentation.ts` (`NEXT_RUNTIME`) — Next.js built-ins, not custom config.

## 5. Add gitleaks to CI

Add a `secrets-scan` job to [.github/workflows/ci.yaml](.github/workflows/ci.yaml) using `gitleaks/gitleaks-action@v2`. Runs on every PR, scans for API keys, tokens, passwords in code and git history. Also add a `.gitleaksignore` for known false positives (like the PostHog key already in git history — we can't rewrite history, but we prevent new leaks).

## 6. Import n8n workflows

`curl POST` all 6 workflow JSONs from [infra/hetzner/workflows/](infra/hetzner/workflows/) to `https://n8n.filefree.tax/api/v1/workflows`. They import as inactive.

## 7. Verify

- `npx tsc --noEmit` clean
- `npx vitest run` all pass
- Ops dashboard shows live n8n workflows
- No secrets in tracked files
- Commit and push to PR #13

