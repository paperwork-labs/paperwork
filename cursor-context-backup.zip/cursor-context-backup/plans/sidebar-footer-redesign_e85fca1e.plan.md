---
name: sidebar-footer-redesign
overview: Hide the sidebar footer entirely for non-admin users until Portfolio is enabled, while keeping the full footer for admin/portfolio-enabled users.
todos:
  - id: footer-conditional-render
    content: Split sidebar footer rendering by portfolio visibility (full footer vs hidden state).
    status: completed
  - id: footer-ui-polish
    content: Clean up layout spacing when footer is hidden in pre-portfolio state.
    status: completed
  - id: footer-tests
    content: Update/run targeted layout tests for both footer states.
    status: completed
isProject: false
---

# Sidebar Footer Redesign Plan

## Goal

Hide the sidebar footer (`account selector + combined portfolio + quick stats`) for users who should not yet see Portfolio features, while keeping richer footer content only when Portfolio is available.

## Scope

Target file: [frontend/src/components/layout/DashboardLayout.tsx](/Users/sankalpsharma/development/axiomfolio/frontend/src/components/layout/DashboardLayout.tsx)

Use existing gating signals already present in the layout:

- `isAdmin`
- `portfolioEnabled`
- `marketOnly`/`appSettings`

## Implementation

- Introduce a clear footer render split:
  - **Portfolio-enabled view** (admin or feature-enabled users): keep account selector + portfolio summary + quick stats card.
  - **Pre-Portfolio view (non-admin, portfolio disabled)**: hide the footer block entirely (no account selector/stats/stub).
- Keep behavior local to sidebar footer only; do not alter route guards or section visibility logic.
- Refactor footer JSX into small helper render blocks in the same file for readability:
  - `renderPortfolioFooter()`
  - `renderHiddenFooter()` (returns `null`)
- Ensure collapsed/expanded sidebar behavior remains visually consistent with current header/sidebar interactions.

## Validation

- Run targeted tests:
  - `frontend/src/components/layout/__tests__/DashboardLayoutPersistence.test.tsx`
  - `frontend/src/pages/__tests__/SettingsShell.test.tsx`
- Add or update layout test assertions (if needed) to verify:
  - footer is hidden for non-admin + portfolio disabled
  - portfolio footer appears when portfolio-enabled path is active

## Notes

- This keeps rollout intent intact: Portfolio surfaces are not functionally exposed early.
- The redesign is implemented now, but visibility is governed by the same rollout flags.

