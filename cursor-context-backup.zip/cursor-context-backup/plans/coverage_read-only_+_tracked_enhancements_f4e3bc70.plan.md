---
name: Coverage Read-only + Tracked Enhancements
overview: Make Market Data Coverage page read-only and concise, move admin-only blocks to Admin Dashboard, clarify job counters, and enrich Tracked table rows.
todos: []
---

# Coverage Read-only + Tracked Enhancements

## Scope

- Make the Market Data Coverage page read-only for regular users: remove admin actions/toggles, remove redundant snapshot/large tables from Coverage; keep concise status/KPIs only.
- Move Coverage snapshot/trend details to admin context (Admin Dashboard) so admin can still view them there.
- Add concise English summary for job counters (e.g., daily backfill) describing counts.
- Tracked page: add last snapshot/time info and ensure rows populate from snapshot or price_data (no blanks for symbols like AAPL/AMD/etc.).

## Steps

1) Coverage page (Market Data)

- Remove admin actions, toggles, and heavy snapshot/tables from `AdminCoverage` for non-admin users.
- Keep a compact status/KPIs view only.
- Move snapshot/trend content to Admin Dashboard.

2) Admin Dashboard

- Ensure coverage snapshot/trend panel is present for admins (if not already) to replace what was removed from Coverage page.
- Add concise English summaries for job counters where shown.

3) Tracked page

- Add last snapshot timestamp to rows; ensure fallback from price_data fills price so cells aren’t blank.

## Files to touch (likely)

- `frontend/src/pages/AdminCoverage.tsx`
- `frontend/src/pages/AdminDashboard.tsx` (coverage snapshot/trend for admin)
- `frontend/src/pages/AdminTracked.tsx`
- (If needed) backend counters summary mapping (frontend display of job counters).

## Notes

- Coverage page for regular users: status/KPIs only; no admin blocks, no 5m toggle, no heavy snapshot tables.
- Admin retains full visibility via Admin Dashboard.