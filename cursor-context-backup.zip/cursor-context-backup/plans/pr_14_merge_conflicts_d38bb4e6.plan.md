---
name: PR 14 merge conflicts
overview: "PR #14 (feat/config-credential-safety) has merge conflicts with main because main merged PR #13 first, which touched the same files (ops dashboard, demo page, tax estimator, image quality, docs). This plan summarizes the conflicts and a safe resolution strategy."
todos: []
isProject: false
---

# PR #14 merge conflict analysis and resolution plan

## Current state

- **Branch**: `feat/config-credential-safety` → [PR #14](https://github.com/sankalp404/fileFree/pull/14)
- **Base**: `main`
- **GitHub**: `mergeable: CONFLICTING`, `mergeStateStatus: DIRTY`
- **CI**: All checks passing (Secrets Scan, API/Web Lint, Tests, Build, Vercel)

**Cause**: Main has one commit ahead — **PR #13** (“Demo refund estimate, blur fix, ops dashboard”). That PR added the same features (ops route, ops page, demo page, tax estimator, image-quality) with a slightly different implementation. Your branch built the config/credential-safety work on top of an earlier base, so both sides modified the same 8 files.

---

## Conflicted files (8)


| File                                                                   | Conflict type | Summary                                                                                                                                                     |
| ---------------------------------------------------------------------- | ------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [docs/KNOWLEDGE.md](docs/KNOWLEDGE.md)                                 | Both modified | **Main**: date `2026-03-12`. **Yours**: date `2026-03-11` + D34 config decision block.                                                                      |
| [docs/TASKS.md](docs/TASKS.md)                                         | Both modified | **Main**: version `8.1`. **Yours**: version `8.3`, updated critical dates, and full “Task I.1 — Config + Credential Safety” section.                        |
| [web/src/app/api/ops/route.ts](web/src/app/api/ops/route.ts)           | Added in both | **Main**: inline interfaces, PostHog hint “API key in web/.env.production”. **Yours**: `serverConfig` + `@/types/ops`, updated PostHog hint, same behavior. |
| [web/src/app/demo/page.tsx](web/src/app/demo/page.tsx)                 | Both modified | **Main**: 3-arg `estimateRefund(..., state_tax_withheld)`, no rate-limit UI. **Yours**: 2-arg `estimateRefund`, `RateLimitStep`, axios 429 handling.        |
| [web/src/app/ops/page.tsx](web/src/app/ops/page.tsx)                   | Both modified | **Main**: inline interfaces. **Yours**: `@/types/ops`, `useReducedMotion`, agent names prefixed “FileFree —”.                                               |
| [web/src/lib/image-quality.ts](web/src/lib/image-quality.ts)           | Both modified | **Main**: `BLUR_THRESHOLD = 15`, no high-res bypass. **Yours**: `BLUR_THRESHOLD = 5`, `HIGH_RES_BYPASS = 1500`, skip blur check for high-res.               |
| [web/src/lib/tax-estimator.ts](web/src/lib/tax-estimator.ts)           | Both modified | **Main**: `estimateRefund(wages, federal, state)` — includes state withholding. **Yours**: `estimateRefund(wages, federal)` — federal-only.                 |
| [web/src/lib/tax-estimator.test.ts](web/src/lib/tax-estimator.test.ts) | Both modified | **Main**: tests for 3-arg API. **Yours**: tests for 2-arg API, updated expected refund/owed.                                                                |


---

## Resolution strategy

**Goal**: Keep PR #14’s behavior and design (config system, shared types, credential safety, federal-only estimate, blur fix, rate-limit step) and absorb main only where it’s clearly an independent improvement (e.g. date).

1. **Merge main into your branch** (e.g. `git fetch origin main && git merge origin/main`).
2. **Resolve each conflict** as below; then run tests and fix any type/import issues.

### Per-file resolution

- **docs/KNOWLEDGE.md**  
Keep your D34 block and your “Last Updated” line. If you prefer the newer date, set it to `2026-03-12` after resolving.
- **docs/TASKS.md**  
Keep your side: version **8.3**, your critical dates, and the full **Task I.1** section. Discard main’s version header (8.1).
- **web/src/app/api/ops/route.ts**  
Keep **your** version: imports from `@/lib/server-config` and `@/types/ops`, and your PostHog access hint. Main’s version duplicates types and references the old env file.
- **web/src/app/ops/page.tsx**  
Keep **your** version: `@/types/ops`, `useReducedMotion`, and “FileFree —” agent names.
- **web/src/app/demo/page.tsx**  
Keep **your** version: 2-arg `estimateRefund`, `RateLimitStep`, and 429 handling. Main’s 3-arg estimator and lack of rate-limit UI would conflict with your tax-estimator and UX.
- **web/src/lib/image-quality.ts**  
Keep **your** version: `BLUR_THRESHOLD = 5`, `HIGH_RES_BYPASS`, and high-res bypass logic (your blur fix).
- **web/src/lib/tax-estimator.ts**  
Keep **your** version: 2-parameter API (federal-only). Aligns with demo and tests.
- **web/src/lib/tax-estimator.test.ts**  
Keep **your** version: 2-arg calls and updated expectations.

**Optional**: After resolving, bump **docs/KNOWLEDGE.md** “Last Updated” to the merge date if you want it to reflect the resolution.

---

## Flow (high level)

```mermaid
flowchart LR
  subgraph main [main]
    M[PR 13 merged]
  end
  subgraph branch [feat/config-credential-safety]
    B[Config + credential safety]
  end
  M --> C[Conflict in 8 files]
  B --> C
  C --> R[Resolve: keep branch behavior]
  R --> T[Tests + typecheck]
  T --> P[Push and merge PR 14]
```



---

## After resolving

1. Run full test suite: `make test` (or equivalent from repo root).
2. Run typecheck/lint: `make lint` (or per-package scripts for web/api).
3. Commit the merge and resolution: e.g. `git add -A && git commit -m "Merge main into feat/config-credential-safety, resolve conflicts"`
4. Push: `git push origin feat/config-credential-safety`.

If you want, the next step can be a step-by-step command sequence (exact `git` and conflict-editor actions) for doing the merge and each file resolution on your machine.