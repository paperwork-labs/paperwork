---
name: Ops+UI polish
overview: "Implement requested improvements in the user-specified order: ops rolling history backfill + sanity check, then UI state persistence, then settings layout tweaks, then align MarketCoverage with AdminDashboard and make its table sortable using MarketSnapshot."
todos:
  - id: ops-rolling-history
    content: Change restore daily orchestrator to backfill snapshot history for rolling 5 trading days; keep 200d as separate action
    status: completed
  - id: ops-sanity-check
    content: Add sanity-check endpoint/job (latest OHLCV counts + latest snapshot-history fill %) and surface it in Admin UI if appropriate
    status: completed
    dependencies:
      - ops-rolling-history
  - id: ui-persist-sidebar
    content: Persist sidebar collapse state in localStorage and restore on load
    status: completed
  - id: ui-restore-last-route
    content: Persist last successful route in localStorage and redirect there after login/session refresh (fallback Dashboard)
    status: completed
    dependencies:
      - ui-persist-sidebar
  - id: ui-settings-maxwidth
    content: Tighten Settings Profile/Preferences layout (max width on large screens)
    status: completed
  - id: marketcoverage-align
    content: Align MarketCoverage summary + histogram with AdminDashboard (read-only)
    status: completed
    dependencies:
      - ops-sanity-check
  - id: marketcoverage-sortable-table
    content: Add sortable MarketSnapshot-backed table to MarketCoverage with Level 1–4 fields
    status: completed
    dependencies:
      - marketcoverage-align
  - id: tests
    content: Update/add backend+frontend tests for new behavior
    status: completed
    dependencies:
      - ops-rolling-history
      - ops-sanity-check
      - ui-persist-sidebar
      - ui-restore-last-route
      - ui-settings-maxwidth
      - marketcoverage-sortable-table
isProject: false
---

# Ordered improvements rollout

## Scope (in your requested order)

### 1) Ops improvements (backend)

- Update the **Restore Daily Coverage (Tracked)** orchestrator (`bootstrap_daily_coverage_tracked`) to backfill **snapshot history for a rolling window (default 5 trading days)** instead of always doing 200 days.
- Keep the **200 trading day** history backfill as a separate explicit operator action (existing “Backfill Snapshot History (200d)” button remains).
- Add a lightweight **sanity-check job/endpoint** that reports:
- latest 1d OHLCV date and distinct-symbol count
- latest snapshot-history as_of_date and distinct-symbol count
- snapshot-history fill % vs tracked universe for the latest trading day
- (optional) list of a few missing symbols for latest day

**Files**:

- [backend/tasks/market_data_tasks.py](backend/tasks/market_data_tasks.py)
- [backend/api/routes/market_data.py](backend/api/routes/market_data.py)

### 2) UI state persistence (frontend)

- Persist sidebar collapse/expand state in localStorage and restore it on reload.
- Persist last successful route in localStorage and after login/session refresh redirect back to it (fallback to Dashboard).

**Files**:

- [frontend/src/components/layout/DashboardLayout.tsx](frontend/src/components/layout/DashboardLayout.tsx)
- [frontend/src/context/AuthContext.tsx](frontend/src/context/AuthContext.tsx)
- [frontend/src/App.tsx](frontend/src/App.tsx)

### 3) Settings layout tightening (frontend)

- Constrain max width on large screens for Settings pages so the cards don’t stretch too wide (keep responsive behavior for small screens).

**Files**:

- [frontend/src/pages/SettingsProfile.tsx](frontend/src/pages/SettingsProfile.tsx)
- [frontend/src/pages/SettingsPreferences.tsx](frontend/src/pages/SettingsPreferences.tsx)

### 4) MarketCoverage alignment + sortable table (frontend)

- Make **MarketCoverage** show the same summary content as **AdminDashboard** (minus admin actions):
- summary card + KPIs + trend + buckets
- daily fill histogram (read-only)
- Replace/augment the page with a **sortable table** backed by `**MarketSnapshot` (latest view)**, showing the Level 1–4 indicators/fields you listed.
- Confirm backend already stores:
- fundamentals (sector/sub-industry) in `MarketSnapshot` (and history)
- Level 1–4 computed fields in `MarketSnapshot` and `MarketSnapshotHistory` wide columns

**Files**:

- [frontend/src/pages/MarketCoverage.tsx](frontend/src/pages/MarketCoverage.tsx)
- [frontend/src/components/SortableTable.tsx](frontend/src/components/SortableTable.tsx)
- (optional shared extraction) [frontend/src/components/coverage/CoverageSummaryCard.tsx](frontend/src/components/coverage/CoverageSummaryCard.tsx)

## Validation

- Add/adjust backend tests for rolling 5-day history behavior and sanity-check payload.
- Add/adjust frontend tests for:

