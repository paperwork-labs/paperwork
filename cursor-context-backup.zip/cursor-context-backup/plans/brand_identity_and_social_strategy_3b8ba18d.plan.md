---
name: Brand Identity and Social Strategy
overview: Create a complete brand identity (logo, colors, typography, voice) and a social content roadmap with rotating hero headlines, covering everything from logo design to a 30-day launch content calendar.
todos:
  - id: logo-generation
    content: Generate FileFree wordmark logo + FF monogram + social avatars via image generation
    status: completed
  - id: brand-mdc
    content: Create .cursor/rules/brand.mdc with formal brand guide (colors, type, voice, logo usage)
    status: completed
  - id: rotating-hero
    content: Add RotatingPunchline to hero.tsx with 5 taglines and crossfade animation
    status: completed
  - id: social-roadmap
    content: Create docs/SOCIAL_ROADMAP.md with 30-day content calendar and viral hook templates
    status: completed
  - id: web-assets
    content: Add favicon, OG image, and social avatars to web/public, update layout.tsx
    status: completed
isProject: false
---

# Brand Identity + Social Content Roadmap

## 1. Rotating Hero Headlines

### Research Verdict

Research is clear: **a single headline with subtle animation outperforms rotating carousels**. Rotating banners lose 66% of users who don't read past the first slide. Kinetic typography (animating individual words) performs 35-52% better than static text in SaaS.

### Recommended Approach

Keep a single headline structure but **animate the punch word** using a typewriter/fade-swap effect on just the gradient word. The headline stays anchored ("Taxes shouldn't ____"), only the emotional payoff rotates:

```
Taxes shouldn't  [make you cry.]
                  [cost $89.]
                  [take 3 hours.]
                  [feel this hard.]
                  [require a CPA.]
```

This is a single Framer Motion `AnimatePresence` component that cycles the gradient word every 4 seconds with a crossfade. The structure remains readable; only the punch changes. Not tacky -- this is what Linear, Vercel, and Raycast do on their landing pages.

**Implementation**: Modify [web/src/components/landing/hero.tsx](web/src/components/landing/hero.tsx) to add a `RotatingPunchline` component using `AnimatePresence` with `mode="wait"` and a `useEffect` interval.

## 2. Brand Identity System

### Logo Strategy

The fintech logo research points strongly to a **wordmark** approach (like Stripe, Wise, Ramp). Reasons:

- FileFree is 8 characters, 3 syllables -- short enough for a clean wordmark
- Wordmarks are easier to trademark than abstract icons
- Wordmarks work at every size (16px favicon to billboard)
- The brand IS the name -- no need for a separate symbol yet

**Logo concept**: "FileFree" in a custom-weighted geometric sans-serif, with the "F" slightly stylized. The gradient accent (violet-to-purple) applies to the logomark for digital use; a solid indigo version for monochrome contexts.

**Lockups to create:**

- Primary: Full wordmark "FileFree" (horizontal)
- Icon: Stylized "FF" monogram (for favicon, app icon, social avatars)
- Monochrome: White on dark, dark on white

### Color Palette (Already Established)

The color system already exists in [web/src/app/globals.css](web/src/app/globals.css). Documenting it formally:

- **Primary**: Indigo `hsl(238, 76%, 57%)` / `#4F46E5`
- **Accent gradient**: `from-violet-500 to-purple-600` (the brand signature)
- **Background (dark)**: `hsl(224, 71%, 4%)` -- near-black with blue undertone
- **Foreground**: `hsl(213, 31%, 91%)` -- warm white
- **Success**: Green (refund amounts)
- **Warning**: Amber (owed amounts)
- **Destructive**: Red (errors)

### Typography (Already Established)

- **Primary**: Inter (400/500/600/700)
- **Mono**: JetBrains Mono (for currency, SSN, data displays)

### Brand Voice (Needs Formal Documentation)

Tone framework based on what already exists in the codebase:

- **Personality**: Smart friend who knows taxes -- not software, not the IRS
- **Register**: Casual but competent. Never condescending, never jargon-heavy.
- **Words we use**: free, simple, fast, yours, done, clear, secure
- **Words we avoid**: optimize, leverage, synergy, disrupt, file (as a noun), taxpayer
- **Anxiety-killing patterns**: "You're done.", "That's it.", "We handle this.", "Nothing hidden."

### Deliverables

I'll create:

1. **Logo generation** -- use the image generation tool to create the wordmark + FF monogram
2. **Brand guide** in `.cursor/rules/brand.mdc` (alwaysApply) -- colors, type, voice, logo usage rules
3. **Favicon + OG image** assets for the site
4. **Social avatar** (the FF monogram on gradient background) sized for all platforms

## 3. Social Content Roadmap

### 30-Day Pre-Launch Content Calendar

Based on the research: **entertainment-first framework** (95% value, 5% CTA). Content pillars from [social.mdc](.cursor/rules/social.mdc) already defined. Here's the specific execution plan:

**Week 1 (Days 1-7): Founder Journey -- Build in Public**

- Day 1: "I quit my job to build a free tax app. Here's why." (X thread + TikTok)
- Day 2: "What TurboTax charges for vs what it costs them" (TikTok -- comparison with receipts)
- Day 3: "Day 1 of building FileFree" (behind-the-scenes TikTok, show the actual code/terminal)
- Day 4: "The IRS has a free filing tool and nobody knows about it" (educational IG Reel)
- Day 5: "How much it actually costs to run a tax app (showing real numbers)" (X thread)
- Day 6-7: Engage with tax-related comments/threads on X, reply to r/tax and r/personalfinance

**Week 2 (Days 8-14): Tax Myths Busted**

- "You don't owe taxes on Venmo payments (unless...)" (TikTok)
- "The tax bracket myth that's costing you money" (TikTok + IG Reel)
- "No, your employer didn't steal your money. Here's what Box 1 actually means" (TikTok)
- "POV: you finally understand your W-2" (TikTok with screen recording of the demo)
- X polls: "What's the most confusing thing about filing taxes?"

**Week 3 (Days 15-21): Product Tease**

- "I scanned a W-2 and my app read every field in 3 seconds" (TikTok screen recording of /demo)
- "Before: 45 minutes on TurboTax. After: 3 minutes on FileFree." (TikTok split-screen)
- "This is what free tax filing actually looks like" (IG Reel, honest, no hype)
- Carousel: "5 things you're overpaying for that should be free" (IG)
- YouTube Short: "How AI reads your W-2 (explained in 60 seconds)"

**Week 4 (Days 22-30): Community Building**

- "Who else is stressed about filing? Comment your #1 question" (engagement bait, respond to every comment)
- "I'll explain your W-2 in the comments" (TikTok -- DM/comment-driven)
- "The waitlist is open. Here's exactly what FileFree does." (CTA post with link in bio)
- Pin first-week launch post on TikTok/IG with waitlist CTA

### Viral Content Formulas (Reusable Templates)

These are the hooks that work in personal finance TikTok based on the research:

- **"Nobody talks about..."** -- creates curiosity gap
- **"POV: you actually understand..."** -- aspiration + relatability
- **"Stop letting [company] do this to you..."** -- outrage trigger
- **"If you make under $[X], watch this"** -- targeting + urgency
- **"I just saved $[X] in [Y] minutes"** -- proof of value
- **"Reply to @user"** -- engagement bait + demonstrates expertise
- **Stitch trending finance videos** with your take
- **Green screen with IRS.gov screenshots** -- authority + education

### Content Production Flow

```
1. Script (AI-drafted via n8n or manual)
2. Record (phone, 15-60s, natural lighting, casual tone)
3. Edit (CapCut -- add captions, trending audio)
4. Post to TikTok (native upload for algorithm favor)
5. Re-edit for IG Reels (different caption style, 20+ hashtags)
6. Extract key points for X thread
7. Schedule via Postiz
```

## 4. Implementation Plan

### Phase A: Brand Identity (can be done in this session)

- Generate logo (wordmark + monogram) via image generation
- Create `brand.mdc` cursor rule with formal brand guide
- Add favicon, OG image, social avatar to web assets
- Update layout.tsx with favicon/OG references

### Phase B: Rotating Hero (code change)

- Add `RotatingPunchline` component to hero.tsx
- 5 punch lines with 4-second crossfade interval
- Respect `prefers-reduced-motion` (static first line only)

### Phase C: Social Content Roadmap (documentation)

- Create `docs/SOCIAL_ROADMAP.md` with the 30-day calendar
- Update `social.mdc` with the viral hook formulas and content production SOP
- Store reusable content templates for n8n automation

### Phase D: Notion Integration

- Create "Content Calendar" database in Notion (if not exists)
- Each post: date, platform, status (draft/scheduled/posted), copy, media, engagement metrics

