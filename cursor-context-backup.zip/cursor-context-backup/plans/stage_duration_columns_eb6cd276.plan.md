---
name: Stage Duration Columns
overview: Add stage duration fields (current/previous) backed by DB columns and backfill them from MarketSnapshotHistory, then surface them in MarketTracked table and snapshots API.
todos:
  - id: migration-columns
    content: Add stage duration columns + migration
    status: completed
  - id: compute-helper
    content: Implement stage run-length helper
    status: completed
  - id: backfill-task
    content: Backfill history + snapshots
    status: completed
  - id: snapshot-update
    content: Populate fields on snapshot compute
    status: completed
  - id: api-ui
    content: Expose fields + update MarketTracked columns
    status: completed
  - id: tests
    content: Add/update tests for new fields
    status: completed
isProject: false
---

- Add DB columns for stage durations and previous stage info in [backend/models/market_data.py](/Users/sankalpsharma/development/axiomfolio/backend/models/market_data.py) on `MarketSnapshot` and `MarketSnapshotHistory` (e.g., `current_stage_days`, `previous_stage_label`, `previous_stage_days`), then generate Alembic migration and keep defaults nullable.
- Implement a stage-run computation helper (likely in [backend/services/market/indicator_engine.py](/Users/sankalpsharma/development/axiomfolio/backend/services/market/indicator_engine.py) or a new helper module) that, given a per-symbol ordered stage_label series by trading day, derives for each date: current run length and previous run label/length.
- Add a backfill task in [backend/tasks/market_data_tasks.py](/Users/sankalpsharma/development/axiomfolio/backend/tasks/market_data_tasks.py) that:
  - loads `MarketSnapshotHistory` by symbol/date,
  - computes durations using the helper,
  - writes the three new fields for each history row and updates the latest `MarketSnapshot` for each symbol.
- Update snapshot computation in [backend/services/market/market_data_service.py](/Users/sankalpsharma/development/axiomfolio/backend/services/market/market_data_service.py) to populate these fields for current snapshots (using latest history if available).
- Expose new fields in the `/market-data/snapshots` response in [backend/api/routes/market_data.py](/Users/sankalpsharma/development/axiomfolio/backend/api/routes/market_data.py) (no API shape breaking).
- Update the tracked UI in [frontend/src/pages/MarketTracked.tsx](/Users/sankalpsharma/development/axiomfolio/frontend/src/pages/MarketTracked.tsx) to replace the “Stage” / “Stage (5d ago)” columns with:
  - `Stage` (current),
  - `Time in Stage` (days),
  - `Previous Stage`,
  - `Time in Previous Stage` (days), using the new fields.
- Add/adjust tests: backfill task unit tests for run-length correctness, and frontend render tests if present for the new columns.

