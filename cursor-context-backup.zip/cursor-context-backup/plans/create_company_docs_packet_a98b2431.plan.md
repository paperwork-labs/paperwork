---
name: Create company docs packet
overview: Create a `docs/` folder containing a small, consistent security/privacy documentation packet you can upload to Plaid now and reuse for future vendor diligence.
todos:
  - id: create-docs-structure
    content: Create docs/ folder structure and add starter security/privacy policy markdown files.
    status: completed
  - id: plaid-answer-sheet
    content: Create Plaid questionnaire answer sheet referencing the new docs and providing copy/paste text.
    status: completed
    dependencies:
      - create-docs-structure
  - id: git-commit-docs
    content: Commit docs folder to repo (no secrets) and push to GitHub.
    status: completed
    dependencies:
      - plaid-answer-sheet
---

# Create company docs packet

## Goals

- Add a `docs/` folder with a reusable starter documentation packet for Plaid + future vendor reviews.
- Keep the content accurate for a solo-founder MVP while still sounding professional.

## Docs to create (files)

- [`docs/security/Security_Overview.md`](/Users/sankalpsharma/development/jointly/docs/security/Security_Overview.md)
- High-level architecture, data flows, where sensitive data lives, encryption, logging, backups.
- [`docs/security/Information_Security_Policy.md`](/Users/sankalpsharma/development/jointly/docs/security/Information_Security_Policy.md)
- Lightweight policy (principles, roles, risk management cadence).
- [`docs/security/Access_Control_Policy.md`](/Users/sankalpsharma/development/jointly/docs/security/Access_Control_Policy.md)
- RBAC/least privilege, admin access, secrets handling, onboarding/offboarding.
- [`docs/security/Incident_Response_Plan.md`](/Users/sankalpsharma/development/jointly/docs/security/Incident_Response_Plan.md)
- Severity levels, triage, containment, comms, timelines.
- [`docs/security/Vulnerability_Management.md`](/Users/sankalpsharma/development/jointly/docs/security/Vulnerability_Management.md)
- Patch cadence, dependency scanning plan, device security baseline.
- [`docs/privacy/Privacy_Policy_Draft.md`](/Users/sankalpsharma/development/jointly/docs/privacy/Privacy_Policy_Draft.md)
- Draft policy you can later publish as a web page.
- [`docs/privacy/Data_Retention_Deletion_Policy.md`](/Users/sankalpsharma/development/jointly/docs/privacy/Data_Retention_Deletion_Policy.md)
- Retention schedule and deletion process (user-request + operational deletion).
- [`docs/plaid/Plaid_Security_Questionnaire_Answers.md`](/Users/sankalpsharma/development/jointly/docs/plaid/Plaid_Security_Questionnaire_Answers.md)
- Copy/paste answers mapped to questions 1–11, referencing the docs above.

## How these map to your Plaid questionnaire

- Q2/Q3/Q8/Q11: backed by the policies + vuln mgmt + retention docs.
- Q5: provide a screenshot of MFA enabled for critical systems (Google/GitHub) and reference `Access_Control_Policy.md`.
- Q6: state TLS is enforced in production deployment (documented in `Security_Overview.md`); dev uses localhost HTTP.
- Q9: provide a link later; for now attach `Privacy_Policy_Draft.md`.

## Implementation notes

- Use “Jointly (solo founder, pre-launch)” as the org identity throughout.
- Avoid claiming controls you don’t have; include an “In progress” section where appropriate.
- Keep each doc 1–3 pages, skimmable.

## Follow-up