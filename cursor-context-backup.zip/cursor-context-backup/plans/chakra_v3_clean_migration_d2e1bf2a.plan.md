---
name: Chakra v3 Clean Migration
overview: Adopt Chakra UI v3 “correctly” by establishing a token/semantic-token based design system with real light/dark support, then migrating all components off v2 patterns and deleting temporary shims.
todos:
  - id: theme-system
    content: Create Chakra v3 system config with tokens + semantic tokens + proper light/dark; wire into ChakraProvider (App.tsx)
    status: pending
  - id: auth-polish
    content: Make Login/Register/AuthLayout use semantic tokens + CardRoot recipe so headings/text are readable and consistent
    status: pending
    dependencies:
      - theme-system
  - id: ui-primitives
    content: Add AppCard/Page/FormField primitives and migrate auth + a couple key pages to use them
    status: pending
    dependencies:
      - theme-system
  - id: remove-shims
    content: Remove temporary useColorModeValue shims and remaining v2-only imports/props across the frontend
    status: pending
    dependencies:
      - ui-primitives
  - id: shell-migration
    content: Normalize DashboardLayout + navigation/header styling using tokens/recipes; ensure v3 primitives for Menu/Tabs/Dialog
    status: pending
    dependencies:
      - remove-shims
---

# Chakra v3 “Correct” Adoption Plan

## Goals

- Eliminate v2-only imports/props (e.g. `useToast`, `useColorModeValue`, `FormControl`, `InputRightElement`, v2 menu APIs).
- Establish a **real v3 design system**: tokens + **semantic tokens** + recipes, with **proper light/dark**.
- Make auth + app shell **Snowball-ish + Apple-ish** and consistent (fix issues like **black headings on dark**).
- Remove migration shims (dark-first `useColorModeValue` fallbacks) once semantic tokens are in.

## Architecture: how Chakra v3 wants to be used

```mermaid
flowchart TD
  App[AppRoot] --> ChakraProvider
  ChakraProvider --> SystemConfig
  SystemConfig --> Tokens
  SystemConfig --> SemanticTokens
  SystemConfig --> Recipes
  SystemConfig --> GlobalCss
  Tokens --> Components
  SemanticTokens --> Components
  Recipes --> Components
  GlobalCss --> Components
```



- **Tokens**: raw values (brand scale, radii, fonts).
- **Semantic tokens**: app-facing names (`bg.canvas`, `bg.panel`, `fg.default`, `border.subtle`) that switch between light/dark.
- **Recipes**: reusable component styling (buttons/cards/inputs) so pages don’t re-implement design.
- **Global CSS**: only for broad base (body background, font smoothing), not per-component styling.

## Step 0: Fix the immediate auth visual bugs (black headings on dark)

- Update auth pages to use semantic tokens (not hardcoded colors).
- Ensure `Heading`/`Text` base styles are readable in dark mode via:
- semantic tokens for foreground (`fg.default`, `fg.muted`) and
- a base recipe (or global styles) that sets sensible defaults.

Files:

- [`frontend/src/pages/Login.tsx`](frontend/src/pages/Login.tsx)
- [`frontend/src/pages/Register.tsx`](frontend/src/pages/Register.tsx)
- [`frontend/src/components/layout/AuthLayout.tsx`](frontend/src/components/layout/AuthLayout.tsx)

## Step 1: Create the v3 design system (tokens + semantic tokens)

- Add `frontend/src/theme/system.ts` exporting `system = createSystem(defaultConfig, {...})`.
- Define:
- **Brand palette** (keep existing brand scale).
- **Semantic tokens**:
    - `bg.canvas`, `bg.panel`, `bg.card`, `bg.input`
    - `fg.default`, `fg.muted`, `fg.subtle`
    - `border.subtle`, `border.strong`
    - `shadow.card`
- **Radii** and spacing that match Snowball/Apple feel.
- Implement proper light/dark switching with semantic token `_light`/`_dark` values.
- Add minimal global CSS (font smoothing, canvas background, body height).

Files:

- New: [`frontend/src/theme/system.ts`](frontend/src/theme/system.ts)
- Update: [`frontend/src/App.tsx`](frontend/src/App.tsx) to import and use the system.

## Step 2: Shared UI primitives (stop styling ad-hoc)

Create a small set of reusable building blocks and migrate pages to them:

- `AppCard` (wrap `CardRoot/CardBody` with standard border, bg, shadow)
- `Page` + `PageHeader` (title/subtitle/actions)
- `FormField` wrapper around v3 `FieldRoot/FieldLabel` with helper/error slots
- `PrimaryButton` / `SecondaryButton` recipe (proper loading/disabled)

Files:

- New: `frontend/src/components/ui/AppCard.tsx`
- New: `frontend/src/components/ui/Page.tsx`
- New: `frontend/src/components/ui/FormField.tsx`
- (Reuse existing where possible: `frontend/src/components/ui/PageHeader.tsx` if present)

## Step 3: Remove all remaining band-aids

- Remove the temporary `useColorModeValue` shim functions scattered across pages/components.
- Replace hardcoded grays/blues with semantic tokens.
- Replace any remaining v2 props (`isLoading`, `icon` on `IconButton`, etc.) with v3 equivalents.

Approach:

- Grep-based sweep for:
- `useColorModeValue`, `useColorMode`, `useToast`
- `FormControl`, `FormLabel`
- `InputLeftElement`, `InputRightElement`
- `MenuButton`, `MenuList`
- Convert page-by-page, committing in small, reviewable chunks.

## Step 4: Migrate core primitives across the app shell

- Standardize navigation + header in [`frontend/src/components/layout/DashboardLayout.tsx`](frontend/src/components/layout/DashboardLayout.tsx) using tokens/recipes.
- Ensure tables/tabs/dialogs use v3 exports:
- `TabsRoot/TabsList/TabsTrigger/TabsContent`
- `DialogRoot/DialogTrigger/DialogContent/...`

## Step 5: Toasts (v3-correct)

- Chakra v3 doesn’t export the v2 `useToast` hook; pick one consistent approach:
- Keep `react-hot-toast` (already in use) and style via tokens, or
- Adopt Chakra v3 toast primitives if/when added in the lib.

Decision for this migration: **standardize on `react-hot-toast`** and stop importing `useToast` anywhere.

## Step 6: QA/verification workflow

- For each migrated page:
- open it, verify no console errors
- verify light/dark toggling (and persistence if desired)