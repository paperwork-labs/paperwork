---
name: Full Audit + Next Steps
overview: Comprehensive multi-persona audit of FileFree infrastructure, codebase, and documentation. Identifies what's done, what's broken, and the prioritized path forward from groundwork to Sprint 1.
todos:
  - id: dns-fix
    content: "Update Vercel DNS values in Spaceship (A: 216.198.79.1, CNAME: e0fd235af7be6e2b.vercel-dns-o17.com) + add api.filefree.tax custom domain on Render"
    status: completed
  - id: cleanup-empty-dirs
    content: Scaffold Alembic in api/alembic/ or remove empty dirs (alembic/, tax-data/)
    status: completed
  - id: knowledge-d21
    content: Add D21 to docs/KNOWLEDGE.md documenting infrastructure completion
    status: completed
  - id: tasks-update
    content: Update docs/TASKS.md to mark completed Sprint 0 infra items
    status: completed
isProject: false
---

# FileFree Full Audit + Forward Path

## DNS Change Recommended (from Vercel screenshot)

Vercel is recommending you update to newer, project-specific DNS values for better routing. Your current records work fine -- this is an optimization, not a breakage.

**Update in Spaceship:**

- A record `@`: change `76.76.21.21` to `216.198.79.1`
- CNAME `www`: change `cname.vercel-dns.com` to `e0fd235af7be6e2b.vercel-dns-o17.com`

**Also needed: `api.filefree.tax` is not working** (returns connection refused). The CNAME DNS record is correct, but the custom domain hasn't been registered on Render's side yet. User needs to go to Render Dashboard > filefree-api > Settings > Custom Domains > Add `api.filefree.tax`. Render handles TLS automatically.

---

## Previous Plans: Status Reconciliation

### FileFree Business Review plan -- COMPLETE

All 13 todos are done. `start-sprint-0` was marked "in_progress" but Sprint 0 infra tasks (Hetzner, Render, Neon, Vercel, DNS) are now complete.

### Persona Review + Hetzner plan -- COMPLETE (stale status in file)

All 4 todos were completed during the PR #3 fixes session:

- Stale doc paths fixed in 4 persona files
- Hetzner pricing updated to EUR 5.49
- `infra/hetzner/` created with compose.yaml, env.example, setup.sh, README.md
- D20 added to docs/KNOWLEDGE.md

---

## Infrastructure Scorecard


| Service           | Status     | URL                                                               | Notes                                                                     |
| ----------------- | ---------- | ----------------------------------------------------------------- | ------------------------------------------------------------------------- |
| Vercel (frontend) | LIVE       | filefree.tax -> [www.filefree.tax](http://www.filefree.tax) (200) | Placeholder page deployed. Update DNS per Vercel recommendation.          |
| Render (API)      | LIVE       | filefree-api.onrender.com/health (200)                            | Free tier. Custom domain `api.filefree.tax` not registered on Render yet. |
| Neon (DB)         | WIRED      | Connection string set on Render                                   | No tables yet -- needs Alembic setup.                                     |
| Hetzner (ops)     | RUNNING    | 204.168.147.100                                                   | Server exists. Not bootstrapped yet -- no Docker, no Postiz, no n8n.      |
| GitHub            | CONNECTED  | sankalp404/fileFree                                               | Auto-deploy on push to main for both Vercel and Render.                   |
| Notion            | CONFIGURED | MCP connected                                                     | FileFree HQ, Partnership Pipeline, Sprint 0 Tasks boards exist.           |
| Spaceship (DNS)   | CONFIGURED | 6 records set                                                     | All propagated. Vercel recommends updated values.                         |


---

## Multi-Persona Review

### Engineering

- Project structure is clean: `api/`, `web/`, `docs/`, `infra/`
- **Gap: Empty directories**: `api/alembic/` and `api/tax-data/` are empty -- should be scaffolded (Alembic init) or removed to avoid confusion
- **Gap: No CI/CD**: No GitHub Actions workflow. Tests only run locally via `make test`
- **Gap: No `.env` validation**: No startup check that required env vars exist
- CORS, Makefile, Docker Compose, pyproject.toml -- all properly configured

### QA

- Only 1 test exists: `api/tests/test_health.py`
- No pre-commit hooks (ruff, eslint)
- No integration test infrastructure
- Acceptable for current stage -- tests grow with code

### UX

- Frontend is a bare placeholder (`web/src/app/page.tsx` -- inline styles, no design system)
- No Tailwind CSS installed (listed in `.cursorrules` as required)
- No shadcn/ui initialized
- No `globals.css` with dark theme variables
- **This is the biggest gap** -- the landing page (Task 0.4) needs Tailwind + shadcn first (Task 0.2)

### Legal

- No privacy policy, ToS, or disclaimers exist yet
- Sprint 0 task B.3 covers this
- Not blocking until landing page goes live

### Growth / Social

- Postiz not deployed on Hetzner (server exists but not bootstrapped)
- n8n not deployed
- No social media content created
- No blog/SEO content
- Blocked by Hetzner bootstrap

### Partnerships

- PARTNERSHIPS.md, PITCH_PACKAGE.md, partnerships.mdc persona all exist
- Notion Partnership Pipeline populated with 10 partners
- No affiliate applications submitted yet (Sprint 0 task B.8)

### CFO

- Infra cost: ~$32.50/mo ($20 Vercel Pro when upgraded + $7 Render Starter when billing added + EUR 5.49 Hetzner). Currently $5.99/mo (only Hetzner is paid; Vercel Hobby and Render free tier).
- Unit economics documented and validated

### Strategy

- All doc paths fixed, pricing updated, co-founder structure in place
- Notion workspace operational
- Decision log current through D20

---

## Prioritized Forward Path

### Immediate (do now)

1. **Fix DNS + custom domains**: Update Vercel DNS values in Spaceship, add `api.filefree.tax` on Render dashboard
2. **Bootstrap Hetzner**: Run `setup.sh` to install Docker + Caddy, then deploy Postiz + n8n
3. **Clean up empty dirs**: Either scaffold Alembic in `api/alembic/` or remove the empty directory

### Sprint 1 (next coding sprint)

1. **Task 0.2 -- Frontend foundation**: Install Tailwind CSS + shadcn/ui in `web/`, set up dark theme, create layout components
2. **Task 0.3 -- Backend foundation**: Initialize Alembic, create User model, implement auth (JWT + cookies), connect to Neon
3. **Task 0.4 -- Landing page**: Build the filefree.tax landing page with waitlist signup
4. **CI/CD**: Add GitHub Actions for tests + linting on PR

### Sprint 0 business ops (parallel)

1. **EFIN application** (45-day lead time -- submit ASAP)
2. **Affiliate applications** (Marcus, Wealthfront, Betterment via Impact/CJ)
3. **Legal drafts v1** (privacy policy, ToS using legal.mdc persona)

---

## Docs to Update

- [docs/KNOWLEDGE.md](docs/KNOWLEDGE.md): Add D21 documenting infrastructure completion (Render live, Neon wired, Vercel deployed, DNS configured, Hetzner provisioned)
- [docs/TASKS.md](docs/TASKS.md): Mark Sprint 0 infra tasks as complete (Docker dev env, Render deploy, Neon setup, Vercel deploy, DNS, Hetzner provisioning)
- Remove or scaffold empty `api/alembic/` and `api/tax-data/` directories

