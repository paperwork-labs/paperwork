---
name: Unify compose + Ladle + UI lib
overview: Make `infra/` the single source of truth for Docker compose, fix Ladle by adding a dedicated Ladle service in `infra/compose.dev.yaml`, and standardize `frontend/src/components/` into a coherent design-system surfaced in Ladle.
todos:
  - id: add-ladle-service
    content: Add a dedicated Ladle service/profile to infra/compose.dev.yaml with proper host binding and port 61000 exposure.
    status: completed
  - id: remove-root-compose
    content: Delete/deprecate root docker-compose.yml and update Makefile/docs to use infra/compose.dev.yaml + infra/env.dev.
    status: completed
  - id: standardize-components
    content: Standardize frontend/src/components (single table stack, fix KPIStatCard v2 refs, decide DataTable wrapper) and add/expand Ladle stories for the reusable UI primitives.
    status: completed
  - id: verify-ladle-and-dev
    content: Verify Ladle shows all expected stories and dev stack still works under the infra compose entrypoint.
    status: completed
---

# Unify Docker compose + standardize component library

## Decisions locked in

- **Canonical compose**: keep `infra/compose.dev.yaml` and `infra/compose.test.yaml`; remove/deprecate root `docker-compose.yml`.
- **Ladle in Docker**: run Ladle via a **separate compose service** (so Vite dev and Ladle can run simultaneously).

## 1) Make Ladle work with the canonical compose (infra)

- Update [`infra/compose.dev.yaml`](/Users/sankalpsharma/development/quantmatrix/infra/compose.dev.yaml):
- Add a new service `ladle` (or `frontend_ladle`) built from `Dockerfile.frontend`, mounting `../frontend:/app`.
- Expose **`61000:61000`** on the host.
- Run `npm run ladle -- --host 0.0.0.0 --port 61000` (or ensure the script binds to `0.0.0.0`).
- Put it behind a profile like `ui` so it’s opt-in.

## 2) Remove the duplicate compose file at repo root

- Delete [`docker-compose.yml`](/Users/sankalpsharma/development/quantmatrix/docker-compose.yml) (or replace with a short README-style pointer file if you prefer not to delete; your preference was “delete stuff that’s not needed”, so default is delete).
- Update any documentation and developer entrypoints that still reference the root compose:
- Add/adjust a root `Makefile` to run `docker compose -f infra/compose.dev.yaml --env-file infra/env.dev …`.
- Update any docs that mention `docker compose up` without `-f infra/compose.dev.yaml`.

## 3) Standardize `frontend/src/components/` and surface it in Ladle

### Target structure

- **`frontend/src/components/ui/`**: reusable design-system building blocks.
- **`frontend/src/components/<feature>/`** (existing folders like `charts/`, `coverage/`, `auth/`, `layout/`): app/feature components.

### Consolidations/fixes

- Keep **one** table stack:
- `frontend/src/components/SortableTable.tsx` as the base table.
- `frontend/src/components/ui/Pagination.tsx` for paging.
- `frontend/src/components/ui/DataTable.tsx` can remain as a thin wrapper *or* be removed if it adds no value (we’ll decide after checking usages).
- Fix remaining Chakra v2-only components in `components/ui/`:
- `frontend/src/components/ui/KPIStatCard.tsx` currently uses v2 `Stat/StatNumber/StatArrow`; migrate to v3 `StatRoot/StatValueText/StatUpIndicator/StatDownIndicator`.

### Ladle coverage (hybrid approach)

- Ensure Ladle shows a curated set:
- Tables (`src/stories/Tables.stories.tsx`) + Pagination
- Loading states (`src/stories/LoadingStates.stories.tsx`)
- Form primitives: `ui/FormField`, `ui/AppCard`, `ui/EmptyState`, `ui/Page`, `ui/PageHeader`, `ui/Toolbar`
- KPI cards: `ui/KPIStatCard`
- (Optional) One or two “feature” components that are stable and reusable (e.g. `AccountFilterWrapper`), but skip highly app-specific chart wrappers unless you explicitly want them.

## 4) Verification

- Verify Ladle discovers stories (sidebar shows `DesignSystem/Tables`, `DesignSystem/LoadingStates`, etc.).
- Verify dev stack still comes up via `infra/compose.dev.yaml`.
```mermaid
graph TD
  infraComposeDev[infra/compose.dev.yaml] --> frontendVite[frontend(Vite:3000)]
  infraComposeDev --> ladleSvc[ladle:61000]
  infraComposeDev --> backend[backend:8000]
  infraComposeDev --> postgres[postgres:5432]
  infraComposeDev --> redis[redis:6379]
  ladleSvc --> stories[src/stories/*.stories.tsx]
  frontendVite --> appRoutes[src/pages/*]



```