---
name: Master Plan Refinement v2
overview: "Incorporate founder feedback on the stress test findings: reverse agent right-sizing into a full hierarchical org chart with governance protocol, expand FileFree tax form coverage for Jan 2027, add compliance monitoring agent, refine user acquisition strategy with budget constraints, strengthen legal/privacy documentation strategy, adjust model cost philosophy, update Founder 2 framing, research AI branding, and create a separate side projects evaluation doc."
todos:
  - id: agent-org-chart
    content: "Rewrite Section 6I: Replace right-sizing with full company org chart. Define all ~43 roles in a tree hierarchy with governance protocol (RACI + consensus + escalation). Research CrewAI/AutoGen/LangGraph patterns for multi-agent governance."
    status: pending
  - id: filefree-form-coverage
    content: "Expand Phase 7-8 scope: Aggressive Jan 2027 launch with 1040 + all major schedules (A, B, C, D, E basic, SE) + 1099-NEC + dependents + ALL 50 state returns. Year 2 adds depreciation, brokerage import, HSA, K-1. Update MeF ATS testing scope."
    status: pending
  - id: compliance-agent
    content: Add Compliance & Security Monitor agent to Section 6E. Add compliance status indicator to Mission Control (P4.4). Track insurance, data accuracy, legal doc freshness.
    status: pending
  - id: legal-liability-research
    content: Research liability exposure for AI tax filing and LLC formation. Compare Credit Karma/FreeTaxUSA/LegalZoom liability approaches. Expand attorney consultation questions. Add Legal Protection Checklist to Section 0C.
    status: pending
  - id: user-acquisition-refine
    content: "Refine Section 5K: Add bootstrapped growth case study (FreeTaxUSA, Credit Karma). Constrain ad budget to $100-300/mo. Add brand mission alignment strategy and viral mechanics."
    status: pending
  - id: partnership-docs-strategy
    content: "Add partnership documentation strategy: agent-produced doc packages per partner, legal doc freshness tracking, quarterly review cadence."
    status: pending
  - id: timeline-reframe
    content: "Reframe timeline: Remove '14-18 months realistic' language. Frame 10 months as feasible with agent workforce. Add context-switching mitigation strategy."
    status: pending
  - id: spend-tracking-and-model-cost
    content: Add Monthly Actuals section to FINANCIALS.MD with category tracking (infra, AI/ML, domains, SaaS, legal, marketing). Make EA responsible for logging expenses. Add quality-first model cost philosophy to Section 0E and AI_MODEL_REGISTRY.md. Expand P4.11 spec with spend overview panel.
    status: pending
  - id: data-accuracy-dashboard
    content: Add Data Integrity Dashboard spec to P4.4 Mission Control. Per-state freshness badges. Increase state data validator frequency to daily for volatile states.
    status: pending
  - id: founder2-framing-and-branding
    content: Remove '2-3 hrs/wk' from Founder 2 references. Research AI branding in financial services (help or hurt trust?). Document findings and add recommendation.
    status: pending
  - id: side-projects-doc
    content: "Create docs/FOUNDER_SIDE_PROJECTS.md: Evaluate axiomfolio, replyrunner, jointly, fittingroom. Market assessment, competitive landscape, trinket-vs-product decision, GO/NO-GO for each."
    status: pending
  - id: slack-comm-hub
    content: "Add Section 14 to master plan: Slack as company communication hub (channel structure, two-way agent interaction via n8n, Slack MCP in Cursor). Professional email aliases on Google Workspace (filefree.ai, launchfree.ai, sankalpsharma.com). Outbound email flow with agent drafts and founder approval. Stress tested."
    status: pending
isProject: false
---

# Master Plan Refinement v2: Founder Feedback on Stress Test

The stress test was implemented in the previous turn. The founder has now reviewed it and has specific pushback and additions. This plan addresses each item.

---

## 1. Reverse Agent Right-Sizing -> Full Company Org Chart (Section 6I rewrite)

**Founder's position**: Agents are employees. Staff the full company from day one. Build a hierarchical governance structure where changes require consensus from relevant bottom-level personas before implementation, with escalation up the chain.

**What changes in [docs/VENTURE_MASTER_PLAN.md](docs/VENTURE_MASTER_PLAN.md)**:

- Replace Section 6I (Right-Sized) with a new **Company Org Chart** model
- Define all ~43 agents as roles in a tree structure, even if some are stubs initially
- Add a **Governance Protocol** section inspired by mature org design (RACI matrix + consensus mechanism):
  - Every proposed change is reviewed by relevant leaf-node personas
  - All must "approve" (no objections in their domain) for auto-implementation
  - Any objection escalates to the parent node (e.g., QA objects -> escalate to Engineering Lead level)
  - Root node (Founder) is final arbiter
- Remove "build triggers" language; instead mark agents as **Active** vs **Standby** (role defined, system prompt ready, activated when workload appears)
- Keep the overlap resolution (6I-1) and EA split (6I-2) since the founder didn't push back on those

**Research needed**: Look at established multi-agent governance frameworks (CrewAI hierarchical process, AutoGen group chat with manager, LangGraph supervisor patterns) to inform the approval chain design.

## 2. Expand FileFree Tax Form Coverage for Jan 2027 (Section 7, Phase 7-8)

**Founder's point**: If we cross-sell LLCs to tax filers and vice versa, FileFree can't just do basic W-2 returns. LaunchFree users have LLC income (1099s, Schedule C). Cross-sell breaks if FileFree can't handle their returns.

**What changes**:

- Update Phase 7 (FileFree Season Prep) to include ALL major forms for Jan 2027 launch
- No hard technical blockers: forms are IRS-published specs, calculations are deterministic, MeF XML schemas are documented. It's spec + code + ATS testing. Agents handle the bulk of generation.
- Update the MeF ATS testing scope (Phase 8) to include additional mandatory test scenarios for each form
- Add a "Form Coverage Roadmap" subsection to Section 7:

**Jan 2027 launch (handle ~80%+ of filers, ALL 50 states):**

- 1040 (base return)
- Schedule 1 (additional income/adjustments)
- Schedule A (itemized deductions)
- Schedule B (interest/dividends over $1,500)
- Schedule C (business income -- CRITICAL for LaunchFree cross-sell)
- Schedule D (capital gains -- user enters cost basis manually, no brokerage import Year 1)
- Schedule SE (self-employment tax -- auto-calculated when Schedule C is present)
- Schedule E (basic rental income/expenses -- no depreciation Year 1)
- 1099-NEC / 1099-MISC support (freelancers, LLC owners)
- Dependent support + Child Tax Credit + EITC
- **ALL 50 state returns** -- the state tax engine from Phase 2 already covers all 50 states. The marginal effort of state #11 through #50 is zero when the engine is JSON-driven.

**Year 1 simplifications (honest, not limitations):**

- Schedule D: manual cost basis entry (no 1099-B brokerage import). Covers ~90% of simple capital gains.
- Schedule E: basic rental income/expenses (no depreciation calculations, no passive activity loss rules).
- No AMT (Form 6251), no foreign income (Form 2555), no estate/trust (K-1 from 1041).

**Year 2 additions:**

- Full Schedule E with depreciation
- Brokerage import (1099-B) for Schedule D
- Form 8889 (HSA), Form 8863 (education credits)
- K-1 passthrough income (partnerships, S-corps)

**Why this is feasible**: Each form is a Pydantic schema + calculation function + MeF XML mapping + PDF section. The tax-domain and engineering agents can spec and generate these systematically. The ATS testing scenarios are published by the IRS annually. Agents pre-generate all test cases before the October window.

## 3. Add Compliance & Security Monitoring Agent

**What changes**:

- Add a new agent to Section 6E: **Compliance & Security Monitor** (n8n cron, daily)
- Responsibilities: cyber insurance renewal tracking, breach response plan status, data accuracy verification status, certificate expiration monitoring
- Add to command center (Section 3): a **Compliance Status** indicator on Mission Control showing green/yellow/red for data accuracy, insurance status, legal doc currency
- This agent rolls up status from:
  - State Data Validator (data freshness)
  - Legal doc currency (privacy policy, ToS last updated dates)
  - Insurance/certificate status (manual input until automated)

## 4. Attorney/Legal Liability Research

**What to add** to Section 0C and 0G:

- Research on liability exposure for AI-assisted tax filing and LLC formation services specifically in CA
- Key liability areas to document: professional liability (E&O), data breach liability (state notification laws), product liability (incorrect calculations), FTC enforcement exposure
- Comparative analysis: how do Credit Karma, FreeTaxUSA, LegalZoom, ZenBusiness handle liability? What disclaimers do they use? What insurance do they carry?
- The attorney consultation questions should be expanded beyond UPL and RA to include: liability caps in ToS, arbitration clauses, class action waivers, indemnification language
- Add a **Legal Protection Checklist** to Section 0C that the Legal persona enforces

## 5. User Acquisition: Budget-Conscious Case Study + Brand Mission

**What to refine** in Section 5K:

- Add a **"Bootstrapped Growth" Case Study** section analyzing how FreeTaxUSA (bootstrapped since 2001, ~150 employees, est. $50-100M revenue) and Credit Karma (free product, referral revenue) grew organically
- Constrain the ad budget to **$100-300/mo maximum** until revenue covers it (not $200-500)
- Add a **Brand Mission Alignment** strategy: the ads and social content should create brand recognition and a sense of belonging/purpose, not just drive clicks. The mission: "Financial services should be free and accessible to everyone. Period."
- Social + ads synergy: organic content proves what resonates, Spark Ads amplify only proven winners, never spend on unvalidated creative
- Add specific viral mechanics: duet/stitch hooks, "tag someone who needs this", LLC journey series

## 6. Partnership Documentation Strategy

**What to add** (new subsection in Section 6 or as a dedicated doc strategy):

- Every partnership gets a detailed doc package prepared by agents:
  - Partnership brief (market data, competitive positioning)
  - Financial projections (specific to partner type)
  - Legal/compliance checklist (FTC, CAN-SPAM, state-specific)
  - Integration spec (API, webhook, tracking)
- The Legal and Partnerships personas collaborate to produce bullet-proof documentation
- Privacy policy and ToS are living documents that agents review quarterly for currency
- Add this as a responsibility of the EA: maintain a "legal document freshness" tracker

## 7. Timeline: Keep Ambitious, Acknowledge Agent Leverage

**What changes**:

- Remove the "14-18 months realistic" language from the timeline section
- Replace with: "10 months with full agent workforce. Human is the bottleneck, not the work. Agents handle research, documentation, code generation, testing, content. Founder handles decisions, code review, legal filings, and partner relationships."
- Keep the hard deadlines (October ATS, January launch) but frame the parallel tracks as feasible with agents rather than unrealistic
- Add a "Context-Switching Mitigation" note: agents don't context-switch. The founder does. Minimize by batching: mornings = code, afternoons = operations/content/legal

## 8. Spend Tracking Enhancement (Founder's Personal CFO)

The founder isn't tracking Cursor, API, domain, and subscription costs today. This needs to be systematized.

**What changes in [docs/FINANCIALS.MD](docs/FINANCIALS.MD)**:

- Add a **Monthly Actuals** section: a running log of actual expenses by month (not just projections)
- Categories: Infrastructure (Render, Hetzner, Vercel), AI/ML (OpenAI, Anthropic, Cursor Pro), Domains, SaaS (Google Workspace, ElevenLabs), Legal (insurance, filings), Marketing (Spark Ads)
- The EA agent's responsibility: when the founder mentions a purchase or subscription in any conversation, the EA logs it to FINANCIALS.MD monthly actuals
- Quarterly: the CFO agent produces a spend analysis (are we trending up? what can be optimized? are free tiers about to be exceeded?)

**What changes in the command center**:

- P4.11 (Revenue Intelligence) expands to include a **Spend Overview** panel: monthly burn chart, category breakdown, free tier usage meters (Neon, Upstash, Vercel, GCP Cloud Vision)
- This is Tier 3 (build when revenue flows), but the data collection (FINANCIALS.MD actuals) starts immediately

**Model cost philosophy** (update Section 0E and AI_MODEL_REGISTRY.md):

- Add "Quality-First Principle": use the best available model for each task. Only downgrade when testing proves equivalent quality.
- Add willingness to use GPT-5 (when available) for high-stakes tasks (tax calculations, legal document review)
- Track monthly AI API spend as a line item in FINANCIALS.MD

## 9. Legal Data 100% Accuracy: Command Center Status

- Add to P4.4 (Mission Control): a **Data Integrity Dashboard** panel showing:
  - 50-state formation data: last verified date per state, freshness badge (green <30d, yellow 30-90d, red >90d)
  - 50-state tax data: same freshness tracking
  - Overall status: "100% Data Valid" or "X states need verification"
- State Data Validator agent (n8n) feeds this panel
- Add to Section 3B: the validator should run **daily** (not monthly) for states where data was recently changed by a legislature, weekly for stable states

## 10. Founder 2 Framing

- Change "partnerships co-founder (2-3 hrs/wk)" to "partnerships co-founder" throughout the plan
- Remove the time-commitment note -- it's internal knowledge, not a plan constraint. The plan should assume Founder 2 delivers outcomes, not hours.

## 11. AI/Education Branding Research

- Add a new subsection to Section 0C or brand.mdc: **"AI-Powered" Branding Decision**
- Research: Does showing "AI-powered" in branding help or hurt trust for financial services?
  - Pro: differentiator, modern, signals innovation
  - Con: financial services customers may distrust AI with their money/taxes
  - Comp study: Credit Karma doesn't say "AI" prominently. TurboTax started using "AI" in 2024. LegalZoom avoids it.
- Recommendation to research and document, then decide

## 12. Model Cost Philosophy Update

- Update Section 0E and [docs/AI_MODEL_REGISTRY.md](docs/AI_MODEL_REGISTRY.md): add a "Quality-First Principle"
- "Use the best available model for each task. Only downgrade to a cheaper model when testing proves equivalent quality. The cost difference between GPT-4o-mini and GPT-4o is ~10x but the quality gap on complex tasks justifies the spend."
- Add willingness to use GPT-5 (when available) for high-stakes tasks (tax calculations, legal document review, operating agreement explanation)

## 14. Agent Communication Hub: Slack + Email Aliases

The plan defines what agents DO but doesn't fully spec how the founder communicates with them beyond Cursor chat sessions. This section adds the company-wide communication infrastructure.

### 14A. Slack as Company Hub

**Platform**: Slack (founder's existing free workspace: sharma'skarma). Free tier is sufficient -- 90-day history is fine because source of truth is git docs, not chat. Single n8n Slack bot credential handles all agent workflows (1 of 10 allowed integrations).

**Channel Structure**:

- `#ops-alerts` -- CRITICAL/WARNING alerts from Infra Health Monitor. Founder acts immediately.
- `#daily-briefing` -- EA Ops Monitor posts 7am daily briefing. Founder reads + replies with priorities.
- `#decisions` -- EA logs decisions from all conversations. Persistent record (also in KNOWLEDGE.md).
- `#social-content` -- Social content agents post drafts. Founder approves/rejects in thread.
- `#legal-review` -- Legal persona posts compliance reviews, content gate results. Founder signs off.
- `#agent-reports` -- Weekly reports from Analytics, Competitive Intel, CFO analysis land here.
- `#support` -- L1/L2 support bot posts escalations. Founder responds.
- `#partnerships` -- Partnership agent posts outreach drafts, deal summaries. Founder 2 reviews.
- `#dev` -- Engineering-related CI/CD notifications, deploy status, test results.
- `#general` -- Catch-all for anything that doesn't fit above.

**Two-Way Interaction Flow**:

```
Agent posts to Slack channel (via n8n HTTP Request -> Slack API)
    |
    v
Founder reads, replies in thread
    |
    v
n8n webhook triggers on new thread reply -> routes to relevant workflow
    |
    v
Agent processes reply (e.g., "approved" -> social bot publishes to Postiz)
                       (e.g., "revise tone" -> agent redrafts, posts new version)
                       (e.g., "declined" -> agent logs and moves on)
```

**Slack MCP in Cursor**: Install Slack MCP server so that during coding sessions, the founder can:

- Read latest messages from any channel without leaving the IDE
- Post decisions directly to `#decisions`
- Ask the EA "what did the social bot post today?" and get Slack context

**What stays on Cursor vs Slack**:

- **Cursor**: Interactive coding conversations with personas (engineering, legal, tax-domain). Real-time decision-making and code generation. Ephemeral.
- **Slack**: Persistent company communication. Agent reports, approvals, alerts, briefings. Two-way async.
- **Google Drive**: Formal document output (briefings, one-pagers, PRDs, reports).
- **Command Center**: Visual dashboards and monitoring. No conversation -- just data.

### 14B. Professional Email Aliases (Google Workspace)

Create functional/department aliases on the existing Google Workspace plan ($0 additional cost). Agents are departments, not people -- nobody external needs to know the legal team is an AI.

**FileFree aliases**:

- `hello@filefree.ai` -- public contact, landing page
- `support@filefree.ai` -- user support (eventually agent-handled via Slack approval flow)
- `legal@filefree.ai` -- compliance correspondence, attorney comms, IRS correspondence
- `partnerships@filefree.ai` -- partner outreach (Founder 2 uses this)
- `security@filefree.ai` -- breach notification contact (required by cyber insurance), bug reports

**LaunchFree aliases**:

- `hello@launchfree.ai` -- public contact
- `support@launchfree.ai` -- user support
- `legal@launchfree.ai` -- compliance, state agency correspondence

**Venture aliases** (on sankalpsharma.com):

- `ops@sankalpsharma.com` -- internal ops, vendor communications
- `founder@sankalpsharma.com` -- founder's professional identity

**Routing**: All aliases route to the founder's primary inbox. n8n can monitor specific aliases via Gmail API and post incoming emails to the relevant Slack channel for agent processing.

**Outbound email flow (agent-assisted)**:

```
Partner emails partnerships@filefree.ai
    |
    v
Gmail API -> n8n detects new email -> posts to #partnerships in Slack
    |
    v
Partnerships agent drafts reply in Slack thread
    |
    v
Founder reviews, edits if needed, replies "send"
    |
    v
n8n sends reply FROM partnerships@filefree.ai via Gmail API
```

Over time, certain templated responses (password resets, filing confirmations, support auto-replies) can auto-send without founder approval.

### 14C. Stress Test: Communication Architecture Risks

- **Slack free tier 90-day limit**: Mitigated -- all decisions logged to git (KNOWLEDGE.md), all reports saved to GDrive. Slack is transient communication, not archive.
- **Single point of failure (n8n Slack bot)**: If n8n goes down, agents can't post to Slack. Mitigation: Infra Health Monitor checks n8n health; if n8n is down, fallback email alerts via Render/Vercel native alerting.
- **Founder overwhelm (too many channels)**: Start with 5 channels (#ops-alerts, #daily-briefing, #social-content, #decisions, #general). Add others only when workflow volume justifies it.
- **Agent reply parsing**: n8n needs to parse founder's Slack thread replies ("approved", "revise", "declined"). Use GPT-4o-mini to classify intent from free-text replies rather than requiring exact keywords. Cost: negligible (~$0.001/classification).
- **Security**: Slack bot token is a credential with write access to all channels. Store in n8n credentials vault (encrypted). Add to CREDENTIALS.md. Rotate quarterly.

## 13. Side Projects Evaluation Doc

- Create [docs/FOUNDER_SIDE_PROJECTS.md](docs/FOUNDER_SIDE_PROJECTS.md) evaluating:
  - **axiomfolio**: Portfolio intelligence platform. Personal tool, not a business. Keep separate.
  - **replyrunner**: Gmail assistant. Could become an agent (EA email management) or a trinket. Evaluate: is there a market for a standalone Gmail organizer, or is this better as an internal tool?
  - **jointly**: Shared finance management for couples. Evaluate against Origin, Honeydue, Zeta. Could be a full product or a trinket calculator. Wife is a built-in beta tester.
  - **fittingroom**: Virtual try-on. Separate market entirely (fashion tech). Deep tech (computer vision, body modeling). Not a trinket -- this is a venture in itself. Park as a "future idea" with market research notes.
- Each project gets: market assessment, competitive landscape, build-vs-buy analysis, trinket-vs-product-vs-internal decision, and a GO/NO-GO recommendation

