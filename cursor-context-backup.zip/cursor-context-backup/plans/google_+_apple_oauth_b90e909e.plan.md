---
name: Google + Apple OAuth
overview: Implement Google One-Tap and Apple Sign In per decision D22. Backend validates social tokens server-side, creates Redis sessions, sets HTTP-only cookies. Frontend adds social login buttons to register and login pages.
todos:
  - id: google-auth-dep
    content: Add google-auth to requirements.txt
    status: completed
  - id: oauth-service
    content: Create oauth_service.py with verify_google_token and verify_apple_token
    status: completed
  - id: social-login
    content: Add social_login() to auth_service.py (find-or-create user by provider)
    status: completed
  - id: oauth-routes
    content: Add POST /auth/google and POST /auth/apple endpoints to auth router
    status: completed
  - id: oauth-tests
    content: Write tests for OAuth verification + social login (mocked tokens, idempotent creation, account linking)
    status: completed
  - id: google-component
    content: Build GoogleSignIn button component with Google Identity Services SDK
    status: completed
  - id: apple-component
    content: Build AppleSignIn button component with Apple JS SDK
    status: completed
  - id: auth-pages-update
    content: Add social buttons + 'or' divider to register and login pages
    status: completed
  - id: auth-hooks
    content: Add useGoogleAuth and useAppleAuth mutations to use-auth.ts
    status: completed
isProject: false
---

# Google + Apple OAuth Sign In

## What Already Exists

- User model has `auth_provider` (LOCAL/GOOGLE/APPLE), `auth_provider_id`, nullable `password_hash` -- all ready
- Config ([api/app/config.py](api/app/config.py)) has `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `APPLE_CLIENT_ID`, `APPLE_TEAM_ID`, `APPLE_KEY_ID`, `APPLE_PRIVATE_KEY_PATH` -- all empty strings (disabled in dev)
- Auth service ([api/app/services/auth_service.py](api/app/services/auth_service.py)) handles `register()` and `login()` for LOCAL only
- Frontend auth pages ([web/src/app/auth/register/page.tsx](web/src/app/auth/register/page.tsx), [web/src/app/auth/login/page.tsx](web/src/app/auth/login/page.tsx)) have email/password only, no social buttons

## Architecture

```mermaid
sequenceDiagram
    participant Browser
    participant NextJS as Next.js Frontend
    participant FastAPI as FastAPI Backend
    participant Google as Google OAuth
    participant Apple as Apple OAuth

    Browser->>NextJS: Click "Sign in with Google"
    NextJS->>Google: Google One-Tap / redirect
    Google-->>Browser: ID token (JWT)
    Browser->>FastAPI: POST /auth/google {id_token}
    FastAPI->>Google: Verify token (google.oauth2.id_token)
    Google-->>FastAPI: {email, name, sub}
    FastAPI->>FastAPI: Find or create user (auth_provider=google)
    FastAPI-->>Browser: Set session cookie + CSRF token
```

## Backend Changes

### 1. New dependency: `google-auth`

Add `google-auth` to [api/requirements.txt](api/requirements.txt) -- this provides `google.oauth2.id_token.verify_oauth2_token()` for server-side Google ID token verification. No new dependency needed for Apple -- we verify Apple JWTs manually using `python-jose` (already installed).

### 2. OAuth service ([api/app/services/oauth_service.py](api/app/services/oauth_service.py) -- new)

Two functions:

- `verify_google_token(id_token: str) -> dict` -- calls `google.oauth2.id_token.verify_oauth2_token()` with `settings.GOOGLE_CLIENT_ID` as audience. Returns `{email, name, sub}`.
- `verify_apple_token(id_token: str) -> dict` -- fetches Apple's public JWKS from `https://appleid.apple.com/auth/keys`, validates JWT signature and claims (`iss`, `aud`, `exp`). Returns `{email, name, sub}`.

### 3. Auth service additions ([api/app/services/auth_service.py](api/app/services/auth_service.py))

New function `social_login(db, redis, provider, email, name, provider_id) -> (User, session_token, csrf_token)`:

- Look up user by `email`
- If exists: verify `auth_provider` matches (or is LOCAL -- allow linking). Update `auth_provider_id` if needed
- If not exists: create new user with `auth_provider=GOOGLE/APPLE`, `email_verified=True`, `password_hash=None`
- Create Redis session + CSRF token (reuse existing logic)

### 4. Auth router additions ([api/app/routers/auth.py](api/app/routers/auth.py))

Two new endpoints:

- `POST /auth/google` -- accepts `{id_token}`, calls `verify_google_token()`, then `social_login()`, returns session cookie
- `POST /auth/apple` -- accepts `{id_token, user?}` (Apple sends user info only on first auth), calls `verify_apple_token()`, then `social_login()`
- Both rate-limited at 5/minute like existing auth endpoints
- Both are unauthenticated endpoints (add to security rules allowlist)

### 5. Tests

- Unit tests for `verify_google_token` and `verify_apple_token` (mocked HTTP)
- Integration test: `POST /auth/google` with a mocked token verifier -> user created with `auth_provider=google`
- Integration test: repeat call -> same user returned (idempotent)
- Integration test: `POST /auth/apple` with mocked verifier
- Test: user registered via email, then logs in via Google with same email -> account linked

## Frontend Changes

### 6. Google Sign In button component ([web/src/components/auth/google-sign-in.tsx](web/src/components/auth/google-sign-in.tsx) -- new)

- Load Google Identity Services library (`accounts.google.com/gsi/client`) via `<Script>` tag
- Render the Google One-Tap button using `google.accounts.id.renderButton()`
- On success callback: POST the `credential` (ID token) to `/api/v1/auth/google`
- Update Zustand auth store with user + CSRF token
- Redirect to `/file`

### 7. Apple Sign In button component ([web/src/components/auth/apple-sign-in.tsx](web/src/components/auth/apple-sign-in.tsx) -- new)

- Load Apple JS SDK (`appleid.cdn-apple.com`)
- Configure `AppleID.auth.init()` with client ID and redirect URI
- On success: POST the `id_token` to `/api/v1/auth/apple`
- Same session/redirect flow as Google

### 8. Update register + login pages

Add to both [register/page.tsx](web/src/app/auth/register/page.tsx) and [login/page.tsx](web/src/app/auth/login/page.tsx):

- Google button above the email form
- Apple button below Google
- "or" divider between social buttons and email form
- Per PRODUCT_SPEC: social buttons go above the email field

### 9. Auth hooks ([web/src/hooks/use-auth.ts](web/src/hooks/use-auth.ts))

Add `useGoogleAuth()` and `useAppleAuth()` mutations that POST to `/auth/google` and `/auth/apple` respectively, then update the Zustand store.

## Dev Experience

- When `GOOGLE_CLIENT_ID` is empty (dev default), Google button renders but shows a "Google Sign In unavailable in dev" toast on click
- When `APPLE_CLIENT_ID` is empty, same pattern for Apple
- No GCP/Apple Developer account needed for local development
