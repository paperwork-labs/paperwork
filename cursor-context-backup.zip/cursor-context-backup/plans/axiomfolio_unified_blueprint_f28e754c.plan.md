---
name: AxiomFolio Unified Blueprint
overview: "Unified plan merging the brokerage sync fix (immediate next PR) with the master blueprint (Sections 2-3). Section 1 (Foundation Polish) was already shipped in PR #188."
todos:
  - id: sync-fix-celery-queue
    content: "Section 1.5: Remove task_routes from celery_app.py so sync tasks go to default queue"
    status: completed
  - id: sync-fix-asyncio-task
    content: "Section 1.5: Fix sync_account_task to use explicit event loop + add RUNNING status update at task start"
    status: completed
  - id: sync-fix-api-status
    content: "Section 1.5: Fix RUNNING->QUEUED overwrite in account_management.py sync endpoint"
    status: completed
  - id: sync-fix-newrelic-dev
    content: "Section 1.5: Remove newrelic-admin wrapper from celery_worker command in compose.dev.yaml"
    status: completed
  - id: sync-cleanup-db
    content: "Section 1.5: Delete duplicate broker accounts (ids 16, 17) and reset stuck QUEUED statuses"
    status: completed
  - id: sync-add-credentials
    content: "Section 1.5: Prompt user to add TT and IBKR credentials to infra/env.dev"
    status: completed
  - id: sync-rebuild-verify
    content: "Section 1.5: Rebuild celery worker, trigger sync, verify positions land in DB"
    status: in_progress
  - id: s2-category-rule-model
    content: "Section 2: Add CategoryRule model + Alembic migration; build CategoryEngine service with presets"
    status: pending
  - id: s2-category-api
    content: "Section 2: Add API endpoints for presets, rules CRUD, drift, rebalance-preview, auto-categorize"
    status: pending
  - id: s2-strategy-enums
    content: "Section 2: Add PAPER_TRADING/BACKTESTING to StrategyStatus; add TRIM/REBALANCE/ROTATE to SignalType"
    status: pending
  - id: s2-rule-evaluator
    content: "Section 2: Build RuleEvaluator service for JSON condition trees; wire as Celery task"
    status: pending
  - id: s2-order-engine
    content: "Section 2: Create Order model + OrderEngine, RiskGate, PaperExecutor, Reconciler services"
    status: pending
  - id: s2-categories-frontend
    content: "Section 2: Redesign Categories page (concentric rings, auto-organize, drift alerts, rebalance)"
    status: pending
  - id: s2-strategy-frontend
    content: "Section 2: Build StrategyList + StrategyBuilder pages; Overview redesign; invisible sync UX"
    status: pending
  - id: s3-broker-apis
    content: "Section 3: IBKR/TastyTrade/Schwab order API integration + broker_executor routing"
    status: pending
  - id: s3-safety-polish
    content: "Section 3: Circuit breakers, kill switch, StrategyDetail, StrategyBacktest, Paper->Live toggle"
    status: pending
isProject: false
---

# AxiomFolio: Unified Blueprint

Merges the brokerage sync fix plan with the master blueprint. **Supersedes** both `fix_brokerage_sync_f86f61e4.plan.md` and `axiomfolio_master_blueprint_ee49d702.plan.md`.

## Status Overview

```mermaid
flowchart LR
    S1["Section 1: Foundation"] -->|"PR #188 MERGED"| S1done["DONE"]
    SyncFix["Section 1.5: Sync Fix"] -->|"NEXT PR"| S1done2["IN PROGRESS"]
    S2["Section 2: Categories + Strategy"] -->|"Future PR"| S2todo["PLANNED"]
    S3["Section 3: Live Execution"] -->|"Future PR"| S3todo["PLANNED"]
```



**Alembic note:** The app is in production. All schema changes use incremental Alembic migrations only.

## Architecture: The Three Pillars

```mermaid
flowchart TB
  subgraph pillar1 [Portfolio - READ ONLY]
    BrokerSync["Broker Sync"]
    Positions["Positions + Tax Lots"]
    Snapshots["Daily Snapshots"]
    Categories["Smart Categories"]
    BrokerSync --> Positions --> Snapshots
    Positions --> Categories
  end

  subgraph pillar2 [Intelligence - BRAIN]
    MarketData["Market Data Pipeline"]
    Indicators["Indicator Engine"]
    SignalGen["Signal Generator"]
    RuleEngine["Rule Engine"]
    MarketData --> Indicators --> SignalGen --> RuleEngine
  end

  subgraph pillar3 [Strategy - EXECUTION]
    StrategyDef["Strategy Definition"]
    Evaluator["Strategy Evaluator"]
    RiskGate["Risk Gate"]
    OrderEngine["Order Engine"]
    Reconciler["Trade Reconciler"]
    StrategyDef --> Evaluator
    RuleEngine --> Evaluator
    Evaluator --> RiskGate --> OrderEngine --> Reconciler
  end

  Categories -.->|"allocation drift"| RuleEngine
  Positions -.->|"current state"| Evaluator
  Reconciler -.->|"fills"| Positions
```



---

# SECTION 1 / PR #188: Foundation -- COMPLETED

Backend cleanup, sync lifecycle wiring, frontend DRY/type safety/UX, accessibility, docs overhaul. Shipped and merged.

---

# SECTION 1.5 / NEXT PR: Brokerage Sync Fix

**Problem:** Zero positions synced. Ever. All broker accounts show `QUEUED` or `NEVER_SYNCED`. Root cause is a Celery queue mismatch -- tasks are routed to a queue nobody consumes from.

```mermaid
flowchart LR
    API["POST /accounts/ID/sync"] -->|"sync_account_task.delay()"| Redis["Redis: account_sync queue"]
    Redis -.->|"NOBODY CONSUMING"| Void["Tasks pile up forever"]
    Worker["Celery Worker"] -->|"listens on"| Default["Redis: celery queue"]
```



### Fix 1: Celery Queue Mismatch (the blocker)

`[backend/tasks/celery_app.py](backend/tasks/celery_app.py)` line 19 routes `backend.tasks.account_sync.*` to queue `account_sync`, but the worker in `[infra/compose.dev.yaml](infra/compose.dev.yaml)` line 101 only listens on default `celery` queue.

**Fix:** Remove `task_routes` entirely from `celery_app.py` lines 18-20:

```python
# DELETE these 3 lines:
task_routes={
    "backend.tasks.account_sync.*": {"queue": "account_sync"},
},
```

### Fix 2: asyncio Event Loop in Celery Task

`[backend/tasks/account_sync.py](backend/tasks/account_sync.py)` uses `asyncio.run()` which can conflict with ib_insync's own event loop management. Use explicit `new_event_loop()` + `set_event_loop()` + `loop.close()` pattern instead:

```python
@shared_task(name="backend.tasks.account_sync.sync_account_task")
def sync_account_task(account_id: int, sync_type: str = "comprehensive") -> dict:
    session = SessionLocal()
    try:
        account = session.query(BrokerAccount).filter(BrokerAccount.id == account_id).first()
        if account:
            account.sync_status = SyncStatus.RUNNING
            account.last_sync_attempt = datetime.now()
            session.commit()

        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result = loop.run_until_complete(
                broker_sync_service.sync_account_async(
                    account_id=account_id, db=session, sync_type=sync_type
                )
            )
        finally:
            loop.close()
        return result if isinstance(result, dict) else {"status": "success", "data": result}
    except Exception as e:
        return {"status": "error", "error": str(e)}
    finally:
        session.close()
```

### Fix 3: Sync Status Tracking in API Endpoint

`[backend/api/routes/account_management.py](backend/api/routes/account_management.py)` lines 219-230: sets status to `RUNNING` then immediately overwrites to `QUEUED`. Fix: set `QUEUED` only (not `RUNNING` first), since the Celery task will set `RUNNING` when it actually starts executing.

### Fix 4: Suppress New Relic Noise in Dev

Celery worker logs are 100% New Relic license key errors. Remove `newrelic-admin run-program` wrapper from the celery_worker command in `[infra/compose.dev.yaml](infra/compose.dev.yaml)` line 101:

```yaml
# FROM:
command: bash -lc "newrelic-admin run-program celery -A backend.tasks.celery_app worker --loglevel=info"
# TO:
command: bash -lc "celery -A backend.tasks.celery_app worker --loglevel=info"
```

### Fix 5: Clean Up Duplicate Accounts

DB has 5 accounts with duplicates. Delete IDs 16 and 17 (placeholder dupes), reset stuck `QUEUED` statuses:

```sql
DELETE FROM broker_accounts WHERE id IN (16, 17);
UPDATE broker_accounts SET sync_status = 'NEVER_SYNCED', sync_error_message = NULL WHERE sync_status = 'QUEUED';
```

### Fix 6: Broker Credentials

User must add to `infra/env.dev` (gitignored):

- `TASTYTRADE_USERNAME` / `TASTYTRADE_PASSWORD`
- `IBKR_FLEX_TOKEN` / `IBKR_FLEX_QUERY_ID`

Read by `[backend/config.py](backend/config.py)` lines 28-40.

### Fix 7: Rebuild and Verify

1. Rebuild celery worker: `docker compose -f infra/compose.dev.yaml up -d --build celery_worker`
2. Verify worker queues: `docker exec axiomfolio-celery-worker celery -A backend.tasks.celery_app inspect active_queues`
3. Trigger sync from UI or API
4. Check celery logs: `docker logs -f axiomfolio-celery-worker`
5. Verify positions: `docker exec axiomfolio-postgres psql -U axiomfolio -d axiomfolio -c "SELECT count(*) FROM positions;"`

### Section 1.5 Files Summary

**Files to modify:**

- `[backend/tasks/celery_app.py](backend/tasks/celery_app.py)` -- remove task_routes
- `[backend/tasks/account_sync.py](backend/tasks/account_sync.py)` -- explicit event loop + status tracking
- `[backend/api/routes/account_management.py](backend/api/routes/account_management.py)` -- fix RUNNING/QUEUED overwrite
- `[infra/compose.dev.yaml](infra/compose.dev.yaml)` -- remove newrelic wrapper from celery_worker

**Manual steps:**

- Add credentials to `infra/env.dev`
- Clean up duplicate DB rows via psql
- Rebuild containers

---

# SECTION 2 / FUTURE PR: Smart Categories + Strategy Engine

Build the category auto-organization engine, the composable rule evaluator, the order engine with paper trading, and the frontend pages for categories and strategies.

## Checkpoint 2A: Category Engine (backend)

**New model -- `CategoryRule`** (add to `[backend/models/portfolio.py](backend/models/portfolio.py)`):

```python
class CategoryRule(Base):
    __tablename__ = "category_rules"
    id = Column(Integer, primary_key=True)
    category_id = Column(Integer, ForeignKey("categories.id"), nullable=False)
    rule_type = Column(String(30))   # SECTOR, INDUSTRY, MARKET_CAP, STAGE, SYMBOL_LIST, CUSTOM
    operator = Column(String(20))    # EQUALS, IN, BETWEEN, GREATER_THAN, LESS_THAN, REGEX
    field = Column(String(50))       # "sector", "industry", "market_cap", "stage_label", etc.
    value = Column(JSON)             # {"values": ["Technology"]} or {"min": 1e9, "max": 10e9}
    priority = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.now())
```

**New service -- `CategoryEngine`** (`backend/services/portfolio/category_engine.py`):

- `auto_categorize(user_id)`: Evaluate all active rules, assign positions
- `compute_drift(user_id)`: Compare actual vs target allocation
- `generate_rebalance_orders(user_id)`: Compute buy/sell proposals when drift exceeds threshold
- Hook into post-sync flow

**Built-in presets:** By Market Cap, By Sector, By Weinstein Stage, By Account Type, Custom rules with AND/OR logic.

**New endpoints** in `[portfolio_categories.py](backend/api/routes/portfolio_categories.py)`:

- `GET /categories/presets`, `POST /categories/presets/apply` + `/confirm`
- `GET /categories/drift`, `POST /categories/auto-categorize` + `/apply`
- `GET /categories/rebalance-preview`
- `POST/GET/DELETE /categories/{id}/rules`

## Checkpoint 2B: Strategy Engine (backend)

**Enum additions:** `PAPER_TRADING`, `BACKTESTING` to `StrategyStatus`; `TRIM`, `REBALANCE`, `ROTATE` to `SignalType`.

**Composable Rule Engine** -- `backend/services/strategies/rule_evaluator.py`: JSON condition tree schema for `Strategy.parameters`. `RuleEvaluator.evaluate(strategy, snapshot, position)` walks the tree, returns `list[Signal]`.

## Checkpoint 2C: Order Engine (backend)

**New model -- `Order`** at `backend/models/order.py` with full status lifecycle (PENDING -> SUBMITTED -> FILLED/CANCELLED/REJECTED/EXPIRED), idempotency keys, paper trade flag.

**New services** in `backend/services/trading/`:

- `order_engine.py`, `risk_gate.py`, `paper_executor.py`, `reconciler.py`

## Checkpoint 2D: Categories Frontend

Concentric rings allocation viz, auto-organize button, drift alerts, rebalance preview shopping list, inline rule builder.

## Checkpoint 2E: Strategy Frontend + Overview Redesign

StrategyList cards grid, StrategyBuilder sentence-based rule builder, Portfolio Overview hero number redesign, invisible sync UX.

---

# SECTION 3 / FUTURE PR: Live Execution + Polish

## Checkpoint 3A: Broker Order APIs

IBKR order API, TastyTrade order API, Schwab OAuth wiring, broker_executor.py routing, position reconciliation.

## Checkpoint 3B: Safety + Polish

Circuit breakers, kill switch, StrategyDetail page, StrategyBacktest page, Paper->Live toggle, mobile optimization, options lifecycle panel.

---

## Design Philosophy (reference for all sections)

### Portfolio: The Calm Dashboard

- One hero number (total value + daily P&L). Not 8 stat cards.
- Progressive disclosure: Overview -> Holdings -> Options -> Transactions
- Invisible sync. "Updated 2m ago" in footer.

### Strategy: The Control Room

- Rule builder as sentences with editable chips (Apple Shortcuts pattern)
- Timeline showing signals, orders, fills, P&L
- Paper -> Live toggle with confidence from data

### Categories: The Allocation Palette

- Concentric rings: inner = target, outer = actual
- Auto-organize: preview, confirm, done
- Rebalance as shopping list

### The "Trim RXRX" End-to-End Flow (reference)

```
1. Market data task -> recompute_indicators_universe()
2. MarketSnapshot for RXRX: td_sell_setup=9, stage_label="2C"
3. Strategy evaluation Celery task (post-indicator)
4. RuleEvaluator: trim_rules match -> Action: TRIM 25%
5. Signal: type=TRIM, symbol=RXRX, quantity_pct=25%
6. Order Factory: 100 shares -> SELL 25
7. Risk Gate: all checks PASS
8. Order: SELL 25 RXRX MARKET DAY, idempotency_key=hash(...)
9. Broker Router -> Paper Executor -> fill at current_price * 0.999
10. Reconciler: Position 100->75, Trade record created
11. Notification: "Trimmed 25 shares RXRX @ $X.XX (TD Sell 9)"
```

