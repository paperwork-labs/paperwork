---
name: ChakraV3+PRAutomation
overview: Fix the frontend blank screen by completing the Chakra UI v3 migration (starting with Divider export errors), then add repo automation to reduce Dependabot noise and provide a safe, repeatable cleanup workflow for existing PRs.
todos: []
---

# Plan: Fix

App Load (Chakra v3) + Clean Dependabot PR Noise

## 1) Fix the current blank screen (Chakra v3 export mismatch)

**Problem:** Browser error: `@chakra-ui/react` “does not provide an export named Divider” originating from `frontend/src/components/layout/DashboardLayout.tsx`.**Approach:** Stay on Chakra v3 and refactor v2-era imports/usages until Vite can compile and the UI renders.

### 1.1 Identify all v2-era Chakra imports that break in v3

- Scan `frontend/src/**` for Chakra components known to have changed (`Divider`, `extendTheme`, older icon patterns).
- Start at the current crash site: `frontend/src/components/layout/DashboardLayout.tsx`.

### 1.2 Replace `Divider` usage with a v3-safe equivalent

Two safe options (we’ll choose the least invasive once we confirm the code patterns):

- **Option A (preferred):** Introduce a small wrapper component `AppDivider` in `frontend/src/components/ui/AppDivider.tsx` implemented using `Box`/borders so it’s independent of Chakra’s `Divider` export.
- Replace all `import { Divider } from '@chakra-ui/react'` usages with this wrapper.
- **Option B:** Replace with Chakra v3’s equivalent if present (e.g., `Separator`) and update props accordingly.

Files already found referencing `Divider` (non-exhaustive from scan):

- `frontend/src/components/layout/DashboardLayout.tsx`
- `frontend/src/pages/*` (Dashboard, Admin pages, OptionsPortfolio, Transactions, etc.)

### 1.3 Fix other likely Chakra v2→v3 breakers

- `frontend/src/App.tsx` currently uses `extendTheme` (v2 pattern). We’ll migrate to Chakra v3 theme setup.
- Run the app and iterate until **no runtime import/export errors** remain.

### 1.4 Verify app loads

- Confirm `http://localhost:3000` renders.
- Confirm `/api` proxy calls succeed (e.g., `GET /api/v1/auth/health`).

## 2) Standardize env usage (without reading secret values into git)

We already confirmed your `.env` contains many real keys; we will:

- Keep `.env` untouched and out of git.
- Ensure `infra/env.dev` and `infra/env.test` remain the canonical runtime env files for Docker.
- Add a short note in `README.md` (or `docs/`) explaining:
- dev stack uses `infra/env.dev`
- tests use `infra/env.test` and **must** point to `postgres_test`

## 3) Reduce Dependabot PR spam + “clean existing PRs” workflow

### 3.1 Add Dependabot configuration to group/limit PRs

- Add `.github/dependabot.yml` with:
- grouped updates (npm + pip)
- weekly schedule
- PR limit
- ignore rules for noisy packages if needed

### 3.2 Add auto-merge policy (repo-side)

- Add a workflow that:
- labels Dependabot PRs
- enables auto-merge when CI passes
- blocks auto-merge for major version bumps by default

### 3.3 Clean existing Dependabot PRs

**Constraint:** I can’t directly close PRs on GitHub from this environment.Deliverable:

- Provide a **GitHub CLI script** you can run locally to close all open Dependabot PRs in bulk (with a clear comment), then let the new grouping rules repopulate cleanly.

## 4) “Merge all code changes” + PR flow

**Constraint:** I can’t push to GitHub or create PRs from this sandbox.Deliverable:

- Provide exact commands to:
- create a branch
- commit changes
- push
- open PR
- enable auto-merge

## Key files we will change

- `frontend/src/components/layout/DashboardLayout.tsx`
- `frontend/src/pages/*` (remove/replace `Divider` usages)
- `frontend/src/App.tsx` (Chakra v3 theme/provider setup)
- `.github/workflows/ci.yml` (already present)
- Add `.github/dependabot.yml`
- Add `.github/workflows/dependabot-automerge.yml` (or extend `ci.yml`)