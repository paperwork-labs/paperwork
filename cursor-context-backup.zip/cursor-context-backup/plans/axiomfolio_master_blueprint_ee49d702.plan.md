---
name: AxiomFolio Master Blueprint
overview: "Three-PR plan: PR1 = Foundation (backend cleanup, frontend DRY/UX, docs overhaul), PR2 = Smart Categories + Strategy Engine, PR3 = Order Execution + Live Trading."
todos:
  - id: s1-delete-dead-endpoints
    content: "PR1/1A: Delete 3 dead endpoints in portfolio.py (get_portfolio_summary, get_positions, get_portfolio_performance)"
    status: pending
  - id: s1-fix-n1-queries
    content: "PR1/1A: Fix N+1 queries in portfolio.py:258, portfolio_live.py:51, portfolio_options.py:104"
    status: pending
  - id: s1-async-sync-all
    content: "PR1/1B: Make /accounts/sync-all async via Celery; return batch task IDs"
    status: pending
  - id: s1-auto-sync-on-add
    content: "PR1/1B: Auto-enqueue Celery sync task after POST /accounts/add"
    status: pending
  - id: s1-reenable-strategies
    content: "PR1/1B: Fix atr_calculator import in strategy_manager.py; uncomment strategies route in main.py"
    status: pending
  - id: s1-extract-shared-utils
    content: "PR1/1C: Create frontend/src/utils/portfolio.ts; extract 7 duplicated functions from 5 page files"
    status: pending
  - id: s1-type-safety
    content: "PR1/1C: Remove 50+ 'as any' casts; add response interfaces to api.ts; type hooks and AccountContext"
    status: pending
  - id: s1-account-filter
    content: "PR1/1D: Migrate PortfolioOptions + PortfolioTransactions from local selectedAccount to global AccountContext"
    status: pending
  - id: s1-debounce
    content: "PR1/1D: Add useDebounce hook; apply to Transactions symbol search; add pagination"
    status: pending
  - id: s1-categories-errors
    content: "PR1/1D: Add useMutation with toasts to Categories mutations; add sync error feedback"
    status: pending
  - id: s1-skeletons
    content: "PR1/1D: Create StatCardSkeleton, TableSkeleton, ChartSkeleton; replace spinner-only states"
    status: pending
  - id: s1-sortable-table
    content: "PR1/1E: Replace native select/input with Chakra; add debounce; add keyboard nav; add aria-sort"
    status: pending
  - id: s1-accessibility
    content: "PR1/1E: Add ARIA labels to StatCard/PnlText/StageBar/StageBadge; add colorblind arrows; mobile overflow"
    status: pending
  - id: s1-docs
    content: "PR1/1F: DELETE TODO.md + STATUS.md; MERGE TEST_PLAN.md into TESTS.md; REWRITE ARCHITECTURE.md, ROADMAP.md, PORTFOLIO.md, MODELS.md, frontend-ui.md"
    status: pending
  - id: s2-category-rule-model
    content: "PR2/2A: Add CategoryRule model + Alembic migration; build CategoryEngine service with presets"
    status: pending
  - id: s2-category-api
    content: "PR2/2A: Add API endpoints for presets, rules CRUD, drift, rebalance-preview, auto-categorize"
    status: pending
  - id: s2-strategy-enums
    content: "PR2/2B: Add PAPER_TRADING/BACKTESTING to StrategyStatus; add TRIM/REBALANCE/ROTATE to SignalType"
    status: pending
  - id: s2-rule-evaluator
    content: "PR2/2B: Build RuleEvaluator service for JSON condition trees; wire as Celery task"
    status: pending
  - id: s2-categories-frontend
    content: "PR2/2C: Redesign Categories page (concentric rings, auto-organize, drift alerts, rebalance shopping list)"
    status: pending
  - id: s2-strategy-frontend
    content: "PR2/2D: Build StrategyList + StrategyBuilder pages; Overview redesign; invisible sync UX"
    status: pending
  - id: s3-order-model
    content: "PR3/3A: Create Order model + migration with idempotency_key, status lifecycle, paper trade flag"
    status: pending
  - id: s3-order-engine
    content: "PR3/3A: Build OrderEngine, RiskGate, PaperExecutor, Reconciler services"
    status: pending
  - id: s3-strategy-pipeline
    content: "PR3/3A: Wire Strategy -> RuleEvaluator -> Signal -> OrderEngine -> PaperExecutor -> Reconciler"
    status: pending
  - id: s3-broker-apis
    content: "PR3/3B: IBKR order API integration; TastyTrade order API; Schwab OAuth wiring"
    status: pending
  - id: s3-safety-polish
    content: "PR3/3B: Circuit breakers, kill switch, StrategyDetail page, StrategyBacktest page, Paper->Live toggle"
    status: pending
isProject: false
---

# AxiomFolio: Master Blueprint

Split into 3 PRs. Complete Section 1, merge, then proceed to Section 2, then Section 3.

**Alembic note:** The app is in production. All schema changes use **incremental Alembic migrations** only -- no consolidation, no dropping old revisions.

## Architecture: The Three Pillars

```mermaid
flowchart TB
  subgraph pillar1 [Portfolio - READ ONLY]
    BrokerSync["Broker Sync"]
    Positions["Positions + Tax Lots"]
    Snapshots["Daily Snapshots"]
    Categories["Smart Categories"]
    BrokerSync --> Positions --> Snapshots
    Positions --> Categories
  end

  subgraph pillar2 [Intelligence - BRAIN]
    MarketData["Market Data Pipeline"]
    Indicators["Indicator Engine"]
    SignalGen["Signal Generator"]
    RuleEngine["Rule Engine"]
    MarketData --> Indicators --> SignalGen --> RuleEngine
  end

  subgraph pillar3 [Strategy - EXECUTION]
    StrategyDef["Strategy Definition"]
    Evaluator["Strategy Evaluator"]
    RiskGate["Risk Gate"]
    OrderEngine["Order Engine"]
    Reconciler["Trade Reconciler"]
    StrategyDef --> Evaluator
    RuleEngine --> Evaluator
    Evaluator --> RiskGate --> OrderEngine --> Reconciler
  end

  Categories -.->|"allocation drift"| RuleEngine
  Positions -.->|"current state"| Evaluator
  Reconciler -.->|"fills"| Positions
```



---

# SECTION 1 / PR 1: Foundation

Backend cleanup, sync lifecycle, frontend DRY/type safety/UX, accessibility, docs overhaul. This stabilizes the existing app before adding new features.

## Checkpoint 1A: Backend Cleanup

1. **Delete 3 dead endpoints** in `[backend/api/routes/portfolio.py](backend/api/routes/portfolio.py)`:
  - Delete `get_portfolio_summary` (lines 39-60): calls nonexistent `sync_service.get_user_portfolio_summary(user.id)`
  - Delete `get_positions` (lines 63-89): calls nonexistent `sync_service.get_user_positions(user.id, broker=broker)`
  - Delete `get_portfolio_performance` (lines 92-115): calls nonexistent `sync_service.get_user_performance(user.id, days=days)`
  - Remove unused import `from backend.services.portfolio.ibkr_sync_service import IBKRSyncService` (line 19)
  - Keep everything from line 118 onward (tax-lots, flexquery, analytics)
2. **Fix N+1 in `portfolio.py:258`** (statements endpoint): Pre-fetch all broker accounts into `accounts_by_id = {a.id: a for a in db.query(BrokerAccount).filter(BrokerAccount.id.in_(account_ids)).all()}` before the loop. Replace per-iteration query with `acc = accounts_by_id.get(t.account_id)`.
3. **Fix N+1 in `portfolio_live.py:51`**: Same pre-fetch pattern for positions loop.
4. **Skip `portfolio_dashboard.py:101-113`**: Already pre-fetches and filters in-memory. No N+1.
5. **Fix N+1 in `portfolio_options.py:104`**: Same pre-fetch pattern for options loop.
6. **Validate**: `cd backend && python -m pytest tests/ -q --tb=short`

## Checkpoint 1B: Sync Lifecycle

1. **Make `/accounts/sync-all` async** in `[backend/api/routes/account_management.py](backend/api/routes/account_management.py)` (lines 231-252): Replace synchronous loop with `sync_account_task.delay(account.id)` per account. Return `{"status": "queued", "task_ids": {key: task.id}}`.
2. **Auto-sync on account add** (after line 132 `db.refresh(broker_account)`): Enqueue `sync_account_task.delay(broker_account.id)`. Return `sync_task_id` in response.
3. **Fix strategy route import error**: `strategy_manager.py` line 35 imports `from backend.services.analysis.atr_calculator import atr_calculator` but the file is `atr_engine.py`. Fix the import, then uncomment `strategies,` on line 32 of `[backend/api/main.py](backend/api/main.py)`.
4. **Validate**: `cd backend && python -m pytest tests/ -q --tb=short`

## Checkpoint 1C: Frontend DRY + Type Safety

1. **Create `frontend/src/utils/portfolio.ts`** -- extract these duplicated functions:
  - `buildAccountsFromPositions()` from `PortfolioOverview.tsx` lines 41-71
  - `buildAccountsFromBroker()` from `PortfolioTransactions.tsx` lines 64-76
  - `stageCountsFromPositions()` from `PortfolioOverview.tsx` lines 74-83
  - `sectorAllocationFromPositions()` from `PortfolioOverview.tsx` lines 86-93
  - `topMoversFromPositions()` from `PortfolioOverview.tsx` lines 96-101
  - `toStartEnd()` from `PortfolioTransactions.tsx` lines 35-62
  - `timeAgo()` from `PortfolioOverview.tsx` lines 30-38
  - Type all params/returns using `EnrichedPosition` from `types/portfolio.ts`
2. **Update imports** in PortfolioOverview, PortfolioHoldings, PortfolioOptions, PortfolioTransactions.
3. **Add response interfaces to `api.ts`**: `StocksResponse`, `DashboardResponse`, `ActivityResponse`, `OptionsPortfolioResponse`, `AccountsResponse`.
4. **Type hook returns in `usePortfolio.ts`**: Replace `.then((r: any) => ...)` with typed responses. Type each `useQuery` generic param.
5. **Type `AccountContext.tsx`**: Replace `as any[]` (line 84) and `as any` (line 86) with `BrokerAccountData` interface.
6. **Validate**: `cd frontend && npx tsc --noEmit && npm run lint && npm run build`

## Checkpoint 1D: Frontend UX Fixes

1. **Create `frontend/src/hooks/useDebounce.ts`**: Standard debounce hook.
2. **Apply debounce** in PortfolioTransactions.tsx for symbol search (300ms).
3. **Fix account filter consistency**: Migrate PortfolioOptions + PortfolioTransactions from local `selectedAccount` state to global `useAccountContext().selected`.
4. **Add mutations with toasts** to PortfolioCategories.tsx: `useMutation` with `onSuccess`/`onError` toasts for create/update/assign. Disable buttons while loading.
5. **Add sync error feedback** in `usePortfolio.ts`: `onError`/`onSuccess` callbacks on sync mutation.
6. **Create `frontend/src/components/shared/Skeleton.tsx`**: `StatCardSkeleton`, `TableSkeleton`, `ChartSkeleton`. Replace spinner-only states.
7. **Validate**: `cd frontend && npm test && npm run build`

## Checkpoint 1E: SortableTable + Accessibility

1. **SortableTable.tsx**: Replace native `<select>` with `NativeSelectRoot`/`NativeSelectField`/`NativeSelectIndicator`. Replace native `<input>` with Chakra `Input`. Add `useDebounce` to text filter inputs.
2. **Keyboard nav**: Add `tabIndex={0}`, `role="button"`, `onKeyDown` (Enter/Space) to clickable rows.
3. **Sortable header aria**: Add `aria-sort` attribute to sortable `<Th>`.
4. **Shared components**: `StatCard.tsx` add `aria-label`. `PnlText.tsx` add arrow chars for colorblind. `StageBar.tsx` replace `title` with `aria-label`. `StageBadge.tsx` add `aria-label`.
5. **Mobile**: Wrap `<Table>` in `<Box overflowX="auto">`. Responsive grid columns (`base: 2, md: 4`). Stack filters vertically on mobile.
6. **Validate**: `cd frontend && npm test && npm run build`

## Checkpoint 1F: Docs Overhaul

1. **Delete**: `docs/TODO.md`, `docs/STATUS.md`
2. **Merge**: `TEST_PLAN.md` content into `TESTS.md` as "Test Plan" subsection. Delete `TEST_PLAN.md`.
3. **Rewrite `ARCHITECTURE.md`**: Add Three Pillars diagram, strategy engine, category engine, execution pipeline, auto-sync lifecycle.
4. **Rewrite `ROADMAP.md`**: Match the 3-section structure of this plan. Add completion status.
5. **Update `PORTFOLIO.md`**: Add sync lifecycle, smart categories, strategy bridge.
6. **Update `MODELS.md`**: Add Order, CategoryRule models. Add updated enum values.
7. **Update `frontend-ui.md`**: Add component map, skeleton pattern, rule builder pattern.
8. **Leave as-is**: `ONBOARDING.md`, `PRODUCTION.md`, `BROKERS.md`, `PR_AUTOMATION.md`, `TESTS.md`, `MARKET_DATA.md`

### Section 1 Files Summary

**Backend files to modify:**

- `[backend/api/routes/portfolio.py](backend/api/routes/portfolio.py)` -- delete dead endpoints, fix N+1
- `[backend/api/routes/account_management.py](backend/api/routes/account_management.py)` -- async sync-all, auto-sync on add
- `[backend/api/routes/portfolio_live.py](backend/api/routes/portfolio_live.py)` -- fix N+1
- `[backend/api/routes/portfolio_options.py](backend/api/routes/portfolio_options.py)` -- fix N+1
- `[backend/api/main.py](backend/api/main.py)` -- uncomment strategies route
- `[backend/services/strategies/strategy_manager.py](backend/services/strategies/strategy_manager.py)` -- fix atr import

**Frontend files to modify:**

- `[frontend/src/pages/portfolio/PortfolioOverview.tsx](frontend/src/pages/portfolio/PortfolioOverview.tsx)` -- extract utilities
- `[frontend/src/pages/portfolio/PortfolioHoldings.tsx](frontend/src/pages/portfolio/PortfolioHoldings.tsx)` -- extract utilities, fix types
- `[frontend/src/pages/portfolio/PortfolioOptions.tsx](frontend/src/pages/portfolio/PortfolioOptions.tsx)` -- use AccountContext, fix types
- `[frontend/src/pages/portfolio/PortfolioTransactions.tsx](frontend/src/pages/portfolio/PortfolioTransactions.tsx)` -- use AccountContext, add debounce, fix types
- `[frontend/src/pages/portfolio/PortfolioCategories.tsx](frontend/src/pages/portfolio/PortfolioCategories.tsx)` -- error handling with toasts
- `[frontend/src/hooks/usePortfolio.ts](frontend/src/hooks/usePortfolio.ts)` -- type returns, remove `any`
- `[frontend/src/services/api.ts](frontend/src/services/api.ts)` -- add response interfaces
- `[frontend/src/context/AccountContext.tsx](frontend/src/context/AccountContext.tsx)` -- type accounts
- `[frontend/src/components/SortableTable.tsx](frontend/src/components/SortableTable.tsx)` -- Chakra components, debounce, keyboard nav, aria
- `[frontend/src/components/shared/StatCard.tsx](frontend/src/components/shared/StatCard.tsx)` -- ARIA labels
- `[frontend/src/components/shared/PnlText.tsx](frontend/src/components/shared/PnlText.tsx)` -- arrow icons for colorblind

**Frontend new files:**

- `frontend/src/utils/portfolio.ts` -- shared utilities
- `frontend/src/hooks/useDebounce.ts` -- debounce hook
- `frontend/src/components/shared/Skeleton.tsx` -- skeleton loading variants

**Docs changes:**

- DELETE: `TODO.md`, `STATUS.md`, `TEST_PLAN.md` (after merge)
- REWRITE: `ARCHITECTURE.md`, `ROADMAP.md`
- UPDATE: `PORTFOLIO.md`, `MODELS.md`, `frontend-ui.md`, `TESTS.md`

---

# SECTION 2 / PR 2: Smart Categories + Strategy Engine

Build the category auto-organization engine, the composable rule evaluator, the order engine with paper trading, and the frontend pages for categories and strategies.

## Checkpoint 2A: Category Engine (backend)

**New model -- `CategoryRule`** (add to `[backend/models/portfolio.py](backend/models/portfolio.py)`):

```python
class CategoryRule(Base):
    __tablename__ = "category_rules"
    id = Column(Integer, primary_key=True)
    category_id = Column(Integer, ForeignKey("categories.id"), nullable=False)
    rule_type = Column(String(30))   # SECTOR, INDUSTRY, MARKET_CAP, STAGE, SYMBOL_LIST, CUSTOM
    operator = Column(String(20))    # EQUALS, IN, BETWEEN, GREATER_THAN, LESS_THAN, REGEX
    field = Column(String(50))       # "sector", "industry", "market_cap", "stage_label", etc.
    value = Column(JSON)             # {"values": ["Technology"]} or {"min": 1e9, "max": 10e9}
    priority = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.now())
```

**New service -- `CategoryEngine`** (`backend/services/portfolio/category_engine.py`):

- `auto_categorize(user_id)`: Evaluate all active rules, assign positions via `PositionCategory`, skip manual overrides
- `compute_drift(user_id)`: For each category with `target_allocation_pct`, compute `actual - target`
- `generate_rebalance_orders(user_id)`: When drift exceeds threshold, compute buy/sell proposals
- Hook into post-sync flow

**Built-in presets:**

- **By Market Cap**: Mega (>$200B), Large ($10B-$200B), Mid ($2B-$10B), Small ($300M-$2B), Micro (<$300M)
- **By Sector**: 1 category per unique sector in positions
- **By Weinstein Stage**: Stage 2 Momentum (2A/2B), Stage 2 Late (2C), Stage 3/4 Declining, Stage 1 Basing
- **By Account Type**: Taxable, IRA, Roth IRA, HSA
- **Custom**: User-defined rules with AND/OR logic

**New endpoints** (add to `[portfolio_categories.py](backend/api/routes/portfolio_categories.py)`):

- `GET /categories/presets` -- list available presets
- `POST /categories/presets/apply` + `/confirm` -- preview and apply preset
- `GET /categories/drift` -- drift report
- `POST /categories/auto-categorize` + `/apply` -- preview and apply auto-categorization
- `GET /categories/rebalance-preview` -- proposed rebalance trades
- `POST/GET/DELETE /categories/{id}/rules` -- rules CRUD

**Tasks:**

- Add Alembic migration for `category_rules` table
- Build CategoryEngine service
- Add category engine tests
- Wire auto-categorize into post-sync Celery chain

## Checkpoint 2B: Strategy Engine (backend)

**Enum changes** (incremental Alembic migrations):

- Add `PAPER_TRADING`, `BACKTESTING` to `StrategyStatus` in `[backend/models/strategy.py](backend/models/strategy.py)`
- Add `TRIM`, `REBALANCE`, `ROTATE` to `SignalType` in `[backend/models/signals.py](backend/models/signals.py)`

**Composable Rule Engine** -- `backend/services/strategies/rule_evaluator.py`:

Condition tree schema for `Strategy.parameters` JSON field:

```json
{
  "entry_rules": {
    "operator": "AND",
    "conditions": [
      {"field": "stage_label", "op": "in", "values": ["2A", "2B"]},
      {"field": "rs_mansfield_pct", "op": ">", "value": 0},
      {"operator": "OR", "conditions": [
        {"field": "rsi", "op": "<", "value": 30},
        {"field": "td_buy_setup", "op": ">=", "value": 9}
      ]}
    ]
  },
  "exit_rules": { ... },
  "trim_rules": { "conditions": [...], "action": {"type": "TRIM", "quantity_pct": 25} }
}
```

`RuleEvaluator.evaluate(strategy, snapshot, position)` walks the tree, returns `list[Signal]`. Called from a Celery task post-indicator computation.

**Tasks:**

- Create Alembic migrations for enum additions
- Build RuleEvaluator service
- Wire as Celery task in post-indicator chain
- Add rule evaluator tests

## Checkpoint 2C: Order Engine (backend)

**New model** -- `Order` at `backend/models/order.py`:

- `idempotency_key`, `strategy_id`, `signal_id`, `user_id`, `account_id`
- `symbol`, `side`, `order_type`, `quantity`, `limit_price`, `stop_price`, `time_in_force`
- `status` lifecycle: PENDING -> SUBMITTED -> PARTIAL_FILL -> FILLED / CANCELLED / REJECTED / EXPIRED
- `is_paper_trade`, `parent_order_id` (for brackets), `broker_order_id`, fill tracking

**Order Engine flow:**

```mermaid
flowchart TB
  Signal["Strategy Signal"] --> OrderFactory["Order Factory"]
  OrderFactory --> RiskCheck["Risk Gate"]
  RiskCheck -->|"PASS"| OrderPersist["Persist PENDING"]
  RiskCheck -->|"FAIL"| Reject["Reject + Alert"]
  OrderPersist --> Router["Broker Router"]
  Router -->|"PAPER"| PaperExec["Paper Executor"]
  Router -->|"IBKR"| IBKRExec["IBKR Order API"]
  Router -->|"TastyTrade"| TTExec["TastyTrade Order API"]
  PaperExec --> Fill["Record Fill"]
  IBKRExec --> Fill
  TTExec --> Fill
  Fill --> Reconciler["Position Reconciler"]
  Reconciler --> Notify["Notify User"]
```



**New services** in `backend/services/trading/`:

- `order_engine.py` -- order creation, status updates, idempotency
- `risk_gate.py` -- concentration limits, daily loss, duplicate checks, buying power, market hours, kill switch, circuit breakers (3 rejects = pause, daily P&L < -2% = halt, >5% of portfolio = manual approval)
- `paper_executor.py` -- simulated fills with configurable slippage
- `reconciler.py` -- post-fill position + trade record updates

**Tasks:**

- Create Alembic migration for `orders` table
- Build all 4 services
- Wire Strategy -> RuleEvaluator -> Signal -> OrderEngine -> PaperExecutor -> Reconciler pipeline
- Add tests for order engine, risk gate, paper executor

## Checkpoint 2D: Categories Frontend

- **Concentric rings** allocation viz: inner = target, outer = actual. Drift is visible as misalignment.
- **Auto-organize button**: Preset picker -> preview ("Move AAPL to Large Cap Tech") -> confirm/cherry-pick
- **Drift alerts banner**: "Healthcare is 5.2% over target. View rebalance plan?"
- **Rebalance preview**: Shopping list: "Sell 12 AAPL (-2.3%), Buy 8 VTI (+1.8%)". Single execute button.
- **Inline rule builder** per category card
- Add MSW setup + portfolio page tests

## Checkpoint 2E: Strategy Frontend + Overview Redesign

- **StrategyList.tsx**: Cards grid with status dots (green=active, yellow=paper, gray=draft), P&L, last action
- **StrategyBuilder.tsx**: Sentence-based rule builder ("Buy when stage enters 2A and RS Mansfield > 0"). Editable chips. Entry/Exit/Trim sections. Universe filter. Position sizing. Risk params.
- **Portfolio Overview redesign**: Hero number (total value + daily P&L), side-by-side donut + performance chart, compact stage bar, inline top movers, invisible sync ("Updated 2m ago" footer)
- **Invisible sync UX**: Remove sync buttons, add freshness indicator, auto-sync on login + 15min intervals during market hours, thin progress bar during sync
- Add strategy routes to `App.tsx`

### Section 2 Files Summary

**Backend new files:**

- `backend/services/portfolio/category_engine.py`
- `backend/services/strategies/rule_evaluator.py`
- `backend/models/order.py`
- `backend/services/trading/order_engine.py`
- `backend/services/trading/risk_gate.py`
- `backend/services/trading/paper_executor.py`
- `backend/services/trading/reconciler.py`
- 3 Alembic migrations (CategoryRule, Order, enum additions)

**Backend files to modify:**

- `[backend/models/portfolio.py](backend/models/portfolio.py)` -- add CategoryRule model
- `[backend/models/strategy.py](backend/models/strategy.py)` -- add PAPER_TRADING, BACKTESTING
- `[backend/models/signals.py](backend/models/signals.py)` -- add TRIM, REBALANCE, ROTATE
- `[backend/api/routes/portfolio_categories.py](backend/api/routes/portfolio_categories.py)` -- new endpoints

**Frontend new files:**

- `frontend/src/pages/strategy/StrategyList.tsx`
- `frontend/src/pages/strategy/StrategyBuilder.tsx`
- `frontend/src/test/mocks/handlers.ts` + `server.ts` -- MSW setup

**Frontend files to modify:**

- `[frontend/src/pages/portfolio/PortfolioOverview.tsx](frontend/src/pages/portfolio/PortfolioOverview.tsx)` -- hero number redesign, invisible sync
- `[frontend/src/pages/portfolio/PortfolioCategories.tsx](frontend/src/pages/portfolio/PortfolioCategories.tsx)` -- concentric rings, auto-organize, drift
- `[frontend/src/context/AccountContext.tsx](frontend/src/context/AccountContext.tsx)` -- sync-on-login
- `[frontend/src/App.tsx](frontend/src/App.tsx)` -- add strategy routes

---

# SECTION 3 / PR 3: Live Execution + Polish

Connect to broker order APIs, add safety infrastructure, build the remaining strategy pages, and polish for production.

## Checkpoint 3A: Broker Order APIs

- **IBKR order API integration** (Client Portal API): Submit orders, poll status, handle fills
- **TastyTrade order API**: Same pattern using existing `[tastytrade_client.py](backend/services/clients/tastytrade_client.py)`
- **Schwab OAuth wiring**: Wire `[schwab_connector.py](backend/services/aggregator/schwab_connector.py)` OAuth flow, build basic sync service at `backend/services/portfolio/schwab_sync_service.py`, env vars `SCHWAB_CLIENT_ID`/`SECRET`/`REDIRECT_URI`/`ACCOUNTS`
- **Build `broker_executor.py`**: Routes orders to the correct broker API based on `account.broker_type`
- **Position reconciliation**: Compare broker-reported state vs DB state after fills

## Checkpoint 3B: Safety + Polish

- **Circuit breakers + kill switch**: Global `ENABLE_TRADING` flag, per-strategy kill switch, 3-reject pause, daily P&L halt
- **StrategyDetail.tsx**: Timeline view (signals, orders, fills, P&L), performance chart, signal history table, active positions table
- **StrategyBacktest.tsx**: Date range picker, equity curve, drawdown chart, trade list, performance metrics using `MarketSnapshotHistory` data
- **Paper -> Live toggle**: "Switch to live trading? This strategy has been paper trading for 14 days with +3.2% return."
- **Mobile optimization**: Table scroll, responsive grids (`base: 2, md: 4`), stacked filters on small screens
- **Options lifecycle panel**: Group trades by underlying+strike+expiry to show open/close lifecycle

### Section 3 Files Summary

**Backend new files:**

- `backend/services/trading/broker_executor.py`
- `backend/services/portfolio/schwab_sync_service.py`

**Backend files to modify:**

- `[backend/services/clients/schwab_client.py](backend/services/clients/schwab_client.py)` -- wire order submission
- `[backend/services/aggregator/schwab_connector.py](backend/services/aggregator/schwab_connector.py)` -- OAuth flow endpoints

**Frontend new files:**

- `frontend/src/pages/strategy/StrategyDetail.tsx`
- `frontend/src/pages/strategy/StrategyBacktest.tsx`

**Frontend files to modify:**

- `[frontend/src/App.tsx](frontend/src/App.tsx)` -- add remaining strategy routes
- `[frontend/src/components/layout/DashboardLayout.tsx](frontend/src/components/layout/DashboardLayout.tsx)` -- skip-to-content link

---

## Design Philosophy (reference for all sections)

### Portfolio: The Calm Dashboard

- One hero number (total value + daily P&L). Not 8 stat cards.
- Progressive disclosure: Overview -> Holdings -> Options -> Transactions
- Invisible sync. "Updated 2m ago" in footer. No sync button.
- Categories as colored allocation bands at top of Holdings

### Strategy: The Control Room

- Strategy as a card with status dot (green/yellow/red), P&L, last action
- Rule builder as sentences with editable chips (Apple Shortcuts pattern)
- Timeline showing signals, orders, fills, P&L chronologically
- Paper -> Live toggle with confidence from data

### Categories: The Allocation Palette

- Concentric rings: inner = target, outer = actual. Misalignment = drift.
- Auto-organize: preview, confirm, done. One interaction.
- Rebalance as shopping list. One button.

### The "Trim RXRX" End-to-End Flow (reference)

```
1. Market data task -> recompute_indicators_universe()
2. MarketSnapshot for RXRX: td_sell_setup=9, stage_label="2C"
3. Strategy evaluation Celery task (post-indicator)
4. RuleEvaluator: trim_rules match -> Action: TRIM 25%
5. Signal: type=TRIM, symbol=RXRX, quantity_pct=25%
6. Order Factory: 100 shares -> SELL 25
7. Risk Gate: all checks PASS
8. Order: SELL 25 RXRX MARKET DAY, idempotency_key=hash(...)
9. Broker Router -> Paper Executor -> fill at current_price * 0.999
10. Reconciler: Position 100->75, Trade record created
11. Notification: "Trimmed 25 shares RXRX @ $X.XX (TD Sell 9)"
```

