---
name: Full-stack bootstrap
overview: Bring up QuantMatrix via Docker, validate health/auth/tasks/frontend/broker sync end-to-end, then produce a crisp current-state snapshot and prioritized backlog.
todos:
  - id: boot-stack
    content: Start full docker-compose stack using ./run.sh start (or explicit docker compose), ensuring no port conflicts and .env not overwritten.
    status: completed
  - id: verify-health
    content: Validate backend health/docs, confirm migrations behavior, and capture any startup errors/warnings from logs.
    status: completed
  - id: verify-celery
    content: Confirm celery worker/beat + Flower are operational; verify key periodic schedules are present and tasks can be observed.
    status: completed
  - id: verify-frontend
    content: Load frontend, confirm Vite proxy calls succeed, and smoke-test a few key pages/endpoints end-to-end.
    status: completed
  - id: verify-auth-rbac
    content: Confirm login + /api/v1/auth/me role, and validate admin RBAC protections and basic admin endpoints.
    status: completed
  - id: exercise-brokers
    content: Trigger at least one TT/IBKR async job path (connect/sync) and observe job_id + polling/status behavior; ensure safe failure when creds missing.
    status: completed
  - id: status-snapshot
    content: "Produce a concise current-state report: green/yellow/red, top risks, and prioritized next steps with owners/time estimates."
    status: completed
---

# QuantMatrix “Spin Up + Current State” Gameplan

## Objectives (what “good” looks like)

- **Full stack running in Docker**: Postgres, Redis, Backend, Frontend, Celery worker/beat, Flower (and optionally cloudflared).
- **Green API surface**: `GET /health` + `GET /docs` load, no fatal startup errors, migrations applied cleanly.
- **Auth/RBAC confirmed**: login works, `GET /api/v1/auth/me` returns role, admin routes gated.
- **Frontend works end-to-end**: key pages render and fetch data through the API (using Vite proxy).
- **Broker pipelines exercised**: at least one TT/IBKR sync job can be started and status observed (even if broker creds aren’t configured, we confirm the job framework behaves correctly).
- **We leave behind a “staff-level” status snapshot**: what’s working, what’s flaky, biggest risks, and the next 3–5 engineering moves.

## Constraints / Safety

- **Docker-first** (no local installs): use `docker compose` / `docker-compose` and `docker compose exec`.
- **Do not overwrite `.env`** (if missing, we can create from template, but only with your explicit go-ahead).
- **No live trading by default**: ensure `ENABLE_TRADING` stays false.

## Step 0 — Preflight

Leverage existing scripts/config:

- Startup helper: [`/Users/sankalpsharma/development/quantmatrix/run.sh`](/Users/sankalpsharma/development/quantmatrix/run.sh)
- Compose stack: [`/Users/sankalpsharma/development/quantmatrix/docker-compose.yml`](/Users/sankalpsharma/development/quantmatrix/docker-compose.yml)

Actions:

- Check Docker daemon is running.
- Confirm whether any containers are already up (avoid double-start / port conflicts).
- Confirm `.env` exists and is being loaded by compose (`env_file: .env`).

## Step 1 — Bring up the full stack

Primary path:

- Run `./run.sh start` (this starts postgres/redis, then backend + celery + flower, then frontend, then cloudflared “best effort”).

Fallback path (if you want explicit control):

- `docker compose up -d --build`

## Step 2 — Verify “platform health” (backend)

Backend entrypoint is Uvicorn on 8000 per compose and [`backend/api/main.py`](/Users/sankalpsharma/development/quantmatrix/backend/api/main.py).Checks:

- `GET http://localhost:8000/health`
- `GET http://localhost:8000/docs`
- Inspect backend logs for:
- alembic auto-upgrade attempt on startup
- admin seeding behavior (only if `DEBUG=True` and `ADMIN_*` set)

## Step 3 — Verify data plane dependencies

- Postgres healthy (`pg_isready` healthcheck in compose)
- Redis healthy
- Confirm backend can connect to Postgres via `DATABASE_URL` from compose.

## Step 4 — Verify Celery scheduling + observability

From compose:

- Worker + beat + Flower should be up (`:5555`).

Checks:

- Open Flower and confirm worker online and queues aren’t stuck.
- Look for periodic schedules described in [`backend/tasks/README.md`](/Users/sankalpsharma/development/quantmatrix/backend/tasks/README.md) and configured in `backend/tasks/celery_app.py`.

## Step 5 — Verify frontend integration

Frontend is Vite on `:3000`. Vite dev proxy forwards `/api/*` to `http://backend:8000` (container DNS) per [`frontend/vite.config.ts`](/Users/sankalpsharma/development/quantmatrix/frontend/vite.config.ts).Checks:

- Load `http://localhost:3000`
- Confirm API calls hit `/api/...` (proxy) and succeed.

## Step 6 — Verify auth + admin RBAC

Target behavior per [`docs/ARCHITECTURE.md`](/Users/sankalpsharma/development/quantmatrix/docs/ARCHITECTURE.md) and [`docs/STATUS.md`](/Users/sankalpsharma/development/quantmatrix/docs/STATUS.md).Checks:

- If `DEBUG=True` + `ADMIN_*` are set: confirm seeded admin works.
- Login, then `GET /api/v1/auth/me` returns role.
- Admin endpoints under `/api/v1/admin/*` are:
- accessible to admin
- 403 for non-admin

## Step 7 — Exercise broker sync paths (TT/IBKR)

Goal is to validate job orchestration + persistence + API behavior.Checks:

- Confirm `/api/v1/aggregator/*` routes respond.
- Trigger a safe “sync” or “connect” job (async job_id + polling per status docs), observe:
- job creation
- job status transitions
- error surfaces cleanly when creds are missing

## Step 8 — Establish a baseline report (staff engineer snapshot)

Deliverables after the run:

- **What’s green** (services + core flows)
- **What’s yellow** (warnings, flaky tasks, slow endpoints)
- **What’s red** (crashes, broken imports, critical missing env)
- **Top risks** (data integrity, broker sync safety, auth, migrations)
- **Top next moves** (3–5 items): highest ROI fixes + a near-term roadmap

## Notes / likely sharp edges we’ll watch

- Backend `startup_event` attempts automatic alembic upgrade; we’ll confirm it’s consistent with `run.sh migrate` behavior.
- `backend/config.py` still contains some legacy constants after `settings`; we’ll treat `settings` as source of truth.
```mermaid
flowchart LR
  user[UserBrowser] --> fe[Frontend_Vite_3000]
  fe -->|"/api proxy"| be[Backend_FastAPI_8000]
  be --> db[Postgres_5432]
  be --> r[Redis_6379]
  beat[CeleryBeat] --> r
  worker[CeleryWorker] --> r
  worker --> db
  flower[Flower_5555] --> r








```