---
name: Eng Upgrades + Revenue Streams
overview: Add Principal Engineer-level production reliability architecture (5 must-have patterns before tax season) and 3 Tier 1 adjacent revenue streams to the Venture Master Plan, with corresponding Phase task updates, KNOWLEDGE.md decisions, and FOUNDER_SIDE_PROJECTS.md evaluations.
todos:
  - id: section-2b
    content: "Add Section 2B: Production Reliability Architecture (5 must-have + 5 should-have patterns) to VENTURE_MASTER_PLAN.md after Section 2 Dev Commands"
    status: completed
  - id: section-1b
    content: "Add Section 1B: Adjacent Revenue Streams (CaaS, Quarterly Estimator, Refund Splitting) to VENTURE_MASTER_PLAN.md after Audit Shield Economics"
    status: completed
  - id: phase-tasks
    content: Add Phase 7 tasks P7.18-P7.22, expand P7.4, add Phase 3.5 note to VENTURE_MASTER_PLAN.md
    status: completed
  - id: revenue-update
    content: Update LaunchFree revenue table in Section 1 with Compliance-as-a-Service line item
    status: completed
  - id: side-projects
    content: Add 3 Tier 1 evaluations + updated summary to FOUNDER_SIDE_PROJECTS.md
    status: completed
  - id: knowledge
    content: Add decisions D62-D64 to KNOWLEDGE.md
    status: completed
  - id: financials
    content: Add Grafana Cloud + k6 cost notes to FINANCIALS.md (free tier, $0)
    status: completed
isProject: false
---

# Engineering Upgrades + Tier 1 Adjacent Revenue Streams

## Context

Two additions to `docs/VENTURE_MASTER_PLAN.md`:

1. **Production Reliability Architecture** -- 5 must-have patterns before January 2027 (idempotency, circuit breakers, reconciliation, observability, load testing) + 5 should-have patterns for Year 1-2.
2. **3 Tier 1 Adjacent Revenue Streams** -- natural extensions of existing products that leverage the data moat with minimal new surface area.

## Changes

### 1. New Section 2B: Production Reliability Architecture

**Insert after**: Line 1039 in [VENTURE_MASTER_PLAN.md](docs/VENTURE_MASTER_PLAN.md) (after "Dev Commands" table, before the `---` separator on line 1041).

**Content** -- a new subsection under Section 2 with two tiers:

**Tier 1 -- Must-Have Before January 2027** (blocks tax season launch if absent):

- **2B.1 Idempotency Keys**: Every state-changing financial operation (filing submission, refund routing, payment processing) requires a client-generated idempotency key. Backend stores key + result in Redis (TTL 24hr) and returns cached result on duplicate request. Pattern: `X-Idempotency-Key` header on all `POST`/`PUT` to `/api/v1/filings/`*, `/api/v1/payments/`*, `/api/v1/submissions/*`. Prevents double-submits during tax deadline surge when users rage-click. Implementation: FastAPI middleware that checks Redis before route handler executes.
- **2B.2 Circuit Breakers + Graceful Degradation**: Every external service call (Cloud Vision OCR, OpenAI GPT, IRS MeF transmitter, Column Tax API, affiliate tracking APIs) wrapped in a circuit breaker (library: `pybreaker` for Python). States: CLOSED (normal) -> OPEN (after 5 failures in 60s, fast-fail for 30s) -> HALF-OPEN (allow 1 probe request). Degradation strategy per service:
  - Cloud Vision down: queue image, return "processing" status, retry via background task
  - OpenAI down: fall back to rule-based field mapping (lower accuracy, no AI insights)
  - IRS MeF down: queue submission, show user "submitted, awaiting IRS confirmation"
  - Column Tax down: fall back to PDF download
  - Affiliate API down: log conversion locally, reconcile later (no user impact)
- **2B.3 Tax Calculation Reconciliation Pipeline**: Dual-path verification for every tax return. Path A: forward calculation (income -> deductions -> credits -> tax owed -> refund). Path B: reverse verification (refund + tax paid -> effective rate -> back-calculate expected income). If delta exceeds $1 tolerance, flag for manual review. Runs as a post-calculation step before user sees results. Also: nightly batch reconciliation job compares all day's calculations against IRS Publication 17 test vectors. Alert to `#ops-alerts` on any mismatch.
- **2B.4 Structured Observability (OpenTelemetry)**: Instrument the full OCR-to-filing pipeline with distributed tracing. Each filing gets a trace ID that follows it through: image upload -> preprocessing -> Cloud Vision -> field mapping -> tax calculation -> PDF generation -> MeF submission -> IRS acknowledgment. Stack: OpenTelemetry SDK (Python) -> export to Grafana Cloud free tier (50GB traces/mo, 50GB logs/mo). Key spans: `ocr.preprocess`, `ocr.cloud_vision`, `ocr.field_mapping`, `tax.calculate`, `tax.reconcile`, `filing.submit`, `filing.ack`. Custom metrics: p50/p95/p99 latency per span, OCR confidence distribution, calculation reconciliation delta distribution. Dashboard: single "Filing Health" view showing pipeline success rate, latency percentiles, and error breakdown.
- **2B.5 Load Testing (Tax Season Patterns)**: Tax filing follows a power-law distribution: 80% of annual volume in 10 weeks (Jan 20 - Mar 31), 40% in the final 2 weeks before April 15. The system must handle 10x average daily load. Tool: k6 (open-source, scriptable, runs in CI). Test scenarios: (1) Steady state: 100 concurrent users filing over 1 hour. (2) Deadline surge: ramp from 100 to 1,000 concurrent users over 15 minutes. (3) OCR bottleneck: 500 concurrent image uploads (tests Cloud Vision rate limits + our queuing). (4) Soak test: 8-hour sustained load at 2x average. Run monthly starting October 2026. Results posted to `#ops-alerts`. Performance budget: p95 filing completion < 30s, p99 < 60s, zero data loss under any load.

**Tier 2 -- Should-Have (Year 1-2)**:

- **2B.6 Event Sourcing for Filing State Machine**: Filing status transitions (draft -> processing -> review -> submitted -> accepted/rejected) stored as an append-only event log, not mutable status column. Enables: audit trail, replay for debugging, temporal queries ("what was the status at 3pm?"). Defer to post-launch; current status column works for MVP.
- **2B.7 Encryption Key Rotation**: AES-256 keys for PII at-rest encryption need rotation capability. Design: key versioning (each encrypted value tagged with key version), background re-encryption job, zero-downtime rotation. Implement before 10K users.
- **2B.8 Schema Registry + API Contract Testing**: As the monorepo grows (3 APIs, 4 frontends), API contracts become fragile. Use OpenAPI specs as source of truth, auto-generate TypeScript clients, and run contract tests in CI. Tool: `openapi-typescript` for codegen, custom CI step for breaking change detection.
- **2B.9 Multi-Region Readiness**: Neon supports read replicas. Render supports multi-region. Design the data layer for eventual multi-region (read replicas for tax season surge, primary in us-west). Don't implement until 50K+ users.
- **2B.10 Progressive Rollout + Canary Deploys**: Feature flags (PostHog) for gradual rollout of new tax forms and calculation changes. Canary deploys via Render (deploy to 10% of traffic, monitor error rate, auto-promote or rollback). Critical for mid-season form releases (Schedule A in February 2027).

### 2. New Section 1B: Adjacent Revenue Streams (Tier 1)

**Insert after**: Line 872 in [VENTURE_MASTER_PLAN.md](docs/VENTURE_MASTER_PLAN.md) (after Audit Shield Economics, before the `---` separator and Section 2).

**Content** -- 3 natural product extensions with business cases:

- **1B.1 Compliance-as-a-Service (LaunchFree Add-On)**
  - What: After LLC formation, ongoing compliance management -- annual report reminders, franchise tax calculations, state deadline tracking, pre-filled renewal forms.
  - Why now: LaunchFree already captures all state-specific formation data. Compliance data is a JSON config extension of existing 50-state data (`packages/data`). Zero new infrastructure.
  - Revenue: $49-99/yr subscription per LLC. At 10% attach rate on 2K formations = $10K-20K/yr. Scales linearly with LaunchFree user growth.
  - Moat leverage: We already know the user's state, entity type, formation date, and registered agent. Competitors (LegalZoom, ZenBusiness) charge $199-299/yr for the same service. We undercut by 3-5x because our marginal cost is near zero (it's calendar math + state fee lookups, no human involvement).
  - Implementation: Phase 3.5 (post-LaunchFree MVP). Add `compliance_calendar` table, state deadline JSON configs, email/push reminder engine (n8n workflow), and a compliance dashboard page in LaunchFree.
  - Competitive positioning: "You formed for free. Now stay compliant for $49/yr. LegalZoom charges $299."
- **1B.2 Quarterly Tax Estimator (FileFree / Trinket)**
  - What: For 1099/freelance workers who must pay estimated quarterly taxes (IRS Form 1040-ES). Input: YTD income + expenses. Output: recommended quarterly payment amount, next deadline, payment voucher PDF.
  - Why now: FileFree already has a tax calculation engine. Quarterly estimates are a simplified version of the annual calculation (apply safe harbor rule: 100% of prior year tax or 90% of current year). This is a year-round engagement hook -- users return 4x/year instead of 1x.
  - Revenue: Free as a Trinket (SEO acquisition) or free within FileFree (retention). Monetize via: (1) Tax Optimization Plan upsell ("We found $2,400 in deductions you're missing"), (2) Year-round engagement that reduces January churn. Indirect value: $5-15/user/yr in increased Tax Optimization Plan conversion.
  - Moat leverage: Prior-year filing data from FileFree auto-populates safe harbor calculations. No other free estimator has this context. Credit Karma's estimator requires manual entry. Ours says "Based on your 2026 return, your Q1 2027 estimated payment is $1,847."
  - Implementation: Could ship as a Trinket in Phase 1.5 (basic version, manual input) or as a FileFree feature in Phase 7 (pre-populated from prior return). Recommend: ship basic Trinket first for SEO, then upgrade to auto-populated FileFree feature.
  - IRS deadlines: Q1 (April 15), Q2 (June 15), Q3 (September 15), Q4 (January 15). Each deadline is a natural re-engagement trigger.
- **1B.3 Refund Splitting + Goal-Based Savings (FileFree Phase 7)**
  - What: At refund moment (the highest-intent financial moment of the year), let users split their refund across multiple destinations: X% to checking, Y% to HYSA, Z% to IRA. IRS Form 8888 already supports direct deposit to up to 3 accounts.
  - Why now: This is the ultimate affiliate conversion moment. User sees "$3,200 refund" and we say "Put $1,000 in a HYSA earning 5.0% APY (opens Betterment account) and $500 in a Roth IRA (opens SoFi account)." The user is already in "money mode" and the refund feels like found money.
  - Revenue: Each split destination is an affiliate conversion. Betterment: $25-1,250/referral. SoFi: $50-100/funded account. Even at conservative rates, each split = $25-75 in affiliate revenue. At 5% split adoption on 10K filers = 500 splits * $50 avg = $25K.
  - Moat leverage: We know the exact refund amount, the user's filing status, and (with intelligence layer) their financial profile. We can recommend goal-appropriate accounts: "You're 24 and single with no retirement savings -- a Roth IRA with your $1,200 split will be worth $15,000 by retirement."
  - Implementation: Expand P7.4 (Refund Plan screen) to include refund splitting UI. Generate IRS Form 8888 with the user's split instructions. The form itself is trivial (3 routing numbers + amounts). The UX -- goal setting, personalized recommendations, account opening flow -- is the product.
  - Competitive edge: TurboTax offers refund splitting but buries it. No free filing product makes it the centerpiece. We make it the star of the post-filing experience.

### 3. Phase Task Additions in Section 7

**Modify Phase 7 table** (after line 2798): Add 5 new tasks P7.18-P7.22 for the must-have engineering reliability patterns.


| Task                                | Details                                                                                                                  |
| ----------------------------------- | ------------------------------------------------------------------------------------------------------------------------ |
| P7.18 Idempotency middleware        | FastAPI middleware + Redis backend. Cover all filing/payment/submission endpoints.                                       |
| P7.19 Circuit breaker wrappers      | pybreaker integration for Cloud Vision, OpenAI, IRS MeF, Column Tax, affiliate APIs. Degradation strategies per service. |
| P7.20 Reconciliation pipeline       | Dual-path tax calculation verification. Nightly batch validation against IRS Pub 17 test vectors.                        |
| P7.21 OpenTelemetry instrumentation | Distributed tracing across OCR-to-filing pipeline. Grafana Cloud free tier. Filing Health dashboard.                     |
| P7.22 Load testing suite            | k6 scripts for 4 tax season scenarios. Monthly runs from October 2026. Performance budget enforcement.                   |


**Expand P7.4** description to include refund splitting: "HYSA referrals, financial product recs, audit shield upsell, **refund splitting UI (Form 8888), goal-based savings recommendations**"

**Add Phase 3.5 note** after Phase 3 table: "Phase 3.5 (post-LaunchFree MVP): Compliance-as-a-Service subscription ($49-99/yr). Compliance calendar, state deadline configs, email reminders, dashboard. See Section 1B.1."

### 4. FOUNDER_SIDE_PROJECTS.md Updates

Add 3 new evaluations (sections 5, 6, 7) to [FOUNDER_SIDE_PROJECTS.md](docs/FOUNDER_SIDE_PROJECTS.md) for the Tier 1 ideas, plus update the Summary table. These get GO verdicts (unlike the existing deferred/no-go projects).

### 5. KNOWLEDGE.md Decisions

Add to [KNOWLEDGE.md](docs/KNOWLEDGE.md):

- **D62 -- Production Reliability Architecture: 5 Must-Haves Before Tax Season (2026-03-13)**: Idempotency keys, circuit breakers, reconciliation pipeline, OpenTelemetry, load testing. Non-negotiable for a product handling SSNs and tax filings at scale. Phase 7 tasks P7.18-P7.22.
- **D63 -- Adjacent Revenue: 3 Tier 1 Extensions (2026-03-13)**: Compliance-as-a-Service (LaunchFree, Phase 3.5), Quarterly Tax Estimator (Trinket/FileFree), Refund Splitting (Phase 7). All leverage existing data moat with minimal new infrastructure.
- **D64 -- Reconciliation Strategy: Dual-Path Tax Calculation (2026-03-13)**: Every tax return verified via forward calculation + reverse verification. Mismatch > $1 flags for review. Nightly batch validation against IRS Pub 17. Zero tolerance for calculation errors in financial software.

### 6. Revenue Model Update (Section 1)

Add Compliance-as-a-Service to the LaunchFree revenue table and update Year 2 projections to reflect new revenue streams.

## Files Modified

- [docs/VENTURE_MASTER_PLAN.md](docs/VENTURE_MASTER_PLAN.md) -- Sections 1B (new), 2B (new), Phase 7 tasks, Phase 3.5 note, P7.4 expansion
- [docs/FOUNDER_SIDE_PROJECTS.md](docs/FOUNDER_SIDE_PROJECTS.md) -- 3 new evaluations + updated summary
- [docs/KNOWLEDGE.md](docs/KNOWLEDGE.md) -- D62, D63, D64
- [docs/FINANCIALS.md](docs/FINANCIALS.md) -- Add Grafana Cloud + k6 cost notes (both free tier, $0 impact)

