---
name: Definitive Execution Plan
overview: Three detailed coding workstreams -- (1) monorepo restructure, (2) shared infrastructure with 50-state data, (3) sankalpsharma.com + AI agent operations -- plus Google Workspace setup, Cursor workspace scoping, and automated data validation agents.
todos:
  - id: register-domain
    content: Register launchfree.ai domain TODAY
    status: pending
  - id: secure-handles
    content: Secure @launchfree on TikTok, Instagram, X, YouTube
    status: pending
  - id: google-workspace
    content: Set up Google Workspace on sankalpsharma.com ($6/mo). Add launchfree.ai + filefree.tax as secondary domains. Create aliases.
    status: pending
  - id: gdrive-structure
    content: Create Google Drive 'Venture HQ' folder structure. Add GDrive MCP to Cursor.
    status: pending
  - id: form-llc
    content: Form LLC with neutral parent name (Sharma Ventures LLC or similar)
    status: pending
  - id: repo-restructure
    content: "CODING TASK 1: Restructure repo into pnpm workspace monorepo. Extract 22 shadcn components to packages/ui, auth hooks to packages/auth, analytics to packages/analytics. Scaffold LaunchFree frontend + API."
    status: pending
  - id: state-data
    content: "CODING TASK 2: Build 50-state LLC formation rules (JSON + validation) AND 50-state tax calculations (JSON + validation) in packages/data/. Build shared state engine. Set up n8n validation agent."
    status: pending
  - id: studio-agents
    content: "CODING TASK 3: Build sankalpsharma.com landing page. Build chat widget component. Build n8n support agent workflow. Set up LaunchFree social workflows in n8n + Postiz. Migrate DNS subdomains."
    status: pending
  - id: notion-migrate
    content: Migrate Notion docs to Google Drive. Update n8n workflow outputs from Notion to GDrive API.
    status: pending
  - id: filefree-background
    content: "BACKGROUND: Continue EFIN application + Column Tax partnership while building LaunchFree"
    status: pending
isProject: false
---

# Definitive Execution Plan: LaunchFree + FileFree Venture

**Decisions locked**: LaunchFree (launchfree.ai). Google Drive. Google Workspace. No Chatwoot. No "Adulting OS." Build LaunchFree first.

---

## Pre-Code: Google Workspace + Domain Setup

### Google Workspace ($6/mo, one user)

- **Primary domain**: sankalpsharma.com
- **Secondary domains** (free to add): launchfree.ai, filefree.tax
- **How it works**: Add each domain in Admin Console > Domains > Manage domains. Set MX records on each domain to point to Google. Create aliases (support@, hello@) under Users > Aliases.
- **Reply-as**: Settings > Accounts > "Send mail as" -- add each alias. When replying to [support@launchfree.ai](mailto:support@launchfree.ai), Gmail sends FROM that address. Customer never sees your personal email.
- **Labels**: Auto-filter by recipient. Label "LaunchFree" for *@launchfree.ai, "FileFree" for *@filefree.tax.
- **GDrive MCP**: Add `@modelcontextprotocol/server-gdrive` to `.cursor/mcp.json`. Enables Cursor to read/write Google Docs directly.

### Google Drive Structure ("Venture HQ")

```
Venture HQ/
  Strategy/
    Vision & North Star.gdoc
    Decision Log.gdoc
    Competitive Landscape.gdoc
  LaunchFree/
    PRD.gdoc
    Tasks.gdoc
    State Formation Rules (Reference).gsheet
    Partnership Pipeline.gsheet
  FileFree/
    PRD.gdoc
    Tasks.gdoc
    Tax Data Reference.gsheet
    Partnership Pipeline.gsheet
  Operations/
    Credentials Registry.gdoc
    Infrastructure Map.gdoc
    Monthly Burn Tracker.gsheet
  Legal/
    Privacy Policy Drafts.gdoc
    Terms of Service.gdoc
  Content/
    Content Calendar.gsheet
    Social Media Playbook.gdoc
```

---

## Workstream 1: Repository Restructure (Monorepo)

### Target Structure

```
venture/
  apps/
    filefree/                   (Next.js -- moved from web/)
      src/
        app/                    (FileFree pages: /, /file/*, /demo, /auth/*, etc.)
        components/             (FileFree-specific: nav, auth-provider, etc.)
        hooks/                  (FileFree-specific: use-filing, use-tax)
        lib/                    (FileFree-specific: tax-estimator, image-quality)
      package.json
      next.config.js
      tsconfig.json

    launchfree/                 (Next.js -- NEW, scaffolded)
      src/
        app/                    (LaunchFree pages: /, /form/*, /auth/*, etc.)
        components/             (LaunchFree-specific components)
        hooks/                  (LaunchFree-specific hooks)
        lib/                    (LaunchFree-specific lib)
      package.json
      next.config.js
      tsconfig.json

  packages/
    ui/                         (shared shadcn components + theme)
      components/               (22 shadcn components from web/src/components/ui/)
      lib/utils.ts              (cn() function)
      lib/motion.ts             (Framer Motion presets)
      tailwind.css              (shared theme variables)
      package.json

    auth/                       (shared auth system)
      hooks/use-auth.ts
      hooks/use-idle-timeout.ts
      components/session-timeout-dialog.tsx
      lib/api.ts                (axios client + interceptors)
      package.json

    analytics/                  (shared PostHog + attribution)
      lib/posthog.ts
      lib/attribution.ts
      components/posthog-provider.tsx
      components/providers.tsx
      package.json

    data/                       (shared state data -- NEW)
      states/formation/         (50 state LLC formation rules)
      states/tax/               (50 state tax calculations)
      federal/2025.json         (moved from api/tax-data/)
      engine/                   (shared state engine pattern)
      package.json

  apis/
    filefree-api/               (Python -- moved from api/)
      app/                      (all existing Python code)
      requirements.txt
      Dockerfile
      pyproject.toml

    launchfree-api/             (Python -- NEW, scaffolded from filefree-api patterns)
      app/
        main.py
        config.py
        database.py
        models/                 (LLC, Formation, StateRule, etc.)
        routers/                (health, auth, formations, states)
        services/               (formation_service, pdf_service)
        repositories/
        schemas/
        utils/                  (copied: encryption, pii_scrubber, correlation, security)
      requirements.txt
      Dockerfile
      pyproject.toml

  infra/
    compose.dev.yaml            (updated for monorepo paths)
    hetzner/                    (existing Hetzner configs)
    env.dev.example

  docs/                         (repo-level docs, legacy reference)
    KNOWLEDGE.md                (stays version-controlled -- agent memory)

  pnpm-workspace.yaml
  package.json                  (root workspace config)
  Makefile                      (updated for monorepo commands)
  .gitignore
  render.yaml                   (updated for both APIs)
```

### Cursor Workspace Scoping

The monorepo supports focused AI context by opening specific directories as Cursor workspaces:

**When working on LaunchFree frontend**:

- Open `apps/launchfree/` as workspace root
- Cursor sees LaunchFree pages + shared packages (via node_modules symlinks from pnpm)
- `.cursor/rules/` in `apps/launchfree/` has LaunchFree-specific .mdc personas

**When working on FileFree frontend**:

- Open `apps/filefree/` as workspace root
- Cursor sees FileFree pages + shared packages

**When working on LaunchFree API**:

- Open `apis/launchfree-api/` as workspace root
- Cursor sees only Python backend code

**When working on shared packages**:

- Open `packages/` as workspace root
- Cursor sees all shared code (UI, auth, analytics, data)

**When working on infrastructure or cross-cutting**:

- Open repo root `venture/` as workspace

Each `apps/` and `apis/` directory has its own `.cursor/rules/` with product-specific .mdc personas. Shared personas (CFO, Strategy) can reference the Google Drive docs via GDrive MCP.

### Key Config Files

**pnpm-workspace.yaml**:

```yaml
packages:
  - "apps/*"
  - "packages/*"
```

**Root package.json**:

```json
{
  "private": true,
  "scripts": {
    "dev:filefree": "pnpm --filter filefree dev",
    "dev:launchfree": "pnpm --filter launchfree dev",
    "build:all": "pnpm -r build",
    "lint:all": "pnpm -r lint",
    "test:all": "pnpm -r test"
  }
}
```

**Package imports** (e.g., in `apps/launchfree/package.json`):

```json
{
  "dependencies": {
    "@venture/ui": "workspace:*",
    "@venture/auth": "workspace:*",
    "@venture/analytics": "workspace:*",
    "@venture/data": "workspace:*"
  }
}
```

### Migration Steps (Exact)

1. Create new repo (or rename current repo)
2. `pnpm init` at root, create `pnpm-workspace.yaml`
3. Create `packages/ui/`, move 22 files from `web/src/components/ui/` + `utils.ts` + `motion.ts`
4. Create `packages/auth/`, move `use-auth.ts`, `use-idle-timeout.ts`, `api.ts`, `session-timeout-dialog.tsx`
5. Create `packages/analytics/`, move `posthog.ts`, `attribution.ts`, `posthog-provider.tsx`, `providers.tsx`
6. Create `packages/data/` (new, empty -- populated in Workstream 2)
7. Move `web/` to `apps/filefree/`, update imports to use `@venture/*` packages
8. Move `api/` to `apis/filefree-api/`
9. Scaffold `apps/launchfree/` (copy `apps/filefree/` structure, strip FileFree-specific pages)
10. Scaffold `apis/launchfree-api/` (copy base patterns from `apis/filefree-api/`)
11. Update `infra/compose.dev.yaml` for new paths
12. Update `render.yaml` for both APIs
13. Update `Makefile` with monorepo commands
14. Update CI (GitHub Actions) for monorepo builds
15. Run `pnpm install`, verify `pnpm dev:filefree` and `pnpm dev:launchfree` both work

---

## Workstream 2: Shared Infrastructure Code

### 2A. 50-State LLC Formation Rules (`packages/data/states/formation/`)

**File structure**:

```
packages/data/states/formation/
  index.ts                    (exports all states, lookup functions)
  types.ts                    (TypeScript interfaces)
  states/
    AL.json                   (Alabama)
    AK.json                   (Alaska)
    ...                       (50 files, one per state)
    WY.json                   (Wyoming)
  validation/
    schema.ts                 (Zod schema for validation)
    validate.test.ts          (tests every state file against schema)
```

**Each state JSON file** (e.g., `WY.json`):

```json
{
  "state": "WY",
  "state_name": "Wyoming",
  "formation": {
    "entity_types": ["LLC", "Corporation", "Nonprofit"],
    "filing_fee_cents": 10000,
    "filing_fee_source": "https://sos.wyo.gov/Business/docs/LLCFees.pdf",
    "expedited_fee_cents": 10000,
    "expedited_turnaround_days": 1,
    "standard_turnaround_days": 15,
    "online_filing_url": "https://wyobiz.wyo.gov/",
    "filing_method": ["online", "mail"],
    "articles_of_organization_template": true
  },
  "naming_rules": {
    "required_designator": ["LLC", "L.L.C.", "Limited Liability Company"],
    "restricted_words": ["bank", "insurance", "trust"],
    "name_search_url": "https://wyobiz.wyo.gov/Business/FilingSearch.aspx",
    "name_reservation_fee_cents": 5000,
    "name_reservation_duration_days": 120
  },
  "registered_agent": {
    "required": true,
    "must_be_state_resident_or_entity": true,
    "commercial_ra_allowed": true
  },
  "annual_requirements": {
    "annual_report_required": true,
    "annual_report_fee_cents": 6000,
    "annual_report_due": "first day of anniversary month",
    "annual_report_url": "https://wyobiz.wyo.gov/",
    "state_tax_type": "none",
    "franchise_tax": false
  },
  "taxes": {
    "has_state_income_tax": false,
    "corporate_tax_rate": null,
    "sales_tax_rate": 4.0,
    "notes": "Wyoming has no state income tax or corporate tax"
  },
  "last_verified": "2026-03-15",
  "last_verified_source": "Wyoming Secretary of State website"
}
```

**Validation**: Zod schema ensures every state file has all required fields. Test suite validates all 50 files on every CI run. Any missing or malformed data fails the build.

### 2B. 50-State Tax Calculations (`packages/data/states/tax/`)

**File structure**:

```
packages/data/states/tax/
  index.ts
  types.ts
  states/
    AL.json through WY.json   (50 files)
  validation/
    schema.ts
    validate.test.ts
```

**Each state tax JSON file** (e.g., `CA.json`):

```json
{
  "state": "CA",
  "state_name": "California",
  "tax_year": 2025,
  "has_income_tax": true,
  "tax_type": "graduated",
  "brackets": {
    "single": [
      { "min": 0, "max": 1113600, "rate": 1.0 },
      { "min": 1113601, "max": 2639400, "rate": 2.0 },
      { "min": 2639401, "max": 4165200, "rate": 4.0 },
      { "min": 4165201, "max": 5783400, "rate": 6.0 },
      { "min": 5783401, "max": 8199000, "rate": 8.0 },
      { "min": 8199001, "max": 41685000, "rate": 9.3 },
      { "min": 41685001, "max": 50022000, "rate": 10.3 },
      { "min": 50022001, "max": 100044000, "rate": 11.3 },
      { "min": 100044001, "max": null, "rate": 12.3 }
    ],
    "married_joint": [ ... ],
    "head_of_household": [ ... ]
  },
  "standard_deduction": {
    "single": 573700,
    "married_joint": 1147400
  },
  "personal_exemption_cents": 15400,
  "source": "California Franchise Tax Board 2025 Tax Rate Schedules",
  "source_url": "https://www.ftb.ca.gov/file/personal/tax-rates.html",
  "all_values_in_cents": true,
  "last_verified": "2026-03-15"
}
```

**For states with no income tax** (AK, FL, NV, NH, SD, TN, TX, WA, WY):

```json
{
  "state": "TX",
  "state_name": "Texas",
  "tax_year": 2025,
  "has_income_tax": false,
  "brackets": null,
  "standard_deduction": null,
  "source": "Texas Constitution, Article VIII",
  "last_verified": "2026-03-15"
}
```

### 2C. State Engine Pattern (`packages/data/engine/`)

A shared TypeScript engine that both products import:

```typescript
// packages/data/engine/index.ts
export function getStateFormationRules(stateCode: string): StateFormationRules
export function getStateTaxRules(stateCode: string): StateTaxRules
export function calculateStateTax(stateCode: string, income: number, filingStatus: string): TaxResult
export function getAllStates(): StateSummary[]
export function getFormationFee(stateCode: string): number
```

LaunchFree imports `getStateFormationRules`, `getFormationFee`, `getAllStates`.
FileFree imports `getStateTaxRules`, `calculateStateTax`, `getAllStates`.
Both use the same engine pattern, same validation, same data structure.

### 2D. Automated State Data Validation (n8n Agent)

**Workflow**: `venture-state-data-validator`

- **Trigger**: n8n cron, 1st of every month
- **Action**:
  1. For each state, check Secretary of State website for formation fee changes
  2. Check state tax authority for rate changes
  3. Compare against current JSON data
  4. If discrepancy found: create GitHub Issue with details + source link
  5. Monthly summary email to founder (via Google Workspace)
- **IRS-specific**: Additional trigger in October when IRS publishes new Revenue Procedure. Parse for bracket/deduction changes. Create PR with proposed JSON updates.
- **Human review required**: No automated data changes. Agent flags, human verifies and merges.

### 2E. Other Shared Infrastructure

**Already exists, moves to packages**:

- PDF generation engine (`@react-pdf/renderer` patterns) -- stays in each app but shares templates from `packages/ui`
- Stripe billing -- implement once in `packages/core/billing/` when needed (Task 5.1 equivalent)
- Email templates -- implement in `packages/email/` using React Email or similar

**Backend patterns** (copy to `apis/launchfree-api/`, not imported as packages):

- Base repository class (`[apis/filefree-api/app/repositories/base.py](apis/filefree-api/app/repositories/base.py)`)
- Response envelope schema (`[apis/filefree-api/app/schemas/base.py](apis/filefree-api/app/schemas/base.py)`)
- Auth service + OAuth (`[apis/filefree-api/app/services/auth_service.py](apis/filefree-api/app/services/auth_service.py)`)
- Encryption, PII scrubber, correlation ID, rate limiter
- Config pattern (Pydantic BaseSettings)
- Database setup (async SQLAlchemy + Alembic)

---

## Workstream 3: sankalpsharma.com + Agent Operations

### 3A. sankalpsharma.com (Venture Studio Site)

**Stack**: Next.js on Vercel (free Hobby tier). Part of the monorepo:

```
venture/
  apps/
    studio/                     (sankalpsharma.com)
      src/app/
        page.tsx                (landing: "I build free tools")
        layout.tsx
      package.json
```

**Page content** (single page, minimal):

- Hero: Name, one-liner ("I build AI-powered tools that make adulting free"), photo/avatar
- Portfolio: Two cards linking to LaunchFree and FileFree with descriptions
- Optional: blog section (future)
- Footer: social links, email

**DNS**:

- sankalpsharma.com -> Vercel (A record)
- ops.sankalpsharma.com -> Hetzner CX33 (A record to existing VPS IP)
- social.sankalpsharma.com -> Hetzner CX33 (A record)

### 3B. Support Agent System (AI Email + Chat Widget)

No Chatwoot. No separate server needed. This runs on existing infrastructure.

**Architecture**:

```mermaid
graph TD
  subgraph userFacing ["User-Facing Channels"]
    widget["Chat Widget (React component in packages/ui)"]
    email["support@launchfree.ai (Google Workspace)"]
  end

  subgraph hetzner ["Existing Hetzner VPS"]
    n8n["n8n (ops.sankalpsharma.com)"]
    pg["PostgreSQL (conversation store)"]
  end

  subgraph ai ["AI Layer"]
    gpt["GPT-4o-mini (fast responses)"]
    gpt4["GPT-4o (complex escalation)"]
  end

  widget -->|"POST /webhook/support"| n8n
  email -->|"Google Apps Script forward"| n8n
  n8n -->|"RAG: search docs"| gpt
  n8n -->|"Store conversation"| pg
  n8n -->|"Respond"| widget
  n8n -->|"Reply via Gmail API"| email
  n8n -->|"Escalate: email founder"| email
```



**Chat Widget** (`packages/ui/components/chat-widget.tsx`):

- Floating bubble in bottom-right corner (shared across LaunchFree + FileFree)
- Click to expand chat window
- Sends messages via POST to n8n webhook
- Receives AI responses
- Stores conversation in localStorage for persistence
- Configurable: product name, accent color, knowledge base URL
- ~200 lines of React code, zero external dependencies

**n8n Support Workflow** (`venture-support-agent`):

1. Webhook receives: `{ message, conversation_id, product, user_email? }`
2. Load conversation history from PostgreSQL
3. Build context: product docs (from Google Drive via API) + FAQ + conversation history
4. Send to GPT-4o-mini with system prompt: "You are LaunchFree/FileFree support. Answer from docs. If unsure, say so."
5. If confidence low OR sentiment angry: escalate (email founder with context + draft reply)
6. Store response in PostgreSQL
7. Return response to webhook caller

**Email Support Flow**:

1. Customer emails [support@launchfree.ai](mailto:support@launchfree.ai)
2. Google Apps Script (or Google Workspace routing rule) forwards to n8n webhook
3. Same AI workflow processes the email
4. n8n replies via Gmail API (reply-as [support@launchfree.ai](mailto:support@launchfree.ai))
5. If AI can't resolve: forward to founder's inbox with AI draft

**Knowledge Base**:

- Source: Google Drive docs (product FAQs, guides, terms)
- Sync: n8n cron nightly, fetch docs via GDrive API, generate embeddings, store in PostgreSQL (pgvector)
- Or simpler: just include FAQ text directly in the system prompt (no vector DB needed for <100 FAQ entries)

**Memory impact on Hetzner**: Near zero. n8n webhooks execute on-demand, not resident. PostgreSQL already running. The only new load is GPT API calls (~$0.01/ticket).

### 3C. Social Media Agent Team

**Current state**: 6 FileFree n8n workflows already exist. Need to:

1. Rename to `filefree-`* prefix
2. Create parallel `launchfree-`* workflows
3. Add LaunchFree social accounts to Postiz

**LaunchFree Social Workflows** (new):


| Workflow                          | Trigger                | Output                                      |
| --------------------------------- | ---------------------- | ------------------------------------------- |
| `launchfree-social-content`       | Daily 8am cron         | 3 draft posts in Postiz (TikTok/IG/X)       |
| `launchfree-growth-content`       | Weekly Monday          | 1 SEO article draft in Google Drive         |
| `launchfree-strategy-checkin`     | Weekly Sunday          | Strategy summary in Google Drive            |
| `launchfree-partnership-outreach` | Bi-weekly              | Partnership email drafts in Google Drive    |
| `launchfree-compliance-monitor`   | Monthly 1st            | State filing deadline alerts                |
| `launchfree-qa-scan`              | On PR (GitHub webhook) | Security/PII scan results as GitHub comment |


**System prompts** for LaunchFree social content are different from FileFree:

- Voice: "Smart friend who makes business formation feel easy, not scary"
- Topics: LLC tips, business compliance, "did you know" facts, RA explained, state comparisons
- Hooks: "3 things you need before forming an LLC", "Wyoming vs Delaware: which is better?", "Your LLC costs less than your Netflix"

**Postiz setup**:

- Add LaunchFree social accounts as new channels in existing Postiz instance
- n8n workflows target LaunchFree channels via Postiz API

### 3D. DNS Migration Plan

**Current** (on filefree.tax):

- n8n.filefree.tax -> Hetzner
- social.filefree.tax -> Hetzner

**Target** (on sankalpsharma.com):

- ops.sankalpsharma.com -> Hetzner (n8n)
- social.sankalpsharma.com -> Hetzner (Postiz)

**Steps**:

1. Add A records on sankalpsharma.com DNS pointing to Hetzner VPS IP
2. Update Caddy config on Hetzner to serve both old and new domains
3. Test new domains work
4. Remove old filefree.tax subdomains (or keep as redirects)

---

## Cost Summary


| Item                    | Monthly        | Notes                                    |
| ----------------------- | -------------- | ---------------------------------------- |
| Hetzner CX33            | EUR 5.49 (~$6) | n8n, Postiz, Temporal, ES, support agent |
| Render (FileFree API)   | $7             | Starter plan                             |
| Render (LaunchFree API) | $7             | Starter plan                             |
| Vercel x3               | $0             | filefree, launchfree, studio (all Hobby) |
| Neon x2                 | $0             | Separate free-tier projects              |
| Upstash x2              | $0             | Separate free-tier projects              |
| Google Workspace        | $6             | Email + Drive for all domains            |
| launchfree.ai domain    | ~$5            | .ai annual                               |
| OpenAI (variable)       | ~$5-15         | n8n workflows + support agent            |
| **Total**               | **~$36-46/mo** | up from $12.49                           |


---

## Sequencing

**Week 1-2 (Now)**:

- Register launchfree.ai domain
- Secure @launchfree social handles
- Set up Google Workspace on sankalpsharma.com
- Create Google Drive "Venture HQ" folder structure
- Form LLC (Sharma Ventures or similar)

**Week 3-4**:

- Restructure repo into pnpm workspace monorepo (Workstream 1)
- Extract shared packages (ui, auth, analytics)
- Scaffold LaunchFree apps (frontend + API)

**Week 5-8**:

- Build 50-state formation rules dataset (Workstream 2A) -- research-heavy
- Build 50-state tax calculations dataset (Workstream 2B) -- research-heavy
- Build state engine pattern (Workstream 2C)
- Set up state data validation n8n agent (Workstream 2D)

**Week 9-12**:

- Build LaunchFree MVP (formation wizard, PDF generation, payment)
- Build sankalpsharma.com landing page (Workstream 3A)
- Build chat widget + support agent (Workstream 3B)
- Set up LaunchFree social workflows + Postiz channels (Workstream 3C)
- Migrate DNS subdomains (Workstream 3D)

**Summer 2026**: Launch LaunchFree

**Background (continuous)**: EFIN application, Column Tax partnership, MeF certification prep for FileFree January 2027 launch