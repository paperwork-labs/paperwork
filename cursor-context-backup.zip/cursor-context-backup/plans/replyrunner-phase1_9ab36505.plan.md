---
name: replyrunner-phase1
overview: "Deliver detailed foundations: data models + migration, auth/OAuth scaffolding, Gmail ingest skeleton, and consolidated documentation replacing prior docs."
todos:
  - id: models-migration
    content: Implement models and initial Alembic migration
    status: completed
  - id: auth-scaffold
    content: Add Google allowlist auth scaffold + cron secret
    status: completed
  - id: gmail-skeleton
    content: Add Gmail ingest service/job stubs + route
    status: completed
  - id: frontend-hook
    content: Wire frontend to API base and placeholder status
    status: completed
  - id: doc-consolidation
    content: Create docs, delete CONTEXT/BUILD_PLAN
    status: completed
---

# Phase 1 Foundations Plan (Detailed, LLM/RAG Ready)

## Scope

Deliver three pillars together: (1) data models + initial Alembic migration (LLM/RAG-ready), (2) auth/OAuth scaffolding with allowlist and cron secret, and (3) Gmail ingest skeleton. Replace the existing CONTEXT.md and BUILD_PLAN.md with a consolidated doc set (project overview + detailed data model + auth/Gmail specifics).

## Steps

1) **Schema & Migration (LLM-ready)**

- Implement ORM models in `backend/app/models/` for User, Account, Agent, EmailThread, EmailMessage, Attachment, Document, DocumentChunk, Embedding, Job, AuditEvent, LLMArtifact; wire metadata in `app/models/base.py`.
- LLM-friendly structures: `Agent` persona/toolset/default_filters; `EmailThread`/`EmailMessage` category/topic tags (JSON) for agent buckets; `Document` collection/project; embeddings carry model/dimension/metadata (user/agent/account/thread/category/project); future pgvector path noted.
- Constraints/indexes: unique (provider, provider_account_id); unique Gmail IDs; history_id index; message sent_at index; category/topic index; attachment hash dedupe; document hash dedupe; chunk_index index; embedding unique per (chunk_id, model) when used; job index (status, type); audit index (user_id, created_at).
- Alembic: initial revision in `backend/alembic/versions/`; ensure imports in `alembic/env.py`; keep `Base.metadata` wired; placeholder vector storage with future pgvector migration.
- Env: extend `.env.example` for DB/Redis/auth/Google/cron secret.

2) **Auth/OAuth Scaffolding**

- Google OAuth endpoints: start flow + callback; store refresh token/expiry/scopes in Account after allowlist (`AUTH_ALLOWED_EMAILS`).
- Token security: encrypt refresh token at rest (placeholder abstraction), avoid logging; optional cached access_token.
- Session/JWT issuance: short-lived access + refresh using `APP_SECRET_KEY`; dependency for protected routes (user context, agent scoping).
- Cron secret dependency: env `CRON_SECRET`; protect job-trigger endpoints.

3) **Gmail Ingest Skeleton**

- Service layer (`backend/app/services/gmail.py`): build Gmail client from stored tokens; list threads/messages by query/label; attachment size guard.
- Job handlers (worker): enqueue via RQ; stub job to fetch/save threads/messages/attachments idempotently (unique Gmail IDs, hash dedupe); populate categories/topics from labels/custom rules hook for agent-specific buckets.
- API trigger: minimal endpoint (cron-secret protected and/or authed) to enqueue sync for an account/agent with query/label params; respond with job id.

4) **Frontend Hook (lightweight)**

- Use `NEXT_PUBLIC_API_BASE`; add placeholder status/auth card on `frontend/src/app/page.tsx` pointing to health/auth endpoints.

5) **Documentation Consolidation**

- Create `docs/PLAN.md` (single source): vision/scope, architecture stance (backend-heavy, read-only frontend), runbook (dev/migrate/test), env keys, milestones; include auth (allowlist/JWT/cron secret), OAuth flow, Gmail ingest flow/limits, docker usage, CI/CD outline, and TDD expectations.
- Create `docs/DATA_MODEL.md`: entity definitions, relationships, constraints/indexes, LLM/RAG notes (categories/topics, collections, embeddings metadata, pgvector path), security notes.
- Optionally `docs/AUTH_GMAIL.md`: OAuth steps, token storage/encryption, allowlist, cron secret enforcement, Gmail sync pipeline, quota and attachment caps, job contracts, idempotency, labeling/categorization hooks.
- Remove `CONTEXT.md` and `BUILD_PLAN.md` after replacing content in new docs.

## Validation

- Tests/TDD: keep health tests; add config/env parsing tests; model import/schema sanity tests; auth/OAuth dependency unit tests with mocks; Gmail service/job stubs fully mocked (no network); job enqueue tests; minimal frontend smoke if trivial.
- Retrieval quality: plan per-thread/agent summaries, prompt-versioning and feedback on `LLMArtifact`; include optional semantic cache later.
- Automation/CI/CD: `make dev`/docker-compose seamless; migrations via `make migrate`; lint/format/test targets wired. CI/CD blueprint: GitHub Actions to lint/test/build images, run migrations pre-deploy; target hosts (Fly/Render/Railway) + frontend (Vercel or container); secrets management and rollout; staging + smoke health check; rollback notes; tagged images per env.
- Resilience/observability: idempotent jobs, poison/dead-letter note; rate-limit/backoff for Gmail; logs/metrics for ingest and queue depth; audit events for access/search; PII logging ban.
- Run `make lint`, `make test`, `make migrate` (against compose DB) to verify migration applies.