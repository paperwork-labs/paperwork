---
name: Fix Coverage Monitor & Toggle
overview: Address redis_client error, recount tracked universe, and add dashboard toggle to disable 5m backfill with backend enforcement.
todos: []
---

# Coverage Monitor Fix & 5m Toggle

## Scope

- Fix `monitor_coverage_health` failing on missing `redis_client`.
- Recount tracked universe (SP500+NASDAQ100+DOW30 + portfolio) and clarify the 184 vs expected count.
- Add Admin Dashboard coverage toggle to disable 5m backfill (persisted, backend-enforced), while daily backfill remains on.

## Plan

1) **Trace redis_client error**

- Inspect `monitor_coverage_health` in `backend/tasks/market_data_tasks.py` and ensure it uses the singleton `market_data_service` with `redis_client` property (now only one `MarketDataService` class in `backend/services/market/market_data_service.py`).
- Add a minimal guard/log around redis access if needed; ensure celery imports the correct instance (no shadowing).

2) **Recount tracked universe & explain 184**

- Run `refresh_index_constituents` then `update_tracked_symbol_cache`; query `IndexConstituent` + portfolio to compute the expected tracked count.
- Report the count breakdown (by index + portfolio) and reconcile vs 184; identify any missing constituents (e.g., provider fetch failure) and re-run fetch if needed.

3) **Toggle to disable 5m backfill (dashboard)**

- Backend: add a persisted flag (e.g., Redis key `coverage:backfill_5m_enabled` default true) and enforce in 5m backfill entrypoints (`backfill_5m_last_n_days`, `backfill_5m_for_symbols`, `bootstrap_universe` chaining) so daily backfills continue.
- Frontend: add an Admin Dashboard coverage card toggle that reflects the flag and calls a small admin API to set/unset it.
- Expose a lightweight admin route (e.g., `POST /market-data/admin/coverage/backfill-5m-toggle`) returning current state.

4) **Validate**

- Re-run `monitor_coverage_health` task; confirm no AttributeError and Redis writes succeed.
- Show tracked count after refresh/cache rebuild; confirm daily backfill can be run; verify toggle blocks 5m backfill but not daily.

## Notes

- No plan edits; minimal surface area: `backend/tasks/market_data_tasks.py`, `backend/api/routes/market_data.py` (small admin toggle), `frontend/src/pages/AdminDashboard.tsx` (toggle UI), and, if needed, `frontend/src/utils/coverage.ts` for action wiring.