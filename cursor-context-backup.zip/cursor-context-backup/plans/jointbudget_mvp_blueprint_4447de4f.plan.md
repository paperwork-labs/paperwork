---
name: JointBudget MVP Blueprint
overview: Define a concrete, buildable MVP spec for a multi-tenant household finance app with iOS+Web parity, Plaid aggregation, server-side budgeting/allowances, and a minimal AI insights layer (categorization + 1–2 monthly recommendations).
todos:
  - id: decide-foundation
    content: Create repo structure with FastAPI domain modules, Postgres schema/migrations, Redis + job worker skeleton, and OpenAPI-first API contract.
    status: completed
  - id: implement-auth
    content: Implement Sign in with Apple + magic link auth, sessions (JWT access+refresh), and household scoping middleware.
    status: completed
    dependencies:
      - decide-foundation
  - id: plaid-link-sync
    content: Implement Plaid link token + exchange, store items/accounts, webhook receiver, and scheduled sync job with idempotent ingestion.
    status: completed
    dependencies:
      - implement-auth
  - id: transactions-inbox
    content: Implement transaction state machine, attribution suggestions, inbox + detail endpoints, bulk confirm, and audit logging.
    status: completed
    dependencies:
      - plaid-link-sync
  - id: allowances-budgets
    content: Implement monthly allowances, enforcement on confirm, budget summaries + 3-month trends, and dashboard endpoints.
    status: completed
    dependencies:
      - transactions-inbox
  - id: ai-categorization-insights
    content: Implement AI categorization suggestions + monthly 1–2 recommendations stored with rationale and rendered in dashboard/insights views.
    status: completed
    dependencies:
      - allowances-budgets
  - id: client-parity
    content: Build iOS + web MVP screens (dashboard/inbox/detail/budgets/insights/monthly review web-first) against shared APIs.
    status: completed
    dependencies:
      - ai-categorization-insights
---

# JointBudget MVP (iOS + Web) — Finalized Blueprint

## MVP scope (ship in 4–8 weeks part-time)

- **Tenancy**: `Household` is the tenant. MVP assumes **one household per user** (keep schema flexible).
- **Auth (both)**:
- **Sign in with Apple** (OIDC) for iOS + web.
- **Email magic link** for web/iOS fallback.
- Backend issues **JWT access + refresh** tokens.
- **Aggregation**:
- **Plaid**: Link flow, token exchange, webhooks, daily scheduled sync.
- Start with **sandbox + 1 real institution**.
- **Transactions**:
- Ingestion (pending/posted), dedupe, enrichment, and a server-enforced **state machine**: `new → proposed → confirmed → locked`.
- **Inbox**: per-person attribution suggestions; bulk confirm/edit.
- **Split** support (simple: 50/50 + custom amounts).
- **Allowance + Budgets (server-side rules)**:
- Per-user monthly **unlogged allowance** (e.g., $500) for **confirmed discretionary transactions without detailed category**.
- Once exceeded, API **requires category assignment** to confirm new discretionary tx.
- Family budget by category + 3-month trends for key categories.
- **AI (minimal but meaningful)**:
- **Auto-categorization suggestion** per new tx with confidence + stored rationale.
- **Monthly 1–2 household insights** (budget adjustment + savings/investments allocation suggestion), each with an explicit “why”.
- **Multi-client parity**:
- Web and iOS expose the same MVP surface: **Dashboard, Inbox, Transaction Detail, Budgets, Insights, Monthly Review (web-first)**.

## Architecture (single source of truth)

- **Clients**: iOS (SwiftUI) + Web (Next.js/React).
- **Backend**: **FastAPI (Python)**, domain-first services (business logic not in controllers).
- **API**: REST + OpenAPI; household-scoped auth middleware.
- **Workers**: background jobs for Plaid sync, AI categorization, allowance rollups, insight generation.
- **DB**: Postgres; **Redis** for idempotency + job queue.
```mermaid
flowchart TD
  subgraph clients [Clients]
    iOSClient[iOS_SwiftUI]
    WebClient[Web_NextJS]
  end

  subgraph backend [Backend_FastAPI]
    APIGateway[REST_API]
    AuthSvc[Auth_Tenancy]
    TxSvc[Transactions]
    BudgetSvc[Budgets_Allowances]
    InsightSvc[Insights_AI]
    NotifySvc[Digests]
  end

  subgraph workers [Workers]
    SyncJob[PlaidSyncJob]
    CatJob[AICategorizeJob]
    InsightJob[MonthlyInsightsJob]
  end

  Postgres[(Postgres)]
  Redis[(Redis)]
  Plaid[Plaid]
  LLM[LLM_API]

  iOSClient --> APIGateway
  WebClient --> APIGateway

  APIGateway --> AuthSvc
  APIGateway --> TxSvc
  APIGateway --> BudgetSvc
  APIGateway --> InsightSvc
  APIGateway --> NotifySvc

  TxSvc --> Postgres
  BudgetSvc --> Postgres
  InsightSvc --> Postgres
  AuthSvc --> Postgres
  NotifySvc --> Postgres

  SyncJob --> Plaid
  SyncJob --> TxSvc
  CatJob --> LLM
  CatJob --> InsightSvc
  InsightJob --> LLM
  InsightJob --> InsightSvc

  SyncJob --> Redis
  CatJob --> Redis
  InsightJob --> Redis

  Plaid -->|webhooks| APIGateway
```




## Domain modules (FastAPI)

- **Auth & Tenancy**: households, users, membership/roles, sessions/refresh tokens.
- **Aggregation**: Plaid items/accounts, webhooks, sync cursor, dedupe.
- **Transactions**: state machine, attribution engine, splitting, notes/tags.
- **Budgets & Allowances**: monthly periods, discretionary allowance enforcement, trend summaries.
- **Insights & AI**: categorization suggestions; monthly recommendations; explainability.
- **Digests/Notifications**: weekly digest endpoint (email job optional in MVP).

## Data model (MVP tables)

Keep your detailed field set; this is the finalized **minimum**.

- `households`
- `users`
- `household_memberships` (keep, even if 1 household/user in MVP)
- `plaid_items` (access token stored securely; item status)
- `accounts` (household_id, plaid_account_id, owner_user_id nullable for joint)
- `transactions` (household_id, account_id, amount, currency, dates, merchant, description, status, owner_user_id, category_id nullable, note, metadata JSONB, idempotency_key)
- `transaction_splits`
- `categories` (global defaults + household custom)
- `tags`, `transaction_tags`
- `budgets` (household/month; category allocations optional MVP)
- `allowances` (user/month: allowance_amount, unlogged_threshold_amount)
- `allowance_usage` (tracks confirmed discretionary uncategorized usage)
- `attribution_rules` (card/merchant/history-derived)
- `household_goals` (simple MVP: emergency_fund_target, monthly_savings_target)
- `ai_categorizations` (transaction_id, suggested_category_id, confidence, rationale, model_version, accepted)
- `ai_recommendations` (household/month, type, title, body, suggested_action, confidence, rationale, inputs_ref, model_version)
- `audit_events` (who changed what; before/after)

### Key invariants (server-enforced)

- **Tenancy**: every query/row is scoped to `household_id`.
- **State machine**:
- `new → proposed`: backend sets suggested owner/category.
- `proposed → confirmed`: allowed when required fields satisfied.
- `confirmed → locked`: month close/reconcile action.
- **Allowance gate**:
- If user’s monthly `allowance_remaining < 0`, then confirming a discretionary tx requires `category_id` (and optionally a note).

## API surface (finalized)

### Auth

- `POST /auth/apple` (exchange Apple identity token → session)
- `POST /auth/magic-link` (request)
- `POST /auth/magic-link/verify` (verify code/token → session)
- `POST /auth/refresh`
- `GET /me`

### Household & goals

- `GET /household`
- `PATCH /household`
- `GET /goals`
- `PATCH /goals`

### Plaid

- `POST /plaid/link-token`
- `POST /plaid/exchange`
- `POST /plaid/webhook`

### Accounts

- `GET /accounts`
- `PATCH /accounts/{id}` (owner_user_id, label)

### Transactions

- `GET /transactions?status=&owner=&month=`
- `GET /transactions/search?q=&from=&to=&merchant=&tag=`
- `POST /transactions/{id}/assign` (owner_user_id, category_id, tags, note, state_transition)
- `POST /transactions/{id}/split`
- `POST /transactions/bulk-confirm` (ids + optional overrides)
- `POST /transactions/{id}/lock`

### Budgets & allowances

- `GET /budgets/current`
- `PATCH /budgets/current` (optional MVP)
- `GET /allowances/current` (remaining headroom per person)

### Insights

- `GET /insights?month=`
- `POST /insights/regenerate` (admin; throttled)

### Digest

- `GET /digest/weekly`

## AI layer (MVP outputs and storage)

### Categorization (online or nearline)

- Trigger: on ingestion + when user edits merchant/category.
- Store in `ai_categorizations`:
- `confidence` (0–1), `rationale` (plain text), `model_version`, `inputs_ref`.
- UI behavior: suggested category is preselected; “Why?” reveals rationale.

### Monthly recommendations (batch job)

Generate **1–2** per household per month:

- **Lifestyle creep**: detect category/person increase vs 3-month baseline.
- **Savings allocation**: suggest a monthly transfer amount based on observed spend volatility + user goal.

Store in `ai_recommendations` with `suggested_action` + `rationale`.

## UX parity (web + iOS)

- **Dashboard**: allowance remaining per person, key category trend tiles, latest 2 insights cards.
- **Inbox**: new/proposed tx list with chips (owner/category/confidence), bulk confirm.
- **Transaction detail**: accept/edit owner/category/tags, split, note, rationale.
- **Budgets**: per-person discretionary + family categories + 3-month trend.
- **Childcare lens** (MVP-lite): preset filter by tag/category.
- **Monthly review (web-first)**: open items, insights, “close month” (locks tx).

## Security & privacy (MVP-good, not painted into a corner)

- Store Plaid access tokens encrypted at rest (KMS/secret manager), never logged.
- Strict household scoping; server-side authorization checks for every row.
- Audit log for transaction edits and confirmations.
- AI explainability stored with each suggestion/recommendation; allow users to override.

## Execution plan (milestones)

- **Milestone A**: Auth + tenancy + OpenAPI contract; iOS/web can login and call `/me`.
- **Milestone B**: Plaid link + accounts; webhook handler stub + scheduled sync.
- **Milestone C**: Transactions ingest + dedupe + state machine + inbox endpoints.
- **Milestone D**: Allowance + budget services + dashboard summaries.
- **Milestone E**: AI categorization job + monthly insights job + UI surfacing.
- **Milestone F**: Monthly review + locking + digest endpoint.

## Open items (explicitly deferred)

- Net-worth aggregation and investments account syncing (beyond Plaid transactions).
- Bill pay, recurring bill negotiation, subscription cancellation workflows.
- Advisor/coach view and external sharing controls.
- Push notifications (start with in-app + optional email digest).
- Complex budgeting systems (envelopes/zero-based), multi-currency edge cases, advanced reconciliation.
- Receipts, attachments, OCR, and document storage.
- Staging environment (design for it; do not implement yet).
- Multi-region, HA, autoscaling, Kubernetes/Helm.

## Development & Environment Setup (Cursor / tooling)

### Environments (conceptual)

We start with **two conceptual environments**:

- **local**: runs on a personal MacBook via Docker (backend, Postgres, Redis, web, workers).
- **prod**: future remote deployment (Fly.io/Render/whatever). The code must be **12‑factor friendly** and configurable only via environment variables.

There is **no separate staging** initially; design so staging is added later by wiring different env vars and separate DBs.

### Docker usage (local only, for now)

- Use Docker primarily to run:
- Postgres
- Redis
- Backend (FastAPI)
- Web (Next.js)
- Optional: a lightweight worker container (Plaid sync, AI jobs)
- The full stack should come up locally with **one command** from a top-level infra folder, e.g. `docker compose up`.
- Code must **not assume it’s always in Docker**:
- It should be possible to run Postgres/Redis in Docker, and run backend/web directly on macOS (`uvicorn` / `npm run dev`) by changing env vars (hostnames/ports).

### Env files & secrets (dev vs prod)

- Use `.env`-style configuration; **no secrets hardcoded** in code.
- Expected file patterns:
- `backend/.env.example`: template with required keys, no real secrets.
- `web/.env.example`: template with required keys, no real secrets.
- `infra/.env.dev`: used by docker-compose for local dev (Plaid sandbox keys, dev DB creds, etc.).
- Real `.env` files (`.env.dev`, `.env.local`, etc.) must be **gitignored**.
- Local/dev assumptions:
- **Plaid sandbox only** (for now).
- A simple dev JWT secret is okay (must differ from prod).
- Code must read all sensitive data from environment variables:
- DB host/port/user/password/name
- Redis host/port
- JWT secret / token expiry
- Plaid client id / secret / env
- LLM API key

Example non-real dev variables:

```env
NODE_ENV=development

# DB
DB_HOST=db
DB_PORT=5432
DB_USER=moneyapp
DB_PASSWORD=moneyapp_dev
DB_NAME=moneyapp_dev

# Redis
REDIS_HOST=redis
REDIS_PORT=6379

# Auth
JWT_SECRET=dev-secret-not-for-prod
ACCESS_TOKEN_TTL_MIN=15
REFRESH_TOKEN_TTL_DAYS=30

# Plaid (sandbox only in local/dev)
PLAID_ENV=sandbox
PLAID_CLIENT_ID=your_sandbox_id_here
PLAID_SECRET=your_sandbox_secret_here

# AI / LLM
LLM_PROVIDER=openai
LLM_MODEL=gpt-4o-mini
LLM_API_KEY=your_dev_llm_key_here
```



### Migrations / DB schema

- Use a proper migration tool (e.g., **Alembic** for SQLAlchemy).
- Provide a **single command** to apply migrations locally, e.g. `make migrate` or `poetry run alembic upgrade head`.
- The same mechanism must work for prod later (CI/CD or deploy step).

### Logging & safety

- Console logging is fine for MVP, but **never log secrets** (Plaid access tokens, API keys, JWT secrets, raw Apple tokens, etc.).
- Logs should include:
- timestamp
- request_id (if available)
- household_id (when in a request context)
- Keep a small abstraction so we can later swap console logging for structured logging.

### Production assumptions (design now, implement later)

- The app must be **12‑factor friendly**:
- Config via env vars
- Stateless containers (no local disk persistence except tmp)
- DB and Redis as external services
- No hardcoded file paths; everything must run inside containers or on a server.
- Auth & tenancy checks must work identically in all environments (no local special cases).
- Avoid provider-specific assumptions until a deploy target is selected.

### Non-goals (explicitly out of scope for now)

- No Kubernetes/Helm or complex infra.
- No separate staging environment yet.