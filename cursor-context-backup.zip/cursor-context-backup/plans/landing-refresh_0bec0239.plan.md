---
name: landing-refresh
overview: Polish the root landing page and developer shortcuts for a professional personal site entry to the private app.
todos:
  - id: landing-ui
    content: Componentize landing with hero/status/highlights/now/life/roadmap
    status: completed
  - id: styling
    content: Adjust global styles/theme spacing for polished look
    status: completed
  - id: dx-scripts
    content: Add npm scripts mirroring make targets and align Makefile if needed
    status: completed
  - id: docs
    content: Update README snippet for landing, status, commands
    status: completed
---

# Plan

1) Build a componentized landing (`src/app/page.tsx` + `src/app/components/*`) with hero (name/tagline/primary sign-in CTA + secondary resume/contact), DB-backed agent status strip (Doorvest/TRIS) derived from Prisma `Agent` data, highlights grid (Work, Personal Agents, Systems, Now), Now strip bullets, Life block, family teaser, and Phase 2/3 roadmap blurb.
2) Tune styling in `src/app/globals.css` (and small component styles) for a clean, minimal theme with room for future posts/gallery.
3) Developer DX: extend `package.json` scripts to mirror Makefile targets (up/down/logs/rebuild/ps) and keep Makefile entries aligned if needed.
4) Update `README.md` snippet to describe the refreshed landing, agent status hookup, and the npm/Makefile shortcuts.