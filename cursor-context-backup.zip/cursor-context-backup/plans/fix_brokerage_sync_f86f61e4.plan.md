---
name: Fix Brokerage Sync
overview: Fix the brokerage sync infrastructure so that TastyTrade and IBKR account data actually flows from broker APIs through Celery into the database and surfaces in the Portfolio UI.
todos:
  - id: fix-celery-queue
    content: Remove task_routes from celery_app.py so sync tasks go to default queue
    status: pending
  - id: fix-celery-task-asyncio
    content: Fix sync_account_task to use explicit event loop (asyncio.new_event_loop) instead of asyncio.run()
    status: pending
  - id: fix-task-status-tracking
    content: Add RUNNING status update at start of sync_account_task, fix the RUNNING->QUEUED overwrite in the API endpoint
    status: pending
  - id: suppress-newrelic-dev
    content: Remove newrelic-admin wrapper from celery_worker command in compose.dev.yaml
    status: pending
  - id: cleanup-duplicate-accounts
    content: Delete duplicate broker accounts (ids 16, 17) and reset stuck QUEUED statuses via psql
    status: pending
  - id: add-credentials-env
    content: Prompt user to add TASTYTRADE_USERNAME/PASSWORD and IBKR_FLEX_TOKEN/QUERY_ID to infra/env.dev
    status: pending
  - id: rebuild-and-verify
    content: Rebuild celery worker, trigger sync, verify positions land in DB
    status: pending
isProject: false
---

# Fix Brokerage Sync End-to-End

## Problem Summary

**Zero positions synced. Ever.** All 5 broker accounts show `QUEUED` or `NEVER_SYNCED` status with `last_successful_sync = NULL`. Root cause is a **Celery queue mismatch** -- tasks are routed to a queue nobody listens on.

```mermaid
flowchart LR
    API["POST /accounts/ID/sync"] -->|"sync_account_task.delay()"| Redis["Redis: account_sync queue"]
    Redis -.->|"NOBODY CONSUMING"| Void["Tasks pile up forever"]
    Worker["Celery Worker"] -->|"listens on"| Default["Redis: celery queue"]
```



## Fix 1: Celery Queue Mismatch (the blocker)

In `[backend/tasks/celery_app.py](backend/tasks/celery_app.py)` line 19, tasks matching `backend.tasks.account_sync.*` are routed to the `account_sync` queue, but the worker command in `[infra/compose.dev.yaml](infra/compose.dev.yaml)` line 101 starts with `--loglevel=info` only (no `-Q` flag), so it only listens on the default `celery` queue.

**Fix**: Remove the task routing entirely so all tasks go to the default `celery` queue. This is simpler than maintaining separate queues during development:

```python
# celery_app.py line 18-20 -- remove these 3 lines:
task_routes={
    "backend.tasks.account_sync.*": {"queue": "account_sync"},
},
```

## Fix 2: Add Broker Credentials to `infra/env.dev`

The `[infra/env.dev](infra/env.dev)` file (gitignored) needs the following vars. The user confirmed they have credentials for both:

- `TASTYTRADE_USERNAME=<your_tt_user>`
- `TASTYTRADE_PASSWORD=<your_tt_pass>`
- `IBKR_FLEX_TOKEN=<your_flex_token>`
- `IBKR_FLEX_QUERY_ID=<your_flex_query_id>`

These are read by `[backend/config.py](backend/config.py)` lines 28-40 via `pydantic_settings.BaseSettings`.

## Fix 3: Clean Up Duplicate Accounts

The DB has 5 accounts with duplicates:


| id  | broker     | number       | notes                           |
| --- | ---------- | ------------ | ------------------------------- |
| 1   | SCHWAB     | 13922637     | keep or remove                  |
| 14  | TASTYTRADE | 5WZ21096     | keep                            |
| 15  | IBKR       | IBKR_FLEX    | keep (has sync attempt)         |
| 16  | SCHWAB     | SCHWAB_OAUTH | duplicate placeholder -- delete |
| 17  | IBKR       | IBKR_FLEX    | duplicate of 15 -- delete       |


Run via psql to clean up:

```sql
DELETE FROM broker_accounts WHERE id IN (16, 17);
```

Also reset stuck `QUEUED` statuses so the UI shows a clean state:

```sql
UPDATE broker_accounts SET sync_status = 'NEVER_SYNCED', sync_error_message = NULL WHERE sync_status = 'QUEUED';
```

## Fix 4: Suppress New Relic Noise in Dev

The celery worker logs are 100% New Relic license key errors, drowning out all task output. The worker command in `[infra/compose.dev.yaml](infra/compose.dev.yaml)` line 101 wraps celery with `newrelic-admin run-program`. For dev, just run celery directly:

```yaml
# line 101 -- change from:
command: bash -lc "newrelic-admin run-program celery -A backend.tasks.celery_app worker --loglevel=info"
# to:
command: bash -lc "celery -A backend.tasks.celery_app worker --loglevel=info"
```

Same for celery_beat (line 132) and backend (line 68) if desired, but celery_worker is the priority since we need to read task logs.

## Fix 5: IBKR asyncio Event Loop Safety

The backend logs show `ib_insync.client` errors: "got Future attached to a different loop". This comes from the FastAPI process (which has a running asyncio loop) when something tries to use ib_insync directly.

In `[backend/tasks/account_sync.py](backend/tasks/account_sync.py)` line 16, the Celery task uses `asyncio.run()` which creates a fresh event loop -- this is correct for the worker. However, the `broker_sync_service.sync_account_async()` method at `[backend/services/portfolio/broker_sync_service.py](backend/services/portfolio/broker_sync_service.py)` line 172 is called from the Celery task context. The task should use the **sync** variant (`sync_account()`) instead, since `asyncio.run()` already provides the loop:

```python
# account_sync.py -- change sync_account_async → sync_account
result = broker_sync_service.sync_account(
    account_id=account_id, db=session, sync_type=sync_type
)
```

But `sync_account()` at line 107-117 has its own `_run()` helper that tries `loop.run_until_complete()` which will fail if no loop is running. Since the Celery task uses `asyncio.run()`, we should instead just call the sync service directly without the asyncio wrapper:

Better approach -- simplify the Celery task to not use `asyncio.run()` and instead call the sync method that handles its own async:

```python
@shared_task(name="backend.tasks.account_sync.sync_account_task")
def sync_account_task(account_id: int, sync_type: str = "comprehensive") -> dict:
    session = SessionLocal()
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result = loop.run_until_complete(
                broker_sync_service.sync_account_async(
                    account_id=account_id, db=session, sync_type=sync_type
                )
            )
        finally:
            loop.close()
        return result if isinstance(result, dict) else {"status": "success", "data": result}
    except Exception as e:
        return {"status": "error", "error": str(e)}
    finally:
        session.close()
```

## Fix 6: Update Sync Status on Task Pickup

Currently the sync endpoint at `[backend/api/routes/account_management.py](backend/api/routes/account_management.py)` line 219 sets status to `RUNNING`, then immediately overwrites to `QUEUED` at line 228. The Celery task itself never updates the status to `RUNNING` when it actually starts executing.

Add status update at the beginning of `sync_account_task`:

```python
# At the start of sync_account_task, after creating session:
account = session.query(BrokerAccount).filter(BrokerAccount.id == account_id).first()
if account:
    account.sync_status = SyncStatus.RUNNING
    account.last_sync_attempt = datetime.now()
    session.commit()
```

And set it to `SUCCESS`/`ERROR` at the end (already handled by `broker_sync_service`).

## Fix 7: Rebuild and Verify

After all changes:

1. Rebuild celery worker: `docker compose -f infra/compose.dev.yaml up -d --build celery_worker`
2. Verify worker listens and tasks are registered
3. Trigger sync from UI or curl
4. Check celery worker logs for task execution
5. Query DB for positions

## Verification Script

After the fix, run from the host or inside the backend container:

```bash
# Check worker is consuming correctly
docker exec axiomfolio-celery-worker celery -A backend.tasks.celery_app inspect active_queues

# Trigger a sync via API
curl -X POST http://localhost:8000/api/v1/accounts/14/sync \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"sync_type": "comprehensive"}'

# Watch celery logs
docker logs -f axiomfolio-celery-worker

# Check positions after sync
docker exec axiomfolio-postgres psql -U axiomfolio -d axiomfolio \
  -c "SELECT count(*) FROM positions; SELECT account_id, count(*), string_agg(DISTINCT symbol, ', ') FROM positions GROUP BY account_id;"
```

