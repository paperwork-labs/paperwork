---
name: History-period UI
overview: Replace the fixed “200d” snapshot history action with period-based controls and remove the standalone Admin Runbook page, keeping Admin Dashboard as the single ops surface.
todos: []
---

# Snapshot History Period UI + Runbook Consolidation

## Goals
- Replace the fixed **“Backfill Snapshot History (200d)”** button with a **period-based** backfill control.
- Keep **two** explicit operator actions in **Admin Dashboard → Advanced**:
  - **Backfill Snapshot History (since)** (existing date picker + button)
  - **Backfill Snapshot History (period)** (new period dropdown + button)
- Remove the **Admin Runbook** page/route entirely, so ops live in one place.

## Backend (no functional change required)
- Reuse existing endpoint `POST /api/v1/market-data/admin/snapshots/history/backfill-last-n-days` which already supports `days` and optional `since_date`.
- Ensure the period button maps period → trading days (approx):
  - `6mo → 126`, `1y → 252`, `2y → 504`, `5y → 1260`

## Frontend changes

### Admin Dashboard: simplify Snapshot History controls
- Update `[frontend/src/pages/AdminDashboard.tsx](frontend/src/pages/AdminDashboard.tsx)`:
  - Remove the **“Backfill Snapshot History (200d)”** button.
  - Add a compact **period selector** (6mo/1y/2y/5y) next to a single **“Backfill Snapshot History (period)”** button.
  - Keep the existing **since-date** picker + **“Backfill Snapshot History (since)”** button.
  - Keep the overall Advanced section clean by grouping the three backfill buttons together:
    - Daily bars (since)
    - Snapshot history (since)
    - Snapshot history (period)

### Remove Admin Runbook page
- Delete/stop routing to `[frontend/src/pages/AdminRunbook.tsx](frontend/src/pages/AdminRunbook.tsx)`.
- Update routing in `[frontend/src/App.tsx](frontend/src/App.tsx)` to remove lazy import + route `settings/admin/runbook`.
- Remove any links/nav entries pointing to the runbook route (likely in the settings/admin nav components).

## Tests

### Frontend
- Update existing tests that reference the old button text:
  - `[frontend/src/pages/__tests__/AdminDashboardCoverageRefresh.test.tsx](frontend/src/pages/__tests__/AdminDashboardCoverageRefresh.test.tsx)`
- Add a focused test ensuring period control calls the correct endpoint:
  - Verify clicking **Backfill Snapshot History (period)** issues `POST /market-data/admin/snapshots/history/backfill-last-n-days?days=<mapped>`.

### Backend
- No new backend tests required (endpoint already covered); keep current coverage.

## Validation
- Run `make test` (backend docker tests)
- Run `make test-frontend` (lint/typecheck/vitest)

## Notes on “period vs trading days”
- UI uses **periods** because operators think in calendar time.
- The system persists snapshots by **trading day**, so the backend needs a **trading-day count** to determine how many ledger rows to compute/write. The period dropdown is just a clean operator-friendly layer on top.