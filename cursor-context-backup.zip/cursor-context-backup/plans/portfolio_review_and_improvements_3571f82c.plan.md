---
name: Portfolio Review and Improvements
overview: "Comprehensive review of the new portfolio implementation identified issues across three tiers: (1) data not appearing due to missing auto-sync on login and potentially broken backend endpoints, (2) UX inconsistencies in account filtering and loading states, and (3) code quality gaps with excessive `any` casts and missing error handling."
todos:
  - id: auto-sync-login
    content: Trigger initial sync after login or first account connection; add onboarding empty state with Sync CTA when no data exists
    status: pending
  - id: fix-dead-endpoints
    content: Remove or fix dead endpoints in portfolio.py that call missing IBKRSyncService methods (get_user_portfolio_summary, get_user_positions, get_user_performance)
    status: pending
  - id: account-filter-consistency
    content: Migrate PortfolioOptions and PortfolioTransactions from local selectedAccount state to global AccountContext
    status: pending
  - id: categories-error-handling
    content: Add error handling, loading states, and success/error toasts to PortfolioCategories mutation operations (create, update, assign)
    status: pending
  - id: transactions-ux
    content: "Add debounce (300ms) to symbol search input; add pagination or load-more to replace hardcoded limit: 500"
    status: pending
  - id: sync-feedback
    content: Add toast notifications for sync success/failure across all portfolio pages; add error message display
    status: pending
  - id: loading-skeletons
    content: Replace spinner-only loading states with skeleton loaders for StatCards, charts, and tables
    status: pending
  - id: type-safety
    content: Remove 'as any' casts across portfolio pages -- type API responses with proper interfaces from types/portfolio.ts
    status: pending
  - id: backend-n1-queries
    content: Fix N+1 queries in portfolio.py, portfolio_live.py, portfolio_dashboard.py, portfolio_options.py using eager loading or JOINs
    status: pending
  - id: async-sync-all
    content: Make /accounts/sync-all async using Celery tasks instead of blocking the HTTP request
    status: pending
isProject: false
---

# Portfolio Implementation Review and Improvement Plan

## Why No Data Is Showing

The most likely cause: **there is no automatic sync on first login or account creation.** The sync is entirely manual -- the user must click the "Sync" button on a portfolio page, or wait for the nightly scheduled sync (if Celery Beat is running and the schedule is enabled).

Additionally, three endpoints in `[backend/api/routes/portfolio.py](backend/api/routes/portfolio.py)` call methods that **don't exist** on `IBKRSyncService`:

- `get_user_portfolio_summary(user_id)` (line ~83)
- `get_user_positions(user_id, broker)` (line ~103)
- `get_user_performance(user_id, days)` (line ~128)

These will throw `AttributeError` at runtime. The pages that use the newer routes (`/portfolio/stocks`, `/portfolio/dashboard`, `/portfolio/options/`*) should still work since those routes use direct DB queries, not these missing methods.

**Fix:** Trigger initial sync after login or account creation, and either implement the missing service methods or remove the dead endpoints.

---

## Architecture Quality: 7/10

**Strengths:**

- Clean separation: broker-specific sync services behind a unified `BrokerSyncService` coordinator
- Portfolio routes split into focused modules (stocks, options, dashboard, categories, etc.)
- Enriched `/portfolio/stocks` endpoint with LEFT JOIN to `MarketSnapshot` is well done
- Good use of React Query for data fetching with cache invalidation on sync

**Weaknesses:**

- N+1 queries in `portfolio.py:259`, `portfolio_live.py:52`, `portfolio_dashboard.py:104`, `portfolio_options.py:105`
- `/accounts/sync-all` runs synchronously (blocks HTTP request); should use Celery like individual account sync
- Three dead endpoints with missing service methods
- No data validation that users can only access their own accounts in some routes

---

## Frontend UX Quality: 6/10

**Strengths:**

- Consistent page structure: `PageHeader` + `AccountFilterWrapper` + content
- Full dark/light mode support via semantic tokens
- Good shared components (`StatCard`, `PnlText`, `StageBar`, `StageBadge`)
- Sync button available on every portfolio page
- Account selection persists across pages via `AccountContext` + localStorage + URL param

**Weaknesses (ranked by impact):**

### P0 - Broken / Missing

1. **No data on first visit** -- no auto-sync, no onboarding prompt
2. **Categories page**: Mutations (create/update/assign) have **zero error handling** and no loading states on buttons -- they fail silently
3. **Dead endpoints**: `/portfolio/summary`, `/portfolio/positions`, `/portfolio/performance` will 500

### P1 - Functional but Poor

1. **Account filter inconsistency**: `PortfolioOptions` and `PortfolioTransactions` manage their own `selectedAccount` local state instead of using `AccountContext`, causing desync across pages
2. **No debounce on symbol search** in Transactions -- fires a new API call on every keystroke
3. **No pagination** in Transactions -- hardcoded `limit: 500`
4. **Performance chart**: No error handling if history query fails; just shows "Loading..." forever

### P2 - Polish

1. **Loading states**: Spinner-only, no skeletons -- page feels jarring on load
2. **No success/error toasts** for sync or category mutations
3. **No retry buttons** in error states
4. **Type safety**: Excessive `as any` casts across all pages (reduces IDE help and catches)
5. **Heatmap toggle** has no loading indicator
6. **Mobile tables** may overflow without horizontal scroll wrapper

### P3 - Nice-to-Have

1. Missing ARIA labels on `StatCard` values and P&L text
2. No breadcrumb navigation
3. No empty state illustrations
4. No keyboard shortcuts

---

## Proposed Improvements

### Tier 1: Fix Data Visibility (Critical)

- Trigger sync automatically after login or first account connection
- Add an onboarding empty state: "No data yet -- click Sync to pull from your brokerage"
- Remove or fix the three dead endpoints calling missing service methods
- Add sync error feedback (toast with error message if sync fails)

### Tier 2: Fix UX Consistency

- Migrate `PortfolioOptions` and `PortfolioTransactions` to use `AccountContext` instead of local state
- Add debounce (300ms) to symbol search in Transactions
- Add pagination or infinite scroll to Transactions (replace hardcoded 500 limit)
- Add error handling + loading states to Categories mutations (disable buttons, show toasts)
- Add error handling to performance history chart

### Tier 3: Polish and Performance

- Replace spinners with skeleton loading states
- Add success/error toasts for sync and mutations
- Add retry buttons in error states
- Reduce `as any` casts -- type the API responses properly
- Make `/accounts/sync-all` async via Celery
- Fix N+1 queries in backend routes
- Add horizontal scroll wrapper for tables on mobile

### Tier 4: Accessibility and Delight

- Add ARIA labels to stat cards and dynamic values
- Add breadcrumb navigation
- Add empty state illustrations
- Add keyboard shortcuts for common actions

