---
name: Market
overview: Finalize scheduler, coverage, and admin UX polish across backend and frontend to close remaining backlog items.
todos:
  - id: todo-1763875408227-3cow9pps6
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1763875408227-p1wedf2iw
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1763875408227-94iqsbwex
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1763875408227-2tavgffy2
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: routes-coverage-admin
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1763875408227-6x5398k4e
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1763875408227-uq69ixcyq
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1763875408227-maioctgvn
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1763875408227-zqn92lmyo
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1763875408227-379jz9383
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: models-migration
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: service-5m
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: tasks-framework
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1763881398178-c4i6rd840
    content: Add redbeat; configure Celery Beat to use RedBeat scheduler
    status: completed
  - id: todo-1763881398178-m0gawz4vt
    content: Create backend job catalog with groups, defaults, safety; seed RedBeat on empty store
    status: completed
  - id: todo-1763881398178-vywfqjqpy
    content: "Implement admin schedules API: list/create/update/pause/resume/delete/run-now with tz/cron validation"
    status: completed
  - id: todo-1763881398178-ro179ykxk
    content: Add export/import, dependencies, maintenance windows, pre-flight checks, safety controls, audit logging
    status: completed
  - id: todo-1763881398178-8z6vu4f38
    content: Build Schedules UI with grouping, cron builder, tz select, next-runs preview, safety controls
    status: completed
  - id: todo-1763881398178-b21wdxma3
    content: Enhance Jobs page (catalog, grouped), run-now with arg overrides, create-from-template
    status: completed
  - id: todo-1763881398178-arszppxdn
    content: Add coverage/freshness KPIs, banners, sparklines, quick actions chain
    status: in_progress
  - id: todo-1763881398178-sl2wldowm
    content: Wire Discord alerts on failures/slow runs; optional Prometheus metrics
    status: pending
  - id: todo-1763881398178-2p4hhi29z
    content: Support queue routing and priority per schedule
    status: completed
  - id: todo-1763881398178-jgxw1sx33
    content: Add tests for catalog/seed, CRUD, tz/DST, safety, windows, dependencies, export/import, audit
    status: pending
  - id: deps-redbeat
    content: Add redbeat; configure Celery Beat to use RedBeat scheduler
    status: completed
  - id: catalog-templates
    content: Create backend job catalog with groups, defaults, safety; seed RedBeat on empty store
    status: completed
  - id: api-schedules-crud
    content: "Implement admin schedules API: list/create/update/pause/resume/delete/run-now with tz/cron validation"
    status: completed
  - id: ui-schedules
    content: Build Schedules UI with grouping, cron builder, tz select, next-runs preview, safety controls
    status: completed
  - id: ui-jobs
    content: Enhance Jobs page (catalog, grouped), run-now with arg overrides, create-from-template
    status: completed
  - id: api-schedules-extras
    content: Add export/import, dependencies, maintenance windows, pre-flight checks, safety controls, audit logging
    status: completed
  - id: todo-1763885600416-4jl930of3
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1763885600416-qefto4dn1
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1763885600416-6bzde3bzv
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1763885600416-tmt58lt9c
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1763885600416-3y4jbsf14
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1763885600416-7f7adfhch
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1763885600416-c8qeqdka8
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1763885600416-gecpr5jfr
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1763885600416-zchesm3j6
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1763885600416-zyp3dsrz9
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1763885600416-tne304do6
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1763885600416-wlvonh6vb
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1763885600416-2wjl8ouy3
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1763885600416-s5ntqt7x1
    content: Add preflight + FMP-first/Wikipedia fallback to refresh_index_constituents
    status: pending
  - id: todo-1763885600416-ntau16zol
    content: Record detailed JobRun counters per index; provider_used/fallback_used
    status: pending
  - id: todo-1763885600416-jn36ydqt5
    content: Add bootstrap_universe task chaining refresh→tracked→backfills→recompute→record
    status: completed
  - id: todo-1763885600416-65egu4bgh
    content: Enhance coverage endpoints with freshness buckets and index counts
    status: completed
  - id: todo-1763885600416-f6opgs8ci
    content: Add Admin Dashboard KPIs, banners, and Bootstrap Universe action
    status: completed
  - id: todo-1763885600416-frm0bxj17
    content: Show last-run status and stats on Jobs catalog cards
    status: completed
  - id: todo-1763885600416-7wq1ezdd4
    content: Expose last-run status/timestamp in Schedules list
    status: completed
  - id: todo-1763885600416-99zp7nt36
    content: Add tests for fallback, preflight, JobRun counters, coverage states
    status: completed
  - id: todo-1763885600416-ybqhf59x1
    content: Document universe bootstrap runbook and troubleshooting
    status: completed
  - id: backend-preflight-fallback
    content: Add preflight + FMP-first/Wikipedia fallback to refresh_index_constituents
    status: completed
  - id: backend-counters
    content: Record detailed JobRun counters per index; provider_used/fallback_used
    status: completed
  - id: todo-1763935553499-3td1ygs3d
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1763935553499-vg3msbd6i
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1763935553499-lje5oqzje
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1763935553499-h0vjiaq7h
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1763935553499-7ijy1jzdj
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1763935553499-cfe3mfj9y
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1763935553499-tc0aaiibs
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1763935553499-h0mnaax0v
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1763935553499-2oohv6p21
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1763935553499-6yl4ymgba
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1763935553499-qxiowanx3
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1763935553499-t0kibspa5
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1763935553499-gd8mwvfyx
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1763935553499-34goxbrjf
    content: Add redbeat; configure Celery Beat to use RedBeat scheduler
    status: completed
  - id: todo-1763935553499-p3giz2u8a
    content: Create backend job catalog with groups, defaults, safety; seed RedBeat on empty store
    status: completed
  - id: todo-1763935553499-okr7a3p0k
    content: "Implement admin schedules API: list/create/update/pause/resume/delete/run-now with tz/cron validation"
    status: completed
  - id: todo-1763935553499-czj8nq73k
    content: Build Schedules UI with grouping, cron builder, tz select, next-runs preview, safety controls
    status: completed
  - id: todo-1763935553499-kflvc3xlr
    content: Enhance Jobs page (catalog, grouped), run-now with arg overrides, create-from-template
    status: completed
  - id: todo-1763935553499-k9mnsjh55
    content: Add export/import, dependencies, maintenance windows, pre-flight checks, safety controls, audit logging
    status: completed
  - id: todo-1763935553499-pu0ss6g9v
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1763935553499-fpu65p0d7
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1763935553499-kjcw75y4c
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1763935553499-6sen7t5ks
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1763935553499-7swniy5jj
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1763935553499-iq3tv17xt
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1763935553499-awv0gfren
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1763935553499-1uo37fosy
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1763935553499-c7sxagsou
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1763935553499-vto606ynk
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1763935553499-c7w0kq1kn
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1763935553499-qn2qpsnxq
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1763935553499-2c69mw67s
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: bootstrap-run
    content: Run bootstrap_universe and validate coverage
    status: completed
  - id: ui-jobs-humanize
    content: Humanize Jobs catalog + fix overflow
    status: completed
  - id: ui-coverage-tracked
    content: Educational snippets + optional columns
    status: completed
  - id: runbook-ui
    content: Add guided Runbook actions
    status: completed
  - id: todo-1763938243354-b6egjokil
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1763938243354-giuhluj5m
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1763938243354-zklffqjm4
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1763938243354-dmrpcr3h7
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1763938243354-9eqwbwco3
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1763938243354-gnesubmcm
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1763938243354-1fjx07hcq
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1763938243354-2pjwvsbt0
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1763938243354-8gnl5hdbr
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1763938243354-3g317ynzq
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1763938243354-xbs5pmzq8
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1763938243354-doij1ewlk
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1763938243354-zviiqdvqj
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1763938243354-9nzaf9258
    content: Add redbeat; configure Celery Beat to use RedBeat scheduler
    status: completed
  - id: todo-1763938243354-83rks8en2
    content: Create backend job catalog with groups, defaults, safety; seed RedBeat on empty store
    status: completed
  - id: todo-1763938243354-sdfasc8a7
    content: "Implement admin schedules API: list/create/update/pause/resume/delete/run-now with tz/cron validation"
    status: completed
  - id: todo-1763938243354-e0kguvijf
    content: Build Schedules UI with grouping, cron builder, tz select, next-runs preview, safety controls
    status: completed
  - id: todo-1763938243354-ryenktyuc
    content: Enhance Jobs page (catalog, grouped), run-now with arg overrides, create-from-template
    status: completed
  - id: todo-1763938243354-u3siweqvy
    content: Add export/import, dependencies, maintenance windows, pre-flight checks, safety controls, audit logging
    status: completed
  - id: todo-1763938243354-7sm8m8ven
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1763938243354-14o91awuz
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1763938243354-8ofkoz8hn
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1763938243354-qu3vp25j2
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1763938243354-w7hgby57a
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1763938243354-lg8qd0hcf
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1763938243354-4dggu4sls
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1763938243354-m2ybfcs6w
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1763938243354-dfz37nk66
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1763938243354-aaagz23vb
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1763938243354-gcfllu9ux
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1763938243354-lz09kapy9
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1763938243354-pjfj8d0k4
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1763938243354-1q0l2wdcz
    content: Add bootstrap_universe task chaining refresh→tracked→backfills→recompute→record
    status: completed
  - id: todo-1763938243354-q60yzns5i
    content: Enhance coverage endpoints with freshness buckets and index counts
    status: completed
  - id: todo-1763938243354-vttyrepr0
    content: Add Admin Dashboard KPIs, banners, and Bootstrap Universe action
    status: completed
  - id: todo-1763938243354-c4noopdqt
    content: Show last-run status and stats on Jobs catalog cards
    status: completed
  - id: todo-1763938243354-3jgnnfxab
    content: Expose last-run status/timestamp in Schedules list
    status: completed
  - id: todo-1763938243354-4hm8axqnu
    content: Add tests for fallback, preflight, JobRun counters, coverage states
    status: completed
  - id: todo-1763938243354-klfcha55u
    content: Document universe bootstrap runbook and troubleshooting
    status: completed
  - id: todo-1763938243354-65gpg7dsk
    content: Add preflight + FMP-first/Wikipedia fallback to refresh_index_constituents
    status: completed
  - id: todo-1763938243354-y1dkmld1s
    content: Record detailed JobRun counters per index; provider_used/fallback_used
    status: completed
  - id: todo-1763938243354-hp3jzryoy
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1763938243354-3nz614myl
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1763938243354-i7konh9wj
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1763938243354-rx8v2j61p
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1763938243354-tdx1i8igr
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1763938243354-4mdn1kd2g
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1763938243354-8kae6zvpi
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1763938243354-8rtk9s24o
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1763938243354-gf9u68olh
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1763938243354-anps38f0z
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1763938243354-c5xsfgwx2
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1763938243354-1kufb5d5y
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1763938243354-1npf53lv1
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1763938243354-73g6fqigl
    content: Add redbeat; configure Celery Beat to use RedBeat scheduler
    status: completed
  - id: todo-1763938243354-vhgtsur6d
    content: Create backend job catalog with groups, defaults, safety; seed RedBeat on empty store
    status: completed
  - id: todo-1763938243354-7y41zh4wr
    content: "Implement admin schedules API: list/create/update/pause/resume/delete/run-now with tz/cron validation"
    status: completed
  - id: todo-1763938243354-9n05yd2fq
    content: Build Schedules UI with grouping, cron builder, tz select, next-runs preview, safety controls
    status: completed
  - id: todo-1763938243354-wsy2jf83q
    content: Enhance Jobs page (catalog, grouped), run-now with arg overrides, create-from-template
    status: completed
  - id: todo-1763938243354-x7nss7348
    content: Add export/import, dependencies, maintenance windows, pre-flight checks, safety controls, audit logging
    status: completed
  - id: todo-1763938243354-qaiwb8fpv
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1763938243354-m0it0do47
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1763938243354-c6d625olz
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1763938243354-ihvkseklr
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1763938243354-fote3vgrs
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1763938243354-zatslvb04
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1763938243354-4a69o3add
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1763938243354-8hg6ur1gm
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1763938243354-25c8vw0y9
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1763938243354-9fwgbxefs
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1763938243354-hziucdbgq
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1763938243354-7f59wgwug
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1763938243354-hxg7bagt8
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1763938243354-jgjqk9bvj
    content: Rebuild AdminJobs cards/modal with single action flow
    status: pending
  - id: todo-1763938243354-9cs0mdtj0
    content: Redesign AdminRunbook layout to be denser
    status: pending
  - id: todo-1763938243354-ru9aftc4r
    content: Update Chakra theme tokens to Hex-inspired palette
    status: pending
  - id: jobs-modal
    content: Rebuild AdminJobs cards/modal with single action flow
    status: completed
  - id: runbook-compact
    content: Redesign AdminRunbook layout to be denser
    status: completed
  - id: theme-refresh
    content: Update Chakra theme tokens to Hex-inspired palette
    status: completed
  - id: theme-blue
    content: Retune theme palette with refined blue hues
    status: completed
  - id: todo-instrument
    content: Add coverage instrumentation to detect stale data
    status: completed
  - id: todo-jobdetail
    content: Add job detail modal/log view from Recent Runs
    status: completed
  - id: todo-sidebar
    content: Adjust sidebar + menu hover colors for dark theme
    status: completed
  - id: todo-1763969247785-m517s4liu
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1763969247785-aca6y4v4s
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1763969247785-6s2hqp8zh
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1763969247785-4qh929sw6
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1763969247785-lmiea0jgg
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1763969247785-wcppdap2o
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1763969247785-18ejll4jw
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1763969247785-auakmq84g
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1763969247785-9hz3h99gd
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1763969247785-w823vhjnu
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1763969247785-xn2nbg7nt
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1763969247785-u9y2s1aqk
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1763969247785-hysypid7d
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1763969247785-ciwraog5r
    content: Add redbeat; configure Celery Beat to use RedBeat scheduler
    status: completed
  - id: todo-1763969247785-r346j98be
    content: Create backend job catalog with groups, defaults, safety; seed RedBeat on empty store
    status: completed
  - id: todo-1763969247785-bzwsanw80
    content: "Implement admin schedules API: list/create/update/pause/resume/delete/run-now with tz/cron validation"
    status: completed
  - id: todo-1763969247785-azpqll38e
    content: Build Schedules UI with grouping, cron builder, tz select, next-runs preview, safety controls
    status: completed
  - id: todo-1763969247785-hlrvop30x
    content: Enhance Jobs page (catalog, grouped), run-now with arg overrides, create-from-template
    status: completed
  - id: todo-1763969247785-1m7rqmsxf
    content: Add export/import, dependencies, maintenance windows, pre-flight checks, safety controls, audit logging
    status: completed
  - id: todo-1763969247785-tqeokoqsl
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1763969247785-8v0pi0t4v
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1763969247785-yn374iqt5
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1763969247785-5wr5ytakc
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1763969247785-yvhfm0112
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1763969247785-qbnzb6slr
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1763969247785-ib0ggj4od
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1763969247785-c2po484oe
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1763969247785-mai1aw9m1
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1763969247785-8f2wdh6fv
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1763969247785-zwll3lhps
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1763969247785-qnhgsui31
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1763969247785-ynvce0c0a
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1763969247785-y02qm1h2e
    content: Add bootstrap_universe task chaining refresh→tracked→backfills→recompute→record
    status: completed
  - id: todo-1763969247785-f2b8sqj6k
    content: Enhance coverage endpoints with freshness buckets and index counts
    status: completed
  - id: todo-1763969247785-toduy2id3
    content: Add Admin Dashboard KPIs, banners, and Bootstrap Universe action
    status: completed
  - id: todo-1763969247785-cwsq6plk7
    content: Show last-run status and stats on Jobs catalog cards
    status: completed
  - id: todo-1763969247785-dzhtk20yw
    content: Expose last-run status/timestamp in Schedules list
    status: completed
  - id: todo-1763969247785-zachnjmw8
    content: Add tests for fallback, preflight, JobRun counters, coverage states
    status: completed
  - id: todo-1763969247785-6l7ka2qse
    content: Document universe bootstrap runbook and troubleshooting
    status: completed
  - id: todo-1763969247785-q9uhnoqq0
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1763969247785-4acnq7xjo
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1763969247785-qak5fqaf9
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1763969247785-mj5k3a2yr
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1763969247785-c2j081trj
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1763969247785-ix9fws6tt
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1763969247785-rdpw2fsut
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1763969247785-cfnacywit
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1763969247785-l6h0qk2y5
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1763969247785-frw392pqh
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1763969247785-9upb06a2h
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1763969247785-8prt9caml
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1763969247785-qxf5s81eb
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1763969247785-uyoe89zay
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1763969247785-bnyji752x
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1763969247785-dpindk0nh
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1763969247785-wwhydweze
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1763969247785-wtwdw4zu7
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1763969247785-qez20f77e
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1763969247785-1d7t7o302
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1763969247785-cyw9ntriu
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1763969247785-zymgirsrh
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1763969247785-pu6n3cdxe
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1763969247785-uc6u7k0oj
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1763969247785-6n1lh9trd
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1763969247785-kduysainy
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1763969247785-0qshwogpc
    content: Add coverage health monitor job
    status: completed
  - id: todo-1763969247785-3zu1r6e3e
    content: Add job details modal/log view
    status: completed
  - id: todo-1763969247785-kyumwa3xk
    content: Run refresh→backfill→recompute chain
    status: completed
  - id: sched-enhance
    content: ""
    status: pending
  - id: tests-scheduler
    content: Add tests for scheduler metadata/export/import UX
    status: completed
  - id: todo-1764042037265-xr0jiv34a
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764042037265-o5o20xn0v
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-q7f2sqm8v
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-h0a3vc6i7
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764042037265-uandum73z
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764042037265-b9l7gl2vg
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764042037265-c73v0p8mk
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764042037265-kmov4lkfp
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764042037265-zjx552eti
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764042037265-wzgq963rd
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764042037265-zhzkgcryv
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764042037265-oh7itz4jy
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-sywgczrbg
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-buz75zkzw
    content: Add redbeat; configure Celery Beat to use RedBeat scheduler
    status: completed
  - id: todo-1764042037265-sjhirp9dy
    content: Create backend job catalog with groups, defaults, safety; seed RedBeat on empty store
    status: completed
  - id: todo-1764042037265-wsgwmaotr
    content: "Implement admin schedules API: list/create/update/pause/resume/delete/run-now with tz/cron validation"
    status: completed
  - id: todo-1764042037265-rzlg7kfn8
    content: Build Schedules UI with grouping, cron builder, tz select, next-runs preview, safety controls
    status: completed
  - id: todo-1764042037265-1adtfin7z
    content: Enhance Jobs page (catalog, grouped), run-now with arg overrides, create-from-template
    status: completed
  - id: todo-1764042037265-ogj5z6ezp
    content: Add export/import, dependencies, maintenance windows, pre-flight checks, safety controls, audit logging
    status: completed
  - id: todo-1764042037265-687ju97yk
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764042037265-39iaa5vn0
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-tr3jmxlvc
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-upwv62amp
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764042037265-kkn8qspn3
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764042037265-w81y7wb6p
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764042037265-q0cfn7qog
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764042037265-dxswy5zav
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764042037265-2r7o6g93g
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764042037265-vqwb4agc5
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764042037265-ocdq3t40h
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764042037265-hbg6cv4pf
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-cs17cqtr9
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-33oe33dze
    content: Add bootstrap_universe task chaining refresh→tracked→backfills→recompute→record
    status: completed
  - id: todo-1764042037265-yspcgjr12
    content: Enhance coverage endpoints with freshness buckets and index counts
    status: completed
  - id: todo-1764042037265-94ft0jdr7
    content: Add Admin Dashboard KPIs, banners, and Bootstrap Universe action
    status: completed
  - id: todo-1764042037265-jraij192c
    content: Show last-run status and stats on Jobs catalog cards
    status: completed
  - id: todo-1764042037265-zs90yvwd0
    content: Expose last-run status/timestamp in Schedules list
    status: completed
  - id: todo-1764042037265-lyhu2qsgr
    content: Add tests for fallback, preflight, JobRun counters, coverage states
    status: completed
  - id: todo-1764042037265-s3rp9ex54
    content: Document universe bootstrap runbook and troubleshooting
    status: completed
  - id: todo-1764042037265-kkn9s4tsd
    content: Add preflight + FMP-first/Wikipedia fallback to refresh_index_constituents
    status: completed
  - id: todo-1764042037265-is0mx07y6
    content: Record detailed JobRun counters per index; provider_used/fallback_used
    status: completed
  - id: todo-1764042037265-zq7kvfmci
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764042037265-4ar0hclr0
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-agmv2kxnv
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-qhj9e2qn7
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764042037265-jzd07d8q8
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764042037265-ijqgsazl9
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764042037265-gnde0k4cm
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764042037265-nqebrqqzm
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764042037265-9iyy93wpm
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764042037265-q5jy5sig3
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764042037265-a11ioykyc
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764042037265-ci91oaw5h
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-t2eyxt2fw
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-wiys4f4rm
    content: Add redbeat; configure Celery Beat to use RedBeat scheduler
    status: completed
  - id: todo-1764042037265-crlwpnxtt
    content: Create backend job catalog with groups, defaults, safety; seed RedBeat on empty store
    status: completed
  - id: todo-1764042037265-z8wwv366a
    content: "Implement admin schedules API: list/create/update/pause/resume/delete/run-now with tz/cron validation"
    status: completed
  - id: todo-1764042037265-diuel1v0j
    content: Build Schedules UI with grouping, cron builder, tz select, next-runs preview, safety controls
    status: completed
  - id: todo-1764042037265-5i4qk9dgl
    content: Enhance Jobs page (catalog, grouped), run-now with arg overrides, create-from-template
    status: completed
  - id: todo-1764042037265-u1ebmhbhw
    content: Add export/import, dependencies, maintenance windows, pre-flight checks, safety controls, audit logging
    status: completed
  - id: todo-1764042037265-2maalfu7t
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764042037265-cobw5jc0x
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-mqgtcwuid
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-ixxowi4tu
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764042037265-ljah7ossu
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764042037265-cofl19vdz
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764042037265-50tqw79qk
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764042037265-bmdrsmv29
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764042037265-tlyev63ue
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764042037265-ni0sa91ov
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764042037265-wivumor7u
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764042037265-v8iiuwsx2
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-263mejpfc
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-wfkk45o6k
    content: Run bootstrap_universe and validate coverage
    status: completed
  - id: todo-1764042037265-bbttvnp6j
    content: Humanize Jobs catalog + fix overflow
    status: completed
  - id: todo-1764042037265-yqy0lc1x7
    content: Educational snippets + optional columns
    status: completed
  - id: todo-1764042037265-hvqojl3v0
    content: Add guided Runbook actions
    status: completed
  - id: todo-1764042037265-77q0sgrjn
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764042037265-rs8hdp9tj
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-r2noizl6i
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-f2oxcs0py
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764042037265-6wsd6is9m
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764042037265-ozzzc7ed7
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764042037265-v65djtdme
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764042037265-8ll2e59i3
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764042037265-2r53phvhr
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764042037265-23ein73u7
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764042037265-438v18c74
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764042037265-hfmob05ht
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-ab1l03kip
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-mobwdacvt
    content: Add redbeat; configure Celery Beat to use RedBeat scheduler
    status: completed
  - id: todo-1764042037265-it4bunrvp
    content: Create backend job catalog with groups, defaults, safety; seed RedBeat on empty store
    status: completed
  - id: todo-1764042037265-82icvbh0i
    content: "Implement admin schedules API: list/create/update/pause/resume/delete/run-now with tz/cron validation"
    status: completed
  - id: todo-1764042037265-qw8qb6kn5
    content: Build Schedules UI with grouping, cron builder, tz select, next-runs preview, safety controls
    status: completed
  - id: todo-1764042037265-6iprmej7e
    content: Enhance Jobs page (catalog, grouped), run-now with arg overrides, create-from-template
    status: completed
  - id: todo-1764042037265-148cixpg8
    content: Add export/import, dependencies, maintenance windows, pre-flight checks, safety controls, audit logging
    status: completed
  - id: todo-1764042037265-bwptkdc39
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764042037265-yaqvl8amf
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-u2jkoa345
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-muxlerji9
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764042037265-khmb4hc42
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764042037265-ytpujr9ei
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764042037265-0o58kkhyj
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764042037265-97j3y3j8n
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764042037265-79tw0lx4t
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764042037265-kuj899afl
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764042037265-h463g1uv6
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764042037265-8cr6e11hz
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-hmaq7yj3h
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-9zilx0eme
    content: Add bootstrap_universe task chaining refresh→tracked→backfills→recompute→record
    status: completed
  - id: todo-1764042037265-bs539fj7d
    content: Enhance coverage endpoints with freshness buckets and index counts
    status: completed
  - id: todo-1764042037265-dvjypegq9
    content: Add Admin Dashboard KPIs, banners, and Bootstrap Universe action
    status: completed
  - id: todo-1764042037265-3pa8gj5gw
    content: Show last-run status and stats on Jobs catalog cards
    status: completed
  - id: todo-1764042037265-porsxdlh7
    content: Expose last-run status/timestamp in Schedules list
    status: completed
  - id: todo-1764042037265-hhkaewiis
    content: Add tests for fallback, preflight, JobRun counters, coverage states
    status: completed
  - id: todo-1764042037265-thr1m2sgm
    content: Document universe bootstrap runbook and troubleshooting
    status: completed
  - id: todo-1764042037265-au43m6ptz
    content: Add preflight + FMP-first/Wikipedia fallback to refresh_index_constituents
    status: completed
  - id: todo-1764042037265-qsbklpsv1
    content: Record detailed JobRun counters per index; provider_used/fallback_used
    status: completed
  - id: todo-1764042037265-4ha3bzjd4
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764042037265-r66t4ei73
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-f5eckdw4x
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-0qyac1h9e
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764042037265-ai3xpz5t8
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764042037265-ur1fb2yxo
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764042037265-q3374i6p2
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764042037265-nhux63zgv
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764042037265-e218zejpd
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764042037265-adjs4z2vk
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764042037265-84i7zaard
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764042037265-uu3n77lw9
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-kcvd5bst1
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-ibu69fd3g
    content: Add redbeat; configure Celery Beat to use RedBeat scheduler
    status: completed
  - id: todo-1764042037265-7rm75iaqs
    content: Create backend job catalog with groups, defaults, safety; seed RedBeat on empty store
    status: completed
  - id: todo-1764042037265-qdfwfr176
    content: "Implement admin schedules API: list/create/update/pause/resume/delete/run-now with tz/cron validation"
    status: completed
  - id: todo-1764042037265-fc7qd45or
    content: Build Schedules UI with grouping, cron builder, tz select, next-runs preview, safety controls
    status: completed
  - id: todo-1764042037265-xkl52ix8j
    content: Enhance Jobs page (catalog, grouped), run-now with arg overrides, create-from-template
    status: completed
  - id: todo-1764042037265-a7b2v2aw1
    content: Add export/import, dependencies, maintenance windows, pre-flight checks, safety controls, audit logging
    status: completed
  - id: todo-1764042037265-30v3gwpzz
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764042037265-7q3le2d6r
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-4k7efchcx
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-513urr6ui
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764042037265-gq7dcni5f
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764042037265-8sc4okk40
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764042037265-o2sr02mk6
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764042037265-76ytgwp7z
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764042037265-nifi3myi6
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764042037265-oxj6s164f
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764042037265-0vsah3l0n
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764042037265-bsovk829j
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-1akucw63z
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-qpkij8r37
    content: Rebuild AdminJobs cards/modal with single action flow
    status: completed
  - id: todo-1764042037265-6cnok0ftj
    content: Redesign AdminRunbook layout to be denser
    status: completed
  - id: todo-1764042037265-qgwqxhij0
    content: Update Chakra theme tokens to Hex-inspired palette
    status: completed
  - id: todo-1764042037265-xty6dy165
    content: Retune theme palette with refined blue hues
    status: completed
  - id: todo-1764042037265-q3qjmreax
    content: Add coverage instrumentation to detect stale data
    status: completed
  - id: todo-1764042037265-ioy0f8les
    content: Add job detail modal/log view from Recent Runs
    status: completed
  - id: todo-1764042037265-hk7t6iawn
    content: Adjust sidebar + menu hover colors for dark theme
    status: completed
  - id: todo-1764042037265-d1w4l0qjw
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764042037265-z8sf72j5f
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-a7na6pin4
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-h4w6hnu7a
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764042037265-l1m2r4nt4
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764042037265-1d1fv23pv
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764042037265-3xthc5wei
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764042037265-08i6cq1zx
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764042037265-kexjdoqsg
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764042037265-drabrhchh
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764042037265-hgiv8p2q5
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764042037265-zmu3j77xl
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-ckb8q5lm2
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-7y8fioq3x
    content: Add redbeat; configure Celery Beat to use RedBeat scheduler
    status: completed
  - id: todo-1764042037265-y02jkkjsu
    content: Create backend job catalog with groups, defaults, safety; seed RedBeat on empty store
    status: completed
  - id: todo-1764042037265-trfrz0nhb
    content: "Implement admin schedules API: list/create/update/pause/resume/delete/run-now with tz/cron validation"
    status: completed
  - id: todo-1764042037265-88c3kypws
    content: Build Schedules UI with grouping, cron builder, tz select, next-runs preview, safety controls
    status: completed
  - id: todo-1764042037265-x5is7g6y0
    content: Enhance Jobs page (catalog, grouped), run-now with arg overrides, create-from-template
    status: completed
  - id: todo-1764042037265-t3gyqr5xl
    content: Add export/import, dependencies, maintenance windows, pre-flight checks, safety controls, audit logging
    status: completed
  - id: todo-1764042037265-2sakg0hqc
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764042037265-482wgb3m6
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-u13y9a4o8
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-x83u7phs0
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764042037265-jf2nzw1ic
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764042037265-pa4pxj1p3
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764042037265-fssohevfw
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764042037265-sz3lc7m7b
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764042037265-sec6oacey
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764042037265-45gz3vahd
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764042037265-4g0iuuu26
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764042037265-pu9r58m2a
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-jl0059ciq
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-y7isigttr
    content: Add bootstrap_universe task chaining refresh→tracked→backfills→recompute→record
    status: completed
  - id: todo-1764042037265-pynsrre8m
    content: Enhance coverage endpoints with freshness buckets and index counts
    status: completed
  - id: todo-1764042037265-qma1qifj2
    content: Add Admin Dashboard KPIs, banners, and Bootstrap Universe action
    status: completed
  - id: todo-1764042037265-toz9ixdqb
    content: Show last-run status and stats on Jobs catalog cards
    status: completed
  - id: todo-1764042037265-6ngz3cup5
    content: Expose last-run status/timestamp in Schedules list
    status: completed
  - id: todo-1764042037265-xiv5q1vvi
    content: Add tests for fallback, preflight, JobRun counters, coverage states
    status: completed
  - id: todo-1764042037265-299mjybr7
    content: Document universe bootstrap runbook and troubleshooting
    status: completed
  - id: todo-1764042037265-fpzxul48z
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764042037265-4fyohxpy6
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-ersorg3xm
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-07pkyp6e9
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764042037265-jpzg6ls4m
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764042037265-nhn44rkuc
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764042037265-6a7a1vjqm
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764042037265-uvuja6hjy
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764042037265-ltjuchmwm
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764042037265-eh19fwh7n
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764042037265-rvq20ndz2
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764042037265-chu1bvdfa
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-88xbybhfi
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-33spb3ha3
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764042037265-lmyxdug6h
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-bnce51mar
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-bf6hr5tai
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764042037265-malbp0q07
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764042037265-jpfcuaxck
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764042037265-wfthmi2uo
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764042037265-rp184nksc
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764042037265-6ywkkiu9n
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764042037265-u4y44jmct
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764042037265-u676rmkk3
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764042037265-atqurfxsu
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764042037265-v0fls07nx
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764042037265-k367i7bj8
    content: Wire coverage KPIs & sparklines into Admin Dashboard/Coverage
    status: pending
  - id: todo-1764042037265-qy2sz54dq
    content: Add Discord/Prom alerts via task metadata hooks
    status: pending
  - id: todo-1764042037265-5jxtvhwia
    content: Expand backend tests for catalog/CRUD/export/import/audit
    status: pending
  - id: todo-1764042037265-j7v5qcylz
    content: Implement preflight + FMP/Wiki fallback counters
    status: pending
  - id: todo-1764042037265-obnhyvr3n
    content: Rebuild Admin Jobs modal & icon flow
    status: pending
  - id: todo-1764042037265-801czq083
    content: Compact Admin Runbook with quick actions
    status: pending
  - id: todo-1764042037265-secp2cy0j
    content: Finish Hex palette tokens in theme
    status: pending
  - id: todo-1764042037265-9ghp8ug53
    content: Polish schedule metadata editor & quick actions
    status: pending
  - id: todo-1764042037265-oirtehypi
    content: Document coverage/alerts/index workflow changes
    status: pending
  - id: coverage-ui
    content: Wire coverage KPIs & sparklines into Admin Dashboard/Coverage
    status: in_progress
  - id: scheduler-alerts
    content: Add Discord/Prom alerts via task metadata hooks
    status: in_progress
  - id: todo-1764051327491-p8zzja1wr
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764051327491-u2gtoh8j7
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-eetgrsbei
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-25mof6c1a
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764051327491-onoji5zh8
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764051327491-kigno5eki
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764051327491-8jsiws6ny
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764051327491-ax325q5dp
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764051327491-x16brug36
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764051327491-y3g1uxcmk
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764051327491-wcer8zwbf
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764051327491-yyx2kyih5
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-k8e6tt07r
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-nxkvkh907
    content: Add redbeat; configure Celery Beat to use RedBeat scheduler
    status: completed
  - id: todo-1764051327491-jod86d9d0
    content: Create backend job catalog with groups, defaults, safety; seed RedBeat on empty store
    status: completed
  - id: todo-1764051327491-vmynekj2t
    content: "Implement admin schedules API: list/create/update/pause/resume/delete/run-now with tz/cron validation"
    status: completed
  - id: todo-1764051327491-7j2l3v3hz
    content: Add export/import, dependencies, maintenance windows, pre-flight checks, safety controls, audit logging
    status: completed
  - id: todo-1764051327491-ycx99t8yo
    content: Build Schedules UI with grouping, cron builder, tz select, next-runs preview, safety controls
    status: completed
  - id: todo-1764051327491-5hgbsxro2
    content: Enhance Jobs page (catalog, grouped), run-now with arg overrides, create-from-template
    status: completed
  - id: todo-1764051327491-o3rs522ra
    content: Add redbeat; configure Celery Beat to use RedBeat scheduler
    status: completed
  - id: todo-1764051327491-ozaeyqnt7
    content: Create backend job catalog with groups, defaults, safety; seed RedBeat on empty store
    status: completed
  - id: todo-1764051327491-nzkdfpuze
    content: "Implement admin schedules API: list/create/update/pause/resume/delete/run-now with tz/cron validation"
    status: completed
  - id: todo-1764051327491-jyj40j82p
    content: Build Schedules UI with grouping, cron builder, tz select, next-runs preview, safety controls
    status: completed
  - id: todo-1764051327491-n0rcxbrec
    content: Enhance Jobs page (catalog, grouped), run-now with arg overrides, create-from-template
    status: completed
  - id: todo-1764051327491-cq25nea7q
    content: Add export/import, dependencies, maintenance windows, pre-flight checks, safety controls, audit logging
    status: completed
  - id: todo-1764051327491-vnv3sh8ul
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764051327491-xpceuhmou
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-e1y4fz9vr
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-ywhqxxg3x
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764051327491-e1w0gsog1
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764051327491-dg1p3k0tp
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764051327491-qehuo7zy4
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764051327491-3cwd4124t
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764051327491-ujd6gs1j3
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764051327491-is4ss5kz4
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764051327491-mmgw4ocrx
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764051327491-jyvyr3o23
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-myrymtad5
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-3jkuiywrj
    content: Add bootstrap_universe task chaining refresh→tracked→backfills→recompute→record
    status: completed
  - id: todo-1764051327491-pedb66sum
    content: Enhance coverage endpoints with freshness buckets and index counts
    status: completed
  - id: todo-1764051327491-clg1ekwqg
    content: Add Admin Dashboard KPIs, banners, and Bootstrap Universe action
    status: completed
  - id: todo-1764051327491-w7fpdxs6s
    content: Show last-run status and stats on Jobs catalog cards
    status: completed
  - id: todo-1764051327491-1d657rjwe
    content: Expose last-run status/timestamp in Schedules list
    status: completed
  - id: todo-1764051327491-w23wls78m
    content: Add tests for fallback, preflight, JobRun counters, coverage states
    status: completed
  - id: todo-1764051327491-uitrtrfan
    content: Document universe bootstrap runbook and troubleshooting
    status: completed
  - id: todo-1764051327491-klkmy77jn
    content: Add preflight + FMP-first/Wikipedia fallback to refresh_index_constituents
    status: completed
  - id: todo-1764051327491-1x747ddlu
    content: Record detailed JobRun counters per index; provider_used/fallback_used
    status: completed
  - id: todo-1764051327491-0a7gudkva
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764051327491-97mt0ouym
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-acawevryk
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-x3q2crhrx
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764051327491-1wy248aga
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764051327491-wp8pmanix
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764051327491-t38k7m1tq
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764051327491-8zzazpfci
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764051327491-tvguvdobf
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764051327491-exl3b0gx6
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764051327491-k48qhg0nh
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764051327491-47mh87ky1
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-jzmvqfors
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-od8b4e6vg
    content: Add redbeat; configure Celery Beat to use RedBeat scheduler
    status: completed
  - id: todo-1764051327491-z1ig5q9ol
    content: Create backend job catalog with groups, defaults, safety; seed RedBeat on empty store
    status: completed
  - id: todo-1764051327491-msr1phl0i
    content: "Implement admin schedules API: list/create/update/pause/resume/delete/run-now with tz/cron validation"
    status: completed
  - id: todo-1764051327491-u1psvy2rl
    content: Build Schedules UI with grouping, cron builder, tz select, next-runs preview, safety controls
    status: completed
  - id: todo-1764051327491-etx9oc8b0
    content: Enhance Jobs page (catalog, grouped), run-now with arg overrides, create-from-template
    status: completed
  - id: todo-1764051327491-tn96x8qpd
    content: Add export/import, dependencies, maintenance windows, pre-flight checks, safety controls, audit logging
    status: completed
  - id: todo-1764051327491-hc62ikcj4
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764051327491-gj0niytax
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-dfyj2w7uz
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-n3pqgacpr
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764051327491-9ae0bxe6a
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764051327491-guh9f6wwe
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764051327491-6y6pb31ss
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764051327491-vi1zt7asg
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764051327491-6r8wxrqjj
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764051327491-rr164plir
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764051327491-87qquvm98
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764051327491-rvragsorr
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-1amzrixf4
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-7hhwizj88
    content: Run bootstrap_universe and validate coverage
    status: completed
  - id: todo-1764051327491-ymlhy00gf
    content: Humanize Jobs catalog + fix overflow
    status: completed
  - id: todo-1764051327491-31flj23dc
    content: Educational snippets + optional columns
    status: completed
  - id: todo-1764051327491-l9sa282zi
    content: Add guided Runbook actions
    status: completed
  - id: todo-1764051327491-6jbqimsq7
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764051327491-jqd0earr4
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-u9ygwvy01
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-pwbad78rp
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764051327491-1lvd9qdrv
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764051327491-omxv36si7
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764051327491-n6nuumbrn
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764051327491-aobq12iqx
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764051327491-5tk4vgd48
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764051327491-2ivlbtsqk
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764051327491-s5zudh8xb
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764051327491-508jniytu
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-dei3mnds7
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-8plpgbfts
    content: Add redbeat; configure Celery Beat to use RedBeat scheduler
    status: completed
  - id: todo-1764051327491-zfb7vn7k9
    content: Create backend job catalog with groups, defaults, safety; seed RedBeat on empty store
    status: completed
  - id: todo-1764051327491-crfi32l7l
    content: "Implement admin schedules API: list/create/update/pause/resume/delete/run-now with tz/cron validation"
    status: completed
  - id: todo-1764051327491-rt1pc5wdf
    content: Build Schedules UI with grouping, cron builder, tz select, next-runs preview, safety controls
    status: completed
  - id: todo-1764051327491-dopbeade3
    content: Enhance Jobs page (catalog, grouped), run-now with arg overrides, create-from-template
    status: completed
  - id: todo-1764051327491-tudm4xwe1
    content: Add export/import, dependencies, maintenance windows, pre-flight checks, safety controls, audit logging
    status: completed
  - id: todo-1764051327491-1qik4ij53
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764051327491-srgusfc1e
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-nfu3xtsy4
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-vhp13h9r3
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764051327491-rik49v6tc
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764051327491-ohakjueif
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764051327491-ldhl6fpp0
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764051327491-od1w815m8
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764051327491-xpk8z9z3r
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764051327491-jvr0lfdiv
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764051327491-5ra4g3039
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764051327491-9uw6xq18z
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-s9e9oq999
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-qk5av7fb2
    content: Add bootstrap_universe task chaining refresh→tracked→backfills→recompute→record
    status: completed
  - id: todo-1764051327491-4noxdy0h5
    content: Enhance coverage endpoints with freshness buckets and index counts
    status: completed
  - id: todo-1764051327491-yvygcikad
    content: Add Admin Dashboard KPIs, banners, and Bootstrap Universe action
    status: completed
  - id: todo-1764051327491-mivwe1agj
    content: Show last-run status and stats on Jobs catalog cards
    status: completed
  - id: todo-1764051327491-bfpkm6f0k
    content: Expose last-run status/timestamp in Schedules list
    status: completed
  - id: todo-1764051327491-wvmlrfayq
    content: Add tests for fallback, preflight, JobRun counters, coverage states
    status: completed
  - id: todo-1764051327491-79bca34v5
    content: Document universe bootstrap runbook and troubleshooting
    status: completed
  - id: todo-1764051327491-h9qabqou5
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764051327491-e2ajp4wqg
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-m6fs03e0g
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-dwflthsmj
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764051327491-rt4dm3eim
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764051327491-azdp4cq21
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764051327491-7te128wy0
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764051327491-z006335bt
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764051327491-941t166m4
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764051327491-rio4l57f9
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764051327491-n3fzz5nys
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764051327491-3dmpw32l1
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-hmvmrriiv
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-rnlk7z86t
    content: Add redbeat; configure Celery Beat to use RedBeat scheduler
    status: completed
  - id: todo-1764051327491-xe0mw0st8
    content: Create backend job catalog with groups, defaults, safety; seed RedBeat on empty store
    status: completed
  - id: todo-1764051327491-t918ug1xf
    content: "Implement admin schedules API: list/create/update/pause/resume/delete/run-now with tz/cron validation"
    status: completed
  - id: todo-1764051327491-5zwmm527y
    content: Build Schedules UI with grouping, cron builder, tz select, next-runs preview, safety controls
    status: completed
  - id: todo-1764051327491-c0550glxp
    content: Enhance Jobs page (catalog, grouped), run-now with arg overrides, create-from-template
    status: completed
  - id: todo-1764051327491-riy7nayqt
    content: Add export/import, dependencies, maintenance windows, pre-flight checks, safety controls, audit logging
    status: completed
  - id: todo-1764051327491-kz6ih0632
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764051327491-o7nm4bp5e
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-gugexodfm
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-1fn1nbksq
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764051327491-n573vm63h
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764051327491-dri6gei4f
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764051327491-952six1xx
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764051327491-2enx4a50e
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764051327491-f875rjha3
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764051327491-te2nju5zd
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764051327491-326dzbmb5
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764051327491-t5il47cxy
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-lghjtgvrg
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-lozicmdqq
    content: Retune theme palette with refined blue hues
    status: completed
  - id: todo-1764051327491-ed141cqgg
    content: Add coverage instrumentation to detect stale data
    status: completed
  - id: todo-1764051327491-y7v19cifr
    content: Add job detail modal/log view from Recent Runs
    status: completed
  - id: todo-1764051327491-l2dxr8koj
    content: Adjust sidebar + menu hover colors for dark theme
    status: completed
  - id: todo-1764051327491-dz0ioaqw8
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764051327491-jbuh1dunb
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-qonhojkzl
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-bfxgt4b7v
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764051327491-cav0w21g4
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764051327491-j4x5bqouq
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764051327491-wnc82j863
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764051327491-h8dr1tv9f
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764051327491-hw3avf4vi
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764051327491-qe8yjya5g
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764051327491-971ksttd5
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764051327491-bdq91ndju
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-25ef5utjg
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-mbf3bxp9p
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764051327491-uba60hjum
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-74w8qfzta
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-f4kh5p53i
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764051327491-0577o4tzf
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764051327491-a9up92toc
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764051327491-4syrpmq56
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764051327491-w0z78wabv
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764051327491-3qbnbd6fq
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764051327491-qh8c7x74z
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764051327491-3j2kw6ual
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764051327491-fte7v81fv
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-5jfayscr2
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-1100chu1g
    content: Add bootstrap_universe task chaining refresh→tracked→backfills→recompute→record
    status: completed
  - id: todo-1764051327491-754jv3fxb
    content: Enhance coverage endpoints with freshness buckets and index counts
    status: completed
  - id: todo-1764051327491-y5tbt6t4f
    content: Add Admin Dashboard KPIs, banners, and Bootstrap Universe action
    status: completed
  - id: todo-1764051327491-87r6ibqqh
    content: Show last-run status and stats on Jobs catalog cards
    status: completed
  - id: todo-1764051327491-n0wfif5x9
    content: Expose last-run status/timestamp in Schedules list
    status: completed
  - id: todo-1764051327491-25hk6m6k8
    content: Add tests for fallback, preflight, JobRun counters, coverage states
    status: completed
  - id: todo-1764051327491-eafvbvv97
    content: Document universe bootstrap runbook and troubleshooting
    status: completed
  - id: todo-1764051327491-6b8a049y1
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764051327491-wbdkvjurz
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-dq90laq70
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-dzclca5lv
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764051327491-berwpgrkr
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764051327491-rnav1xiv7
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764051327491-o1qe45xiq
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764051327491-9oetx12nw
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764051327491-r4vzkz1lu
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764051327491-azcfn8nu3
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764051327491-e4r4ucmo2
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764051327491-v0q95bmww
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-hzrxmlyfl
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-wb5rh96tg
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764051327491-zu0l4rgc1
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-rdubeiwuh
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-9cmqd1h7z
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764051327491-qjgsa256z
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764051327491-kp0tb1cgx
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764051327491-xm3dkub4s
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764051327491-nvp6m4ab8
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764051327491-qeoju47pq
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764051327491-7whevclqp
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764051327491-4gx2jhlcr
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764051327491-nuxiu2kf8
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764051327491-6n3o0s8wg
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764051327491-bwar7xvnb
    content: Wire coverage KPIs & sparklines into Admin Dashboard/Coverage
    status: pending
  - id: todo-1764051327491-gi9qo9513
    content: Add Discord/Prom alerts via task metadata hooks
    status: pending
  - id: todo-1764051327491-0qr5qic6i
    content: Expand backend tests for catalog/CRUD/export/import/audit
    status: pending
  - id: todo-1764051327491-tc3rgoqgz
    content: Add preflight + FMP/Wiki fallback counters
    status: pending
  - id: todo-1764051327491-4jkjacih7
    content: Rebuild Admin Jobs modal & icon flow
    status: pending
  - id: todo-1764051327491-vsf18q8ys
    content: Compact Admin Runbook with quick actions
    status: pending
  - id: todo-1764051327491-ved9iilhd
    content: Finish Hex palette tokens in theme
    status: pending
  - id: todo-1764051327491-v5dcpr2cx
    content: Polish schedule metadata editor & quick actions
    status: pending
  - id: todo-1764051327491-gntg9fyz9
    content: Document coverage/alerts/index workflow changes
    status: pending
  - id: todo-1764051327491-vsvg5gw79
    content: Restore Postgres database from latest backup
    status: pending
  - id: todo-1764051327491-oec4qg8ef
    content: Point pytest to test DB + add safety guard
    status: pending
  - id: todo-1764116207990-yr3l9xc2i
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764116207990-gftje72ef
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207990-h1dnsg4vu
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764116207990-f78zluhl1
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764116207990-9ykl77knh
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764116207990-lp616xsoc
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764116207990-0dapt7cu2
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764116207990-daf1gzlio
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764116207990-eq13egf8b
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764116207990-9t69j9gnw
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764116207990-pdv9qxf79
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764116207990-7j64bwkbp
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207990-5ajnnl6d7
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764116207990-kzphcdmul
    content: Add redbeat; configure Celery Beat to use RedBeat scheduler
    status: completed
  - id: todo-1764116207990-kn05p3oo3
    content: Create backend job catalog with groups, defaults, safety; seed RedBeat on empty store
    status: completed
  - id: todo-1764116207990-85uwe0bel
    content: "Implement admin schedules API: list/create/update/pause/resume/delete/run-now with tz/cron validation"
    status: completed
  - id: todo-1764116207990-rr1802hh1
    content: Add export/import, dependencies, maintenance windows, pre-flight checks, safety controls, audit logging
    status: completed
  - id: todo-1764116207990-eh7r71abm
    content: Build Schedules UI with grouping, cron builder, tz select, next-runs preview, safety controls
    status: completed
  - id: todo-1764116207990-msyfezna6
    content: Enhance Jobs page (catalog, grouped), run-now with arg overrides, create-from-template
    status: completed
  - id: todo-1764116207990-8cl5z759j
    content: Add redbeat; configure Celery Beat to use RedBeat scheduler
    status: completed
  - id: todo-1764116207990-1nfyszevz
    content: Create backend job catalog with groups, defaults, safety; seed RedBeat on empty store
    status: completed
  - id: todo-1764116207990-7kai7y011
    content: "Implement admin schedules API: list/create/update/pause/resume/delete/run-now with tz/cron validation"
    status: completed
  - id: todo-1764116207990-xqgzzpyd1
    content: Build Schedules UI with grouping, cron builder, tz select, next-runs preview, safety controls
    status: completed
  - id: todo-1764116207990-hr4cqz90t
    content: Enhance Jobs page (catalog, grouped), run-now with arg overrides, create-from-template
    status: completed
  - id: todo-1764116207990-igaffbxox
    content: Add export/import, dependencies, maintenance windows, pre-flight checks, safety controls, audit logging
    status: completed
  - id: todo-1764116207990-1cg47i5v4
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764116207990-551t89am3
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207990-8xe6ekogh
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764116207990-5gr9nj8y7
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764116207990-2slqv3rf1
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764116207990-gl7ntaj88
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764116207990-lt9ng2nc5
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764116207990-9t8io3zc5
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764116207990-bj8oh9sgo
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764116207990-pt8l7wpcl
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764116207990-qswmww5s2
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764116207990-zxzeaxb5k
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207990-wolg71vhl
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764116207990-ypyeo6hsw
    content: Add bootstrap_universe task chaining refresh→tracked→backfills→recompute→record
    status: completed
  - id: todo-1764116207990-oayd32gsu
    content: Enhance coverage endpoints with freshness buckets and index counts
    status: completed
  - id: todo-1764116207990-fea1g5541
    content: Add Admin Dashboard KPIs, banners, and Bootstrap Universe action
    status: completed
  - id: todo-1764116207990-phg6ybqv5
    content: Show last-run status and stats on Jobs catalog cards
    status: completed
  - id: todo-1764116207990-tmb89lygi
    content: Expose last-run status/timestamp in Schedules list
    status: completed
  - id: todo-1764116207990-8oqeegq9f
    content: Add tests for fallback, preflight, JobRun counters, coverage states
    status: completed
  - id: todo-1764116207990-1vgbdi0r8
    content: Document universe bootstrap runbook and troubleshooting
    status: completed
  - id: todo-1764116207990-daa0zzzvv
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764116207990-d54reh398
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207990-xs9kn2414
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764116207990-p65q6lkr7
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764116207990-n15v6ql16
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764116207990-1009neyai
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764116207990-ynd264l3r
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764116207990-javk0j2q8
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764116207990-sgkjdvij2
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764116207990-hl07bwuuc
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764116207990-a0c4avfmi
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764116207990-fpgjexskf
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207990-el3mtek2a
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764116207990-x5fsv0hco
    content: Add redbeat; configure Celery Beat to use RedBeat scheduler
    status: completed
  - id: todo-1764116207990-0tdy2azu9
    content: Create backend job catalog with groups, defaults, safety; seed RedBeat on empty store
    status: completed
  - id: todo-1764116207990-nz69do205
    content: "Implement admin schedules API: list/create/update/pause/resume/delete/run-now with tz/cron validation"
    status: completed
  - id: todo-1764116207990-l5mfqbg12
    content: Build Schedules UI with grouping, cron builder, tz select, next-runs preview, safety controls
    status: completed
  - id: todo-1764116207990-8ip1pf92j
    content: Enhance Jobs page (catalog, grouped), run-now with arg overrides, create-from-template
    status: completed
  - id: todo-1764116207990-t6u7x5s48
    content: Add export/import, dependencies, maintenance windows, pre-flight checks, safety controls, audit logging
    status: completed
  - id: todo-1764116207990-a4r0ifq7h
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764116207990-zuetxd207
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207990-myxb5nnoq
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764116207990-fwurzr5ad
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764116207990-67gzur3lm
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764116207990-ib2pka8lj
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764116207990-und03w1nb
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764116207990-t67m8neux
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764116207990-0710ox0q0
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764116207990-2h7pdq7hj
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764116207990-zzcnn059w
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764116207990-3psackkuv
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207990-t0c6ruopl
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764116207990-vfavv5uvw
    content: Run bootstrap_universe and validate coverage
    status: completed
  - id: todo-1764116207990-lbf0uzqs2
    content: Humanize Jobs catalog + fix overflow
    status: completed
  - id: todo-1764116207990-zagg02gdv
    content: Educational snippets + optional columns
    status: completed
  - id: todo-1764116207990-hca2jm0kj
    content: Add guided Runbook actions
    status: completed
  - id: todo-1764116207990-x3ufu5xud
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764116207990-ipo9ceudp
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207990-1kdaobxax
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764116207990-g91arfjta
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764116207990-fog0herbi
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764116207990-rhdzsipgc
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764116207990-7zpp9xj37
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764116207990-v56wphzkm
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764116207990-hpxrm3bmq
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764116207990-z0es1ryw2
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764116207990-znni8xzfe
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764116207990-sl3d0kuzy
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207990-eghdv7vj3
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764116207990-4rqzrelrb
    content: Add redbeat; configure Celery Beat to use RedBeat scheduler
    status: completed
  - id: todo-1764116207990-60tc0dbeo
    content: Create backend job catalog with groups, defaults, safety; seed RedBeat on empty store
    status: completed
  - id: todo-1764116207990-2k3f8jwxs
    content: "Implement admin schedules API: list/create/update/pause/resume/delete/run-now with tz/cron validation"
    status: completed
  - id: todo-1764116207990-cf4g1r1oy
    content: Build Schedules UI with grouping, cron builder, tz select, next-runs preview, safety controls
    status: completed
  - id: todo-1764116207990-okb7egj5l
    content: Enhance Jobs page (catalog, grouped), run-now with arg overrides, create-from-template
    status: completed
  - id: todo-1764116207990-1ehpp9ccf
    content: Add export/import, dependencies, maintenance windows, pre-flight checks, safety controls, audit logging
    status: completed
  - id: todo-1764116207990-ol420skmp
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764116207990-8gwglrlrm
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207990-vnh0hn44d
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764116207990-3r2kldccn
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764116207990-pmhkhjsz0
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764116207990-n3kzr793f
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764116207990-40y1vsjqi
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764116207990-gvq0ochoz
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764116207990-etyp4coa7
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764116207990-bd71s8msi
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764116207990-nw52szpha
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764116207990-exje1tbda
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207990-p35p26uiy
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764116207990-2eqh52rm7
    content: Add bootstrap_universe task chaining refresh→tracked→backfills→recompute→record
    status: completed
  - id: todo-1764116207990-w15hg1yx0
    content: Enhance coverage endpoints with freshness buckets and index counts
    status: completed
  - id: todo-1764116207990-yp9uwhenv
    content: Add Admin Dashboard KPIs, banners, and Bootstrap Universe action
    status: completed
  - id: todo-1764116207990-s3czp6ofe
    content: Show last-run status and stats on Jobs catalog cards
    status: completed
  - id: todo-1764116207990-pr3zw0j81
    content: Expose last-run status/timestamp in Schedules list
    status: completed
  - id: todo-1764116207990-zsrty40qc
    content: Add tests for fallback, preflight, JobRun counters, coverage states
    status: completed
  - id: todo-1764116207990-yhtxkg25q
    content: Document universe bootstrap runbook and troubleshooting
    status: completed
  - id: todo-1764116207990-z337ol5si
    content: Add preflight + FMP-first/Wikipedia fallback to refresh_index_constituents
    status: completed
  - id: todo-1764116207990-jy4l0b4s0
    content: Record detailed JobRun counters per index; provider_used/fallback_used
    status: completed
  - id: todo-1764116207990-86zhumxpn
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764116207990-kpf4fhp1n
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207990-drzok73mz
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764116207990-jaktdqhus
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764116207990-9uy76dgzh
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764116207990-dsaxsojhb
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764116207990-p4jvizbbb
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764116207990-2in5g2r2v
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764116207990-qzb9m91yt
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764116207990-pv1ud3ygm
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764116207990-m6yve4ey7
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764116207990-1kw9zr5m4
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207990-y1uj4vw6p
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764116207990-sr1tek3kx
    content: Add redbeat; configure Celery Beat to use RedBeat scheduler
    status: completed
  - id: todo-1764116207990-vp1f2b152
    content: Create backend job catalog with groups, defaults, safety; seed RedBeat on empty store
    status: completed
  - id: todo-1764116207990-5siilel4i
    content: "Implement admin schedules API: list/create/update/pause/resume/delete/run-now with tz/cron validation"
    status: completed
  - id: todo-1764116207990-4nw9sumqi
    content: Build Schedules UI with grouping, cron builder, tz select, next-runs preview, safety controls
    status: completed
  - id: todo-1764116207990-6vdtup7re
    content: Enhance Jobs page (catalog, grouped), run-now with arg overrides, create-from-template
    status: completed
  - id: todo-1764116207990-ywx59c13q
    content: Add export/import, dependencies, maintenance windows, pre-flight checks, safety controls, audit logging
    status: completed
  - id: todo-1764116207990-ymnkipjmu
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764116207990-nzv6gs8ow
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207990-gwoud9gg8
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764116207990-9lxsdwawl
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764116207990-p0w4kjks7
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764116207990-lotqucoxn
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764116207990-85txwz7c3
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764116207990-mkpeyeywv
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764116207990-ar7aybndy
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764116207990-608qucyaw
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764116207990-gzsticlyz
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764116207990-5oxx9jynz
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207990-yo8fpjex9
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764116207990-08hqdz7qe
    content: Retune theme palette with refined blue hues
    status: completed
  - id: todo-1764116207990-qdul2y9wy
    content: Add coverage instrumentation to detect stale data
    status: completed
  - id: todo-1764116207990-k44ipsjle
    content: Add job detail modal/log view from Recent Runs
    status: completed
  - id: todo-1764116207990-vqbyy2lai
    content: Adjust sidebar + menu hover colors for dark theme
    status: completed
  - id: todo-1764116207990-whzv4h31b
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764116207990-7n3qkcn2t
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207990-o2vnmymx3
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764116207990-u97kzknu2
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764116207990-042rnn9j7
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764116207990-mllzsz93f
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764116207990-bw0nz2gw1
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764116207990-6kz1rfmxk
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764116207990-miplt664y
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764116207990-cepx5fwzd
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764116207990-mwdpw4982
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764116207990-t4sd326fe
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207990-bxtcpugbc
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764116207990-ryxax98hc
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764116207990-oky9t1uw2
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207990-c4czw17do
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764116207990-gbtj569yi
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764116207990-bat0j1wsi
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764116207990-b7wqou88n
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764116207990-pk9di4zvs
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764116207990-dxf99jep8
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764116207990-ygu5snfb0
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764116207990-vc5yj0vpg
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764116207990-2rpje48v5
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764116207990-nuyn1qgky
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207990-u3nzpkr1r
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764116207990-ghr03yfcl
    content: Add bootstrap_universe task chaining refresh→tracked→backfills→recompute→record
    status: completed
  - id: todo-1764116207990-3g6q2ny6b
    content: Enhance coverage endpoints with freshness buckets and index counts
    status: completed
  - id: todo-1764116207990-y2k6tn555
    content: Add Admin Dashboard KPIs, banners, and Bootstrap Universe action
    status: completed
  - id: todo-1764116207990-zhzjorzel
    content: Show last-run status and stats on Jobs catalog cards
    status: completed
  - id: todo-1764116207990-myxlabzz1
    content: Expose last-run status/timestamp in Schedules list
    status: completed
  - id: todo-1764116207990-8i1b7wthm
    content: Add tests for fallback, preflight, JobRun counters, coverage states
    status: completed
  - id: todo-1764116207990-38hql4wka
    content: Document universe bootstrap runbook and troubleshooting
    status: completed
  - id: todo-1764116207990-blnnsok8r
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764116207990-3qifal0od
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207990-8b6blpyw9
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764116207990-cosqt897g
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764116207990-wezl4jlyo
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764116207990-v8uip5sb0
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764116207990-ffwygpmvi
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764116207990-isavt9exj
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764116207990-l2dp8sxyr
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764116207990-4tb6klv19
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764116207990-onbsunm52
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764116207990-srsxbc1q2
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207990-4yrpk9x4z
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764116207990-0zr2n3jlh
    content: Add job_run table; add/verify indexes; optional partitioning by interval
    status: completed
  - id: todo-1764116207990-uuwh1b6vv
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207990-19nrpjoax
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
  - id: todo-1764116207990-ksjufh8pl
    content: Implement 5m backfill tasks and retention task
    status: completed
  - id: todo-1764116207990-3i43n98kt
    content: Add DB history, coverage, admin task/job routes with RBAC
    status: completed
  - id: todo-1764116207991-nrq0v03sk
    content: Add schedules API with RedBeat support and static read-only fallback
    status: completed
  - id: todo-1764116207991-hynal0bbe
    content: Add AdminShell with Dashboard, Jobs, Schedules, Coverage, Tracked (RBAC-gated)
    status: completed
  - id: todo-1764116207991-7plwrhrf0
    content: Manual triggers UI for tasks; job table; schedule editor/readonly view
    status: completed
  - id: todo-1764116207991-5wcagldhv
    content: Add tests for service, routes, tasks, models (5m, retention, RBAC, schedules)
    status: completed
  - id: todo-1764116207991-evumretmf
    content: Update MARKET_DATA.md and runbook (admin flows, scheduler)
    status: completed
  - id: todo-1764116207991-kydhno4o9
    content: Add job_run table; verify indexes; optional price_data partitioning
    status: completed
  - id: todo-1764116207991-87crvt99u
    content: Implement 5m provider fetch and backfill_intraday_5m; DB history reader
    status: completed
  - id: todo-1764116207991-19bwzqe3z
    content: Create task decorator for job_run+Redis; add locks and counters
    status: completed
---

# Hardening Coverage, Scheduler, and Test Architecture

## 1. Coverage KPIs & Instrumentation (`todo-1763881398178-arszppxdn`)
- Surface Redis `coverage:health:last` snapshot on Admin Dashboard & Coverage pages with SLA banners, sparkline trends, and stale counts.
- Extend backend `/market-data/coverage` response with sparkline-friendly history if needed (store recent snapshots or derive from Redis lists).
- Update `AdminDashboard.tsx` & `AdminCoverage.tsx` to show KPI cards (status, tracked count, stale counts) plus action buttons.
- Add tests covering new snapshot formatting and UI data adapters.

## 2. Scheduler Alerts & Observability (`todo-1763881398178-sl2wldowm`)
- Introduce Discord webhook + optional Prometheus push helpers (new module under `backend/services/alerts.py`).
- Enhance `task_run` decorator to emit alerts on failure/slow runs based on metadata thresholds (queue, max duration) and publish Prom metrics.
- Wire metadata hooks from `ScheduleMetadata` (e.g., `hooks.discord_channels`) to alert destinations.
- Document configuration in `MARKET_DATA.md` and add unit tests for alert dispatch logic.

## 3. Scheduler Test Suite Expansion (`todo-1763881398178-jgxw1sx33`)
- Add fixtures for seeded RedBeat store to verify catalog seeding, tz/DST cron validation, maintenance windows, dependencies, export/import, and audit stamps.
- Tests live in `backend/tests/` (e.g., `test_admin_scheduler_crud.py`, `test_schedule_export_import.py`).
- Mock Redis/Celery where needed to keep tests deterministic.

## 4. Index Refresh Hardening (`todo-1763885600416-s5ntqt7x1`, `todo-1763885600416-ntau16zol`)
- Implement FMP-first + Wikipedia fallback pipeline with preflight checks inside `market_data_service.get_index_constituents`.
- Capture per-index counters (`provider_used`, `fallback_used`, `preflight_passed`) into `JobRun.counters` and persist summary metadata (Redis or DB).
- Extend admin endpoints/tests to assert counters exist; document in `MARKET_DATA.md` runbook.

## 5. Admin UX Polishing
- **Jobs single-action modal** (`todo-1763938243354-jgjqk9bvj`): consolidate run-now/run-with-args/schedule into streamlined modal, ensure data hooks reused, update `AdminJobs.tsx` tests.
- **Runbook density** (`todo-1763938243354-9cs0mdtj0`): redesign `AdminRunbook.tsx` layout with compact cards, grouped steps, and quick action buttons tied to `triggerTaskByName` helpers.
- **Scheduler enhancements (`sched-enhance`)**: finish metadata editor niceties (input validation, quick actions to schedule coverage monitor, import/export UX hints), ensure pause/resume states highlighted.

## 6. Theme Palette Refinement (`todo-1763938243354-ru9aftc4r`)
- Finalize Hex-inspired semantic tokens in `App.tsx` / theme file (adjust surfaces, typography, sidebar) and propagate to components (Buttons, Tabs, Cards) for consistent light/dark contrast.
- Validate via storybook/pages and tweak Settings/Admin shells accordingly.

## 7. Recover Production Data & Safeguards
- Immediately restore `price_data` (and other affected tables) from the most recent available backup/snapshot instead of attempting backfills.
- Enforce a single test architecture: every DB test must use the `test_db` / `db_session` fixtures, any direct `SessionLocal` usage in tests should either raise or be linted out. Add a hard guard so destructive tests abort when not running against `TEST_DATABASE_URL`.
- Add CI/linting hooks to flag tests that bypass the fixture and update docs so contributors know the policy.

## 8. Remaining Scheduler/UI Backlog
- Complete the rest of the plan items: scheduler alerts, expanded tests, index refresh counters, Jobs/Runbook UI polish, theme tokens, documentation, etc., so no backlog items remain.

### Implementation Todos
- coverage-ui: Wire coverage KPIs & sparkline data into Admin Dashboard/Coverage.
- scheduler-alerts: Add Discord/Prom alerts + metadata-driven hooks.
- scheduler-tests: Expand backend tests for catalog/CRUD/export/import/audit.
- index-refresh: Add preflight + FMP/Wiki fallback with counters.
- jobs-ux: Rebuild Admin Jobs single action modal & quick actions.
- runbook-density: Compact Admin Runbook layout w/ task triggers.
- theme-hex: Finish Hex-inspired theme tokens across Settings/Admin.
- sched-enhance: Final polish for schedule metadata editor & quick actions.
- docs-update: Document coverage/alerts/index workflow changes.
- restore-prod-db: Restore Postgres tables from latest backup.
- test-db-guard: Point pytest at dedicated test DB and add safety checks.
- test-architecture-enforce: Enforce fixture-only DB access (guards + lint).