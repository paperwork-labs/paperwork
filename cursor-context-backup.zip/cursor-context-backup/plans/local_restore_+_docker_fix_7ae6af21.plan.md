---
name: Local restore + docker fix
overview: Recover the locally-missing `web/` and `backend/` files from git history without losing any uncommitted work, then fix Docker Compose env/project naming so `make up` works reliably.
todos:
  - id: snapshot-local
    content: Create a safety snapshot (stash + optional backup) before restoring files.
    status: completed
  - id: restore-web-backend
    content: Restore `web/` and `backend/` from git (HEAD or last-good commit containing them).
    status: completed
    dependencies:
      - snapshot-local
  - id: reapply-local-changes
    content: Re-apply stashed local changes and resolve any conflicts.
    status: completed
    dependencies:
      - restore-web-backend
  - id: fix-compose-env-naming
    content: Align `infra/compose.yaml` port/env vars with `infra/env.dev` and ensure Compose project is `jointly`.
    status: completed
    dependencies:
      - reapply-local-changes
  - id: restart-stack
    content: Run `make down` then `make up --build` and validate containers/ports.
    status: completed
    dependencies:
      - fix-compose-env-naming
---

# Restore missing web/backend locally

## What’s happening

Your working tree currently has **missing files** (e.g. `web/package.json`, `backend/Dockerfile`, `backend/app/*`). Your local git history still exists (we can see multiple commits in `.git/logs`), so the most reliable restore is to **stash your current uncommitted work**, then **restore the missing paths from a known-good commit**.

## Steps (safe, preserves your changes)

### 1) Snapshot your current local state (so nothing is lost)

- Create a safety checkpoint via **stash** (includes untracked files).
- Optionally also create a local backup archive of `web/` + `backend/` as they exist right now (even if sparse).

### 2) Restore `web/` and `backend/` from git

- First try restoring from **`HEAD`** (fast path):
- `git restore --source=HEAD --staged --worktree web backend`
- If `HEAD` doesn’t contain those paths (unlikely, but possible), restore from the last commit that did:
- Find the last commit containing `web/package.json` and `backend/app/main.py`.
- Restore those folders from that commit.

### 3) Re-apply your local changes cleanly

- Pop the stash.
- If there are conflicts, resolve them with a bias toward keeping the restored project structure + your edits.

### 4) Fix Docker Compose naming + env wiring (so `make up` works)

Right now there’s an env mismatch:

- `infra/env.dev` defines `DB_HOST_PORT`, `BACKEND_HOST_PORT`, etc.
- `infra/compose.yaml` currently expects `DB_PORT`, `BACKEND_PORT`, etc.

We’ll standardize to the `*_HOST_PORT` variables in `infra/env.dev` and update Compose accordingly.

- Update [`infra/compose.yaml`](/Users/sankalpsharma/development/jointly/infra/compose.yaml) to:
- Keep `name: jointly`
- Use `DB_HOST_PORT`, `REDIS_HOST_PORT`, `BACKEND_HOST_PORT`, `WEB_HOST_PORT` in port mappings
- Ensure web gets a sane `NEXT_PUBLIC_API_BASE_URL` (either set in env file, or computed consistently)
- Update [`Makefile`](/Users/sankalpsharma/development/jointly/Makefile) to always run compose with `--project-name jointly --env-file env.dev`

### 5) Bring the stack up and verify

- `make down`
- `make up --build`
- Confirm containers are named under the `jointly` project and ports bind as expected.

## Files we’ll touch

- Restore from git: `web/**`, `backend/**`
- Config fixes:
- [`infra/compose.yaml`](/Users/sankalpsharma/development/jointly/infra/compose.yaml)
- [`infra/env.dev`](/Users/sankalpsharma/development/jointly/infra/env.dev) (add any missing vars like `NEXT_PUBLIC_API_BASE_URL` if needed)