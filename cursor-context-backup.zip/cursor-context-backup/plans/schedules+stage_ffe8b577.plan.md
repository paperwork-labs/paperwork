---
name: Schedules+Stage
overview: Explain current scheduling/coverage behavior, add user-friendly cron display in Admin Schedules, and fix empty Stage/RS in MarketTracked by ensuring snapshot computation has required inputs and visibility.
todos: []
isProject: false
---

# Admin Schedules (friendly cron) + Stage/RS fix

## What’s happening today (answers)

- **Tracked list updates**:
- **Nightly** by default when schedules are seeded (RedBeat): `update_tracked_symbol_cache` defaults to `30 2 * * *` UTC (see `[backend/tasks/job_catalog.py](backend/tasks/job_catalog.py)`), and **Restore Daily Coverage (Tracked)** also refreshes constituents + tracked cache as part of the chain.
- **On demand**: Admin Dashboard → Advanced → **Update Tracked**.
- **Why Stage / Stage(5d ago) / RS are empty for all symbols**:
- These are computed from **OHLCV** and **SPY benchmark data** during `recompute_indicators_universe` / snapshot generation.
- If the snapshot job hasn’t run since recent schema changes (or SPY history is missing), those columns will stay null across all rows.

## 1) Admin Schedules: show cron in user-friendly text (user TZ)

**Files:**

- `[frontend/src/pages/AdminSchedules.tsx](frontend/src/pages/AdminSchedules.tsx)`
- (optional) `[backend/api/routes/admin_scheduler.py](backend/api/routes/admin_scheduler.py)`

Plan:

- Keep the raw **cron** column.
- Add a **“Schedule (friendly)”** column:
- Use `/admin/schedules/preview?cron=…&timezone=…&count=1` to fetch the **next run**.
- Render: `Every day at 03:00 AM PT (UTC 11:00)` or `Every hour at :00 PT` when pattern matches.
- If cron is uncommon, show: `Next run: <date/time in user TZ>`.
- Add helper text in the page header: “Times are shown in your timezone; cron is stored in schedule timezone.”

## 2) Fix Stage/RS empty in MarketTracked

**Files:**

- `[backend/services/market/indicator_engine.py](backend/services/market/indicator_engine.py)`
- `[backend/services/market/market_data_service.py](backend/services/market/market_data_service.py)`
- `[backend/tasks/market_data_tasks.py](backend/tasks/market_data_tasks.py)`
- `[frontend/src/pages/AdminDashboard.tsx](frontend/src/pages/AdminDashboard.tsx)`

Plan:

- Verify computation pipeline for Mansfield RS + Weinstein Stage:
- Ensure SPY history is available when computing RS; if missing, log and mark RS as null with a clear error counter.
- Ensure `compute_weinstein_stage_from_daily` is called with sufficient lookback.
- Add a **small diagnostic note** in Admin Dashboard Advanced:
- “If Stage/RS are empty, run Recompute Indicators (Market Snapshot).”
- If still empty after recompute, add a short **admin warning**: “SPY history missing; RS/Stage cannot be computed.”

## 3) Update MarketTracked explanation text

**File:** `[frontend/src/pages/MarketTracked.tsx](frontend/src/pages/MarketTracked.tsx)`

- Add a small info line describing:
- sector/sub-sector = **fundamentals**
- Level 1–4 = **derived from OHLCV + SPY benchmark**

## 4) Tests

- Update or add a small frontend test for **AdminSchedules** to ensure the new “friendly schedule” column renders.
- Add backend test (if needed) for schedule preview usage or for RS/Stage missing → warning path.

