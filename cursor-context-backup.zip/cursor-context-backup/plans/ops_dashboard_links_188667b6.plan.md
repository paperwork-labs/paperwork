---
name: Ops dashboard links
overview: Add clickable dashboard URLs and quick-start access instructions for each service on the /ops page.
todos:
  - id: add-dashboard-urls
    content: Add dashboardUrl and accessHint fields to PRODUCTION_SERVICES in the API route and ServiceCheck interface
    status: completed
  - id: render-links-on-cards
    content: Update ServiceCard in the ops page to show clickable dashboard link and access hint
    status: completed
isProject: false
---

# Ops Dashboard: Service Links + Access Guide

Two changes across two files:

## 1. Add a `dashboardUrl` field to each service in the API response

In [web/src/app/api/ops/route.ts](web/src/app/api/ops/route.ts), add a `dashboardUrl` (the URL you visit to manage the service) to each entry in `PRODUCTION_SERVICES` alongside a one-line `accessHint`:

- **Render API** -- `https://dashboard.render.com` / "Render dashboard > filefree-api service"
- **Vercel Frontend** -- `https://vercel.com/dashboard` / "Vercel dashboard > filefree project"
- **n8n (Agents)** -- `https://n8n.filefree.tax` / "Login with N8N_USER / N8N_PASSWORD from env"
- **Postiz (Social)** -- `https://social.filefree.tax` / "Login, then connect TikTok/IG/X/YouTube accounts"
- **PostHog (Analytics)** -- `https://us.posthog.com` / "Login to view funnels, events, dashboards"

These fields are passed through unchanged in the `ServiceCheck` interface and JSON response.

## 2. Show clickable link + access hint on each service card

In [web/src/app/ops/page.tsx](web/src/app/ops/page.tsx), update the `ServiceCard` component:

- Below the status line, render the `dashboardUrl` as a clickable link with an `ExternalLink` icon (already imported) that opens in a new tab. Display just the hostname (strip protocol).
- Below that, show the `accessHint` as a muted text line so you know how to get into each service.

The card would go from:

```
[icon] n8n (Agents)
       healthy
       245ms
```

to:

```
[icon] n8n (Agents)
       healthy
       n8n.filefree.tax  [external-link-icon]
       Login with N8N_USER / N8N_PASSWORD from env
       245ms
```

No new files, no new dependencies, no tests needed -- purely additive UI metadata.