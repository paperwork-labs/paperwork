---
name: market-data-improvements
overview: Plan targeted improvements across market data performance, cache contract, resiliency, data quality, backfill ergonomics, observability, and retention policies.
todos:
  - id: indexes
    content: Add/verify composite indexes for hot market tables
    status: completed
  - id: cache-contract
    content: Add coverage cache schema validation + tests
    status: completed
  - id: provider-resiliency
    content: Centralize retry/backoff + error sampling
    status: completed
  - id: data-quality
    content: Nightly audit job + admin read endpoint
    status: completed
  - id: backfill-dryrun
    content: Add coverage restore dry‑run endpoint + tests
    status: completed
  - id: observability
    content: Standardize JobRun counters + Admin UI display
    status: completed
  - id: retention-policy
    content: Formalize 5m retention schedule + alerts
    status: completed
  - id: tests
    content: Run make test + fix regressions
    status: completed
isProject: false
---

# Market Data Improvements Plan

## Scope

- Focus on performance, reliability, observability, and operator ergonomics in market-data workflows without changing business behavior.
- Keep backend as the source of truth; ensure UI remains read‑only for market data unless admin‑triggered.

## Plan

- **Index + query performance**
  - Audit and add composite indexes for hot paths:
    - `[backend/models/market_data.py](/Users/sankalpsharma/development/axiomfolio/backend/models/market_data.py)` add/verify composite index for `price_data(symbol, interval, date)` and `market_snapshot(symbol, analysis_type, analysis_timestamp)`.
  - Validate query usage in `[backend/services/market/market_data_service.py](/Users/sankalpsharma/development/axiomfolio/backend/services/market/market_data_service.py)` and coverage paths to ensure they hit indexed columns.
- **Coverage cache contract + validation**
  - Define a versioned schema for Redis payloads (e.g., `coverage:health:last`), validate on read, and fallback to DB if mismatched.
  - Implement validation in `[backend/services/market/coverage_service.py](/Users/sankalpsharma/development/axiomfolio/backend/services/market/coverage_service.py)`; update tests in `[backend/tests/test_coverage_states.py](/Users/sankalpsharma/development/axiomfolio/backend/tests/test_coverage_states.py)` to cover schema mismatch fallback.
- **Provider resiliency + structured errors**
  - Centralize retry/backoff and rate‑limit handling in provider calls; ensure retries are bounded and logged.
  - Add structured error sampling (`provider`, `symbol`, `error_type`) for task runs.
  - Touch `[backend/services/market/market_data_service.py](/Users/sankalpsharma/development/axiomfolio/backend/services/market/market_data_service.py)` and `[backend/tasks/market_data_tasks.py](/Users/sankalpsharma/development/axiomfolio/backend/tasks/market_data_tasks.py)`.
- **Data quality audits**
  - Add nightly audit job to detect missing OHLCV gaps and snapshot history inconsistencies.
  - Store audit results (counts + samples) and surface in admin endpoints.
  - Update `[backend/tasks/market_data_tasks.py](/Users/sankalpsharma/development/axiomfolio/backend/tasks/market_data_tasks.py)` and add a lightweight admin read endpoint in `[backend/api/routes/market_data.py](/Users/sankalpsharma/development/axiomfolio/backend/api/routes/market_data.py)`.
- **Backfill ergonomics**
  - Add a dry‑run endpoint to preview inferred `history_days` and affected date ranges for `admin_coverage_restore`.
  - Implement in `[backend/api/routes/market_data.py](/Users/sankalpsharma/development/axiomfolio/backend/api/routes/market_data.py)` and test with a small unit test under `[backend/tests/](/Users/sankalpsharma/development/axiomfolio/backend/tests/)`.
- **Task observability**
  - Standardize `JobRun.counters` for market‑data tasks with counts and latency buckets to help UI reporting.
  - Extend the Admin UI display to show these counters in `[frontend/src/pages/AdminDashboard.tsx](/Users/sankalpsharma/development/axiomfolio/frontend/src/pages/AdminDashboard.tsx)`.
- **Retention policy enforcement**
  - Formalize 5m retention thresholds and enforce via scheduled task, with alerts on deletion volume anomalies.
  - Update `[backend/tasks/celery_app.py](/Users/sankalpsharma/development/axiomfolio/backend/tasks/celery_app.py)` and `[backend/tasks/job_catalog.py](/Users/sankalpsharma/development/axiomfolio/backend/tasks/job_catalog.py)`.

## Test Plan

- Add/extend unit tests for cache schema validation, audit results, and dry‑run endpoint.
- Run `make test`.

