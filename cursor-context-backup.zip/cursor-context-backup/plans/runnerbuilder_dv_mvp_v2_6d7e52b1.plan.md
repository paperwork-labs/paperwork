---
name: RunnerBuilder_DV_MVP_v2
overview: Gmail-inspired Runner Builder with preview→create flow, multi-runner support, Doorvest promo/actionable separation, continuous ingest, Poe-powered drafts (approval-only), plus dark mode (system default + override in topbar and settings).
todos:
  - id: runner-data-model
    content: Add runner tables + Alembic migration (runners, runner_filters, runner_items, runner_runs).
    status: pending
  - id: runner-preview-api
    content: "Implement Runner preview API: facets → compiled Gmail query → paged preview results (cap=1000)."
    status: pending
    dependencies:
      - runner-data-model
  - id: runner-create-seed
    content: "Create runner: store filter + enqueue seed ingest job to ingest previewed emails into DB."
    status: pending
    dependencies:
      - runner-preview-api
  - id: runner-polling-jobs
    content: Add polling scheduler + delta ingest jobs for new matches per runner.
    status: pending
    dependencies:
      - runner-create-seed
  - id: promo_actionable_classify
    content: Rules-first classification + Poe LLM fallback; persist promo/actionable + confidence + reason.
    status: pending
    dependencies:
      - runner-polling-jobs
  - id: structured_extraction
    content: Doorvest extraction (JSON schema) + persistence for UI fields.
    status: pending
    dependencies:
      - promo_actionable_classify
  - id: draft_generation
    content: Poe OpenAI-compatible draft generation (approval-only) stored as artifact linked to runner items.
    status: pending
    dependencies:
      - promo_actionable_classify
  - id: frontend_runners_ui
    content: Add Runners nav + builder (search+facet chips w/ icons)+preview+create flow + runner detail tabs and item actions.
    status: pending
    dependencies:
      - runner-preview-api
      - runner-create-seed
  - id: theme_darkmode
    content: "Add dark mode: tokenized CSS vars, system default + cookie override, toggle in Topbar and Settings."
    status: pending
  - id: docs_suite
    content: Add docs/RUNNERS.md + docs/LLM_POE.md; update docs/UX_FRONTEND.md with runner journeys + dark mode + diagrams.
    status: pending
    dependencies:
      - frontend_runners_ui
      - theme_darkmode
---

# Runner Builder MVP v2 (Doorvest-first, multi-runner, dark mode, Poe LLM)

## What we’re building (MVP outcome)
A **Runner Builder** that feels like Gmail search:
- Type search (e.g., `doorvest`)
- Add facet chips (From, Subject, Body, Labels, Date range, Unread, Has attachment) with icons
- **Preview** matched emails (paged, default cap=1000)
- Click **Create Runner** → seed ingest those emails into DB + store rule
- Background polling keeps ingesting **new matches**
- Runner UI shows **Queue (actionable)** vs **Promos**, supports workflows, and can generate **LLM reply drafts** (never auto-send)

Also add **Dark Mode** (system default + user override) accessible in **Topbar and Settings**, persisted via cookie.

## UX journeys (PM view)
### Journey_CreateRunner
1) Runners → New Runner
2) Search bar: `doorvest`
3) Add/edit facets via chips + popovers:
   - From include/exclude
   - Subject contains/doesn’t
   - Body contains/doesn’t
   - Labels include/exclude
   - Date range (newer_than/older_than)
   - Unread
   - Has attachment
4) Preview list updates live; user can page through results
5) Create Runner:
   - name runner
   - confirm seed ingest scope (cap=1000)
   - choose cadence defaults

### Journey_UseRunner
- Runner detail tabs: Queue (Actionable), Promos, All matched, Drafts, Settings
- Item actions: mark done, assign owner + due date, tags, open in Gmail, generate draft, create internal task

### Journey_PromoFiltering
- Rules-first + LLM fallback (only when uncertain)
- Promo emails stay ingested but don’t clutter the actionable queue

### Journey_Drafts
- Draft generation uses Poe via OpenAI-compatible endpoint
- Always requires review; output stored in DB as an artifact

### Journey_DarkMode
- Default: follow system theme
- User can override (Light/Dark/System) from Topbar toggle or Settings
- Preference persisted via cookie

## Architecture (architect view)
- **Read-only Gmail** scope now (gmail.readonly). Future: add gmail.modify for labeling/mark-read.
- Seed creation ingests previewed messages into Postgres (threads/messages/attachments) so the agent has context.
- Continuous polling enqueues jobs; idempotent on Gmail IDs.
- LLM via Poe OpenAI-compatible API base URL `https://api.poe.com/v1` (per Poe docs) using your `POE_API_KEY`.
  - We will include recommended attribution headers `HTTP-Referer` and `X-Title`.

Reference: Poe OpenAI-compatible usage examples and base URL are documented at [Poe External Application Guide](https://creator.poe.com/docs/external-applications/external-application-guide#querying-poe-bots-via-an-api-key).

```mermaid
flowchart TD
  runnerUI[RunnerBuilderUI] --> api[RunnerAPI]
  api --> gmail[GmailSearch_Readonly]
  api --> db[Postgres]
  api --> queue[RQ]
  queue --> worker[RunnerJobs]
  worker --> poe[Poe_OpenAI_Compatible]
  worker --> db
```

## Backend scope (engineer view)
### 1) Data model additions
- `runners`
- `runner_filters` (facets_json + compiled_query)
- `runner_items` (email_message_id + classification + workflow fields)
- `runner_runs` (optional, for auditability)

### 2) APIs
- `POST /assistant/api/runners/preview` (facet payload → preview results)
- `POST /assistant/api/runners` (create runner + seed ingest enqueue)
- `GET /assistant/api/runners` / `GET /assistant/api/runners/{id}`
- `GET /assistant/api/runners/{id}/items?tab=queue|promos|all`
- `POST /assistant/api/runners/{id}/items/{item_id}/actions`
- `POST /assistant/api/runners/{id}/drafts`

### 3) Jobs
- Seed ingest job: ingest preview matches (paged) into DB
- Poll job: periodically search for new matches; ingest delta
- Classify job: promo vs actionable (rules + LLM fallback)
- Extract job: Doorvest-specific structured fields
- Draft job: generate reply draft (approval-only)

### 4) Poe LLM integration
- Config:
  - `POE_API_KEY`
  - `LLM_BASE_URL=https://api.poe.com/v1`
  - `LLM_MODEL_*` (balanced defaults)
  - `LLM_HTTP_REFERER` and `LLM_X_TITLE` (placeholders now; you’ll provide production values later)
- Implementation uses OpenAI-compatible `/chat/completions`.

## Frontend scope
### IA
- Add **Runners** to nav
  - `/runners` list
  - `/runners/new` builder
  - `/runners/[id]` detail
- Keep Next’s `page.tsx` convention, but move real components into:
  - `frontend/src/features/runners/*` (named components)
  - `frontend/src/app/components/ui/*` (shared primitives)

### Runner Builder UI details
- Gmail-like search bar + facet chips with icons
- Facet popovers (clean, compact)
- Preview results table
- Create Runner modal/step

### Dark mode
- Implement tokenized theming (CSS variables)
- `Theme` cookie + system theme detection
- Toggle in Topbar + Settings screen

## Documentation
- Update `docs/UX_FRONTEND.md` with runner journeys + dark mode.
- Add `docs/RUNNERS.md` with concepts, facet→query mapping, polling behavior.
- Add `docs/LLM_POE.md` with Poe config + headers + model selection.

## Open questions (to answer before coding)
- Provide production values for Poe attribution headers (`LLM_HTTP_REFERER`, `LLM_X_TITLE`).

## Implementation todos
- runner-data-model: Add runner tables + migrations
- runner-preview-api: Preview endpoint + Gmail query compilation
- runner-create-seed: Create runner + enqueue seed ingest
- runner-polling-jobs: Polling + delta ingestion
- promo_actionable_classify: Rules + Poe fallback classifier
- structured_extraction: Doorvest extraction schema
- draft_generation: Poe drafts + storage
- frontend_runners_ui: Builder + preview + runner detail UI + icons
- theme_darkmode: System-default theme + cookie override + Topbar+Settings toggle
- docs_suite: UX/Runners/Poe docs updates
