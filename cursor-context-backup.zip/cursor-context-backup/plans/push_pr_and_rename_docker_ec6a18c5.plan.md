---
name: Push PR and Rename Docker
overview: Push the auth branch, create a PR, and rename the Docker Compose project from "infra" to "filefree" so containers show the correct name in Docker Desktop.
todos:
  - id: push-pr
    content: Push feat/2.1-backend-auth branch and create PR
    status: completed
  - id: rename-docker
    content: "Add name: filefree to compose.dev.yaml and update Makefile"
    status: completed
isProject: false
---

# Push PR and Rename Docker Project

## 1. Push branch and create PR for Task 2.1

The auth system is committed on `feat/2.1-backend-auth` (1 commit ahead of main) but never pushed.

- Push to origin
- Create PR with summary of all 7 new files, 20 tests, architecture

## 2. Rename Docker project from "infra" to "filefree"

Currently the compose file at [infra/compose.dev.yaml](infra/compose.dev.yaml) has no explicit project name, so Docker uses the parent directory name "infra".

Two changes:

- Add `name: filefree` at the top of `infra/compose.dev.yaml` (Docker Compose v2.17+ supports this)
- Update the Makefile `COMPOSE` variable to include `-p filefree` as a fallback for older Docker Compose versions

After this, Docker Desktop will show the project as "filefree" with containers named `filefree-api-1`, `filefree-postgres-1`, etc.

**Note**: You'll need to `make clean && make dev` once to recreate containers under the new name (old "infra" containers will need manual removal or `docker compose -f infra/compose.dev.yaml -p infra down -v`).