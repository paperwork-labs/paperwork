---
name: Adjacent Business Opportunities
overview: "A McKinsey-style strategic assessment of high-potential business opportunities that share FileFree's DNA: free service as acquisition channel, AI-powered document processing, financial product referral monetization, vibe-coded by a lean team with AI agents, targeting underserved \"adulting anxiety\" moments."
todos:
  - id: review-report
    content: Review the strategic opportunity assessment with both co-founders and decide which opportunity to pursue first
    status: pending
  - id: validate-bizfree
    content: "If BizFree is chosen: research state filing APIs, registered agent partnership options, and business banking affiliate programs"
    status: pending
  - id: validate-loanfree
    content: "If LoanFree is chosen: research FSA API documentation, student loan refinancing affiliate applications, and IDR plan calculation rules"
    status: pending
isProject: false
---

# FileFree Adjacent Opportunity Assessment

**Classification**: Internal -- Founders + Advisors
**Prepared by**: AI Strategy Team (multi-persona review: Strategy, CFO, Growth, CPA, Legal, Engineering)
**Date**: March 2026

---

## Executive Summary

FileFree has built a repeatable playbook: identify a **high-anxiety government/financial paperwork moment**, make it **free and fast with AI**, and monetize through **financial product referrals at the decision point**. This is the Credit Karma playbook ($7.1B acquisition) applied to tax filing.

The strategic question: **Where else does this playbook apply?**

We evaluated 10 adjacent markets against FileFree's core competencies: OCR/AI document processing, free-as-acquisition-channel economics, financial product referral monetization, mobile-first Gen Z targeting, and vibe-codability (buildable by 1-2 founders + AI agents in 6-8 weeks).

**Verdict: Three opportunities score higher than FileFree on revenue potential, and two of them are less seasonal.** The top recommendation is **AI-powered small business formation and compliance** -- it has FileFree's exact playbook but with recurring revenue, higher ARPU, and a larger addressable market.

---

## The FileFree Playbook (What We're Looking For)

Every opportunity is scored against these seven criteria -- the DNA of what makes FileFree work:

1. **Anxiety-Driven Paperwork Moment** -- Government or institutional process that causes stress, confusion, and procrastination
2. **Free Service = Acquisition Channel** -- The core service can be free because the economics work through referral monetization
3. **AI/OCR Meaningfully Reduces Friction** -- Not just "chatbot on top of a form" but genuine 10x speed improvement
4. **Financial Product Referral Monetization** -- Natural moment to recommend financial products with proven affiliate/referral revenue
5. **High ARPU Through Partnerships** -- $5+ per user achievable through existing affiliate programs
6. **Vibe-Codeable** -- Buildable by 1-2 founders with AI coding agents in 6-8 weeks, same tech stack (Next.js + FastAPI + managed services)
7. **Defensible Lock-In** -- First-mover advantage compounds (data, trust, switching costs)

---

## TIER 1: RECOMMENDED OPPORTUNITIES

### Opportunity 1: Free Small Business Formation & Compliance ("BizFree")

**One-liner**: "LegalZoom charges $299. We charge $0. Just pay the state fee."

**The Pain**:

- 5.5M new business applications filed in the US per year (Census Bureau, 2023-2025 trend)
- LegalZoom charges $0-$299 for formation + $299/yr for registered agent
- ZenBusiness charges $0-$199 + $199/yr registered agent
- Solo founders and side-hustlers pay $500-1,500 total in Year 1 for what amounts to filling out a form and filing it with the state
- TAM: $12.5B global company registration market (2026), growing at 8.1% CAGR

**Why This is Bigger Than FileFree**:


| Factor            | FileFree (Tax)                    | BizFree (Formation)                                                                       |
| ----------------- | --------------------------------- | ----------------------------------------------------------------------------------------- |
| Seasonal?         | Yes (Jan-Apr)                     | No (year-round)                                                                           |
| Revenue type      | Mostly one-time referrals         | RECURRING (registered agent)                                                              |
| ARPU              | $8.05                             | $150-250 (registered agent + referrals)                                                   |
| Engagement        | 1x/year                           | Monthly (compliance reminders, filings)                                                   |
| TAM               | 166M filers but only Gen Z target | 5.5M new businesses/year, ALL segments                                                    |
| Natural referrals | HYSA, IRA                         | Business banking ($100-200), insurance ($50-100), payroll ($50-100/yr), bookkeeping tools |


**The Playbook** (identical to FileFree):

1. **Free LLC/Corp formation** -- user answers 10 questions, AI generates articles of incorporation, we file with the state. User pays only the state fee ($50-500 depending on state).
2. **OCR/AI parallel**: Scan existing business documents, extract EIN, articles, past filings. Auto-populate compliance calendar.
3. **Gate the ongoing relationship**: "Your LLC is formed! Now let's keep it in good standing." Annual report reminders, compliance calendar, registered agent service.
4. **Monetization at the decision moment**:
  - Registered agent service: $99-149/yr RECURRING (this alone is a massive business -- CSC Global does $2B/yr)
  - Business bank account referrals: Mercury, Relay, Novo pay $100-200 per funded account
  - Business insurance referrals: Next Insurance, Hiscox pay $50-100 per policy
  - Payroll referrals: Gusto, Rippling pay $50-100 per signup
  - Bookkeeping referrals: QuickBooks, Xero pay $50-100 per signup
  - Business credit card referrals: $100-200 per approval

**Cost Structure** (CFO assessment):

- State filing APIs / manual filing: $0-10/filing (some states have APIs, others need mail)
- AI form generation: ~$0.01/filing (GPT-4o-mini structured output)
- Infrastructure: same stack as FileFree (~$12-15/mo fixed)
- Cost per user: ~$0.05-0.15 (nearly identical to FileFree)
- Gross margin: 95%+

**Competitive Moat**:

- First-mover in "truly free formation" builds trust pipeline (same as FileFree's first-filer lock-in)
- Registered agent is sticky (annual recurring, painful to switch)
- Compliance data compounds (multi-year business records = better advisory)
- B2B API opportunity: embed formation into fintech apps (Stripe Atlas charges $500)

**Vibe-Codability**: HIGH

- Same tech stack (Next.js + FastAPI + PostgreSQL)
- Form generation = PDF generation (we already do this for 1040)
- State filing APIs exist for ~30 states, manual filing (mail) for the rest
- 6-week MVP: formation questionnaire, articles generation, PDF download, compliance calendar
- Phase 2: registered agent service, state filing automation, business banking referrals

**Risk Assessment**:

- ZenBusiness already offers $0 formation (but charges $199/yr registered agent and upsells aggressively)
- State filing requirements vary significantly (50 states = 50 rule sets, similar to state tax)
- Registered agent requires a physical address in each state (can partner with existing RA networks)
- Legal: formation is NOT practicing law if you're just filling in forms per user input (settled law: LegalZoom v. State Bar cases)

**Strategy Verdict**: STRONG PROCEED. This is FileFree's playbook with recurring revenue and no seasonality. The registered agent service alone is a $200M+ market. Combined with referral monetization, ARPU could be 15-30x higher than FileFree.

---

### Opportunity 2: AI Student Loan Optimizer ("LoanFree")

**One-liner**: "45 million Americans owe $1.77 trillion. None of them know the optimal repayment plan."

**The Pain**:

- $1.77T in outstanding student loan debt, 45M borrowers
- 8 different IDR (income-driven repayment) plans, each with different rules
- SAVE plan chaos (2024-2026 legal battles) left millions confused
- Average Gen Z borrower: $33,500 in debt, $350/mo payments
- 4 in 10 high school seniors don't complete FAFSA, leaving $3.6B in Pell Grants unclaimed
- Refinancing can save $5,000-30,000 over the life of a loan, but most borrowers never compare

**Why This is Bigger Than FileFree**:


| Factor                  | FileFree (Tax)           | LoanFree (Student Loans)         |
| ----------------------- | ------------------------ | -------------------------------- |
| TAM users               | ~35M Gen Z filers        | 45M borrowers (ALL ages)         |
| TAM dollars             | $8.2B tax prep market    | $1.77T outstanding debt          |
| Pain intensity          | High but seasonal        | Chronic, year-round anxiety      |
| Engagement              | 1x/year                  | Monthly (payment tracking)       |
| Per-referral commission | $50-100 (HYSA)           | $100-200 (refinancing)           |
| Data advantage          | W2 income, filing status | Income + debt + rates + employer |


**The Playbook**:

1. **Free loan dashboard** -- connect to studentaid.gov (FSA API) or upload loan statements (OCR). Show all loans, interest rates, servicers, repayment plan options, total cost of each plan.
2. **AI advisor**: "Based on your income ($55K) and loans ($33K at 6.5%), switching from Standard to SAVE would reduce your monthly payment by $120 and you'd pay $4,200 less over the life of the loan."
3. **The decision moment**: "Your interest rate is 6.5%. Current refinancing rates start at 4.2%. You could save $8,400 by refinancing."
4. **Monetization**:
  - Refinancing referrals: SoFi ($100-150/lead), Earnest ($200/referral), Splash Financial ($100-150)
  - HYSA for loan sinking fund: Marcus ($50-100/funded account) -- "Save for extra payments here"
  - FAFSA assistance (upstream): scholarship matching, aid optimization
  - Income-Driven Repayment optimizer tool: premium feature ($19/yr)
  - Public Service Loan Forgiveness (PSLF) tracker: premium feature ($29/yr)

**Cost Structure** (CFO assessment):

- FSA API integration: free (government API)
- OCR for loan statements: ~$0.005/doc (same Cloud Vision + GPT pipeline)
- AI repayment calculations: ~$0.02/user (GPT-4o for plan comparison)
- Infrastructure: ~$12-15/mo
- Cost per user: ~$0.03-0.05
- Gross margin: 98%+

**Vibe-Codability**: HIGH

- Same tech stack, same OCR pipeline (scan loan statements instead of W-2s)
- Repayment calculator = integer math engine (same pattern as tax calculator)
- FSA API is well-documented
- 6-week MVP: loan import, plan comparison, refinancing recommendations
- Phase 2: FAFSA helper, PSLF tracker, employer student loan benefit optimizer

**Risk Assessment**:

- Refinancing is NOT always the right choice (lose federal protections like IDR, PSLF, forbearance)
- CPA persona concern: must clearly explain tradeoffs, never push refinancing when federal benefits are valuable
- Legal: student loan advice is less regulated than tax advice, but still need disclaimers
- Market timing risk: if government forgives loans broadly, TAM shrinks (but this has been unlikely since 2024 court rulings)
- Competition: NerdWallet, Credible, and LendEDU already do loan comparison, but none have the "free dashboard + AI advisor" angle

**Strategy Verdict**: STRONG PROCEED. Chronic pain (not seasonal), higher per-referral commissions, massive TAM. The "trust-to-advisory" pipeline is even more natural here than taxes -- users need ongoing help navigating repayment for 10-20 years.

---

### Opportunity 3: AI Car Insurance Switcher ("SwitchFree")

**One-liner**: "Snap your insurance card. Save $700/year."

**The Pain**:

- 230M licensed drivers in the US
- $300B auto insurance market
- 85% of drivers overpay for car insurance
- Average savings from switching: $600-800/year
- Process is tedious: re-entering the same info on 5 different sites
- Incumbents (Jerry, Gabi, The Zebra) have proven the model works but are venture-funded and bloated

**Why This is Potentially Bigger Than FileFree**:


| Factor           | FileFree (Tax)    | SwitchFree (Insurance)                  |
| ---------------- | ----------------- | --------------------------------------- |
| TAM users        | ~35M Gen Z filers | 230M licensed drivers                   |
| Revenue per user | $8.05             | $30-100 (commission per policy)         |
| Frequency        | Annual            | Annual renewal (+ life events)          |
| OCR use case     | W-2 scan          | Insurance card + declarations page scan |
| Proven model?    | Credit Karma      | Jerry (5M+ users), Gabi, The Zebra      |


**The Playbook**:

1. **Snap your insurance card** -- OCR extracts carrier, policy number, coverage levels, premium
2. **Upload or OCR your declarations page** -- extracts all coverage details for apples-to-apples comparison
3. **AI compares quotes** from 40-50 carriers in real time
4. **The decision moment**: "You're paying $2,400/year with State Farm. We found the same coverage for $1,680 with Progressive. That's $720/year back in your pocket."
5. **Monetization**: Insurance carrier commissions ($30-100 per bound policy). No referral tracking needed -- carriers pay on bound policies directly.

**Critical Challenge**: Carrier API access is the moat that existing players (Jerry, Gabi) have built over years. Getting quotes requires either:

- (a) Direct carrier API integrations (hard to get, takes months per carrier)
- (b) Partnership with a quote aggregator (Socotra, EverQuote, QuoteWizard)
- (c) Starting with a smaller set of carriers and growing

**Vibe-Codability**: MEDIUM

- OCR piece: identical to FileFree (snap card, extract fields)
- Quote comparison UI: straightforward
- Carrier integrations: NOT vibe-codeable -- requires business partnerships
- 6-week MVP could do: snap card + show current coverage analysis + recommend checking specific carriers
- Full product requires carrier partnerships (6-12 month ramp)

**Risk Assessment**:

- Jerry raised $160M+, Gabi was acquired by Experian -- this market has well-funded incumbents
- Carrier API access is a real barrier (not just "build it and they will come")
- Insurance licensing required in some states for quoting/selling
- Higher regulatory burden than tax filing

**Strategy Verdict**: PROCEED WITH CAUTION. The economics are proven and the TAM is massive, but carrier API access creates a chicken-and-egg problem that can't be vibe-coded around. Best approach: start as an "insurance analyzer" (OCR your card, we tell you if you're overpaying and which carriers to check), then layer in carrier partnerships as you grow.

---

## TIER 2: STRONG OPPORTUNITIES WITH HIGHER BARRIERS

### Opportunity 4: AI Estate Planning / Will Creator ("WillFree")

- **TAM**: 67% of Americans (180M+) have no will. Trust & Will valued at "hundreds of millions" after $75M raised.
- **Gen Z angle**: 580% more likely than Silent Gen to trust AI for estate planning.
- **Monetization**: Free basic will, premium trusts ($199-499), life insurance referrals ($200-500/policy -- HIGHEST per-referral commission of any opportunity).
- **Vibe-codability**: HIGH -- questionnaire to legal document PDF is the exact same pattern as FileFree's tax filing flow.
- **Barrier**: Legal complexity varies by state. Not practicing law, but close to the line.
- **Verdict**: PROCEED as Phase 2 product. Life insurance referral commissions alone could generate $200-500 ARPU for users who convert. The "adulting anxiety" brand synergy with FileFree is strong.

### Opportunity 5: AI FAFSA & Scholarship Optimizer ("AidFree")

- **TAM**: $3.6B in Pell Grants go unclaimed annually. 20M+ students file FAFSA each year.
- **Pain**: 40% of high school seniors don't complete FAFSA. ScholarAI has helped 50K+ students access $2.8B.
- **Monetization**: Student loan servicer referrals, student banking referrals (SoFi, Discover), credit card referrals (student cards), textbook/education platform referrals.
- **Vibe-codability**: HIGH -- FAFSA is a government form (like 1040). Same OCR + form generation pipeline.
- **Barrier**: Department of Ed is improving their own tools (Aidan AI assistant). Lower per-user monetization than other opportunities.
- **Synergy**: Natural upstream feeder to LoanFree (Opportunity 2). File FAFSA at 18, optimize loans at 22, file taxes at 22.
- **Verdict**: CONSIDER as part of LoanFree product suite, not standalone.

### Opportunity 6: AI-Powered Free Bookkeeping ("BookFree")

- **TAM**: $7.5B market growing at 46% CAGR to $50B by 2030. Explosive.
- **Pain**: Small businesses spend 5-10 hours/week on bookkeeping. QuickBooks costs $30+/mo.
- **Monetization**: Payroll referrals, lending referrals (Kabbage, BlueVine pay $100-200/funded), payment processing referrals, tax filing referrals (back to FileFree!).
- **Vibe-codability**: MEDIUM -- bank integrations (Plaid) add complexity, but core categorization is AI-native.
- **Barrier**: Accounting accuracy is mission-critical. Wave proved free works but was acquired by H&R Block.
- **Synergy**: Natural downstream product from BizFree (Opportunity 1). Form LLC, then manage books.
- **Verdict**: CONSIDER as Phase 2 of BizFree, not standalone. The "form your business, then run it" pipeline is powerful.

---

## TIER 3: INTERESTING BUT NOT RECOMMENDED NOW

### Opportunity 7: AI Health Insurance Navigator

- Commissions are the highest ($300-600/enrollment) but broker licensing requirements vary by state, and the regulatory burden is heavy. Open enrollment is a narrow window (6 weeks). Proceed only if a co-founder has insurance industry experience.

### Opportunity 8: AI Immigration Document Prep

- Massive emotional pain point and willingness to pay, but legal liability is extreme. One mistake on an I-485 can result in deportation. Requires immigration attorney oversight. Not appropriate for vibe coding.

### Opportunity 9: AI Benefits Enrollment Optimizer

- $750B/year lost to suboptimal benefits is a real number, but the go-to-market is B2B (sell to employers/brokers). B2B sales cycles don't lend themselves to the vibe-coded, viral, consumer playbook.

---

## STRATEGIC RECOMMENDATION: THE "ADULTING OS" PORTFOLIO

The highest-value strategic play is not picking one opportunity -- it is building a **portfolio of "adulting anxiety" products** that share infrastructure, brand, and user base. Each product is the acquisition channel for the next.

```mermaid
flowchart LR
    AidFree["AidFree\nFAFSA + Scholarships\n(Age 17-18)"] --> LoanFree["LoanFree\nStudent Loan Optimizer\n(Age 18-30)"]
    LoanFree --> FileFree["FileFree\nFree Tax Filing\n(Age 22+)"]
    FileFree --> BizFree["BizFree\nFree LLC Formation\n(Age 25+)"]
    BizFree --> BookFree["BookFree\nFree Bookkeeping\n(Business Owners)"]
    FileFree --> WillFree["WillFree\nFree Will + Estate\n(Age 25+)"]
```



**Shared infrastructure across all products**:

- Same Next.js + FastAPI + PostgreSQL stack
- Same OCR pipeline (Cloud Vision + GPT)
- Same authentication and user management
- Same financial product referral engine
- Same brand voice ("smart, calm friend who makes adulting easy")
- Same cost structure (~$0.05-0.15/user, 95%+ gross margins)

**The portfolio math** (at 100K users each, Scenario B assumptions):


| Product      | ARPU   | Revenue     | Revenue Type    |
| ------------ | ------ | ----------- | --------------- |
| FileFree     | $8.05  | $805K       | Mostly seasonal |
| BizFree      | $150+  | $15M+       | Recurring       |
| LoanFree     | $15-25 | $1.5-2.5M   | Year-round      |
| WillFree     | $25-50 | $2.5-5M     | Year-round      |
| BookFree     | $10-20 | $1-2M       | Year-round      |
| **Combined** |        | **$20-25M** | **Diversified** |


---

## IMMEDIATE NEXT STEP: PICK ONE

If the founders want to start a second product TODAY, the recommendation is:

**BizFree (Small Business Formation)** -- for three reasons:

1. **Recurring revenue**: Registered agent fees are $99-149/yr per customer, billed automatically. FileFree's biggest weakness is seasonality. BizFree solves it.
2. **Highest ARPU**: Business banking + insurance + payroll referrals stack to $150-250/user vs FileFree's $8.05.
3. **Natural FileFree synergy**: Every BizFree user needs to file business taxes. Every FileFree user who starts a side hustle needs BizFree. Cross-sell is organic.

**MVP scope (6 weeks with AI agents)**:

- Week 1-2: Formation questionnaire + articles of incorporation PDF generation (reuse FileFree's PDF pipeline)
- Week 3: State filing guide for all 50 states (data-driven JSON, same pattern as state tax data)
- Week 4: Business banking referral screen (reuse Refund Plan screen pattern)
- Week 5: Compliance calendar + annual report reminders
- Week 6: Registered agent service signup (partner with existing RA network like Northwest or Incorp)

**Cost to launch**: ~$15/mo incremental infrastructure (one more Render service). Same Vercel, same Neon, same stack.

---

## RISK SUMMARY (Legal Persona)


| Opportunity | Legal Risk  | Key Concern                                                                                    |
| ----------- | ----------- | ---------------------------------------------------------------------------------------------- |
| BizFree     | LOW         | Formation is NOT practicing law (settled: LegalZoom precedent). Need clear disclaimers.        |
| LoanFree    | LOW-MEDIUM  | Student loan advice is education, not fiduciary advice. Must disclaim refinancing tradeoffs.   |
| SwitchFree  | MEDIUM      | Insurance quoting/selling requires licensing in some states. Start as "analyzer" not "seller." |
| WillFree    | MEDIUM-HIGH | Will creation approaches unauthorized practice of law. State-by-state analysis needed.         |
| AidFree     | LOW         | FAFSA is a government form. Helping complete it is not regulated.                              |


---

## PERSONA SIGN-OFFS

**Strategy (Chief of Staff)**: The "Adulting OS" portfolio thesis is compelling. Each product reinforces the others. Start with BizFree for recurring revenue diversification, then LoanFree for Gen Z deepening. Do NOT try to build all five simultaneously.

**CFO**: BizFree has the best unit economics of any opportunity evaluated. Registered agent revenue is recurring, high-margin, and predictable. At 10K customers, registered agent alone is $1M+/yr ARR before any referral revenue. Infrastructure cost increase is negligible.

**Growth**: Every BizFree customer is a potential FileFree customer (business taxes) and vice versa. Cross-sell organic acquisition could reduce CAC to near-zero for the second product. The "entrepreneurship" angle also plays extremely well on TikTok/Instagram -- "I started my LLC in 5 minutes for free" is inherently viral content.

**CPA / Tax Advisor**: BizFree creates a natural pipeline to business tax filing (Schedule C, quarterly estimated taxes). This extends FileFree's TAM from simple W-2 filers to small business owners -- a segment with 3-5x higher lifetime value.

**Legal**: Formation services have strong legal precedent (LegalZoom fought and won these battles). Use the same disclaimers pattern as FileFree. Registered agent service requires a physical address in each operating state -- partner with an existing network rather than building from scratch.

**Engineering**: 90%+ code reuse from FileFree. Same PDF generation pipeline, same form validation patterns, same auth system, same deployment infrastructure. The state-by-state filing rules are analogous to state tax rules -- use the same JSON-driven engine pattern from Task 3.4.