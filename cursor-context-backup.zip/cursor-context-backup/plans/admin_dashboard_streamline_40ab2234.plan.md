---
name: Admin Dashboard Streamline
overview: Reduce redundancy in the Admin Dashboard by removing the dynamic task catalog and consolidating repeated sections while keeping a focused set of core admin actions.
todos:
  - id: remove-catalog-ui
    content: Remove task catalog UI/state from AdminDashboard
    status: completed
  - id: curate-actions
    content: Keep small curated admin actions panel
    status: completed
  - id: dedupe-sections
    content: Consolidate repeated sections after tasks
    status: completed
  - id: simplify-task-actions
    content: Simplify taskActions utility to match curated UI
    status: completed
  - id: adjust-tests
    content: Update tests/docs impacted by catalog removal
    status: completed
isProject: false
---

# Admin Dashboard Streamline

## Goals

- Remove the dynamic task catalog UI that’s cluttering the page.
- Keep a concise, curated set of admin actions with clear labels.
- Eliminate repeated sections after the tasks block.

## Plan

- Trim the task catalog section in [frontend/src/pages/AdminDashboard.tsx](frontend/src/pages/AdminDashboard.tsx):
  - Remove catalog fetch state (`taskActions`, `taskActionsLoading`, `taskActionParams`) and the render block that lists every catalog entry.
  - Keep a small curated action panel (coverage refresh/restore, stale daily backfill, snapshot history backfill, retention enforce) with descriptions.
- Collapse duplicated UI blocks in [frontend/src/pages/AdminDashboard.tsx](frontend/src/pages/AdminDashboard.tsx):
  - Identify repeated “after tasks” sections and consolidate them into a single panel, keeping the most useful metrics and controls.
- Simplify task action wiring in [frontend/src/utils/taskActions.ts](frontend/src/utils/taskActions.ts):
  - Retain only what’s needed for the curated buttons (no catalog fetch/caching).
- Update any dependent UI copy/tests if they reference the catalog (AdminDashboard tests or snapshots if present).

## Notes

- I’ll preserve the core admin actions and coverage visuals; this is a UI simplification pass, not a behavior change.

