---
name: PR Workflow and Docker Polish
overview: Disable Cursor PR attribution, update git workflow with Copilot review steps, clean up Docker container names, and create an architecture doc with diagrams in docs/.
todos:
  - id: cursor-setting
    content: Disable 'Made with Cursor' in Cursor settings.json
    status: completed
  - id: git-workflow
    content: Update git-workflow.mdc with Copilot review steps
    status: completed
  - id: container-names
    content: Add explicit container_name to all services in compose.dev.yaml and restart
    status: completed
  - id: architecture-doc
    content: Create docs/ARCHITECTURE.md with system diagrams (auth flow, OCR pipeline, infra)
    status: completed
  - id: copilot-review
    content: "Request Copilot review on PR #9, read and address feedback"
    status: completed
isProject: false
---

# PR Workflow, Docker Polish, and Architecture Docs

## 1. Disable "Made with Cursor" in PRs

Set `"cursor.chat.addMadeWithCursorToGithubPRs": false` in Cursor settings.json. No need to edit PR #9.

## 2. Update git-workflow.mdc with Copilot review

Add to [.cursor/rules/git-workflow.mdc](.cursor/rules/git-workflow.mdc) after step 5:

- Step 6: Request Copilot review via `gh pr edit <number> --add-reviewer @copilot`
- Step 7: Poll for review completion, read comments via `gh api`
- Step 8: Address findings, push fixes, confirm clean before returning PR URL

## 3. Clean Docker container names

Add `container_name` to each service in [infra/compose.dev.yaml](infra/compose.dev.yaml) to drop the `-1` suffix:

- `filefree-postgres`, `filefree-redis`, `filefree-api`, `filefree-web`

Restart containers under new names.

## 4. Create docs/ARCHITECTURE.md

Create a living architecture reference at [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) with mermaid diagrams covering:

- **System overview** -- high-level component diagram (Vercel, Render, Neon, Upstash, GCP)
- **Auth flow** -- the sequence diagram from the sprint plan (register, /me, logout)
- **OCR pipeline** -- tiered Cloud Vision + GPT flow
- **Data model** -- entity relationships (User, Filing, Document, TaxProfile, TaxCalculation)
- **Local dev stack** -- Docker Compose service topology

Keep it concise, visual-first. This becomes the go-to reference for understanding the system at a glance.

## 5. Copilot review on PR #9

Request review, read feedback, address if needed.

