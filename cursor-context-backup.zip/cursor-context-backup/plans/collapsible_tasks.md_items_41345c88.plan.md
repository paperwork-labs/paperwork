---
name: Collapsible TASKS.md items
overview: Make each task (and optionally each sprint section) in docs/TASKS.md collapsible by wrapping heading + body in HTML `<details>` / `<summary>` so viewers can expand/collapse items.
todos: []
isProject: false
---

# Collapsible headings and body in [TASKS.md](http://TASKS.md)

## What you’re asking for

You want each “item” in [docs/TASKS.md](docs/TASKS.md) to be **collapsible**: the heading stays visible as a clickable summary, and the body (checklists, paragraphs, code blocks) is hidden until expanded. That’s the standard “accordion” / “expand/collapse” behavior.

## Content preservation (mandatory)

**Do not change, delete, or lose any existing content.** The only edits are:

- **Add** opening `<details>` and `<summary>...</summary>` before each task (or sprint) heading.
- **Add** closing `</details>` after each task (or sprint) body.
- **Replace** the single line that is the `### Task ...` (or `## Sprint ...`) heading with the `<summary>` line that shows the same text.

Everything else stays exactly as written: every checklist item `- [ ]` / `- [x]`, paragraph, bold, link, code block, sub-bullet, `---`, blank line, and "Acceptance" / "Branch" / "**APPLY THIS WEEK.**" text must be preserved character-for-character. No rewording, no trimming, no normalizing. Body content is copied verbatim into the `<details>` block.

## Approach: HTML `<details>` / `<summary>`

Plain Markdown doesn’t support collapsible sections. The standard, widely supported way is HTML:

- `**<details>`** – the collapsible block (collapsed by default).
- `**<summary>`** – the visible “heading” that you click to toggle.

GitHub, Cursor’s Markdown preview, and most renderers support these and still render Markdown **inside** `<details>`. So bullet lists, checkboxes, bold, links, and code blocks will all work.

**Example** (one task converted):

```html
<details>
<summary><strong>Task B.1 — EFIN Application (Form 8633)</strong></summary>

**APPLY THIS WEEK.** 45-day IRS processing time is the longest lead item.

- [ ] PTIN (Preparer Tax Identification Number) — apply at irs.gov/ptin
- [ ] IRS e-Services account — register at irs.gov
...

</details>
```

Blank line after `</summary>` is required so the body is parsed as Markdown.

## Scope: what to make collapsible

The doc has two natural “items”:


| Level         | Example                            | Count             |
| ------------- | ---------------------------------- | ----------------- |
| **## Sprint** | `## Sprint 0: Business Operations` | 7 sprint sections |
| **### Task**  | `### Task B.1 — EFIN Application`  | ~50 tasks         |


Recommendation:

1. **Make every `### Task ...` block collapsible**
  Each task becomes one `<details>`: `<summary>` = task title, body = everything until the next `###` or `##`.  
   This matches “heading and body of each item” and keeps the doc scannable (collapse done tasks, expand the one you’re on).
2. **Optional: make `## Sprint` sections collapsible**
  Wrap each sprint (including its progress line and all task `<details>`) in an outer `<details>` with the sprint name as `<summary>`.  
   Gives two levels: collapse a whole sprint, or expand it and then expand individual tasks.

If you only want one level, doing **tasks only** is the minimal and clearest change.

## Implementation steps

1. **Parse the file**
  - Keep lines 1–22 (title, version, critical dates, first `---`) as-is.  
  - For the rest, detect blocks by headings:  
    - `## Sprint ...` starts a section (and optionally a `<details>` for the whole sprint).  
    - `### Task ...` starts a task; body = all lines until the next `###` or `##` (or end of file).
2. **Convert each task**
  - Replace only the heading line: `### Task X.X — Title` → `<details>\n<summary><strong>Task X.X — Title</strong></summary>\n\n` (same title text in the summary).
  - Leave the task body **verbatim**: do not edit, reflow, or remove any line (sub-bullets, code blocks, **Acceptance**, checkboxes, `---`, blank lines).
  - Insert `\n</details>\n` immediately before the next `###` or `##` (or end of file). Do not remove or alter any of the body lines when inserting the closing tag.
3. **Optional: wrap each sprint**
  - After `## Sprint N: ...`, insert `<details>\n<summary><strong>Sprint N: ...</strong></summary>\n\n`.  
  - After the last task of that sprint (and before the next `##`), insert `\n</details>\n`.  
  - Keep the `> **Progress: ...`** line inside the sprint `<details>` so it’s part of the sprint body.
4. **“How to Use This Document”**
  - Either leave as a normal `##` or wrap in `<details>` for consistency; your choice.
5. **Default state**
  - All `<details>` start **closed** (collapsed).  
  - Optional: add `open` to tasks marked “DONE” so completed work is visible by default (e.g. `<details open>`). This is a small tweak if you want it.

## Edge cases to handle

- **Task body contains HTML**  
The current doc doesn’t use raw HTML in task bodies; if it did, we’d avoid stripping or re-interpreting it when wrapping.
- **Blank lines between tasks**  
Preserve existing `---` and blank lines between tasks so the doc still reads well when everything is expanded.
- **Code blocks inside tasks**  
No change needed; they stay inside the same `<details>` block and will render correctly.

## Files to change

- **[docs/TASKS.md](docs/TASKS.md)** — only file to edit. No new files, no code; the change is purely to the Markdown/HTML structure of this doc.

## Summary

- Use `<details>` / `<summary>` so each task (and optionally each sprint) has a clickable heading and collapsible body.  
- **Preserve all content:** only add wrapper tags; no changes or deletions to existing text, checkboxes, formatting, or structure.  
- Implement by converting every `### Task ...` line into a `<summary>` and wrapping its existing body in `<details>...</details>` without modifying the body.  
- Optionally wrap each `## Sprint` in its own `<details>`; optionally use `open` on DONE tasks.  
- Single file, no new tooling; works in GitHub and Cursor preview.

