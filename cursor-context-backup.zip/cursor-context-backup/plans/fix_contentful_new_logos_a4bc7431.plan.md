---
name: Fix Contentful new logos
overview: Update all references across slides and prep doc to correctly frame SmileDirectClub, MLB, Medtronic, and Asurion as Contentful new logo wins with 140% quota attainment (not expansion accounts). Reconvert .docx files.
todos:
  - id: fix-html-slide5
    content: Update Contentful line in deal-review-slides.html Slide 5
    status: completed
  - id: fix-prep-doc
    content: Update all Contentful references in openai-interview-prep.md (slide content, speaker notes, opening, Q&A)
    status: completed
  - id: reconvert-docx
    content: Reconvert openai-interview-prep.md to .docx via pandoc
    status: cancelled
isProject: false
---

# Fix Contentful Accounts: All New Logos, 140% Quota

All four Contentful accounts (SmileDirectClub, MLB, Medtronic, Asurion) were new logos. The "140%" figure refers to quota attainment, not account expansion.

## Files to update

### 1. [deal-review-slides.html](olgaSharma/deal-review-slides.html) - Slide 5

Current (line ~565):

```
Closed new logos including SmileDirectClub ($351K) and MLB. Expanded Medtronic, Asurion 140%+.
```

Change to:

```
Closed new logos: SmileDirectClub ($351K), MLB, Medtronic, Asurion. 140% of annual quota.
```

### 2. [openai-interview-prep.md](olgaSharma/openai-interview-prep.md)

**Slide 5 content** (line ~179):

- "Closed new logos including SmileDirectClub ... and MLB. Expanded Medtronic and Asurion accounts by 140%+." -> list all four as new logos, reframe 140% as quota

**Speaker notes** (line ~193):

- "I closed new logos like SmileDirectClub ... and MLB. I expanded accounts like Medtronic and Asurion by over 140%." -> all four as new logos, 140% as quota

**Opening statement** (line ~24):

- "expanded Fortune 500 accounts by 140%" -> reframe as quota attainment

**Q&A answer** (~line 233, "this is a great program but not really a sale"):

- "closed new logos, and expanded enterprise accounts" -> closed new logos across the board

### 3. Reconvert to .docx

- `openai-interview-prep.docx`
- `interview-source-notes.docx` (check for any Contentful references)

