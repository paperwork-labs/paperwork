---
name: Stage Quality + Admin Observability
overview: Harden stage-data correctness with deterministic validations and lightweight repair workflows, then extend Admin Dashboard with high-signal system/data-quality telemetry so issues are visible before they impact users.
todos:
  - id: stage-integrity-endpoint
    content: Add stage integrity checks endpoint + service validations for stage invariants and recent-run consistency.
    status: completed
  - id: stage-regression-tests
    content: Expand backend stage derivation tests for UNKNOWN/sparse/transition edge cases.
    status: completed
  - id: admin-stage-quality-card
    content: Add Stage Quality card in Admin Dashboard wired to new admin stage-quality endpoint.
    status: completed
  - id: admin-jobs-audit-cards
    content: Add Jobs Health summary and Market Audit cards to Admin Dashboard using new/existing endpoints.
    status: completed
  - id: verify-and-rollout
    content: Run backend/frontend tests and execute stage-only repair workflow with post-check verification.
    status: completed
isProject: false
---

# Stage Data Correctness And Admin Observability Plan

## Goals

- Ensure stage fields (`stage_label`, `current_stage_days`, `previous_stage_label`, `previous_stage_days`) are internally consistent and remain correct after recompute/backfill.
- Add actionable Admin Dashboard telemetry for system health, provider quality, and data quality drift.

## Stage Data Correctness

- Add a stage integrity check endpoint and service method to validate invariants over recent data:
  - `stage_label` in allowed set (`1`, `2A`, `2B`, `2C`, `3`, `4`, `UNKNOWN`)
  - `current_stage_days >= 1` when stage is known
  - `previous_stage_days` present when `previous_stage_label` is present
  - recent run monotonicity within stage windows
- Implement this in backend route/service layer:
  - [backend/api/routes/market_data.py](/Users/sankalpsharma/development/axiomfolio/backend/api/routes/market_data.py)
  - [backend/services/market/market_data_service.py](/Users/sankalpsharma/development/axiomfolio/backend/services/market/market_data_service.py)
- Add focused regression tests for `_derive_stage_run_fields` edge cases (`UNKNOWN` transitions, sparse history, same-stage continuity):
  - [backend/tests/test_market_data_backfill_service.py](/Users/sankalpsharma/development/axiomfolio/backend/tests/test_market_data_backfill_service.py)
- Add a reusable “stage-only repair” admin operation (already validated manually) to recompute last-N history rows and sync current snapshot stage fields.

## Admin Dashboard Additions (High Signal First)

- Add **Stage Quality** card:
  - unknown-rate, known-rate, invalid-count, stale-stage-count (optional)
  - show warning state when unknown-rate/invalid-count breaches threshold.
- Add **Jobs Health** card:
  - failed jobs (24h), success rate (24h), latest failed job summary.
- Add **Market Audit** card (wire existing endpoint):
  - latest snapshot-history fill %, missing sample symbols, benchmark freshness.
- Frontend implementation target:
  - [frontend/src/pages/AdminDashboard.tsx](/Users/sankalpsharma/development/axiomfolio/frontend/src/pages/AdminDashboard.tsx)
- Backend endpoints to add/extend:
  - extend [backend/api/routes/market_data.py](/Users/sankalpsharma/development/axiomfolio/backend/api/routes/market_data.py) with:
    - `GET /market-data/admin/stage-quality`
    - `GET /market-data/admin/jobs/summary` (or summary mode on existing jobs endpoint)
  - reuse `GET /market-data/admin/market-audit` as-is.

## Provider/Data Reliability (Next)

- Add optional **Provider Health** summary endpoint/card (configured providers, recent provider errors/rate-limit counts).
- Add tests for API response shapes and dashboard render paths (happy + degraded states).

## Validation & Rollout

- Run backend tests for stage derivation and new admin endpoints.
- Run frontend AdminDashboard tests and add cases for warning states.
- Execute stage-only repair in non-prod/prod and verify integrity endpoint trends toward healthy baseline.
- Keep repair command available as an operational runbook entry.

