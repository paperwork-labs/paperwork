---
name: Daily backfill completeness + schedules
overview: Fix why Restore Daily Coverage only fills ~75% by making backfill treat provider failures as errors (not silent empties), adding symbol normalization/fallback, and making MarketSnapshotHistory write for tracked universe. Also document and tune schedules for laptop dev.
todos:
  - id: classify-empty-vs-failure
    content: Update MarketDataService/backfill tasks to distinguish true no-data from provider/transient failures; surface skipped/error samples in JobRun counters.
    status: pending
  - id: symbol-normalization
    content: Add per-provider symbol normalization (e.g., BRK.B->BRK-B) and retry-on-empty before classifying a symbol as no-data.
    status: pending
  - id: tracked-history-default
    content: Change record_daily_history to default to tracked:all universe and write history rows keyed by as-of date; return richer counters.
    status: pending
  - id: schedule-runbook
    content: Document and verify dev scheduling behavior (celery_beat/RedBeat) and recommend nightly bootstrap + hourly monitor schedules.
    status: pending
---

# Daily latest-bar completeness + schedules

## Goals

- **Make “Restore Daily Coverage (Tracked)” reliably reach ~100% on the newest trading day** (unless the provider genuinely has no bar yet).
- **Stop silently counting transient/provider failures as `skipped_empty`** (so we can see and retry real failures).
- **Populate `MarketSnapshotHistory` for the tracked universe** (so the history UI/backtesting foundation is real).
- **Make schedules predictable** on a laptop dev stack (Celery Beat + RedBeat), with clear runbook.

## What we learned from your job logs

- `backfill_last_200_bars` updated **387/516** and marked **129 as `skipped_empty`** with **`errors: 0`**.
- In code, `MarketDataService.get_historical_data()` swallows exceptions and returns `None` if all providers fail/return empty, which becomes **`skipped_empty`**.
- `record_daily_history()` defaults to **portfolio symbols**, which is why the restore chain logs **“Wrote 0 history rows”**.

## Implementation plan

### 1) Make backfill “empty” vs “failure” explicit

- Update [`backend/services/market/market_data_service.py`](/Users/sankalpsharma/development/quantmatrix/backend/services/market/market_data_service.py):
- Track **attempted providers** and last failure reason.
- When all providers return empty/None, return a structured result so callers can classify:
    - **no_data** (provider has no bars for symbol)
    - **transient_failure** (timeouts/429/5xx after retries)
    - **symbol_invalid/unsupported** (symbol formatting / mapping issue)
- Update [`backend/tasks/market_data_tasks.py`](/Users/sankalpsharma/development/quantmatrix/backend/tasks/market_data_tasks.py) (`backfill_last_200_bars`):
- Count and report:
    - `skipped_empty` (true no-data)
    - `errors` + `error_samples` (transient/provider failures)
    - `skipped_samples` (bounded list of symbols + reason) so Admin Jobs tells you *which* 129.

### 2) Add symbol normalization and fallback retries

- Add a small helper in `MarketDataService` to normalize symbols per provider:
- For **FMP/YFinance**, try `BRK.B → BRK-B` / `BF.B → BF-B` (and similar `.` → `-`).
- For TwelveData, keep the original (or try both).
- On empty result, retry once with normalized symbol before classifying as no-data.

### 3) Fix `record_daily_history` to write tracked-universe history

- Update [`backend/tasks/market_data_tasks.py`](/Users/sankalpsharma/development/quantmatrix/backend/tasks/market_data_tasks.py) (`record_daily_history`):
- Default universe when `symbols is None`:
    - Prefer Redis `tracked:all`, fallback to DB-derived tracked universe.
- Use `MarketSnapshot.as_of_timestamp` when available to set `as_of_date` (fallback to latest `price_data` date).
- Return richer counters (written, skipped_no_snapshot, errors, error_samples).

### 4) Schedules: make “latest days” automatic on laptop

- Ensure `celery_beat` is running in dev compose.
- In Admin Schedules, create:
- **Nightly**: `backend.tasks.market_data_tasks.bootstrap_daily_coverage_tracked` (after market close; e.g. 9pm local).
- **Hourly**: `backend.tasks.market_data_tasks.monitor_coverage_health`.
- Add a short doc section (and/or small UI hint) explaining:
- schedules live in Redis (RedBeat)
- **your laptop + Docker must be running** or jobs won’t execute
- “Run now” is always available.

## Validation

- Run the restore flow and confirm:
- Newest date fill approaches 100%.
- Any remaining gap has a visible reason + sample symbols.
- `record_daily_history` writes ~516 rows/day (or close, minus true no-data symbols).

## Files to change

- [`backend/services/market/market_data_service.py`](/Users/sankalpsharma/development/quantmatrix/backend/services/market/market_data_service.py)
- [`backend/tasks/market_data_tasks.py`](/Users/sankalpsharma/development/quantmatrix/backend/tasks/market_data_tasks.py)