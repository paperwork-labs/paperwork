---
name: OpenAI Interview Round Prep
overview: "Prepare Olga for the 4-session OpenAI interview round: Deal Review deck (5 slides, content-first), Hiring Manager prep, Leadership Chat prep, and Technical Aptitude prep (LLMs, prompt engineering, fine-tuning)."
todos:
  - id: deal-review-content
    content: Write the 5-slide deal review content (bullet points + speaker notes + anticipated Q&A) based on her existing 6-slide deck and H1 PSC
    status: completed
  - id: hiring-manager-prep
    content: Write Hiring Manager interview prep with scripted answers for common environment-match questions
    status: completed
  - id: leadership-chat-prep
    content: Write Leadership Chat prep with talking points and 3-4 questions to ask them
    status: completed
  - id: technical-aptitude-prep
    content: Write Technical Aptitude prep covering LLMs, prompt engineering, fine-tuning with clear non-engineer explanations
    status: completed
  - id: create-slide-deck
    content: Create professional HTML slide deck (deal-review-slides.html) with dark theme, clean typography, 5 slides
    status: completed
  - id: convert-docx
    content: Convert the final prep doc to .docx for Google Docs sharing
    status: completed
isProject: false
---

# OpenAI Interview Round Prep

## Interview Structure

Four sessions totaling 2.5 hours:

1. **45-min Deal Review Presentation** -- sales acumen (5-slide deck required)
2. **45-min Hiring Manager Interview** -- OpenAI environment match
3. **30-min Leadership Chat** -- OpenAI environment match
4. **30-min Technical Aptitude** -- product depth (LLMs, prompt engineering, fine-tuning)

---

## 0. Writing Style: Sound Like Olga, Not a Bot

Every word in every deliverable should sound like it came from a confident, Berkeley MBA-educated, multilingual professional with 10+ years of enterprise experience. Not from an AI.

**Voice rules:**

- Write the way a sharp person talks in a senior interview. Direct, clear, no fluff.
- Vary sentence length. Short punchy sentences next to longer ones. Rhythm matters.
- Use first person naturally. "I identified the gap" not "The gap was identified."
- Contractions are fine. "I didn't escalate" reads more human than "I did not escalate."
- Be specific, not abstract. "I called the CTO on Tuesday" beats "I proactively engaged executive stakeholders."

**Words and patterns to AVOID (AI tells):**

- No em dashes (use commas, periods, or parentheses instead)
- No "leverage," "utilize," "facilitate," "spearhead," "orchestrate," "synergy"
- No "compelling," "robust," "seamless," "holistic," "actionable," "transformative"
- No "uniquely positioned," "deeply understand," "at its core," "in today's landscape"
- No starting sentences with "Importantly," "Notably," "Crucially," "Furthermore"
- No three-part lists that escalate ("not just X, but Y, and ultimately Z")
- No corporate filler: "It's worth noting that," "It goes without saying," "At the end of the day"

**Tone target:** Think of a partner at McKinsey presenting to a client, or a YC founder pitching investors. Confident without being arrogant. Precise without being dry. Human without being casual.

**Test:** Read every answer out loud. If it sounds like a LinkedIn post, rewrite it. If it sounds like something a real person would actually say in a conversation, keep it.

---

## 1. Deal Review Deck: Content Refinement

**Source material:** [OlgaKlinger_OpenAIDealReview_2026.pptx](olgaSharma/OlgaKlinger_OpenAIDealReview_2026.pptx) (6 slides) + [_H1 25 PSC.docx](olgaSharma/_H1%2025%20PSC.docx) for supplemental detail.

**Current state:** 6 text-heavy slides about the Meta $1.5M Lifestyle RFP. Strong substance but needs to be cut to 5, made more scannable, and explicitly bridged to the OpenAI role.

### Critical Framing: "Is This a Sale?"

The biggest risk is an interviewer thinking: "This is program management, not sales." The fix is to frame the ENTIRE presentation through a sales lens from Slide 1. The RFP has every element of a complex enterprise deal:

- **Pipeline generation** = outbound sourcing across Discord, social channels, Meta developer comms, her direct network (89 inbound, 40% net-new)
- **Qualification** = cross-functional scoring framework (technical feasibility, commercial viability, ecosystem lift, roadmap alignment)
- **Competitive dynamics** = internal competing team trying to run a parallel initiative
- **Executive selling** = independently meeting with executive, product, and strategy heads to secure endorsement
- **Deal structuring** = milestone-based capital deployment with revenue accountability
- **Negotiation** = contract terms tied to Top 20 Quest Store ranking, phased funding gates
- **Account management** = managing 8 partners through delivery, milestone tracking, proactive risk surfacing
- **Post-sale expansion** = framework creation adopted org-wide for future deals

She should name this mapping in her opening narration (not on the slide) when she introduces the deal: "I chose this deal because even though it's structured as an investment program, it required every skill I'd use in enterprise sales: pipeline generation, qualification, competitive positioning, executive stakeholder management, commercial structuring, and post-close account management."

She should also reference her traditional SaaS sales background early: "Before Meta, I ran full-cycle enterprise sales at Contentful and Khoros -- closing new logos like SmileDirectClub, expanding Fortune 500 accounts by 140%, and exceeding quota by 220% managing accounts like Visa, Square, and Sephora. This Meta deal is where I brought those skills to their most complex application."

### Proposed 5-slide structure

- **Slide 1: Deal Overview** -- One-slide context. Left side: what the deal was ($1.5M RFP to fund 8 global developer partnerships for Meta's VR app marketplace). Right side: what she personally owned (conception, business case, executive buy-in, partner sourcing, selection, contract negotiation, execution governance). Bottom: key stats (89 applications, 180% over forecast, 40% net-new, 8 selected, 9% acceptance rate). Frame it as: "I identified the gap, built the business case, ran the competitive process, structured the deals, and managed the accounts through delivery."
- **Slide 2: Navigating Internal Competition** -- Her strongest story. A competing team launched a parallel initiative targeting a different customer segment. Risk: resource dilution, strategic confusion, initiative cancellation. Her move: didn't escalate reactively. Instead, independently met with executive, product, and strategy leads. Clarified differentiated positioning (their initiative = VC-adjacent NORAM-focused; hers = global tech studios across EMEA, APAC, NORAM). Presented structured ROI framework. Outcome: secured executive endorsement, maintained ownership, both initiatives proceeded. This is gold for OpenAI -- shows she can navigate a matrixed organization, influence without authority, and protect her deal.
- **Slide 3: Commercial Structure & Execution** -- How she built and closed the deals. Three sections: (1) Sourcing: global outbound across Discord, social, developer comms + her network. Result: 89 submissions, 40% net-new ecosystem entrants. (2) Selection: cross-functional scoring framework (technical feasibility, commercial viability, ecosystem lift, roadmap alignment) with a review committee spanning Product, Merchandising, PMM, Engineering, and Partnerships. (3) Deal terms: 3-4 gated milestones (prototype, technical validation, store readiness, revenue performance). Final incentive tied to Top 20 Quest Store ranking within 6 months. Contracts closed in 2 weeks (record timeline) by pre-aligning legal templates.
- **Slide 4: Results** -- Hard numbers only. $1.5M deployed across 8 global partnerships. 112% of game sales targets on Quest platform. 140% of MAP and MAU targets. Top partner Targo's "Crafting Crimes" sustained Top 5 ranking for 4 consecutive weeks. Zero partner drop-off (100% completion rate). Created repeatable framework (scoring model + milestone template + onboarding playbook) adopted org-wide for future initiatives.
- **Slide 5: Why This Deal & Why OpenAI** -- The bridge. Three columns: (1) "What this deal proves": I can identify market gaps, build business cases, navigate internal complexity, structure commercial terms, and manage accounts through delivery against revenue targets. (2) "My sales foundation": Before Meta, I ran full-cycle enterprise SaaS at Contentful (closed $351K flagship new logo, expanded accounts 140%+) and Khoros (exceeded quota 220% managing Visa, Square, Sephora). (3) "Why OpenAI": The Account Director role combines both skill sets -- deep strategic partnerships with 5 key accounts AND commercial rigor around consumption revenue. I want to bring this approach to OpenAI's customers. End note: "Milestone-based funding where revenue grows with partner success is the same economic model as consumption revenue -- our incentives are aligned with the customer's usage."

### Key content principles

- Bullet points, not paragraphs. The slides are scaffolding; her narration is the substance.
- Every slide should have 1-2 "discussion hooks" that invite questions.
- Strip Meta jargon: "Quest Store" = "Meta's VR app marketplace" on first reference.
- Quantify everything: dollars, percentages, timelines, headcounts.
- No slide should have more than 5-6 bullet points. White space is confidence.

### Anticipated interviewer questions (prep for ALL of these)

**On the deal itself:**

- "Walk me through the negotiation with the competing team."
- "How did you decide on milestone-based vs. upfront funding?"
- "How did you get 89 applications? Walk me through your sourcing strategy."
- "What was the total ROI for Meta? How did you calculate it?"
- "What was the biggest risk during execution and how did you mitigate it?"
- "Tell me about a partner that was underperforming. What was your playbook?"
- "How did you prioritize across 8 partners simultaneously?"
- "What would you do differently if you ran this again?"
- "How did you forecast revenue from this program?"
- "Walk me through the contract negotiation. What were the hardest terms?"

**On the "is this sales?" question (expect this):**

- "This is a great program, but it's not really a sale. You were deploying capital, not selling a product. How is this relevant?"
- "Walk me through a time you actually closed a deal where the customer was buying from you."
- "How would you apply MEDDPICC (or your sales framework) to this deal?"
- "What's the difference between managing developer partnerships and managing enterprise accounts?"

**On OpenAI relevance:**

- "How does this experience prepare you to manage consumption revenue?"
- "OpenAI's customers are buying API tokens, not receiving grants. How do you bridge that gap?"
- "What would your first 30 days look like at OpenAI?"

---

## 2. Hiring Manager Interview Prep (45 min, environment match)

This is the longest non-presentation session. The hiring manager (likely Maddie's boss or a senior sales leader) is assessing: Would I want this person on my team? Can she operate in OpenAI's fast-moving, ambiguous environment?

**Must-prep questions (scripted, speakable answers for all):**

- **"Why OpenAI?"** -- Career arc narrative: SaaS sales (Contentful, Khoros) -> platform partnerships (Meta) -> AI platform sales (OpenAI). Natural progression from selling content platforms to selling THE platform. The Discord written assignment showed she can reason about AI products and think like an Account Director. This role lets her do it for real.
- **"Why are you leaving Meta?"** -- THIS WILL COME UP. Needs an honest, positive answer. Frame: "Meta Reality Labs gave me incredible experience building partnerships at scale. But I want to be closer to revenue -- owning accounts, owning quota, owning the customer relationship end-to-end. At Meta, I was deploying capital. At OpenAI, I'd be earning it. That's the motion I want to be in."
- **"Why this role specifically?"** -- ~5 accounts, not 50. Deep strategic relationship management, not transactional. Matches her Meta partnership style (deep with Peloton, Strava, Duolingo, Discord). Consumption revenue means her success is tied to the customer's success -- that alignment is what she's built her career around.
- **"Describe your sales process / framework."** -- Should articulate a clear framework. Recommended: MEDDPICC (Metrics, Economic Buyer, Decision Criteria, Decision Process, Paper Process, Identify Pain, Champion, Competition). Map each letter to a concrete example from her career. If she doesn't use MEDDPICC, any structured framework is fine, but she needs to name it and walk through it.
- **"Tell me about a deal you lost."** -- Needs a REAL answer. Suggest: the Contentful period had deals that didn't close. Frame it honestly: "I was pursuing [company X] for a CMS migration. We had a strong champion in marketing, but I didn't multi-thread early enough into IT procurement. When our champion went on leave, the deal stalled because I didn't have relationships with the technical decision-maker or the economic buyer. I lost the deal to a competitor who had. The lesson: never build a deal on a single champion. At Meta, I applied that by always mapping stakeholders across product, engineering, legal, and business from day one."
- **"How do you handle ambiguity?"** -- Meta Reality Labs was effectively a startup inside a $1T company. Product roadmaps changed quarterly. Hardware launches got delayed. She had to adapt partnership strategies in real-time. Give a specific example of pivoting.
- **"How do you manage forecasting?"** -- Milestone-based tracking at Meta, Salesforce pipeline management at Contentful/Khoros. She should be comfortable talking about pipeline stages, close probabilities, and forecast accuracy.
- **"How do you collaborate with solutions engineers?"** -- At OpenAI, Solutions Engineers are embedded with Account Directors. She should articulate a partnership model: ADs own the relationship and commercial strategy, SEs own the technical architecture and POC execution. They're a team, not a handoff.
- **"How do you handle competing priorities across 5 accounts?"** -- Prioritization framework: revenue potential x urgency x strategic value. Weekly account reviews. Proactive risk flagging. She managed 8 partners at Meta and 15 accounts at Khoros -- she's done this.
- **"What questions do you have for me?"** -- Prep 3-4 sharp questions: "What does the current account portfolio look like for this role?", "How does OpenAI think about customer success vs. sales -- where does the AD's responsibility end?", "What's the biggest challenge your team is facing right now?", "How are consumption targets set and how often are they recalibrated?"

---

## 3. Leadership Chat Prep (30 min, environment match)

This is a senior leader (VP or C-level) assessing culture fit and strategic thinking. More conversational, less structured. They're asking: "Is this someone I'd want representing OpenAI to our most important customers?"

**Must-prep questions:**

- **"What kind of team culture do you thrive in?"** -- Builder mentality, small team, high ownership. Meta RL was effectively a startup within a $1T company. She thrives when she has autonomy to identify opportunities and run with them (the RFP is proof -- she conceived it herself).
- **"How do you influence without direct authority?"** -- The competing-team story from the deal review. Also: at Meta, she coordinated across Product, Engineering, Marketing, Legal, and Store Merchandising without any of them reporting to her. "I lead with data and clarity. When I walked into those executive meetings about the competing initiative, I didn't complain about the other team. I presented a differentiated positioning with a structured ROI framework. The data did the persuading."
- **"Where do you see AI in 5 years?"** -- She should have a genuine, thoughtful answer. Not a generic "AI will change everything." Something like: "I think the biggest shift will be from AI as a tool to AI as infrastructure. Right now, companies are experimenting with AI features. In 5 years, AI will be embedded so deeply into products that it's invisible -- like cloud computing today. Nobody says 'we use cloud.' It's just how things work. OpenAI's role is to be the infrastructure layer that makes that happen."
- **"What's the biggest mistake you've made as a leader?"** -- Honest, specific, with a clear learning. Not a humblebrag.
- **"How do you build trust with technical teams when you're not technical?"** -- "I don't pretend to be an engineer. I ask good questions, I do my homework on the product, and I show up prepared. At Meta, I worked closely with Partner Engineering, and the way I earned their respect was by understanding enough about the technical constraints to have useful conversations, not by trying to out-engineer them. I brought the commercial context they didn't have, and they brought the technical depth I didn't have."
- **"What questions do you have for us?"** -- These need to be GOOD. Senior leaders notice the quality of your questions. Prep: "What's the hardest part about selling AI right now that you didn't expect?", "How does OpenAI think about the tension between growing revenue and maintaining safety?", "What does the ideal Account Director look like 2 years into this role -- what have they built?", "What's one thing about OpenAI's culture that surprises new hires?"

---

## 4. Technical Aptitude Prep (30 min, product depth)

They explicitly say "you are not expected to be an engineer." They're evaluating "how you learn, explain, and apply new technical concepts." The key skill: can she take a technical concept and explain it to a customer in a way that drives a business decision?

### The 3 Required Topics (with definitions AND application scenarios)

**What is an LLM?**

- Definition: A large language model is a type of AI trained on massive amounts of text to understand and generate human language. It's read most of the internet and can now write, summarize, translate, classify, and reason about text. OpenAI's models (GPT-5, GPT-5 mini, GPT-5.4) are LLMs. "Large" refers to billions of learned parameters.
- Customer-facing explanation: "Think of it as the most well-read colleague you've ever had. It's absorbed billions of documents and can now help with anything language-based: writing, summarizing, translating, answering questions, classifying content. The key difference from traditional software: you talk to it in plain English instead of writing code."
- Application scenario: "If a VP of Product at Discord asks 'what can an LLM actually do for us?', I'd say: 'Every time a moderator manually summarizes what happened in a channel, an LLM can do that in seconds. Every time a user asks a question that's been answered before, an LLM can find and surface that answer. It turns your unstructured conversation data into structured, searchable knowledge.'"

**What is prompt engineering?**

- Definition: Crafting the input you give to an LLM to get the best output. Like briefing a very capable but literal colleague -- the more specific and structured your instructions, the better the result.
- Customer-facing explanation: "It's the difference between telling someone 'write me something about our Q3 results' versus 'write a 3-bullet executive summary of Q3 results, focusing on revenue growth, new customers, and churn, in a tone suitable for the board.' Same person, dramatically different output. Prompt engineering is how customers tune the AI's behavior without any coding or model training."
- Application scenario: "A customer says 'the AI's summaries are too long and too generic.' Before jumping to fine-tuning (expensive, slow), I'd work with our Solutions Engineer to refine their prompts. Add constraints: 'Summarize in exactly 3 bullet points, max 15 words each, prioritize decisions and action items over discussion.' That often solves 80% of quality issues at zero additional cost."
- Key insight for the interview: Prompt engineering is usually the FIRST thing you try. It's free, fast, and iterative. Smart customers exhaust prompt engineering before considering fine-tuning.

**What is fine-tuning, and when should it be used?**

- Definition: Training a base model on your own data to specialize it for a specific task. Currently available for GPT-4.1 and GPT-4.1 mini (not yet on GPT-5 models).
- When to use it: (1) Prompt engineering alone isn't producing consistent results. (2) You need the model to adopt a specific tone, vocabulary, or domain expertise. (3) You want to reduce token usage (shorter prompts because the model already knows the patterns).
- When NOT to use it: When prompt engineering or RAG can solve the problem (cheaper, faster, no training data collection needed).
- Customer-facing explanation: "Fine-tuning is like hiring a specialist vs. a generalist. GPT-5 is a brilliant generalist. But if you need someone who deeply understands YOUR company's terminology, YOUR moderation standards, YOUR customer communication style, you fine-tune a model on your own data. It learns your patterns and applies them consistently."
- Application scenario: "Discord has gaming servers and enterprise developer servers. The moderation standards are completely different -- what's acceptable in a gaming community would be unprofessional in a corporate developer channel. Fine-tuning lets you create specialized models for each context rather than trying to handle everything with one set of prompts."
- Revenue angle: Fine-tuning generates training revenue AND increases ongoing consumption because the fine-tuned model gets deployed into production workflows.

### Bonus Concepts (from the existing glossary -- know these cold)

- **Structured Outputs**: Guarantees model responses match a JSON schema. Customer value: predictable, machine-readable outputs that integrate cleanly into existing systems.
- **RAG (Retrieval-Augmented Generation)**: Feed the model your own documents as context instead of relying on its training data. Reduces hallucination. Customer value: accurate, grounded answers based on YOUR data.
- **Embeddings**: Convert text to numerical vectors for semantic search. Customer value: search by meaning, not keywords.
- **Tokens**: How OpenAI charges. ~750 words = 1,000 tokens. Both input and output count.
- **The GPT model family**: GPT-5.4 ($2.50/$15, flagship), GPT-5 ($1.25/$10, reasoning), GPT-5 mini ($0.25/$2, cost-efficient), GPT-4.1 ($2/$8, supports fine-tuning).
- **Agents SDK**: Framework for building AI agents that chain tools together. Shows platform depth beyond individual API calls.
- **Consumption revenue**: OpenAI charges per token. More usage = more revenue. The AD's job is to help customers succeed so usage grows organically.

### Practice Exercise

Before the interview, Olga should practice this drill: pick any product (Uber, Spotify, Airbnb) and spend 5 minutes explaining how an LLM, prompt engineering, and fine-tuning would each apply to that company. This builds the muscle of applying concepts on the fly, which is exactly what the 30-minute session will test.

---

## 5. Slide Creation

Content first, then format. Two-step approach:

**Step 1:** Write the 5-slide content as markdown with exact bullet points and speaker notes. This goes into `olgaSharma/openai-interview-prep.md`.

**Step 2:** Create a professional HTML slide deck at `olgaSharma/deal-review-slides.html` (same approach as the Discord proposal). Dark theme, clean typography, proper slide formatting with `@page` CSS for print-to-PDF. She can present from the browser (full-screen) or export to PDF. The coordinator can receive the PDF ahead of time.

Design direction: minimal, modern, dark background with white text and accent color. Each slide has a clear title, 4-6 bullet points max, and generous white space. Numbers/metrics get visual emphasis. No clip art, no stock photos, no animations. Let the content breathe.

If PPTX format is strictly required (ask the coordinator), the HTML content can be pasted into **Gamma.app** (free tier, 60-second PPTX export) as a backup path.

---

## Deliverables

Two files:

1. `**olgaSharma/openai-interview-prep.md`** (+ `.docx` conversion) -- Comprehensive prep doc containing:
  - Deal Review: 5-slide content with speaker notes + full anticipated Q&A with scripted answers
  - Hiring Manager: Scripted answers for all environment-match questions
  - Leadership Chat: Talking points + questions to ask them
  - Technical Aptitude: LLM/prompt engineering/fine-tuning explanations with customer-facing application scenarios
2. `**olgaSharma/deal-review-slides.html`** -- Professional 5-slide HTML deck for presentation/PDF export

