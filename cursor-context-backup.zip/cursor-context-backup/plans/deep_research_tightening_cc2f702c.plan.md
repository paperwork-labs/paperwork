---
name: Deep Research Tightening
status: archived
overview: "ARCHIVED — All findings merged into venture_master_plan_v1_61fe6d89.plan.md (Sections 0B, 0C, 0D + updated F2-F12). Explicitly superseded."
todos:
  - id: update-findings
    content: Update F2, F3, F5, F6, F7, F8, F9, F11, F12 in venture_master_plan_v1 with deep research findings
    status: pending
  - id: add-brand-palettes
    content: Add Section on brand palettes (FileFree violet-indigo, LaunchFree teal-cyan, Studio zinc-neutral) with CSS variable implementation
    status: pending
  - id: add-trademark-section
    content: "Add trademark risk section: filefree.com owned by Intuit, Supplemental Register filing, strict brand guidelines, FTC free compliance"
    status: pending
  - id: update-knowledge
    content: Add D35-D40 to docs/KNOWLEDGE.md (venture plan, company structure, brand palettes, trademark risk, social pipeline, CI filters)
    status: pending
  - id: update-tasks
    content: "Update docs/TASKS.md: expand B.2 company setup, add venture-wide sprint sections (V.0 through V.8) cross-referencing plan phases"
    status: pending
  - id: update-summary-table
    content: Update the F1-F12 summary table with revised severities and actions based on deep research
    status: pending
  - id: archive-plans
    content: Archive superseded plan files, create .cursor/rules/plans.mdc ordering rule
    status: pending
isProject: false
---

# Deep Research Tightening: Final McKinsey Review

All findings below are backed by real research. Each section updates the corresponding finding in the [Venture Master Plan v1](../../.cursor/plans/venture_master_plan_v1_61fe6d89.plan.md).

---

## F6 + F9 Revision: Brand Palettes (Each Product Gets Its Own Researched Theme)

### Research Finding

Multi-brand design systems use a **shared component library with theme switching via CSS variables** ([source: Medium](https://building.theatlantic.com/theming-architecture-multi-brand-design-systems-that-actually-work-ad7ed8445fed)). The pattern: one `packages/ui/` codebase, three theme configs. shadcn/ui + Tailwind v4 supports this natively via CSS `@theme` directives and `data-theme` attributes ([source: vaibhavt.com](https://www.vaibhavt.com/blog/multi-theme), [source: jitendra.dev](https://jitendra.dev/build-dynamic-themes-in-nextjs-with-tailwind-shadcn-ui)).

Best practice: **split complementary color systems** -- a base hue plus two colors adjacent to its complement. This gives visual differentiation while maintaining family cohesion ([source: thegrowthuxstudio.com](https://thegrowthuxstudio.com/split-complementary-colors-what-they-say-about-your-brand-product-and-design-maturity/)).

### Proposed Palettes

**FileFree** (Tax / Trust / Calm): Violet-Indigo family (EXISTING -- keep as-is)

- Primary: `#4F46E5` (Indigo 600) -- trust, financial authority
- Gradient: `#8B5CF6` -> `#9333EA` (Violet 500 -> Purple 600)
- Background: `#020817` (Slate 950)
- Accent: Emerald for refund amounts, Amber for owed amounts
- Typography: Inter + JetBrains Mono
- Personality: "Calm competent friend" -- premium dark, minimal

**LaunchFree** (Business Formation / Energy / Action): Teal-Cyan family (NEW)

- Primary: `#0D9488` (Teal 600) -- growth, fresh start, entrepreneurial energy
- Gradient: `#14B8A6` -> `#06B6D4` (Teal 400 -> Cyan 500)
- Background: `#0A0F1A` (deep navy, distinct from FileFree's slate)
- Accent: Amber for deadlines/fees, Emerald for completed steps
- Typography: Inter + JetBrains Mono (shared)
- Personality: "Entrepreneurial launchpad" -- energetic but professional

**Studio/Command Center** (Internal / Data / Ops): Zinc-Neutral family (NEW)

- Primary: `#71717A` (Zinc 500) -- neutral, data-focused, no personality needed
- Accent: Each product's color appears as a badge/tag color when displaying that product's data
- Background: `#09090B` (Zinc 950 -- pure dark)
- Typography: Inter + JetBrains Mono (shared)
- Personality: "Bloomberg terminal" -- dense, functional, monospace activity feeds

### Implementation

In `packages/ui/`, the theme config lives in a shared `themes.css`:

```css
[data-theme="filefree"] {
  --primary: 238 76% 57%;        /* Indigo 600 */
  --primary-foreground: 0 0% 100%;
  --accent: 258 90% 66%;          /* Violet 500 */
  --background: 224 71% 4%;       /* Slate 950 */
}

[data-theme="launchfree"] {
  --primary: 173 58% 39%;         /* Teal 600 */
  --primary-foreground: 0 0% 100%;
  --accent: 188 78% 41%;          /* Cyan 600 */
  --background: 222 47% 7%;       /* Deep navy */
}

[data-theme="studio"] {
  --primary: 240 4% 46%;          /* Zinc 500 */
  --primary-foreground: 0 0% 100%;
  --background: 240 10% 4%;       /* Zinc 950 */
}
```

Each app sets its theme in `layout.tsx` via `<body data-theme="launchfree">`. Shared components automatically inherit the right colors.

---

## F2 Revision: Company Structure + CAN-SPAM (Multi-Angle Legal Deep Dive)

### Company Structure Research

Three structures evaluated for multi-product venture with potential future acquisition:

**Option A: Single LLC + DBAs** (simplest)

- One LLC, file DBA for "FileFree" and "LaunchFree"
- DBA cost: $10-25 per name ([source: beancount.io](https://beancount.io/blog/2026/01/20/legal-structure-multiple-businesses-complete-guide))
- Risk: **shared liability pool** -- lawsuit against FileFree puts LaunchFree assets at risk
- Risk: DBAs don't provide exclusive name rights
- Risk: harder to sell individual product (needs asset purchase agreement, not stock sale)

**Option B: Holding Company + Subsidiary LLCs** (cleanest for acquisition)

- Parent LLC owns FileFree LLC and LaunchFree LLC
- Each product is independently sellable (stock sale)
- Each product has its own liability shield
- Cost: 3 LLC filings ($50-200 each) + 3 sets of annual reports
- Best for: venture-scale thinking, investor readiness

**Option C: Series LLC** (Delaware/Wyoming only)

- One master LLC with separate "series" for each product
- Asset isolation between series (in theory)
- Risk: **limited legal precedent**, evolving regulations, not recognized in all states ([source: legalgps.com](https://www.legalgps.com/series-llc/series-llc-vs-holding-company-which-one-is-better/))
- Risk: investors unfamiliar, complicates acquisition
- Risk: if the series structure is ever invalidated by a court, all liability shields collapse

**RECOMMENDATION: Option A NOW, Option B at revenue**

Start with a single LLC (Wyoming -- no state tax, $103 filing fee, privacy-friendly) with DBAs for each brand. This is the right call pre-revenue because:

1. The liability risk is near-zero when there are no users and no revenue
2. Administrative overhead of 3 LLCs for a pre-launch startup is pointless
3. When combined Year 1 revenue exceeds ~$50K, THEN create subsidiary LLCs and convert to a holding structure
4. Wyoming LLC can serve as the future parent/holding company

### CAN-SPAM Deep Dive

Key findings from FTC guidelines ([source: ftc.gov](https://www.ftc.gov/legal-library/browse/rules/guide-concerning-use-word-free-similar-representations)):

1. **CAN-SPAM is opt-OUT, not opt-IN** for same-entity commercial emails. You CAN send marketing emails without prior consent as long as you include an unsubscribe mechanism. However...
2. **Cross-brand emails within the same company are still from ONE sender** if they share the same legal entity (single LLC). The "designated sender" rules apply when multiple entities advertise in one email.
3. **Since we're recommending a single LLC**: FileFree and LaunchFree are brands (DBAs), not separate legal entities. CAN-SPAM treats them as the same sender. We can technically email cross-brand without separate opt-in.
4. **BUT -- best practice (and CCPA/state law) still demands explicit consent** for cross-brand communications. California's CCPA and other state privacy laws may impose stricter requirements. Being proactive here protects us AND builds user trust.

**REVISED RECOMMENDATION**:

- Keep the opt-in checkbox (unchecked by default) as designed -- this exceeds CAN-SPAM requirements but satisfies state privacy laws and builds trust
- Single unsubscribe link in every email covers all brands (since they're the same legal entity)
- Privacy policy language: "FileFree and LaunchFree are products of [LLC Name]. With your consent, we may send you relevant information about our other products."
- Account deletion cascades: product user record deleted, venture identity link removed, if no other products -> venture identity deleted. This satisfies CCPA right-to-delete.

---

## F3 Revision: Faceless Social Pipeline (Deep Research)

### Existing Solutions Evaluated


| Tool                         | Price          | What It Does                                        | API/n8n Integration     | Our Use?                                            |
| ---------------------------- | -------------- | --------------------------------------------------- | ----------------------- | --------------------------------------------------- |
| **Shortsbot**                | $10-33/mo      | Full auto: script, visuals, voice, editing, posting | No API, closed platform | No -- no API, can't customize for tax/legal content |
| **Tubify.ai**                | $19-69/mo      | Auto-posting TikTok/YT/IG faceless shorts           | No API, closed platform | No -- same problem                                  |
| **FacelessAI**               | Varies         | 12+ AI tools, Sora 2 + Veo 3 video gen              | No API documented       | No -- overkill, no control                          |
| **n8n template (LeeWei)**    | $12 one-time   | OpenAI + RunwayML + ElevenLabs pipeline             | Native n8n workflow     | **YES -- customizable, self-hosted**                |
| **n8n template (Nate Herk)** | Free           | Similar pipeline, community supported               | Native n8n workflow     | **YES -- free, good starting point**                |
| **DIY n8n pipeline**         | API costs only | Full control, our prompts, our compliance           | We build it             | **YES -- maximum control, recommended**             |


### Recommended Pipeline (DIY on n8n, informed by existing templates)

The free n8n templates ([source: n8n.io/workflows/8290](https://n8n.io/workflows/8290-automate-faceless-shorts-with-openai-runwayml-and-elevenlabs-script-to-social-media/)) demonstrate a proven architecture:

```
1. Schedule Trigger (daily 9 AM)
2. GPT-4o: Generate script from tax/biz content calendar
3. GPT-4o: Generate image prompt from script
4. DALL-E 3: Generate background image ($0.04/image)
5. ElevenLabs: Generate voiceover ($0.06 per 1K chars, ~150 words = ~$0.05)
6. FFmpeg (on Hetzner): Assemble video (image + audio + captions)
7. Review queue: Send to founder via email/Slack for 5-min review
8. Postiz API: Schedule approved post
```

### Cost Per Video


| Component                | Cost       | Notes                   |
| ------------------------ | ---------- | ----------------------- |
| GPT-4o (script + prompt) | ~$0.01     | ~500 tokens in, 500 out |
| DALL-E 3 (image)         | $0.04      | Standard quality        |
| ElevenLabs (voice)       | $0.05      | ~150 words, Flash model |
| FFmpeg (assembly)        | $0.00      | Runs on Hetzner, free   |
| **Total per video**      | **~$0.10** |                         |
| **30 videos/month**      | **~$3.00** | Both brands combined    |


Alternative: Use **Kling** instead of DALL-E + RunwayML for video generation. Kling offers $6.99/mo with 66 daily free credits, produces longer clips (2-3 min), and has an API at $0.07-0.17/sec.

### Validation Strategy (Updated from "10 manual videos")

Instead of recording manually, use the pipeline itself for validation:

1. **Week 1-2**: Build the n8n pipeline (it's ~4 hours using the template as a starting point)
2. **Week 2-3**: Generate 10 videos per brand (20 total) using the pipeline
3. Post all to TikTok + IG with manual review before each post
4. **Week 4**: Analyze performance. Benchmark: >500 avg views, >40% completion rate
5. If validated: enable auto-scheduling (with review queue)
6. If not: adjust format (try different hooks, different visual styles, different voice tones) before another 2-week test

This is better than manual testing because it validates the ACTUAL output quality, not a proxy.

---

## F5 Revision: Founder 2 Timing (Acknowledged)

The user is correct -- at the idea stage, Founder 2's time commitment is minimal. The partnership tasks in the plan are time-sequenced:

- **Now (pre-build)**: Zero partnership work needed. Just awareness.
- **At LaunchFree MVP launch**: HYSA affiliate applications (self-serve, 30 min)
- **At 500+ users**: Column Tax demo call (1 hour)
- **At 5K+ users**: TaxAudit white-label negotiation (2-3 hours total)
- **Scale engagement with user growth**: As products get traction, partnership work naturally increases

No plan change needed. F5 recommendation stands but with explicit acknowledgment that Founder 2 is not needed until products have live users.

---

## F7 Revision: RA Legal + FileFree Trademark Risk (CRITICAL NEW FINDING)

### filefree.com is Intuit's Property -- Confirmed

WHOIS confirms: `filefree.com` registered via **MarkMonitor Inc.** (Intuit's enterprise registrar), created 1999, Akamai DNS infrastructure (same as intuit.com). Domain status: `clientDeleteProhibited`, `clientTransferProhibited`, `clientUpdateProhibited` -- full lock, typical of corporate IP holdings.

**This is definitively Intuit's domain.**

### Trademark Risk Assessment

**The "FileFree" name in the tax space carries real legal risk:**

1. **Intuit owns filefree.com since 1999** -- this demonstrates prior use/awareness of the term in the tax/financial services space
2. **FTC has aggressively pursued "free" claims in tax software** -- Intuit itself was sued by FTC for deceptive "free" advertising (TurboTax), H&R Block settled similar claims ([source: FTC.gov](https://www.ftc.gov/news-events/news/press-releases/2022/03/ftc-sues-intuit-its-deceptive-turbotax-free-filing-campaign))
3. **"FileFree" is arguably descriptive** ("file [taxes] free") which means:
  - Harder to register as a trademark on the Principal Register (requires "secondary meaning" after 5 years of use) ([source: PatentPC](https://patentpc.com/blog/how-to-use-secondary-meaning-to-overcome-trademark-refusals))
  - BUT also harder for Intuit to enforce against us (they can't own a descriptive term)
  - We COULD register on the Supplemental Register as a placeholder
4. **However**: If Intuit sends a C&D, even without a registered trademark, the cost of legal defense ($10K-50K) could be existential for a bootstrapped startup
5. **Precedent**: "FreeTaxUSA" (Taxhawk, Inc.) successfully defended their descriptive mark AND enforced it against squatters. But they had years of commercial use and significant user base.

### STRICT GUIDELINES (New)

**Immediate actions:**

1. **DO NOT use filefree.com** -- ever. We operate on `filefree.tax` / `filefree.ai`. No confusion with Intuit's domain.
2. **File a trademark application for "FILEFREE"** (one word, stylized) on the Supplemental Register in Class 036 (financial services) and Class 042 (software). Cost: ~$250-350 filing fee. This establishes priority date without needing to prove secondary meaning yet.
3. **Monitor Intuit's TESS filings** quarterly. If Intuit files for "FILE FREE" or "FILEFREE", we need immediate legal counsel.
4. **Use "FileFree" as a brand name (proper noun), not a description**. Always capitalize. Never write "file free" (lowercase, two words) in marketing copy. This builds distinctiveness.
5. **Brand guidelines enforcement**: The brand always appears as "FileFree" -- never "File Free", "file free", or "Filefree". This is already in `brand.mdc` but must be strictly enforced across all content.
6. **FTC "free" compliance**: Since our filing IS actually free with no hidden conditions, we are on solid ground under FTC guidelines. BUT we must never add conditions that make it not-free for some users (the exact thing Intuit got sued for). Document this commitment: "Free means free. 100% of filers. No asterisks."
7. **Keep "LaunchFree" name clean**: Similar analysis applies. "LaunchFree" is also descriptive but has no known competitor claiming it. Still file on Supplemental Register.

### RA Legal Requirements (Expanded)

Research confirms ([source: howtostartabusiness.org](https://www.howtostartabusiness.org/registered-agent/requirements/)):

- **All 50 states require**: physical street address (no PO box), availability during business hours, 18+ years old
- **Delaware**: commercial RAs must obtain a certificate from the state
- **Nevada**: commercial RAs must be licensed
- **California**: 60-day resignation notice required
- Some states (e.g., Alaska) prohibit non-corporate LLCs from serving as RA

**RECOMMENDATION stands**: Partner with established RA (Northwest RA: ~$125/yr wholesale, resell at $49/yr with credit offset). DIY RA is Phase 3+ only, requires:

- Physical addresses in all 50 states (virtual office services: ~$50-100/state/yr = $2,500-5,000/yr)
- Compliance staff or very robust automation
- E&O insurance (errors & omissions) for RA liability
- State-by-state commercial RA registration where required

---

## F8 Revision: Cross-Sell Compliance (Holistic Review)

### The Full Compliance Picture

Cross-sell messages touch FOUR regulatory frameworks simultaneously:

1. **CAN-SPAM** (email): Unsubscribe mechanism, physical address in email, honest subject lines, no deceptive headers. Penalty: $51,744 per email.
2. **FTC "Free" Guide** (advertising): When we say "File taxes FREE" or "Form your LLC FREE", the service must actually be free with no hidden conditions. We pass this test today. BUT: "free RA credits" must clearly disclose that the base price is $49/yr and credits reduce it -- cannot say "Free RA" without the full context. Penalty: FTC enforcement action.
3. **IRS Circular 230** (tax advice): We cannot give specific tax advice (e.g., "You should form an LLC"). Only licensed practitioners (CPAs, EAs, attorneys) can. We CAN provide tax education. Every user-facing message must use education framing. Already addressed in F8 but needs to extend to:
  - AI-generated tips in the app
  - Social media content
  - Email subject lines
  - Push notifications
4. **State UPL laws** (unauthorized practice of law): LLC formation guidance that says "you SHOULD form in Delaware" could be construed as legal advice in some states. Safer: "Many entrepreneurs form in Delaware because of its business-friendly courts. Here are the facts."

### Template Compliance Checklist (for every user-facing message)

Every cross-sell email, in-app notification, and social post must pass:

- Uses education framing, not advice ("Many do X" vs "You should do X")
- No specific tax/legal recommendations for the user's situation
- "Free" claims have no hidden conditions
- Includes Circular 230 disclaimer if discussing tax topics: "This is tax education, not tax advice. Consult a qualified tax professional for advice specific to your situation."
- FTC disclosure on any partner/affiliate recommendation: "We may earn a commission if you sign up."
- Unsubscribe link present and functional
- Physical business address in footer (CAN-SPAM)
- Cross-product opt-in was given (if sending about other product)

---

## F11 Revision: Monorepo CI with Path Filters (Detailed Spec)

### Research-Backed Implementation

Using `dorny/paths-filter@v3` (the industry standard for monorepo CI, [source: oneuptime.com](https://oneuptime.com/blog/post/2025-12-20-monorepo-path-filters-github-actions/view)):

```yaml
# .github/workflows/ci.yml
name: CI
on:
  push:
    branches: [main]
  pull_request:

jobs:
  detect-changes:
    runs-on: ubuntu-latest
    outputs:
      filefree: ${{ steps.filter.outputs.filefree }}
      launchfree: ${{ steps.filter.outputs.launchfree }}
      studio: ${{ steps.filter.outputs.studio }}
      filefree-api: ${{ steps.filter.outputs.filefree-api }}
      launchfree-api: ${{ steps.filter.outputs.launchfree-api }}
      studio-api: ${{ steps.filter.outputs.studio-api }}
      shared: ${{ steps.filter.outputs.shared }}
    steps:
      - uses: actions/checkout@v4
      - uses: dorny/paths-filter@v3
        id: filter
        with:
          filters: |
            filefree:
              - 'apps/filefree/**'
            launchfree:
              - 'apps/launchfree/**'
            studio:
              - 'apps/studio/**'
            filefree-api:
              - 'apis/filefree-api/**'
            launchfree-api:
              - 'apis/launchfree-api/**'
            studio-api:
              - 'apis/studio-api/**'
            shared:
              - 'packages/**'
              - 'pnpm-lock.yaml'

  filefree-ci:
    needs: detect-changes
    if: >
      needs.detect-changes.outputs.filefree == 'true' ||
      needs.detect-changes.outputs.shared == 'true'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v4
      - uses: actions/setup-node@v4
        with: { node-version: '20', cache: 'pnpm' }
      - run: pnpm install --frozen-lockfile
      - run: pnpm --filter filefree lint
      - run: pnpm --filter filefree test
      - run: pnpm --filter filefree build

  # Repeat pattern for launchfree-ci, studio-ci
  # API jobs use Python setup instead of Node
```

Key rules:

- **Shared packages change triggers ALL downstream apps** (the `shared` output)
- **pnpm-lock.yaml change triggers everything** (dependency change)
- **Docs-only changes (`docs/`**, `*.md`) trigger nothing** -- add to `paths-ignore`
- **Gitleaks runs on every PR regardless** (security is not optional)
- Expected CI time: 2-3 min per affected app (vs 10+ min for everything)

---

## Final McKinsey Validation: Business Opportunity Still Sound?

### Market Size Confirmation

- **Tax filing**: 150M+ individual returns filed annually. IRS Free File used by <3% of eligible filers. TurboTax has ~37% market share at $50-200/return. Massive addressable market for free alternatives.
- **LLC formation**: ~5M new businesses formed annually in the US. LegalZoom IPO'd at $4.4B. ZenBusiness raised $1B+. Market is large and growing.
- **Combined TAM**: Both markets are $10B+ and dominated by incumbents with high pricing. "Free" is the proven disruption vector (Credit Karma proved this at $7.1B acquisition).

### Competitive Moat Assessment


| Moat                                                        | Strength                                                                          | Threat                                                                  |
| ----------------------------------------------------------- | --------------------------------------------------------------------------------- | ----------------------------------------------------------------------- |
| Free forever (no per-return cost once MeF transmitter live) | STRONG -- no VC-funded competitor can match $0/return without burning cash        | Intuit could make TurboTax truly free (but shareholders won't allow it) |
| Two-product cross-sell                                      | MODERATE -- unique: no competitor does both tax filing AND LLC formation for free | LegalZoom could add tax filing, TurboTax could add LLC formation        |
| AI-native UX                                                | MODERATE -- "photo to done in 5 minutes" is genuinely differentiated              | Every competitor will add AI. Speed of execution matters.               |
| 50-state data pipeline                                      | MODERATE -- real-time accuracy across tax + formation is operationally hard       | Larger companies have dedicated research teams                          |
| Brand trust via free filing                                 | STRONG -- trust earned through free filing is hard to replicate                   | Takes years to build, first-mover advantage matters                     |


### Risk Matrix (Updated)


| Risk                                    | Probability | Impact   | Mitigation                                                                           |
| --------------------------------------- | ----------- | -------- | ------------------------------------------------------------------------------------ |
| Intuit sends C&D for "FileFree"         | LOW-MEDIUM  | HIGH     | Supplemental Register filing, descriptive term defense, operate on .tax/.ai not .com |
| IRS rejects MeF transmitter application | LOW         | CRITICAL | Column Tax fallback, re-apply next cycle                                             |
| Faceless social content flops           | MEDIUM      | MEDIUM   | 2-week validation cycle, pivot to different format                                   |
| Partnership revenue underperforms       | MEDIUM      | HIGH     | Multiple revenue streams, not dependent on any single partner                        |
| Solo founder burnout                    | MEDIUM      | HIGH     | AI agents reduce workload, command center reduces cognitive overhead                 |
| State data becomes stale                | LOW         | HIGH     | 3-layer monitoring pipeline (Section 3B)                                             |
| Competitor launches free LLC formation  | LOW         | MEDIUM   | Cross-sell moat, brand loyalty, first-mover                                          |


---

## Updates to docs/KNOWLEDGE.md

Add the following decisions:

- **D35 -- Venture Master Plan v1**: Multi-product venture (FileFree + LaunchFree + Command Center). pnpm workspace monorepo. Federated identity. 50-state AI data pipeline. Faceless social pipeline. 38 AI agents.
- **D36 -- Company Structure**: Single Wyoming LLC with DBAs for each brand. Convert to holding company structure when combined revenue exceeds $50K.
- **D37 -- Brand Palette Strategy**: FileFree (violet-indigo), LaunchFree (teal-cyan), Studio (zinc-neutral). Shared `packages/ui/` with CSS variable theming.
- **D38 -- FileFree Trademark Risk**: filefree.com confirmed owned by Intuit (MarkMonitor registrar, since 1999). File "FILEFREE" on USPTO Supplemental Register. Never use filefree.com. Strict brand name guidelines enforced.
- **D39 -- Faceless Social Pipeline**: DIY n8n workflow (GPT script + DALL-E/Kling visuals + ElevenLabs voice + FFmpeg assembly). ~$0.10/video, ~$3/month for 30 videos. Validated with 2-week test before full automation.
- **D40 -- CI Path Filters**: `dorny/paths-filter@v3` for selective builds. Shared package changes trigger all apps. Expected CI: 2-3 min per affected app.

## Updates to docs/TASKS.md

Add venture-wide section after the existing FileFree sprints, preserving all existing FileFree task detail. The new section references the Venture Master Plan phases (P0 through P8) with links to the plan for full specs. Key additions:

- Sprint B.2 (Company Setup) updated with LLC filing details (Wyoming, DBA filings)
- New Sprint V.0 (Venture Phase 0): Domain purchases, Google Workspace, social handles
- New Sprint V.1 (Monorepo Migration): Phase 1 from plan
- Cross-reference to plan for Phases 2-8 (detailed specs live in the plan, TASKS.md has the checklist items)

