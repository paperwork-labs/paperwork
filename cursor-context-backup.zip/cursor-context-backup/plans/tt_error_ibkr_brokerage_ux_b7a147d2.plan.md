---
name: TT Error IBKR Brokerage UX
overview: "Comprehensive implementation plan: Connect job persistence (Redis), TT/IBKR error surfacing, IBKR per-user credentials, sync history, edit connections, clean account display, DRY refactors, and tests."
todos:
  - id: phase-0-connect-job-store
    content: "Phase 0: Create ConnectJobStore (Redis), replace JOBS in aggregator, add job_id to ibkr_flex_status"
    status: completed
  - id: phase-1-error-surfacing
    content: "Phase 1: Add sync_error_message to API + UI, sync 409 dedup, persist last_error on connect fail"
    status: completed
  - id: phase-2-credentials-service
    content: "Phase 2: Create AccountCredentialsService.get_decrypted, refactor tastytrade_sync to use it"
    status: completed
  - id: phase-3-ibkr-per-user
    content: "Phase 3: IBKR FlexQuery credential injection, IBKR account_number in wizard, IBKR_FLEX fallback"
    status: completed
  - id: phase-4-sync-history
    content: "Phase 4: Create AccountSync rows in sync_task, GET sync-history API, Sync Jobs UI section"
    status: completed
  - id: phase-5-edit-connections
    content: "Phase 5: PATCH /accounts/{id}/credentials, Edit button + modal for TT/IBKR"
    status: completed
  - id: phase-6-clean-display
    content: "Phase 6: PATCH account_name, Account column with name+number, Edit name pencil"
    status: completed
  - id: phase-7-dry-decompose
    content: "Phase 7: useConnectJobPoll hook, ConnectWizard, BrokerAccountRow components"
    status: completed
  - id: phase-8-ibkr-poll
    content: "Phase 8: IBKR connect polling passes jobId, checks job_error"
    status: completed
  - id: phase-9-docs
    content: "Phase 9: Encryption key rotation doc, IBKR FlexQuery helper text"
    status: completed
  - id: phase-10-tests
    content: "Phase 10: pytest for ConnectJobStore, sync-history, PATCH, 409, AccountCredentialsService, IBKR creds"
    status: completed
isProject: false
---

# Brokerage: TT Error, IBKR Data, Sync Jobs, Edit, Clean Display

Detailed implementation plan with ordered tasks. Covers production fixes, error visibility, IBKR credential flow, sync history, edit flow, display polish, DRY refactors, and tests.

---

## Phase 0: Connect Job Persistence (Production Critical)

**Problem**: In-memory `JOBS` dict fails with multiple uvicorn workers. IBKR status never exposes job errors.

### Tasks


| ID  | Task                                                                                                                                                      | File(s)                                                              |
| --- | --------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------- |
| 0.1 | Create `ConnectJobStore` using Redis: `connect_job:{job_id}` key, JSON `{state, error, started_at, broker}`, TTL 600s. `set(job_id, data)`, `get(job_id)` | New `backend/services/security/connect_job_store.py`                 |
| 0.2 | Replace `JOBS` in aggregator with `ConnectJobStore`. `_tt_connect_job` and `_ibkr_connect_job` write to store                                             | [backend/api/routes/aggregator.py](backend/api/routes/aggregator.py) |
| 0.3 | `tastytrade_status(job_id)` reads from store instead of JOBS                                                                                              | [backend/api/routes/aggregator.py](backend/api/routes/aggregator.py) |
| 0.4 | Add `job_id: Optional[str] = Query(None)` to `ibkr_flex_status`; when provided, read from store and return `job_state`, `job_error`                       | [backend/api/routes/aggregator.py](backend/api/routes/aggregator.py) |
| 0.5 | Wire Redis URL from settings (reuse existing REDIS_URL/CELERY_BROKER_URL if available)                                                                    | [backend/config.py](backend/config.py)                               |


---

## Phase 1: Error Surfacing (TT + Accounts)

### Backend


| ID  | Task                                                                                                                                                 | File(s)                                                                              |
| --- | ---------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------ |
| 1.1 | Add `sync_error_message: Optional[str]` to `BrokerAccountResponse`; include in list serializer                                                       | [backend/api/routes/account_management.py](backend/api/routes/account_management.py) |
| 1.2 | Sync deduplication: if `account.sync_status in (QUEUED, RUNNING)`, return `409 Conflict` with detail "Sync already in progress"                      | [backend/api/routes/account_management.py](backend/api/routes/account_management.py) |
| 1.3 | When connect fails in `_tt_connect_job` / `_ibkr_connect_job`, persist `AccountCredentials.last_error` (or `BrokerAccount`) for the affected account | [backend/api/routes/aggregator.py](backend/api/routes/aggregator.py)                 |


### Frontend


| ID  | Task                                                                                                                                     | File(s)                                                                                |
| --- | ---------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------- |
| 1.4 | Status cell: when `a.sync_status` is `error`/`failed` and `a.sync_error_message`, show Tooltip with error on hover over the status Badge | [frontend/src/pages/SettingsBrokerages.tsx](frontend/src/pages/SettingsBrokerages.tsx) |
| 1.5 | Add Alert (or inline text) when `tt.last_error` or `tt.job_error` exists; display in TT connect area or above table                      | [frontend/src/pages/SettingsBrokerages.tsx](frontend/src/pages/SettingsBrokerages.tsx) |


---

## Phase 2: AccountCredentialsService (DRY)


| ID  | Task                                                                                                                                                                                                      | File(s)                                                                                                        |
| --- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------- |
| 2.1 | Create `AccountCredentialsService` with `get_decrypted(account_id: int, db) -> dict`. Loads `AccountCredentials`, decrypts via `credential_vault`, returns `{provider, ...payload}`. Raises if not found. | New `backend/services/portfolio/account_credentials_service.py`                                                |
| 2.2 | Refactor `tastytrade_sync_service` to use `AccountCredentialsService.get_decrypted` instead of inline decrypt                                                                                             | [backend/services/portfolio/tastytrade_sync_service.py](backend/services/portfolio/tastytrade_sync_service.py) |


---

## Phase 3: IBKR Per-User Credentials

### Backend


| ID  | Task                                                                                                                                                                                                                                                   | File(s)                                                                                                                                                                      |
| --- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 3.1 | `IBKRFlexQueryClient.__init__(token=None, query_id=None)`: use provided values over `settings.IBKR_FLEX_TOKEN` / `settings.IBKR_FLEX_QUERY_ID`                                                                                                         | [backend/services/clients/ibkr_flexquery_client.py](backend/services/clients/ibkr_flexquery_client.py)                                                                       |
| 3.2 | Add `get_ibkr_credentials(account_id, db)` in `AccountCredentialsService` that returns `{flex_token, query_id}` (calls `get_decrypted`, validates shape)                                                                                               | [backend/services/portfolio/account_credentials_service.py](backend/services/portfolio/account_credentials_service.py)                                                       |
| 3.3 | In `IBKRSyncService.sync_comprehensive_portfolio`: load creds via service for the BrokerAccount; construct `IBKRFlexQueryClient(token=..., query_id=...)`. Fall back to env if no stored creds                                                         | [backend/services/portfolio/ibkr_sync_service.py](backend/services/portfolio/ibkr_sync_service.py)                                                                           |
| 3.4 | `IBKRFlexConnectRequest`: add `account_number: Optional[str]`. In `_ibkr_connect_job`, if provided, create/update BrokerAccount with that `account_number` instead of `"IBKR_FLEX"`                                                                    | [backend/api/routes/aggregator.py](backend/api/routes/aggregator.py)                                                                                                         |
| 3.5 | When `account_number == "IBKR_FLEX"`: in `get_full_report`, do not pass `acct` param on first attempt; if "Account is invalid", retry without acct. In XML parsing, if no account_id match, use first `accountId` found in FlexStatement for filtering | [backend/services/clients/ibkr_flexquery_client.py](backend/services/clients/ibkr_flexquery_client.py), [ibkr_sync_service](backend/services/portfolio/ibkr_sync_service.py) |


### Frontend


| ID  | Task                                                                                                                                    | File(s)                                                                                |
| --- | --------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------- |
| 3.6 | IBKR wizard step: add optional Input "IBKR Account Number" (placeholder: "e.g. U1234567 - optional"). Pass to `ibkrFlexConnect` payload | [frontend/src/pages/SettingsBrokerages.tsx](frontend/src/pages/SettingsBrokerages.tsx) |
| 3.7 | Update `ibkrFlexConnect` API to accept `account_number` in payload                                                                      | [frontend/src/services/api.ts](frontend/src/services/api.ts)                           |


---

## Phase 4: Sync History (AccountSync)

### Backend


| ID  | Task                                                                                                                                                                                                        | File(s)                                                                                                                                    |
| --- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------ |
| 4.1 | In `sync_account_task`, before calling broker service: create `AccountSync(account_id, sync_type, status=RUNNING, started_at=now)`. Commit and keep `sync_id`                                               | [backend/tasks/account_sync.py](backend/tasks/account_sync.py)                                                                             |
| 4.2 | On success: update AccountSync with `status=SUCCESS`, `completed_at`, `duration_seconds`. On error: `status=ERROR`, `error_message`                                                                         | [backend/tasks/account_sync.py](backend/tasks/account_sync.py) or [broker_sync_service](backend/services/portfolio/broker_sync_service.py) |
| 4.3 | Add `GET /accounts/sync-history?account_id=&limit=20` (account_id optional). Returns recent `AccountSync` for user's accounts, ordered by `started_at DESC`. Validate ownership via `BrokerAccount.user_id` | [backend/api/routes/account_management.py](backend/api/routes/account_management.py)                                                       |
| 4.4 | Normalize `AccountSync.status` to use same `SyncStatus` enum as BrokerAccount (SUCCESS, ERROR, RUNNING)                                                                                                     | [backend/models/broker_account.py](backend/models/broker_account.py)                                                                       |


### Frontend


| ID  | Task                                                                                                                                                                            | File(s)                                                                                |
| --- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------- |
| 4.5 | Add `accountsApi.syncHistory(accountId?: number)`                                                                                                                               | [frontend/src/services/api.ts](frontend/src/services/api.ts)                           |
| 4.6 | Add "Sync Jobs" or "Recent syncs" section below the accounts table. Fetch sync history, display as list: account name, status badge, timestamp, error (expandable). Limit 10–20 | [frontend/src/pages/SettingsBrokerages.tsx](frontend/src/pages/SettingsBrokerages.tsx) |


---

## Phase 5: Edit Connections

### Backend


| ID  | Task                                                                                                          | File(s)                                                                                                                                                   |
| --- | ------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 5.1 | Add `PATCH /accounts/{id}/credentials` with body `{ broker: "tastytrade"                                      | "ibkr", credentials: {...} }`. Validate user owns account. Route by broker to update` AccountCredentials` (decrypt existing, merge/overwrite, re-encrypt) |
| 5.2 | TT credentials: require `client_id`, `client_secret`, `refresh_token`. IBKR: require `flex_token`, `query_id` | [backend/api/routes/account_management.py](backend/api/routes/account_management.py)                                                                      |
| 5.3 | Optional: support `account_number` in IBKR credentials update to change BrokerAccount.account_number          | [backend/api/routes/account_management.py](backend/api/routes/account_management.py)                                                                      |


### Frontend


| ID  | Task                                                                                                                                                                                                                          | File(s)                                                                                |
| --- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------- |
| 5.4 | Add "Edit" button per account row. Opens modal/dialog with broker-specific form (TT: client_id, secret, refresh_token; IBKR: flex_token, query_id). Placeholders for secrets. Submit calls `PATCH /accounts/{id}/credentials` | [frontend/src/pages/SettingsBrokerages.tsx](frontend/src/pages/SettingsBrokerages.tsx) |
| 5.5 | Add `accountsApi.updateCredentials(accountId, { broker, credentials })`                                                                                                                                                       | [frontend/src/services/api.ts](frontend/src/services/api.ts)                           |
| 5.6 | Schwab: Edit = reuse existing "Connect Charles Schwab" flow (no new endpoint)                                                                                                                                                 | —                                                                                      |


---

## Phase 6: Clean Account Display

### Backend


| ID  | Task                                                                                                                        | File(s)                                                                              |
| --- | --------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------ |
| 6.1 | Add `PATCH /accounts/{id}` with body `{ account_name?: str, account_type?: str }`. Validate ownership. Update BrokerAccount | [backend/api/routes/account_management.py](backend/api/routes/account_management.py) |


### Frontend


| ID  | Task                                                                                                                                                                                    | File(s)                                                                                |
| --- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------- |
| 6.2 | Account column: show `account_name` as primary, `account_number` in smaller muted text (e.g. `<Text fontSize="xs" color="fg.muted">{a.account_number}</Text>`). Fallback: `account_name |                                                                                        |
| 6.3 | Add pencil icon "Edit name" next to account. Click opens inline Input or small modal; submit calls `PATCH /accounts/{id}` with `account_name`                                           | [frontend/src/pages/SettingsBrokerages.tsx](frontend/src/pages/SettingsBrokerages.tsx) |
| 6.4 | Add `accountsApi.updateAccount(accountId, { account_name })`                                                                                                                            | [frontend/src/services/api.ts](frontend/src/services/api.ts)                           |


---

## Phase 7: DRY and Frontend Decomposition


| ID  | Task                                                                                                                                                                 | File(s)                                                                                  |
| --- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------- |
| 7.1 | Extract `useConnectJobPoll(jobId, statusApi, isSuccess, getError)` hook: polls every 1s up to 30s; returns `{ done, success, error }`. Used by TT and IBKR in wizard | New `frontend/src/hooks/useConnectJobPoll.ts`                                            |
| 7.2 | Refactor submitWizard to use `useConnectJobPoll` for TT and IBKR (replace inline for-loops)                                                                          | [frontend/src/pages/SettingsBrokerages.tsx](frontend/src/pages/SettingsBrokerages.tsx)   |
| 7.3 | Extract `ConnectWizard` component: step 1 broker picker, step 2 broker-specific forms. Props: `open`, `onClose`, `onSuccess`                                         | New `frontend/src/components/brokerage/ConnectWizard.tsx`                                |
| 7.4 | Extract `BrokerAccountRow` component: displays row, Sync/Edit/Disable/Delete, expandable sync history. Props: account, onSync, onEdit, etc.                          | New `frontend/src/components/brokerage/BrokerAccountRow.tsx`                             |
| 7.5 | Use `CredentialType` Literal or enum in Python for `credential_type` validation                                                                                      | [backend/models/broker_account.py](backend/models/broker_account.py) or new types module |


---

## Phase 8: IBKR Connect Job Polling Fix


| ID  | Task                                                                                                          | File(s)                                                                                |
| --- | ------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------- |
| 8.1 | Update frontend IBKR connect flow: pass `jobId` to `ibkrFlexStatus(jobId)` when polling (matching TT pattern) | [frontend/src/pages/SettingsBrokerages.tsx](frontend/src/pages/SettingsBrokerages.tsx) |
| 8.2 | In polling loop, check `st?.job_state === 'error'` and throw `st?.job_error` so user sees failure reason      | [frontend/src/pages/SettingsBrokerages.tsx](frontend/src/pages/SettingsBrokerages.tsx) |
| 8.3 | Add `job_id` param to `ibkrFlexStatus` in api.ts if not already supported                                     | [frontend/src/services/api.ts](frontend/src/services/api.ts)                           |


---

## Phase 9: Docs and Runbook


| ID  | Task                                                                                                                                 | File(s)                                                                                |
| --- | ------------------------------------------------------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------------- |
| 9.1 | Document encryption key rotation: rotating `ENCRYPTION_KEY` invalidates stored credentials. Add to ops/runbook or `docs/`            | New or existing `docs/`                                                                |
| 9.2 | Add IBKR FlexQuery setup helper text in wizard: "Client Portal > Reports > Flex Queries, enable web service, get token and Query ID" | [frontend/src/pages/SettingsBrokerages.tsx](frontend/src/pages/SettingsBrokerages.tsx) |


---

## Phase 10: Tests


| ID   | Task                                                                                                                     | File(s)                                                                                                 |
| ---- | ------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------- |
| 10.1 | pytest: `ConnectJobStore` set/get with Redis (or fake Redis)                                                             | New `backend/tests/test_connect_job_store.py`                                                           |
| 10.2 | pytest: `GET /accounts/sync-history` returns only user's syncs; 403 for wrong user                                       | [backend/tests/](backend/tests/)                                                                        |
| 10.3 | pytest: `PATCH /accounts/{id}` and `PATCH /accounts/{id}/credentials` validate ownership                                 | [backend/tests/](backend/tests/)                                                                        |
| 10.4 | pytest: Sync returns 409 when `sync_status in (QUEUED, RUNNING)`                                                         | [backend/tests/](backend/tests/)                                                                        |
| 10.5 | pytest: `AccountCredentialsService.get_decrypted` raises when no creds; returns dict when present. Mock credential_vault | [backend/tests/](backend/tests/)                                                                        |
| 10.6 | pytest: IBKR sync uses stored credentials when present (mock AccountCredentialsService)                                  | [backend/tests/test_broker_sync_service.py](backend/tests/test_broker_sync_service.py) or IBKR-specific |


---

## Implementation Order

Execute phases in order. Phase 0 and 1 are critical for production and UX. Phase 2–3 unblock IBKR data. Phases 4–6 deliver user-requested features. Phase 7 improves maintainability. Phase 8 fixes IBKR connect UX. Phases 9–10 are polish and safety.

```mermaid
flowchart LR
  P0[Phase 0: Redis Jobs] --> P1[Phase 1: Errors]
  P1 --> P2[Phase 2: CredService]
  P2 --> P3[Phase 3: IBKR Creds]
  P3 --> P4[Phase 4: Sync History]
  P4 --> P5[Phase 5: Edit]
  P5 --> P6[Phase 6: Display]
  P6 --> P7[Phase 7: DRY]
  P7 --> P8[Phase 8: IBKR Poll]
  P8 --> P9[Phase 9: Docs]
  P9 --> P10[Phase 10: Tests]
```



---

## Key Files Summary


| File                                                        | Changes                                                                              |
| ----------------------------------------------------------- | ------------------------------------------------------------------------------------ |
| `backend/services/security/connect_job_store.py`            | New: Redis-backed job store                                                          |
| `backend/api/routes/aggregator.py`                          | Replace JOBS; job_id in ibkr status; IBKR account_number; persist last_error on fail |
| `backend/api/routes/account_management.py`                  | sync_error_message; sync 409; GET sync-history; PATCH account; PATCH credentials     |
| `backend/services/portfolio/account_credentials_service.py` | New: get_decrypted, get_ibkr_credentials                                             |
| `backend/services/portfolio/broker_sync_service.py`         | Create AccountSync; use AccountCredentialsService                                    |
| `backend/services/clients/ibkr_flexquery_client.py`         | Constructor accepts token, query_id                                                  |
| `backend/services/portfolio/ibkr_sync_service.py`           | Load creds; IBKR_FLEX fallback                                                       |
| `frontend/src/pages/SettingsBrokerages.tsx`                 | All UI changes; extract components                                                   |
| `frontend/src/hooks/useConnectJobPoll.ts`                   | New: shared polling hook                                                             |
| `frontend/src/components/brokerage/ConnectWizard.tsx`       | New                                                                                  |
| `frontend/src/components/brokerage/BrokerAccountRow.tsx`    | New                                                                                  |


