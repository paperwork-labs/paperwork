---
name: PR Fixes + Deploy
overview: "Address all 7 Copilot PR review comments on PR #3, fix stale persona doc paths, update Hetzner pricing, create Hetzner deploy configs, then merge the PR, deploy to Render via MCP, and complete Neon DB setup."
todos:
  - id: pr-comment-1
    content: "Fix Makefile: change `exec` to `run --rm` for test/lint/format targets"
    status: completed
  - id: pr-comment-2
    content: Replace root TASKS.md with redirect to docs/TASKS.md
    status: completed
  - id: pr-comment-3-4
    content: Fix stale doc paths in strategy.mdc, partnerships.mdc, workflows.mdc, cfo.mdc
    status: completed
  - id: pr-comment-5
    content: Make CORS origins configurable via FRONTEND_URL env var in api/app/main.py
    status: completed
  - id: pr-comment-6
    content: Mount pyproject.toml into API container in compose.dev.yaml
    status: completed
  - id: pr-comment-7
    content: Add guard messages to Makefile migrate/seed targets (not yet scaffolded)
    status: completed
  - id: hetzner-pricing
    content: Update Hetzner pricing from $7.50 to $5.49 in docs/TASKS.md, cfo.mdc, strategy.mdc
    status: completed
  - id: hetzner-configs
    content: Create infra/hetzner/ with compose.yaml, env.example, setup.sh, README.md
    status: completed
  - id: knowledge-d20
    content: Add D20 entry to docs/KNOWLEDGE.md
    status: completed
  - id: commit-merge
    content: "Commit all changes, push, merge PR #3"
    status: completed
  - id: render-deploy
    content: Create filefree-api service on Render via MCP and configure env vars
    status: completed
  - id: neon-setup
    content: Guide user through Neon project creation, wire DATABASE_URL to Render
    status: in_progress
isProject: false
---

# PR Fixes, Deploy, and Neon Setup

## Context

PR #3 (`groundwork` -> `main`) has 7 Copilot review comments. After addressing them, we merge, deploy the API to Render via MCP, and finalize the Neon database connection.

---

## Part 1: Address PR #3 Review Comments

### Comment 1 -- Makefile `exec` requires running stack

**File:** [Makefile](Makefile)
**Issue:** `make test/lint/format` use `docker compose exec` which fails if containers aren't running.
**Fix:** Change `exec` to `run --rm` for `test`, `lint`, `format` targets so they work from a cold start. Keep `exec` only for interactive targets (`shell-api`, `shell-web`, `db`) where a running stack is expected.

### Comment 2 -- Root `TASKS.md` is a stale duplicate

**File:** [TASKS.md](TASKS.md) (root)
**Issue:** Root `TASKS.md` duplicates `docs/TASKS.md` with broken relative links. The canonical version is `docs/TASKS.md`.
**Fix:** Replace root `TASKS.md` with a short redirect:

```markdown
# FileFree Build Tasks
See [docs/TASKS.md](docs/TASKS.md) for the full task plan.
```

### Comment 3 -- `strategy.mdc` stale `KNOWLEDGE.md` path

**File:** [.cursor/rules/strategy.mdc](.cursor/rules/strategy.mdc)
**Issue:** 3 references to `KNOWLEDGE.md` without `docs/` prefix (lines 71, 73, 91).
**Fix:** Update all 3 to `docs/KNOWLEDGE.md`.

### Comment 4 -- `partnerships.mdc` stale doc paths

**File:** [.cursor/rules/partnerships.mdc](.cursor/rules/partnerships.mdc)
**Issue:** Line 112 references `PRD.md / STRATEGY_REPORT.md` without `docs/` prefix.
**Fix:** Update to `docs/PRD.md / docs/STRATEGY_REPORT.md`.

### Comment 5 -- CORS hardcoded to localhost

**File:** [api/app/main.py](api/app/main.py)
**Issue:** CORS only allows `http://localhost:3000`. Production requests from `filefree.tax` will be blocked.
**Fix:** Read `FRONTEND_URL` from environment, build origins list from it. Fallback to `http://localhost:3000` in dev.

```python
import os

frontend_url = os.getenv("FRONTEND_URL", "http://localhost:3000")
origins = [frontend_url]
if frontend_url != "http://localhost:3000":
    origins.append("http://localhost:3000")
```

The `FRONTEND_URL` env var already exists in both `infra/env.dev.example` (line 23) and `render.yaml` (line 30, set to `https://filefree.tax`).

### Comment 6 -- Docker volume missing `pyproject.toml`

**File:** [infra/compose.dev.yaml](infra/compose.dev.yaml)
**Issue:** API container mounts `../api:/app` but `pyproject.toml` lives at repo root. Ruff/mypy inside the container can't find the config.
**Fix:** Add a read-only bind mount for `pyproject.toml` into the API container:

```yaml
volumes:
  - ../api:/app
  - ../pyproject.toml:/pyproject.toml:ro
```

### Comment 7 -- Makefile `migrate` and `seed` targets reference non-existent code

**File:** [Makefile](Makefile)
**Issue:** `make migrate` calls `alembic upgrade head` (no alembic config exists), `make seed` calls `app.seed` (no seed module exists).
**Fix:** Add a guard comment and make both targets print a helpful message until scaffolded:

```makefile
migrate: ## Run database migrations (requires alembic setup — see Sprint 1)
	@echo "Alembic not yet configured. Run 'make dev' first, then set up alembic in api/."

seed: ## Seed test data (requires seed module — see Sprint 1)
	@echo "Seed module not yet implemented. See docs/TASKS.md Sprint 1."
```

---

## Part 2: Fix Remaining Stale Persona Paths

### `workflows.mdc` -- stale `KNOWLEDGE.md` and `TASKS.md` paths

**File:** [.cursor/rules/workflows.mdc](.cursor/rules/workflows.mdc)
**Issue:** 5 references to `KNOWLEDGE.md` and 2 to `TASKS.md` without `docs/` prefix.
**Fix:** Update all to `docs/KNOWLEDGE.md` and `docs/TASKS.md`.

### `cfo.mdc` -- stale Hetzner pricing

**File:** [.cursor/rules/cfo.mdc](.cursor/rules/cfo.mdc)
**Issue:** Hetzner listed as `$7.50/mo` (line 30), total infra as `$34.50/mo` (line 32, 55, 83).
**Fix:** Update to `$5.49/mo` (EUR 5.49) and total to `$32.49/mo`. Also update `strategy.mdc` line 55 (same pricing).

### `docs/TASKS.md` -- stale Hetzner pricing

**File:** [docs/TASKS.md](docs/TASKS.md)
**Issue:** Line 71 says `$7.50/mo, CX33: 8GB RAM, 2 vCPU`.
**Fix:** Update to `$5.49/mo, CX33: 8GB RAM, 4 vCPU, 80GB SSD`.

---

## Part 3: Create Hetzner Deploy Configs

Create `infra/hetzner/` with deployment files for the ops stack on the existing Hetzner server (`204.168.147.100`):

- `**infra/hetzner/compose.yaml`** -- Docker Compose for Postiz + n8n + PostgreSQL + Redis
- `**infra/hetzner/env.example`** -- Environment template for ops stack
- `**infra/hetzner/setup.sh`** -- Bootstrap script (install Docker, clone repo, start services)
- `**infra/hetzner/README.md**` -- Setup and maintenance instructions

---

## Part 4: Knowledge Entry

Add **D20** to [docs/KNOWLEDGE.md](docs/KNOWLEDGE.md):

- Multi-persona review findings (stale paths, pricing fixes)
- Hetzner ops stack architecture decision
- Render MCP integration for deployment management

---

## Part 5: Commit, Push, and Merge PR

1. Commit all fixes to the `groundwork` branch
2. Push to remote
3. Merge PR #3 into `main`

---

## Part 6: Deploy API to Render via MCP

After merge, use the Render MCP to:

1. Create the `filefree-api` web service via `create_web_service` pointing to `sankalp404/fileFree` repo, `main` branch, Python runtime
2. Set environment variables via `update_environment_variables`:
  - `ENVIRONMENT=production`, `DEBUG=false`
  - `FRONTEND_URL=https://filefree.tax`
  - `DATABASE_URL` (from Neon connection string -- user provides)
  - Other secrets as user provides them
3. Verify deploy via `list_deploys` and `list_logs`

---

## Part 7: Neon Database Setup

The user has a Neon account. Steps:

1. User creates a `filefree` project in Neon (Postgres 17, US East 1)
2. User provides the connection string
3. We set `DATABASE_URL` on Render via MCP
4. We add it to `infra/env.prod.example` as a reference placeholder

---

## Important: Render MCP as a Superpower

Going forward, always use the Render MCP for:

- Deploying, monitoring, and debugging the API backend
- Managing environment variables
- Checking deploy status, logs, and metrics
- Avoid manual dashboard work where possible

