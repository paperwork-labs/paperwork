---
name: Admin and Dashboard v2
overview: Fix missing fundamentals, resolve red health dimensions (stage quality + audit), surface schedules, refactor runbook with context-aware logic, and redesign MarketDashboard. Each issue carries acceptance criteria, tests, observability, and rollback. Rolled out as 5 incremental PRs to reduce blast radius.
todos: []
isProject: false
---

# Admin Fixes and Dashboard