---
name: Postiz Backend Restart
overview: The Postiz backend was stuck during cold-start after container recreation. A PM2 restart resolved it -- the backend is now running and the registration endpoint should work.
todos: []
isProject: false
---

# Postiz Backend Cold-Start Fix

## What Happened

When the container was recreated (to add `MAIN_URL`), the backend process started via PM2 but got stuck during NestJS initialization -- likely a race condition with the Temporal/ES services still warming up. The frontend (Next.js) and nginx started fine, so the page loaded but API calls to port 3000 returned 502.

## Fix Applied

Ran `pm2 restart backend` inside the container. The backend then started normally:

```
Nest application successfully started
Configuration check completed without any issues
Backend is running on: http://localhost:3000
```

## No Code Changes Needed

This was a transient startup ordering issue. The compose file already has `depends_on` for postgres, redis, and temporal. The ES healthcheck and temporal startup add ~60s of delay, and the backend may need a retry on its Temporal connection.

## Next Step

Try registering again at `https://social.filefree.tax/auth` -- the API should respond now.