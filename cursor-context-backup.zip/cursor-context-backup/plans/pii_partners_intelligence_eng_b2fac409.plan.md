---
name: PII Partners Intelligence Eng
status: archived
overview: "ARCHIVED — Content integrated into Venture Master Plan Section 0I/4/6K. Seven updates: PII/privacy strategy, recommendation intelligence engine, autonomous engineering agents, package rename, workspace simplification."
todos:
  - id: add-pii-lifecycle
    content: "Add Section 0I: PII Data Lifecycle (CCPA, data inventory, retention, deletion, consent, ADMT)"
    status: pending
  - id: add-intelligence-engine
    content: Add recommendation intelligence engine spec (Section 5B), credit score roadmap, Partnership Intelligence agent, rename cross-sell -> intelligence
    status: pending
  - id: add-autonomous-eng
    content: "Add Section 6K: Autonomous Engineering Protocol (background agent tasks, PR review flow)"
    status: pending
  - id: simplify-workspace
    content: Update workspace scoping (root default), agent availability (alwaysApply), collapse Section 9 self-review
    status: pending
  - id: sync-commit-push
    content: Sync VENTURE_MASTER_PLAN.md, update KNOWLEDGE.md, FINANCIALS.md if needed, commit and push
    status: pending
isProject: false
---

# PII Strategy, Partner Intelligence, Autonomous Engineering, and Plan Cleanup

---

## 1. PII Strategy (CCPA-First, Not GDPR)

The plan already has scattered PII requirements (.cursorrules security rules, Section 0C legal protection checklist, Section 0G pre-code actions). What's missing is a single consolidated **PII Lifecycle section**. This goes into the master plan as a new Section 0I.

**What to add** (Section 0I: PII Data Lifecycle):

- **Applicability**: CCPA/CPRA (California), not GDPR (US-only product). CCPA applies once we hit thresholds (50K+ consumers/year or $25M revenue). Pre-threshold, we follow CCPA voluntarily because (a) we're a CA LLC and (b) it's the right thing to do.
- **Data inventory**: SSN (FileFree only), name, email, address, filing status, income data, LLC owner info (LaunchFree), credit score (future). Classify by sensitivity tier.
- **Retention policy**: W-2 images: 24hrs (GCP lifecycle). Tax return data: 7 years (IRS requirement). LLC formation data: indefinite (user's business records). User account data: until deletion request.
- **Deletion rights**: Account deletion endpoint from day one. Cascade: Neon DB, GCP Cloud Storage, Upstash sessions, venture identity. 30-day response window (CCPA requirement).
- **Consent architecture**: Opt-in checkbox for cross-product data use. Global Privacy Control (GPC) signal detection. "Do Not Sell" link in footer (even though we don't sell data -- preemptive compliance).
- **ADMT disclosure**: Since we use AI for tax calculations and formation guidance, CCPA 2026 rules require Automated Decision-Making Technology notices. Add to privacy policy.
- **Risk assessments**: Document for SSN processing (FileFree) and credit score processing (future). Required by CPRA for sensitive data.

All of this consolidates existing scattered references into one authoritative section. No new concepts -- just organizational clarity.

---

## 2. Recommendation Intelligence Engine (Credit Karma Model)

This is the biggest strategic addition. Rename `packages/cross-sell` to `packages/intelligence` and evolve it from a simple recommendation engine into a **user financial profile matching system**.

### The Credit Karma Playbook (Research-Backed)

Credit Karma's model:

- User gives permission to pull credit score (TransUnion/Equifax)
- CK builds a financial profile (credit score + income range + debt + account types)
- CK matches users to financial products with "Approval Odds" based on partner eligibility criteria
- Partners pay CK per approved referral (not per click -- performance-based)
- CK never sells user data -- they sell the match

**Our version** (adapted for our scale and products):

```mermaid
graph TD
    subgraph userProfile [User Financial Profile]
        TaxData["Tax Return Data (FileFree)"]
        LLCData["Business Data (LaunchFree)"]
        CreditScore["Credit Score (opt-in, Phase 2+)"]
    end

    subgraph intelligence [packages/intelligence]
        ProfileBuilder["Profile Builder"]
        Matcher["Partner Matcher"]
        Ranker["Best-Fit Ranker"]
    end

    subgraph partners [Partner Ecosystem]
        HYSA["HYSA (Betterment, SoFi, Wealthfront)"]
        Banking["Banking (Ally, Chime)"]
        Investing["Investing (Robinhood, Acorns)"]
        CreditCards["Credit Cards (Phase 2+)"]
        Loans["Loans (Phase 2+)"]
        Insurance["Business Insurance (Phase 2+)"]
    end

    TaxData --> ProfileBuilder
    LLCData --> ProfileBuilder
    CreditScore --> ProfileBuilder
    ProfileBuilder --> Matcher
    Matcher --> Ranker
    Ranker --> HYSA
    Ranker --> Banking
    Ranker --> Investing
    Ranker --> CreditCards
    Ranker --> Loans
    Ranker --> Insurance
```



### Phased Approach

**Phase 1 (Launch)**: Simple rules-based recommendations + financial profile foundation. User filed taxes -> we already know: income, filing status, dependents, refund amount, state. User formed LLC -> we know: entity type, state, industry. Show HYSA options for refund routing, business banking for LLC owners. Self-serve affiliate links. **Start collecting the financial profile from day one** -- every interaction adds data points.

**Phase 1.5 (Launch + 3 months)**: Add opt-in soft credit pull during onboarding. "Want personalized financial recommendations? Let us check your credit score -- it won't affect your score." Soft pull via TransUnion reseller (Array or SavvyMoney, ~$0.50-2.00/pull). Display score + range + what it means in plain English. This is subtle but transformative: now we have income (from tax return) + credit score + debt profile = a financial identity richer than what most fintech partners see from their own customers. **This is the data moat. Start building it before competitors realize you have it.**

**Phase 2 (Year 2, 10K+ users)**: Experimentation platform + churn intelligence. A/B test recommendation placements, partner ordering, messaging. Deploy retention models. Credit card and loan recommendations matched to score bands. Performance-based partner billing.

**Phase 3 (Year 3+)**: Full financial profile matching. Tax data + LLC data + credit score + spending patterns (if user links bank via Plaid) = personalized "Fit Scores" for each partner product. ML-ranked recommendations. The data compounds: 2nd tax season users have 2 years of income trajectory, credit score delta, and behavioral signals.

### Why Early Credit Score Is the Moat (Not Just a Feature)

Credit Karma's moat wasn't the credit score itself -- Intuit, NerdWallet, and every bank now offer free scores. CK's moat was **2,500 data points per user** accumulated over time. We have a unique advantage CK never had: **we see the user's actual tax return**. That's the most complete financial snapshot that exists.

**What FileFree knows that CK doesn't from a single filing:**

- Exact income (not self-reported range -- actual W-2 Box 1)
- Filing status (single, married, HOH -- tells us household composition)
- Dependents (family size, child ages)
- Refund/owed amount (disposable income signal)
- State of residence (cost of living context)
- Employer (stability signal)

**Add credit score to that and we have:**

- Income + creditworthiness = approval odds for any financial product
- Refund amount + credit score = right HYSA vs right credit card recommendation
- Business owner (LaunchFree) + credit score = business credit card, business loan eligibility

**Partners will pay a premium** to reach users we can describe as "W-2 income $75K, credit score 720+, $3,200 refund, single, CA resident, 28 years old." That's not a lead -- that's a pre-qualified customer. CK charges $25-1,250 per referral because they can do exactly this. We can too.

### Experimentation Platform (Our "Darwin")

Credit Karma's Darwin runs 22,000 models monthly and makes 60 billion predictions daily. We don't need that scale. We need a lightweight experimentation framework that grows with us.

**Phase 1 -- Feature Flags + Simple A/B (Launch)**:

- PostHog feature flags (already in stack, free tier: 1M events/mo)
- A/B test: recommendation card placement, partner ordering, CTA copy
- Track: click-through rate, conversion rate, revenue per impression
- No ML needed. Just measure which recommendation layout converts better.

**Phase 2 -- Multi-Armed Bandit (Year 2, 10K+ users)**:

- Replace static A/B tests with Thompson Sampling bandit for partner ranking
- Automatically allocate more traffic to higher-converting partners
- Personalized ranking: different users see different partner orders based on their profile
- Implementation: Python (scipy.stats.beta) in the recommendation API, ~200 lines of code

**Phase 3 -- ML Recommendation Models (Year 3+, 50K+ users)**:

- Train collaborative filtering model on user-partner interaction data
- Input: financial profile (income, credit score, state, age, filing status) + behavioral signals (clicks, time on page, past conversions)
- Output: ranked partner list with predicted conversion probability
- Infrastructure: o4-mini for feature engineering, train on Neon DB data, serve via FastAPI
- This is where we catch CK's playbook at a fraction of the scale

**FTC compliance note**: CK got fined for A/B testing "pre-approved" language that was misleading. Our experimentation must NEVER test language that implies guaranteed approval. Always use "may qualify" or "based on your profile." Build this constraint into the experimentation framework.

### Retention Intelligence (Churn + Lifecycle)

**The problem**: Tax filing is seasonal (Jan-Apr). LLC formation is one-time. Without retention, we lose users after the transaction. The intelligence engine must keep users engaged year-round.

**Data signals for churn prediction:**

- Days since last login
- Did they file last season? (repeat vs one-time)
- Did they engage with recommendations? (click, convert, ignore)
- Did they opt out of emails?
- Credit score change (if tracked -- score drops = financial stress = re-engagement opportunity)

**Retention campaigns (n8n + packages/email):**


| Trigger                                | Campaign                                                   | Channel        | Timing                |
| -------------------------------------- | ---------------------------------------------------------- | -------------- | --------------------- |
| Filed taxes, no refund action          | "Your $X refund is coming -- here's where to put it"       | Email + in-app | 3 days post-filing    |
| Filed taxes, 6 months no return        | "Your tax profile is getting smarter" (mid-year check-in)  | Email          | July                  |
| Formed LLC, no banking setup           | "Your LLC needs a bank account"                            | Email + push   | 7 days post-formation |
| Credit score dropped >20 pts           | "Your credit score changed -- here's what to know"         | Email + in-app | Within 48 hours       |
| Tax season approaching, returning user | "Your W-2 info is pre-filled from last year"               | Email + push   | January               |
| Annual report deadline approaching     | "Your [state] annual report is due in X days"              | Email + push   | 30 days before        |
| No login for 90 days                   | "We've been watching your financial profile" (value recap) | Email          | At 90 days            |


**Churn prediction model (Phase 2+):**

- Use ChurnGuard AI (open-source, connects PostHog + Stripe, 15-min setup) for MVP
- Features: login frequency, recommendation engagement, email open rate, conversion history
- Output: risk score (Critical/High/Medium/Low) per user
- Critical risk users get personalized re-engagement (AI-drafted, founder-approved email)
- Reducing churn by 10% at 10K users = significant retained revenue

**Push notifications (Phase 2+):**

- Web push via service worker (no app store needed)
- Only for high-value triggers: credit score change, tax season reminder, deadline alert
- Opt-in only, max 2/week, always actionable

### Credit Score Integration Research

- **Soft pull vs hard pull**: We only ever do SOFT pulls. Never affects user's score. Users must understand this.
- **TransUnion reseller** (Array, SavvyMoney): Easiest path for startups. $0.50-2.00 per pull. No direct bureau contract needed. Array provides embeddable credit score widget.
- **Plaid LendScore**: Cash-flow based scoring (not traditional credit score). Trained on ~1B transactions, 25% better predictive performance than traditional scores. Good for users with thin credit files.
- **CRS Credit API**: Unified three-bureau monitoring. Overkill for Phase 1 but ideal for Phase 3.
- **FCRA compliance**: Required when displaying credit scores. Disclosures, dispute process, adverse action notices. Attorney consultation needed before implementing. Budget: $500-1,000 for FCRA compliance review.
- **Timeline**: Phase 1.5 (3 months post-launch). The soft pull integration is straightforward (~1 week of engineering). The FCRA compliance review is the bottleneck.

### Partnership Intelligence Agent

Add a new agent: **Partnership Intelligence** (n8n workflow, weekly cron + Cursor persona for strategic analysis). This agent:

1. Scans affiliate networks (Impact.com, CJ Affiliate, ShareASale, Partnerize) for new fintech programs
2. Compares commission rates across similar partners (e.g., all HYSA affiliates)
3. Monitors our existing affiliate performance (clicks, conversions, revenue per partner)
4. Tracks partner program changes (rate changes, new terms, program closures)
5. Generates a weekly "Partnership Opportunities" report to Slack `#partnerships`
6. Flags when a competitor launches a new partnership we should evaluate
7. For each potential partner, generates a compatibility score based on our user profile data

This agent supports Olga but also works fully autonomously when she's not available. It actively seeks better deals -- if Betterment pays $25/referral and SoFi pays $50 for equivalent products, the agent flags this and recommends shifting traffic.

### Package Rename + Structure

Rename `packages/cross-sell/` to `packages/intelligence/` in the monorepo structure. Update all references. This package contains:

- **Profile builder**: Aggregates user data from FileFree + LaunchFree + credit score into a unified financial profile
- **Partner matcher**: Rules engine (Phase 1) -> bandit (Phase 2) -> ML model (Phase 3). User profile -> eligible partners -> ranked recommendations
- **Experimentation**: Feature flag integration (PostHog), A/B test tracking, bandit allocation
- **Retention engine**: Churn signals, lifecycle campaign triggers, re-engagement logic
- **Campaign triggers**: Milestone-based ("you just filed -> here's what to do with your refund")

### Partner Dashboard (Phase 2+, paperworklabs.com/admin/partners)

Show partners their performance data:

- Referral volume, conversion rate, revenue generated
- User demographics (anonymized: age range, income bracket, state)
- This makes us valuable to partners and increases retention

---

## 3. Autonomous Engineering Agents

The user is right -- no agent is currently assigned to write production code for FileFree or LaunchFree. All engineering work happens in interactive Cursor sessions. The plan should specify how AI agents can write code autonomously in the background.

### What's Feasible Now (2026)

- **Cursor Background Agents** (already available): Can run multi-file tasks, create PRs, run tests. Ideal for well-scoped tasks with clear specs.
- **Pattern**: Human writes the first implementation (e.g., first state tax module). Agent replicates the pattern for remaining 49 states. Human reviews PR.

### What to Add to the Plan

**Autonomous Engineering Tasks** (suitable for background agents):


| Task                                                   | Agent Model   | Input                                                 | Output                                 | Human Review |
| ------------------------------------------------------ | ------------- | ----------------------------------------------------- | -------------------------------------- | ------------ |
| State tax JSON configs (Tier 1 conforming, ~30 states) | Claude Sonnet | Template from first state + state tax docs            | `packages/data/tax/{state}.json`       | PR review    |
| State formation JSON (50 states)                       | Claude Sonnet | Template + SOS website data                           | `packages/data/formation/{state}.json` | PR review    |
| Shared UI components from designs                      | Claude Sonnet | Figma specs or component descriptions                 | `packages/ui/components/*.tsx`         | PR review    |
| Test suites for tax calculations                       | Claude Sonnet | Tax calc implementation + IRS Publication 17 examples | `packages/data/__tests__/*.test.ts`    | PR review    |
| MeF XML schema -> Zod types                            | Claude Sonnet | Downloaded IRS XML schemas                            | `packages/data/mef/schemas/*.ts`       | PR review    |
| API endpoint scaffolding                               | Claude Sonnet | OpenAPI spec or route descriptions                    | `apis/*/routes/*.py`                   | PR review    |


**Key principle**: Agent writes code, creates PR. Human reviews and merges. Never auto-merge production code. The agent IS the engineering team; the founder IS the tech lead who reviews.

Add this as Section 6K in the master plan: "Autonomous Engineering Protocol."

---

## 4. Package Rename: cross-sell -> intelligence

Simple rename in the monorepo structure section. `packages/cross-sell/` becomes `packages/intelligence/`. Update all references throughout the plan (Phase 5 todo, architecture section, etc.).

---

## 5. Workspace Scoping (Simplify)

The user doesn't want to manually open different workspaces. The current recommendation ("Open `apps/launchfree/` as workspace root") is optional guidance, not a requirement. The default workflow is: **open the repo root, see everything in the sidebar, work on whatever you need.** Cursor handles context well with `.cursor/rules/` glob patterns.

Update the "Cursor Workspace Scoping" section to make this clear: root workspace is the default, focused workspaces are optional for deep-focus sessions.

---

## 6. Agent Availability

All Cursor personas should use `alwaysApply: true` or broad enough glob patterns to be available in any context. The user shouldn't have to switch workspaces to access an agent. The three-tier model (venture-level `alwaysApply`, product-level globs, n8n autonomous) is correct -- just ensure venture-level personas are always on.

For n8n agents, they're already available everywhere (they run on Hetzner, triggered by webhooks or cron). The Slack integration (Section 14) makes them accessible from anywhere. No change needed here.

---

## 7. Self-Review Section (Section 9) Cleanup

Section 9 "McKinsey Self-Review" is now historical -- all findings have been addressed and implemented. Per the anti-bloat rules (Section 8), this should be **collapsed to a summary line** rather than carrying 200+ lines of resolved findings. Keep the findings table (F1-F12 summary) but collapse the detailed research under each finding.

---

## Summary of Changes


| #   | Change                             | Section                                                              | Impact                                                                                        |
| --- | ---------------------------------- | -------------------------------------------------------------------- | --------------------------------------------------------------------------------------------- |
| 1   | Add PII Data Lifecycle             | New Section 0I                                                       | Consolidates scattered privacy requirements                                                   |
| 2   | Recommendation Intelligence Engine | New Section 5B + rename packages/cross-sell -> packages/intelligence | Credit Karma-style matching, credit score integration roadmap, Partnership Intelligence agent |
| 3   | Autonomous Engineering Protocol    | New Section 6K                                                       | Defines what agents can build autonomously, PR-based review flow                              |
| 4   | Package rename                     | Section 2 architecture                                               | cross-sell -> intelligence                                                                    |
| 5   | Workspace scoping                  | Section 2                                                            | Simplify: root is default, focused is optional                                                |
| 6   | Agent availability                 | Section 6B                                                           | Confirm alwaysApply for venture-level personas                                                |
| 7   | Self-review collapse               | Section 9                                                            | Collapse resolved findings to summary table                                                   |


