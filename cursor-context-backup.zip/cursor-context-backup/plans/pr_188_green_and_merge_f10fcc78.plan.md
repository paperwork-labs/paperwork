---
name: PR 188 Green and Merge
overview: "Fix the remaining CI failures on PR #188, clean up legacy MVP strategy code, and merge Section 1. Then outline the gameplan for Sections 2 and 3."
todos:
  - id: fix-flaky-test
    content: Mock get_fundamentals_info in test_compute_snapshot_from_db_derives_previous_stage_from_history_labels to prevent Yahoo Finance 429 timeouts in CI
    status: completed
  - id: remove-strategy-services
    content: Delete strategy_manager.py, dca_service.py, atr_calculator.py, atr_signal_generator.py, daily_atr_signals.py
    status: completed
  - id: gut-strategies-route
    content: Replace strategies.py endpoints with a single placeholder GET; remove dead imports
    status: completed
  - id: update-strategy-tests
    content: Remove/skip test_services.py TestSignalGenerationService and test_database_api.py ATR tests
    status: completed
  - id: update-frontend-placeholders
    content: Update Strategies.tsx and StrategiesManager.tsx placeholder text to reference rules engine
    status: completed
  - id: validate-and-push
    content: Run backend + frontend tests locally, push, verify CI green
    status: completed
  - id: merge-pr-188
    content: "Merge PR #188 after CI is green"
    status: in_progress
isProject: false
---

# PR #188: Get Green, Clean Up, Merge + Sections 2-3 Gameplan

## Current State

**PR #188** (`feature/next`): "feat(section-1): foundation polish"

- Frontend CI: **PASS** (lint fix pushed)
- Backend CI: **FAIL** -- one flaky test hitting Yahoo Finance rate limits (429 timeout), pre-existing, not caused by PR
- Section 1 blueprint completion: **~95%** (all checkpoints substantially done)

**What remains before merge:**

1. Fix the flaky backend test
2. Clean up legacy strategy MVP code (per user direction -- rules engine replaces ATR/DCA)

---

## Part 1: Fix Flaky Backend Test

**File:** [backend/tests/test_market_data_backfill_service.py](backend/tests/test_market_data_backfill_service.py) line 213

**Problem:** `test_compute_snapshot_from_db_derives_previous_stage_from_history_labels` mocks `compute_weinstein_stage_from_daily` (line 243-247) but does NOT mock `get_fundamentals_info`. So `compute_snapshot_from_db` (line 249) makes real HTTP calls to Yahoo Finance (`yf.Ticker(symbol).info`), gets 429 rate-limited, retries with backoff, and hits the 15s pytest-timeout.

**Fix:** In `backend/tests/test_market_data_backfill_service.py`, at line 243 (BEFORE the existing `monkeypatch.setattr` for `compute_weinstein_stage_from_daily`), insert this additional monkeypatch:

```python
monkeypatch.setattr(
    market_data_service, "get_fundamentals_info",
    lambda *a, **kw: {"sector": "Test", "industry": "Test"}
)
```

The `market_data_service` object is already imported at line 4: `from backend.services.market.market_data_service import market_data_service`. This mock goes on the **instance** (not the module), same as how `compute_weinstein_stage_from_daily` is mocked on `mds_module`.

**Exact edit** -- find this block starting at line 243:

```python
    monkeypatch.setattr(
        mds_module,
        "compute_weinstein_stage_from_daily",
        lambda *_args, **_kwargs: {"stage_label": "2A", "stage_slope_pct": 1.1, "stage_dist_pct": 0.9, "rs_mansfield_pct": 0.4},
    )
```

Insert ABOVE it (new lines 243-246):

```python
    monkeypatch.setattr(
        market_data_service, "get_fundamentals_info",
        lambda *a, **kw: {"sector": "Test", "industry": "Test"},
    )
```

So the result is two monkeypatches in a row, then `snap = market_data_service.compute_snapshot_from_db(...)`.

**Validation:** Run `cd /Users/sankalpsharma/development/axiomfolio && make test` -- the `test_compute_snapshot_from_db_derives_previous_stage_from_history_labels` test should now pass without hitting Yahoo Finance.

---

## Part 2: Strategy MVP Cleanup

The old ATR Matrix / DCA strategy code was MVP scaffolding. The architecture's "brain" (Market Data Pipeline -> Indicators -> MarketSnapshot) already computes all the signals (stages, RS Mansfield, TD Sequential, etc). Strategies should be **user-defined composable rules** that react to those computed indicators (Section 2 RuleEvaluator), not hardcoded services.

### Step 2A: Delete these 5 files

Use `git rm` for each:

1. `git rm backend/services/strategies/strategy_manager.py` (582 lines -- MVP ATR/DCA orchestrator)
2. `git rm backend/services/strategies/dca_service.py` (525 lines -- MVP DCA logic)
3. `git rm backend/services/analysis/atr_calculator.py` (43 lines -- thin adapter, only used by deleted files)
4. `git rm backend/services/signals/atr_signal_generator.py` (~700 lines -- ATR signal generation)
5. `git rm backend/tasks/archive/daily_atr_signals.py` (archived ATR Celery task)

Also remove their `__pycache__` dirs if present:

- `rm -rf backend/services/strategies/__pycache__`
- `rm -rf backend/services/signals/__pycache__`

### Step 2B: Replace strategies.py routes with placeholder

**File:** [backend/api/routes/strategies.py](backend/api/routes/strategies.py)

Replace the ENTIRE file contents with this minimal placeholder:

```python
"""
Strategies API -- placeholder.

The composable rules engine (Section 2) will replace the old ATR/DCA strategy
services.  This router is kept so the mount in main.py stays valid.
"""

from fastapi import APIRouter, Depends
from backend.api.dependencies import get_current_user
from backend.models.user import User

router = APIRouter()


@router.get("/status")
async def strategies_status(user: User = Depends(get_current_user)):
    return {
        "status": "coming_soon",
        "message": "Strategy engine is being rebuilt with the composable rules system.",
    }
```

This removes all imports of `strategy_manager`, `StrategyManager`, `StrategyRequest`, `atr_calculator`, etc. The `router` object is kept so `main.py` line 398 (`app.include_router(strategies.router, ...)`) doesn't break.

**DO NOT touch [backend/api/main.py](backend/api/main.py) line 398** -- the `strategies.router` registration stays.

### Step 2C: Files to keep (DO NOT delete)

- `backend/models/strategy.py` -- Strategy, StrategyRun, StrategyExecution models (generic, reused in Section 2)
- `backend/models/signals.py` -- Signal model (generic, `atr_distance` field left as nullable for now -- no Alembic migration needed)
- `backend/services/analysis/atr_engine.py` -- Independent ATR calc engine, used by market data pipeline. NOT strategy-specific. Keep as-is.
- `backend/models/user.py` -- `strategies` and `strategy_executions` relationships must stay (FK integrity)

### Step 2D: Update tests

**File: [backend/tests/test_services.py](backend/tests/test_services.py)**

Delete the entire `TestSignalGenerationService` class (lines 283-322). This class has two methods that import `atr_signal_generator` which no longer exists:

- `test_signal_generator_import` (lines 287-300)
- `test_portfolio_signal_generation` (lines 302-322)

Find this exact block and delete it entirely:

```python
class TestSignalGenerationService:
    """Test signal generation service functionality."""

    @pytest.mark.asyncio
    async def test_signal_generator_import(self):
        ...  (through line 322)
```

The next class `TestDatabaseServices` (line 325) stays.

NOTE: The `TestServiceIntegration` class (line 341) has `test_atr_to_discord_integration` and `test_market_data_to_atr_integration` -- these import `atr_engine` (which we are KEEPING), NOT `atr_signal_generator`. So these tests are fine and should NOT be deleted.

**File: [backend/tests/test_database_api.py](backend/tests/test_database_api.py)**

1. In class `TestDatabaseOperations`, delete the method `test_atr_signals_table` (lines 38-70). It's a placeholder that just `assert True` but references ATR signals conceptually.
2. In class `TestSystemIntegration` (line 234), delete these two methods:
  - `test_end_to_end_atr_signal_generation` (lines 238-253) -- placeholder referencing ATR signal flow
  - `test_portfolio_integration_with_atr` (lines 255-270) -- placeholder referencing ATR integration
3. Delete the fixture `sample_atr_signals` (lines 286-304).
4. In the `run_database_tests` function (line 308), remove the line:

```python
   test_db.test_atr_signals_table()
   

```

1. In the `run_integration_tests` function (line 334), remove these two lines:

```python
   await test_integration.test_end_to_end_atr_signal_generation()
   await test_integration.test_portfolio_integration_with_atr()
   

```

### Step 2E: Update frontend placeholders

**File: [frontend/src/pages/Strategies.tsx](frontend/src/pages/Strategies.tsx)**

Change line 14 from:

```tsx
<Badge colorPalette="yellow">Under migration</Badge>
```

to:

```tsx
<Badge colorPalette="blue">Coming Soon</Badge>
```

Change lines 15-17 from:

```tsx
<Text color="fg.muted">
  This page is being migrated to Chakra v3 and will return with the shared table/filters system.
</Text>
```

to:

```tsx
<Text color="fg.muted">
  The strategy engine is being rebuilt with a composable rules system. Define entry, exit, and trim rules using computed market indicators.
</Text>
```

**File: [frontend/src/pages/StrategiesManager.tsx](frontend/src/pages/StrategiesManager.tsx)**

Same pattern -- change the Badge to `<Badge colorPalette="blue">Coming Soon</Badge>` and the Text to:

```tsx
<Text color="fg.muted">
  The strategy builder will let you compose rules from market indicators like Weinstein stage, RS Mansfield, TD Sequential, and more.
</Text>
```

**DO NOT touch [frontend/src/App.tsx](frontend/src/App.tsx)** -- routes on lines 86-89 stay.

---

## Part 3: Validate and Merge

Run these commands in order. All must pass before pushing.

1. **Backend tests:** `cd /Users/sankalpsharma/development/axiomfolio && make test`
  - Expected: All tests pass. The deleted test classes and methods should no longer appear. The flaky Yahoo Finance test should pass because of the new mock.
  - If any test fails due to import of deleted modules (strategy_manager, dca_service, atr_calculator, atr_signal_generator), grep for the import and remove it.
2. **Frontend typecheck:** `cd /Users/sankalpsharma/development/axiomfolio/frontend && npx tsc --noEmit`
  - Expected: Clean exit (0 errors). The placeholder pages have no new type issues.
3. **Frontend tests:** `cd /Users/sankalpsharma/development/axiomfolio/frontend && npm test -- --run`
  - Expected: All tests pass.
4. **Commit and push:**

```bash
   cd /Users/sankalpsharma/development/axiomfolio
   git add -A
   git commit -m "chore: remove legacy ATR/DCA strategy services; fix flaky Yahoo Finance test

   - Delete strategy_manager.py, dca_service.py, atr_calculator.py,
     atr_signal_generator.py, daily_atr_signals.py
   - Replace strategies.py routes with placeholder for rules engine
   - Remove ATR-specific test classes and fixtures
   - Mock get_fundamentals_info in snapshot test to prevent 429 timeouts
   - Keep strategy/signal models and atr_engine.py (reused in Section 2)"
   git push origin feature/next
   

```

1. **Wait for CI to go green on PR #188**, then merge via `gh pr merge 188 --squash`

---

## Part 4: Sections 2-3 Gameplan (post-merge)

After merging Section 1, the architecture looks like this:

```mermaid
flowchart TB
  subgraph done [Section 1 - DONE]
    BrokerSync["Broker Sync + Auto-sync"]
    Positions["Positions + Enriched Data"]
    MarketPipeline["Market Data Pipeline"]
    Indicators["Indicator Engine"]
    Snapshots["MarketSnapshot"]
    Portfolio["Portfolio UI"]
    MarketPipeline --> Indicators --> Snapshots
    BrokerSync --> Positions
    Snapshots -.->|"LEFT JOIN"| Positions
    Positions --> Portfolio
  end

  subgraph section2 [Section 2 - NEXT]
    CategoryEngine["Category Engine + Rules"]
    RuleEvaluator["Composable Rule Evaluator"]
    OrderModel["Order Model"]
    PaperExec["Paper Executor"]
    CategoriesUI["Categories Redesign"]
    StrategyUI["Strategy Builder UI"]
    Snapshots -->|"indicators feed rules"| RuleEvaluator
    Positions -->|"allocation data"| CategoryEngine
    RuleEvaluator -->|"signals"| OrderModel
    OrderModel --> PaperExec
  end

  subgraph section3 [Section 3 - FUTURE]
    BrokerExec["Broker Order APIs"]
    Safety["Circuit Breakers + Kill Switch"]
    PaperExec -.->|"promote"| BrokerExec
  end
```



### Section 2 priorities (in order)

1. **CategoryRule model + Alembic migration + CategoryEngine service** -- auto-categorize positions by sector/market-cap/stage, compute drift, generate rebalance previews
2. **RuleEvaluator service** -- composable JSON condition trees that consume MarketSnapshot fields (stage_label, rs_mansfield_pct, rsi, td_buy_setup, etc). This IS the strategy engine. No hardcoded strategies.
3. **Enum migrations** -- add PAPER_TRADING/BACKTESTING to StrategyStatus, TRIM/REBALANCE/ROTATE to SignalType
4. **Order model + OrderEngine + PaperExecutor** -- order lifecycle, risk gate, simulated fills
5. **Frontend** -- Categories redesign (concentric rings, auto-organize, drift alerts), StrategyList + StrategyBuilder pages

### Section 3 (after Section 2 is stable)

1. IBKR + TastyTrade order API integration
2. Safety infrastructure (circuit breakers, kill switch, daily P&L halt)
3. Paper-to-live promotion flow
4. StrategyDetail + StrategyBacktest pages

