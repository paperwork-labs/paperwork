---
name: Make coverage whole
overview: Fix the stale-daily backfill and coverage computation so Restore Daily Coverage reliably drives Daily coverage to green for the full tracked universe (not just a sampled subset), and make cached coverage consistent with the live endpoint.
todos:
  - id: freshness-helper
    content: Create shared helper to compute daily freshness buckets + full stale/missing list for a provided symbol universe; reuse across endpoints/tasks
    status: completed
  - id: stale-backfill-task
    content: Implement async Celery task backfill_stale_daily_tracked and wire POST /admin/coverage/backfill-stale-daily to enqueue it (no sampling)
    status: completed
    dependencies:
      - freshness-helper
  - id: monitor-consistency
    content: Update monitor_coverage_health to compute tracked-universe freshness incl. missing symbols, consistent with GET /market-data/coverage
    status: completed
    dependencies:
      - freshness-helper
  - id: ui-polish
    content: Adjust AdminDashboard UX for stale-only backfill response (queued + counts) while keeping minimal guided UI
    status: completed
    dependencies:
      - stale-backfill-task
  - id: tests
    content: Add/update backend tests for full stale backfill and monitor_coverage_health correctness; update frontend tests if response contract changes
    status: completed
    dependencies:
      - stale-backfill-task
      - monitor-consistency
---

# Make Daily Coverage Green (end-to-end)

## Why it’s not reaching green (root cause)

- The current **stale-only backfill** path uses `MarketDataService.coverage_snapshot()` which returns a **sampled** stale list capped by `COVERAGE_STALE_SAMPLE` (default 50). The endpoint then backfills only that sample:
- `backfill_stale_daily` reads `snap['daily']['stale'] `(sample) and calls `backfill_symbols(stale)`.
- Result: if you have >50 stale/missing symbols, you will remain degraded even after “stale-only”.

## Goals

- **Backfill all stale + missing daily bars for the tracked universe** (not a 50-symbol sample).
- Make **cached coverage** (`monitor_coverage_health` / Redis) compute the same way as `GET /market-data/coverage` so UI doesn’t lie.
- Keep operator UX clean: the only daily operator actions remain:
- Restore Daily Coverage (Tracked)
- Backfill Daily (Stale Only)
- Refresh Coverage Cache

## Implementation

### 1) Centralize “tracked daily freshness” computation (DRY)

- Add a shared helper (in [`backend/services/market/market_data_service.py`](/Users/sankalpsharma/development/quantmatrix/backend/services/market/market_data_service.py) or a small module) that, given `symbols`, returns:
- per-symbol last bar
- freshness buckets
- **full** stale/missing symbol list
- a sampled list for UI
- Reuse this helper from:
- `GET /api/v1/market-data/coverage` recompute path
- `monitor_coverage_health`
- the stale-only backfill task (below)

### 2) Fix stale-only backfill to backfill ALL stale/missing (and run async)

- Replace the current request-thread implementation in [`backend/api/routes/market_data.py`](/Users/sankalpsharma/development/quantmatrix/backend/api/routes/market_data.py):
- Stop calling `svc.coverage_snapshot()` for stale candidates.
- Stop directly calling `backfill_symbols(...)` in the request.
- Add a new Celery task in [`backend/tasks/market_data_tasks.py`](/Users/sankalpsharma/development/quantmatrix/backend/tasks/market_data_tasks.py):
- `backfill_stale_daily_tracked()`:
    - determine tracked universe
    - compute **full** stale+missing list (48h/none)
    - call `backfill_symbols(stale_symbols)`
    - trigger `monitor_coverage_health()` at end
- Update the endpoint `POST /admin/coverage/backfill-stale-daily` to `_enqueue_task(backfill_stale_daily_tracked)`.

### 3) Make `monitor_coverage_health` consistent with tracked universe + missing symbols

- Update `monitor_coverage_health()` to:
- compute freshness/buckets for the **tracked universe**
- include **missing** symbols (no `price_data`) in `none`
- set `status.stale_daily` based on full counts, and store a sampled stale list for UI.

### 4) Frontend: keep labels, improve transparency

- [`frontend/src/pages/AdminDashboard.tsx`](/Users/sankalpsharma/development/quantmatrix/frontend/src/pages/AdminDashboard.tsx):
- Keep the button label “Backfill Daily (Stale Only)” but ensure it triggers the async task (same endpoint) and shows “queued” + the count returned by the enqueue response (if present).
- [`frontend/src/pages/AdminRunbook.tsx`](/Users/sankalpsharma/development/quantmatrix/frontend/src/pages/AdminRunbook.tsx) stays as transparency-only for steps.

### 5) Tests

- Add/update backend tests to prove:
- stale-only backfill uses **all** stale/missing, not sample-capped
- `monitor_coverage_health` counts missing correctly for tracked universe
- Update any frontend tests expecting old response shapes if needed.