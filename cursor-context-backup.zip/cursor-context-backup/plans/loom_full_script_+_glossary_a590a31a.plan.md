---
name: Loom Full Script + Glossary
overview: Replace the current bullet-point talking points with a full read-along Loom video script (complete sentences Olga can read verbatim), with action/pause prompts throughout, and a glossary of all OpenAI products at the bottom. Align to the final HTML edits she made.
todos:
  - id: write-script
    content: Write the full Loom video script with action prompts, aligned to final HTML edits
    status: completed
  - id: write-glossary
    content: Write the OpenAI product glossary and prep notes section at the bottom of the document
    status: completed
isProject: false
---

# Loom Full Script + Glossary

## What changes

Replace the current [loom-talking-points.md](loom-talking-points.md) with a comprehensive document containing:

1. **Full read-along script** (~1,100 words of spoken content for ~8 minutes at natural pace)
2. **Action prompts** throughout: `[SCROLL TO ...]`, `[PAUSE]`, `[POINT TO ...]`
3. **OpenAI Product Glossary** at the bottom with every product explained in plain language
4. **Quick Prep Notes** for things she should know cold if asked follow-up questions

## Script structure (aligned to final HTML)

The script follows the same 6-section structure but as full paragraphs she reads verbatim, not bullet points:

- **Section 1 (0:00-1:00)**: Why Discord, Meta insider angle. Opens the PDF on screen.
- **Section 2 (1:00-2:30)**: The problem. Adds the "4,000 unread messages" color. Voice angle.
- **Section 3 (2:30-5:00)**: Four capabilities walked through one by one. Longer spoken explanations than the PDF, with real examples.
- **Section 4 (5:00-6:30)**: Technical reasoning. "Models suggest, system executes." Names all 7 products.
- **Section 5 (6:30-7:30)**: Risks. Honest assessment, 2-3 called out.
- **Section 6 (7:30-8:30)**: Close. Consumption model, enthusiasm for the role.

## HTML edits she made (script must reflect these)

Three changes from her side:

- Line 245: "I led the **strategic** platform partnership **with Discord** at Meta Reality Labs" (added specificity)
- Line 249: "AI is the **key**" (was "unlock")
- Line 293: "**structured outputs**" lowercase (was "Structured Outputs")

## OpenAI Product Glossary (bottom of doc)

All 7 products verified as real and current against OpenAI's live documentation:

- **GPT-4o**: Flagship multimodal model. Text, image, audio input. Best for complex analysis, summarization, synthesis.
- **GPT-4o mini**: Smaller, cheaper model. Same capabilities but optimized for high-volume, lower-complexity tasks. Ideal for classification, filtering, routine summaries.
- **Whisper / Audio API**: Speech-to-text transcription. The `whisper-1` model plus newer `gpt-4o-transcribe` variants. Supports 50+ languages, file uploads up to 25MB. Recently added speaker diarization.
- **Realtime API**: Low-latency speech-to-speech. Supports WebRTC (browser), WebSocket (server), and SIP (telephony). Enables live voice agents, captioning, translation.
- **Embeddings API**: Converts text into numerical vectors for semantic search. Models: `text-embedding-3-small` and `text-embedding-3-large`. Powers RAG (retrieval-augmented generation).
- **Moderation API**: Free content moderation endpoint. Classifies text for hate, violence, self-harm, sexual content, etc. Returns category scores.
- **Fine-tuning API**: Customize GPT-4o or GPT-4o mini on your own data. Training costs ~$25/M tokens. Can achieve strong results with dozens of examples.
- **Structured Outputs**: Feature (not a separate product) that guarantees model responses match a predefined JSON schema. 100% schema compliance. Available on GPT-4o and GPT-4o mini.

## Additional prep section topics

- What RAG means (in 2 sentences, in case they ask)
- What "consumption revenue" means (usage-based pricing, the metric this role is measured on)
- Discord's current AI efforts (they deprecated Clyde, launched AutoMod AI, exploring AI features)
- Why she picked Discord vs. other digital-native companies (Shopify, Stripe, Roblox)
- Her unique angle: the Meta Reality Labs partnership with Discord

## Delivery

Single file: overwrite [loom-talking-points.md](loom-talking-points.md) with the full script + glossary. Clean markdown that pastes into Google Docs easily.