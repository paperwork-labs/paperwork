---
name: Partner Marketplace Roadmap
overview: Add Section 4O Financial Marketplace Platform (4-stage roadmap) + strategic-from-day-1 upgrades to data model, recommendation engine, event taxonomy, consent architecture, and partnership strategy across VENTURE_MASTER_PLAN.md, PARTNERSHIPS.md, KNOWLEDGE.md, and FINANCIALS.md.
todos:
  - id: section-4o
    content: "Add Section 4O: Financial Marketplace Platform (4-stage roadmap with volume gates, competitive moat analysis, FTC constraints) to VENTURE_MASTER_PLAN.md after Section 4N"
    status: completed
  - id: data-model-upgrade
    content: Upgrade Section 4B data model with marketplace-ready partner tables (partner_products, partner_eligibility, fit_scores, partner_bids) designed for Stage 4 from day 1
    status: completed
  - id: rec-engine-upgrade
    content: Upgrade Section 4E recommendation engine to pluggable scorer architecture (rules -> bandit -> ML) with Fit Score interface designed from day 1
    status: completed
  - id: event-taxonomy-upgrade
    content: Add MARKETPLACE EVENTS block to Section 4C event taxonomy (partner_product_viewed, fit_score_computed, match_confidence_displayed, partner_bid_placed)
    status: completed
  - id: consent-upgrade
    content: Upgrade consent architecture in Sections 0I and 4H to marketplace-grade framing that covers all 4 stages without re-consent
    status: completed
  - id: partner-dashboard-upgrade
    content: Upgrade Section 4N from simple metrics page to marketplace portal seed with Stage 2-4 evolution path
    status: completed
  - id: partnerships-md-overhaul
    content: "Overhaul PARTNERSHIPS.md: align tiering with marketplace stages, add strategic partner scoring matrix, add Stage 2/3/4 outreach templates, add data reciprocity strategy"
    status: completed
  - id: valuation-update
    content: Rewrite Section 0D valuation scenarios with marketplace-stage ARPU math, per-user value benchmarks, and CK comparison
    status: completed
  - id: knowledge-decisions
    content: Add D65 (Financial Marketplace Platform) and D66 (Strategic-from-Day-1 Architecture) to KNOWLEDGE.md
    status: completed
  - id: financials-projections
    content: Update FINANCIALS.md with Year 2-5 revenue projections reflecting marketplace ARPU evolution
    status: completed
isProject: false
---

# Partner Marketplace Roadmap + Strategic-from-Day-1 Upgrades

## Context

Credit Karma's Lightbox is a bidirectional partner marketplace where lenders upload underwriting models, CK matches them against 140M user profiles, and users see products with ~90% approval odds. Lenders pay CPA ($25-1,250/approval). CK's ARPU: ~$11.43 ($1.6B / 140M users). Intuit paid $8.1B = 7.1x revenue.

FileFree's per-user data is **deeper** than CK's was at the same scale (actual W-2 income vs. self-reported, tax filing data CK never had). The path from affiliate links to a full marketplace is a 4-stage evolution gated by user volume thresholds.

**Critical design principle**: Several foundational components (data model, recommendation engine, event taxonomy, consent architecture, partnership strategy) are currently designed for Stage 1 only. Refactoring these under load with live users is expensive and risky. We design for Stage 4 from day 1, even though Stage 1 only fills in basic fields. The schema, APIs, and consent language must support the full marketplace evolution without breaking changes.

## What Gets Added / Changed

### 1. New Section 4O: Financial Marketplace Platform (The Long Game)

**Insert after**: Section 4N in [VENTURE_MASTER_PLAN.md](docs/VENTURE_MASTER_PLAN.md) (~line 2013, before `---` and Section 5).

A 4-stage roadmap with clear user-volume gates:

**Stage 1 -- Affiliate Links (0-5K users, Year 1)**: Self-serve affiliate programs. Static partner links. Rules-based recommendation engine. Revenue: flat CPA $25-100. ARPU: $3-7. **What we're building**: the user profile data asset.

**Stage 2 -- Smart Matching (5K-25K users, Year 2)**: Thompson Sampling bandit replaces static ordering. **Fit Score** visible to users (94% match, NOT "pre-approved"). Personalized partner ranking. Negotiate tiered affiliate rates using conversion data. ARPU: $8-15.

**Stage 3 -- Partner API (25K-50K users, Year 2-3)**: Partner-facing API for product parameter submission, anonymized segment data, and CPA bidding. Segment marketplace: partners bid on segments, not individuals. Self-serve partner onboarding portal. Auction-based CPA. ARPU: $15-35.

**Stage 4 -- Full Marketplace (50K+ users, Year 3+)**: Partners upload eligibility models into secure sandbox. Real-time matching. Match Confidence displayed to users. Multi-product marketplace. CPA auction + platform access fees. ARPU: $35-80+.

**Competitive Moat Analysis** (5 compounding advantages):

1. Tax return data = rarest financial dataset (IRS-quality income verification)
2. Cross-product compound profiles (20+ data points per user)
3. Time-series data compounds (2+ years of credit trajectory, income growth)
4. Trust built at the mandatory moment (SSN = highest trust threshold)
5. Cost structure moat ($284/mo vs CK's 1,300 employees)

### 2. Strategic-from-Day-1 Upgrades (6 components)

#### 2a. Data Model Upgrade (Section 4B)

**Current state**: Basic tables (`recommendations`, `recommendation_outcomes`). No partner-side schema.

**Upgrade**: Add marketplace-ready tables from day 1. Stage 1 only fills basic fields; columns are nullable until their stage arrives. No schema migration needed when upgrading stages.

New tables to add:

```
partner_products:      id, partner_id, partner_name, product_type (hysa/ira/credit_card/loan/insurance),
                       product_name, affiliate_network, affiliate_link, commission_type (cpa/cps/rev_share),
                       commission_amount_cents, min_credit_score, max_credit_score, min_income_cents,
                       states_available[], product_details_json, status (active/paused/archived),
                       cpa_bid_cents (Stage 3+), eligibility_model_id (Stage 4+), created_at, updated_at

partner_eligibility:   id, partner_product_id, criteria_type (credit_score_range/income_range/state/age/filing_status),
                       criteria_value_json, created_at
                       -- Stage 1-2: populated by us from affiliate program docs
                       -- Stage 3+: populated by partners via API

fit_scores:            id, venture_identity_id, partner_product_id, score (0-100), score_version,
                       factors_json (which profile fields contributed), computed_at
                       -- Stage 1: score = 50 (flat, all products equal)
                       -- Stage 2: score = rules-based match
                       -- Stage 3+: score = ML model output

partner_bids:          id, partner_product_id, segment_id, bid_cents, bid_type (cpa/monthly_access),
                       status (active/paused), created_at, updated_at
                       -- Empty until Stage 3. Table exists from day 1.
```

#### 2b. Recommendation Engine Upgrade (Section 4E)

**Current state**: Static rules (`segment + milestone + timing + consent -> action`). No pluggable architecture.

**Upgrade**: Design a 3-layer scoring pipeline from day 1:

```
Layer 1: CANDIDATE GENERATION
  - Input: user's financial profile + consent status
  - Output: list of eligible partner_products (filtered by state, credit score range, income range)
  - Stage 1: SQL query on partner_products WHERE state IN user.state AND status = 'active'
  - Stage 3+: partner_eligibility criteria matching

Layer 2: SCORING
  - Input: (user_profile, partner_product) pairs
  - Output: fit_score (0-100) per pair
  - Stage 1: static score = 50 (all products equal, ordered by commission)
  - Stage 2: rules-based score (credit_score_match * 0.3 + income_match * 0.3 + state_relevance * 0.2 + historical_conversion * 0.2)
  - Stage 2+: Thompson Sampling bandit adjusts scores based on click/conversion feedback
  - Stage 3+: ML model (collaborative filtering on user-partner interaction data)
  - Interface: `score(user_profile, partner_product) -> FitScore` -- swappable backend, same API

Layer 3: RANKING + RENDERING
  - Input: scored partner_products
  - Output: ordered list with Fit Score labels for UI
  - Stage 1: order by commission_amount DESC (we show highest-paying first)
  - Stage 2+: order by fit_score DESC (personalized, user-first ordering)
  - Stage 3+: factor in partner CPA bids (bid_weight * 0.3 + fit_score * 0.7)
  - FTC constraint: NEVER use "pre-approved", "guaranteed", "you qualify". Permitted: "strong match", "94% fit", "personalized for you"
```

The key insight: the scorer interface (`score(profile, product) -> FitScore`) stays the same from Stage 1 to Stage 4. Only the implementation behind it changes. Frontend always receives scored, ranked products with fit labels. Zero frontend changes across stages.

#### 2c. Event Taxonomy Addition (Section 4C)

Add a new `MARKETPLACE EVENTS` block to the existing taxonomy:

```
MARKETPLACE EVENTS (all stages):
  partner_product_viewed       -- partner_product_id, placement, fit_score
  partner_product_clicked      -- partner_product_id, fit_score, position_in_list
  fit_score_computed           -- venture_identity_id, partner_product_id, score, score_version, factors_json
  match_confidence_displayed   -- partner_product_id, confidence_label (strong_match/good_match/match)
  recommendation_list_rendered -- list_length, scoring_method (static/rules/bandit/ml), placement

PARTNER-SIDE EVENTS (Stage 3+, empty until then):
  partner_product_submitted    -- partner_id, product_type, eligibility_criteria_count
  partner_criteria_updated     -- partner_product_id, fields_changed[]
  partner_bid_placed           -- partner_product_id, segment_id, bid_cents
  partner_bid_adjusted         -- partner_product_id, old_bid_cents, new_bid_cents
  partner_dashboard_viewed     -- partner_id, page (overview/funnel/segments)
```

#### 2d. Consent Architecture Upgrade (Sections 0I + 4H)

**Current state**: "Opt-in checkbox for cross-product data use." This covers email cross-sell but NOT marketplace-level product matching.

**Upgrade**: Reframe consent to cover the full marketplace evolution from day 1:

- **Consent tier 1 (cross-product)**: "Use my data across FileFree and LaunchFree products" (existing)
- **Consent tier 2 (personalized matching)**: "Use my financial profile to show me personalized product recommendations" -- this is the marketplace consent. Covers Stages 1-4. Users who consent see Fit Scores and matched products. Users who don't see generic product listings.
- **Consent tier 3 (anonymized insights, Stage 3+)**: "Include my anonymized data in aggregate insights shared with financial product partners" -- enables segment marketplace without PII sharing.

By getting tier 2 consent at signup, we NEVER need to re-consent users when upgrading from Stage 1 to Stage 4. The consent language already covers personalized matching via any method (rules, bandit, ML, partner models).

**Privacy policy language**: "We may use your financial profile (income bracket, credit score range, filing status, state) to match you with financial products from our partners. We never share your personal information with partners. Partners see only anonymized, aggregate data about user segments."

#### 2e. Partner Dashboard Upgrade (Section 4N)

**Current state**: Simple metrics page showing referral volume, conversion rate, revenue.

**Upgrade**: Design as the seed of the Stage 3 self-serve partner portal:

- **Stage 1-2 (internal only)**: Admin-only page at `paperworklabs.com/admin/partners`. Shows per-partner conversion funnel: impressions -> clicks -> signups -> funded accounts -> revenue. Anonymized user demographics per partner.
- **Stage 2 (partner-facing read-only)**: Give top partners read-only access to their conversion data. Login via partner invite link. This builds trust and makes us sticky -- partners who see data don't churn.
- **Stage 3 (self-serve portal)**: Partners can: (a) submit/update product details, (b) set eligibility criteria, (c) place CPA bids on segments, (d) view real-time conversion funnel, (e) download anonymized segment reports.
- **Stage 4 (full marketplace console)**: Partners can upload eligibility models, run segment simulations ("how many users match these criteria?"), A/B test different bid strategies, and access a partner API for programmatic management.

Design the database schema and API routes for Stage 3 from day 1. Stage 1-2 just doesn't expose the partner-facing endpoints.

#### 2f. PARTNERSHIPS.md Strategic Overhaul

**Current state**: Tactical playbook (apply to affiliates, outreach templates). 4 partnership phases that don't align with marketplace stages.

**Upgrade**: Full rewrite to align with the 4-stage marketplace evolution:

- **Partner Tiering Framework** aligned with marketplace stages:
  - Tier A (Stage 1): Self-serve affiliates -- apply online, no relationship needed (Betterment, SoFi, etc.)
  - Tier B (Stage 2): Managed affiliates -- tiered CPA, dedicated account rep from partner, co-marketing (negotiated upgrades from Tier A)
  - Tier C (Stage 3): API partners -- submit products via API, bid on segments, get conversion data (new partnerships category)
  - Tier D (Stage 4): Marketplace participants -- upload eligibility models, real-time bidding, platform access fee
- **Strategic Partner Scoring Matrix** (evaluate every potential partner):

  | Factor                 | Weight | Description                                                                     |
  | ---------------------- | ------ | ------------------------------------------------------------------------------- |
  | Revenue per conversion | 30%    | CPA/CPS amount                                                                  |
  | Data reciprocity       | 25%    | Does the partner give us data back? (approval rates, funded amounts, retention) |
  | User trust alignment   | 20%    | Does this product genuinely help our users?                                     |
  | Integration complexity | 15%    | API vs affiliate link vs custom build                                           |
  | Exclusivity value      | 10%    | Would exclusivity give us competitive advantage?                                |

  "Data reciprocity" is the strategic differentiator. Partners who share approval rates and funded amounts back to us make our ML models better, which makes recommendations better, which increases conversion, which makes us more valuable to partners. This is the flywheel.
- **New outreach templates** for Stage 2-4:
  - Template F: Tiered CPA upgrade pitch ("Your conversion rate through FileFree is 3x your network average...")
  - Template G: Partner API introduction ("We're opening our partner API to select financial product providers...")
  - Template H: Marketplace invitation ("Join our financial marketplace platform -- reach 50K+ pre-qualified users...")
- **Exclusivity strategy**: Never grant category exclusivity (e.g., "only HYSA partner"). Competition between partners drives CPA bids up. DO offer "featured partner" placement for a premium -- higher bid = top position, but competitors still visible.
- **Data reciprocity agreements**: When upgrading from Tier A to Tier B/C, negotiate for partners to share:
  - Approval rates per segment (helps us compute real approval odds, not just "fit scores")
  - Average funded amounts (helps us estimate LTV per recommendation)
  - 30/60/90-day retention (helps us recommend products users actually keep)
  This data feeds back into the scoring model, making recommendations better for ALL partners.

### 3. Updated Valuation Scenarios (Section 0D)

**Replace** existing valuation scenarios with marketplace-stage analysis:


| Scenario                 | Users | ARPU | Revenue    | Multiple | Valuation | Stage          | What Unlocks It                            |
| ------------------------ | ----- | ---- | ---------- | -------- | --------- | -------------- | ------------------------------------------ |
| A: Seed (Year 1)         | 5K    | $5   | $25K-65K   | 3-5x     | $75K-325K | Stage 1        | First tax season + LaunchFree launch       |
| B: Traction (Year 2)     | 25K   | $12  | $300K-500K | 5-8x     | $1.5M-4M  | Stage 2        | Smart matching + compliance SaaS recurring |
| C: Growth (Year 3)       | 50K   | $25  | $1.25M-2M  | 6-10x    | $7.5M-20M | Stage 3        | Partner API live, auction CPA              |
| D: Scale (Year 4-5)      | 200K  | $40  | $8M+       | 8-12x    | $64M-96M  | Stage 4        | Full marketplace, multi-product            |
| E: CK Playbook (Year 5+) | 500K+ | $50+ | $25M+      | 10-15x   | $250M+    | Stage 4 mature | Network effects, data licensing            |


CK benchmark: $8.1B / 140M users = $57.86/user. FileFree at 50K users with 3-5x deeper per-user data = $150-400/user justified.

### 4. KNOWLEDGE.md Decisions

- **D65 -- Financial Marketplace Platform: 4-Stage Evolution (2026-03-14)**: Formalize path from affiliate commissions to full partner marketplace with auction-based CPA. Gated by user volume. Valuation inflects at Stage 3.
- **D66 -- Strategic-from-Day-1 Architecture (2026-03-14)**: Design 6 foundational components for Stage 4 from day 1 (data model, recommendation engine, event taxonomy, consent architecture, partner dashboard, partnership strategy). Implementation is incremental by stage; architecture is designed for the end state. Avoids costly schema migrations, API breaking changes, and re-consent flows under load.

### 5. FINANCIALS.md Update

Update Year 2 and add Year 3-5 revenue projections reflecting ARPU growth.

## Files Modified

- [docs/VENTURE_MASTER_PLAN.md](docs/VENTURE_MASTER_PLAN.md) -- New Section 4O, upgraded Sections 4B/4C/4E/4H/4N, updated Section 0D, updated consent in 0I
- [docs/PARTNERSHIPS.md](docs/PARTNERSHIPS.md) -- Strategic overhaul: marketplace-aligned tiering, scoring matrix, new templates, data reciprocity strategy
- [docs/KNOWLEDGE.md](docs/KNOWLEDGE.md) -- D65, D66
- [docs/FINANCIALS.md](docs/FINANCIALS.md) -- Extended revenue projections

## Key Design Principle

The marketplace platform does NOT get a branded name. Internally: "Financial Marketplace Platform." User-facing: "personalized recommendations" / "products matched to your profile." The technology is invisible. The brand is FileFree.